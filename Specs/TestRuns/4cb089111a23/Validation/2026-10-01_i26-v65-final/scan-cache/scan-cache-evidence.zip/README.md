# Scan-cache V45 descriptive packet

Three sequential fresh x64 Debug processes per version ran FileOps_IntegratedPresentationPerf; each receipt records 1 passed, 0 failed, 0 skipped, clean sandbox. See run-receipts.tsv and each copied receipt. Descriptive only; no performance acceptance, threshold, or waiver.

## UI-thread CPU deltas

ui-cpu-deltas.csv records cumulative UI-thread CPU value0 deltas between scan-kind-before and scan-kind-after, in microseconds. ui-cpu-medians.csv uses the middle of three sorted values, index floor(3/2)=1. Debug observations are descriptive.

| Version | Kind | Three deltas (us) | Median (us) |
|---|---|---:|---:|
| v42d | compare | 140625, 140625, 156250 | 140625 |
| v42d | change-case | 109375, 140625, 203125 | 140625 |
| v42d | change-attributes | 171875, 203125, 234375 | 203125 |
| v42d | file-list | 187500, 203125, 218750 | 203125 |
| v43 | compare | 187500, 203125, 250000 | 203125 |
| v43 | change-case | 203125, 218750, 265625 | 218750 |
| v43 | change-attributes | 218750, 218750, 234375 | 218750 |
| v43 | file-list | 234375, 265625, 265625 | 265625 |
| v45 | compare | 109375, 125000, 203125 | 125000 |
| v45 | change-case | 140625, 171875, 171875 | 171875 |
| v45 | change-attributes | 156250, 187500, 203125 | 187500 |
| v45 | file-list | 156250, 171875, 171875 | 171875 |

## Limits and cache review

Each batch performs eight synchronous redraws; wall timings can include presentation/message/compositor pacing. Debug timings are not isolated renderer cost or Release FPS. CPU, memory, handles, and cache values are noisy with OS scheduling, cache state, background work, and process conditions; three runs are descriptive only.

Comparison copies include HostCacheEntries, SingleTargetLogicalBytes, HostRenderResize, and phase rows; adjacent source hash manifests record original files, sizes and hashes. Selected JSONL lines preserve source bytes and map to 1-based line, raw hash and size.

V42d/V45 physical fixture hashes differ only in CR line endings; comparator records same CR-stripped hash/text. V43/V45 physical fixture hash matches. Source freeze inputs, inventory, expected-head copies are under source-freezes. Full raw logs remain at original paths in raw-file-manifest.json.

| Version | Three passing run IDs |
|---|---|
| v42d | 20260930T192903Z-11768-5afec6aed9574da09c9aef989939b796; 20260930T193001Z-11768-4442ccb5f45d4a83855ce2918b798273; 20260930T193102Z-11768-efc0a68f515d4cac96b6ac43eabcaeeb |
| v43 | 20260930T193704Z-101380-196d6123d9d44093bff30ec6578a7a7c; 20260930T193806Z-101380-0e239b75fe0940549097dbc23f1fed6b; 20260930T193907Z-101380-963cadd3521d4d8d9e63ccf6513a93bb |
| v45 | 20260930T195854Z-83476-79c9cc95710644c4ac01d48f109dd5d5; 20260930T195954Z-83476-a94e958194f542119e16a8c9777339cd; 20260930T200049Z-83476-2486a083cf3d4ce28dc59692d987d512 |

Exact selected JSONL byte ranges are also packed in selected-metrics.zip; raw-file-manifest.json records original file SHA/size, selected SHA/size and each 1-based line number. comparison-files.zip is a compressed copy of selected comparison outputs; the comparison directory still has readable copies, and source-hashes files identify original source reports.

## Comparison and cache reports

- [V42d to V45 resource phases](comparison/scan-perf-v42d-v45-comparison-scan-resource-phase-rows.csv), [deltas](comparison/scan-perf-v42d-v45-comparison-scan-resource-deltas.csv), [cross-side medians](comparison/scan-perf-v42d-v45-comparison-scan-resource-cross-side-medians.csv), and [provenance](comparison/scan-perf-v42d-v45-comparison-comparison-provenance.json).
- [V43 to V45 resource phases](comparison/scan-perf-v43-v45-comparison-scan-resource-phase-rows.csv), [deltas](comparison/scan-perf-v43-v45-comparison-scan-resource-deltas.csv), [cross-side medians](comparison/scan-perf-v43-v45-comparison-scan-resource-cross-side-medians.csv), and [provenance](comparison/scan-perf-v43-v45-comparison-comparison-provenance.json).
- Complete compressed copies are in [comparison-files.zip](comparison/comparison-files.zip); source report hashes and sizes are in the matching `source-hashes.json` files.
