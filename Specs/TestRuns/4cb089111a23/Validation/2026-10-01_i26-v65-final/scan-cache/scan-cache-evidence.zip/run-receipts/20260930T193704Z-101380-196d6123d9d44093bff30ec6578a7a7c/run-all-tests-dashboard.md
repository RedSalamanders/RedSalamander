# Run-AllTests Case Dashboard

- Run: `20260930T193704Z-101380-196d6123d9d44093bff30ec6578a7a7c`
- Suite: `FileOps`

## Top Slowest Cases

| Harness | Case | Source | Status | Classification | Duration ms | Seed | Attempt |
|---|---|---|---|---|---:|---|---:|
| FileOperations | FileOps_IntegratedPresentationPerf | case | passed | PASSED | 7828 |  | 1 |

## Failure And Retry Evidence

| Harness | Case | Source | Status | Classification | Seed | Reason |
|---|---|---|---|---|---|---|
| (none) |  |  |  |  |  |  |
