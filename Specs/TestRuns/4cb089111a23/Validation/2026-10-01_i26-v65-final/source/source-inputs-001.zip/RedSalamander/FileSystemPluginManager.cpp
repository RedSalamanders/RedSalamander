#include "Framework.h"

#include "FileSystemPluginManager.h"

#include <algorithm>
#include <cassert>
#include <cstring>
#include <cwchar>
#include <cwctype>
#include <format>
#include <limits>
#include <optional>
#include <unordered_set>

#include "Helpers.h"
#include "HostServices.h"
#include "LocalizationManager.h"
#include "PlugInterfaces/Factory.h"
#include "SessionState.h"

#pragma warning(push)
// WIL: C4625 (copy ctor deleted), C4626 (copy assign deleted), C5026 (move ctor deleted), C5027 (move assign deleted)
#pragma warning(disable : 4625 4626 5026 5027)
#include <wil/win32_helpers.h>
#pragma warning(pop)

namespace
{
using CreateFactoryFunc                            = HRESULT(__stdcall*)(REFIID, const FactoryOptions*, IHost*, const wchar_t*, void**);
using EnumeratePluginsFunc                         = HRESULT(__stdcall*)(REFIID, const PluginMetaData**, unsigned int*);
using GetConfigurationSchemaExportFunc             = HRESULT(__stdcall*)(REFIID, const wchar_t*, const char**);
using BrowseConnectionTargetsExportFunc =
    HRESULT(__stdcall*)(REFIID, const wchar_t*, const FactoryConnectionBrowseRequest*, FactoryConnectionBrowseResult*) noexcept;

bool IsDllPath(const std::filesystem::path& path) noexcept
{
    if (path.empty())
    {
        return false;
    }

    std::error_code ec;
    if (! std::filesystem::is_regular_file(path, ec))
    {
        return false;
    }

    const std::wstring ext = path.extension().wstring();
    return _wcsicmp(ext.c_str(), L".dll") == 0;
}

std::wstring SafeCoalesce(const wchar_t* value) noexcept
{
    return value ? std::wstring(value) : std::wstring();
}

std::string SafeCoalesce(const char* value) noexcept
{
    return value ? std::string(value) : std::string();
}

HRESULT ValidateConnectionBrowseRoot(const Common::Settings::JsonValue& root) noexcept
{
    const std::optional<uint32_t> version = Common::Settings::GetUInt32(root, "version");
    return version.has_value() && version.value() == 1u ? S_OK : HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
}

HRESULT ParseConnectionBrowseDevicesJson(std::string_view jsonUtf8, std::vector<FileSystemPluginManager::ConnectionBrowseDevice>& outDevices) noexcept
{
    outDevices.clear();

    Common::Settings::JsonValue root;
    const HRESULT parseHr = Common::Settings::ParseJsonValue(jsonUtf8, root);
    if (FAILED(parseHr))
    {
        return parseHr;
    }
    const HRESULT validateHr = ValidateConnectionBrowseRoot(root);
    if (FAILED(validateHr))
    {
        return validateHr;
    }

    const Common::Settings::JsonArray* devices = Common::Settings::GetArray(root, "devices");
    if (! devices)
    {
        return HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
    }

    outDevices.reserve(devices->items.size());
    for (const Common::Settings::JsonValue& item : devices->items)
    {
        auto pnpId = Common::Settings::GetWString(item, "pnpId");
        if (! pnpId.has_value() || pnpId->empty())
        {
            return HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
        }

        outDevices.push_back(FileSystemPluginManager::ConnectionBrowseDevice{
            .pnpId        = std::move(pnpId.value()),
            .friendlyName = Common::Settings::GetWString(item, "friendlyName").value_or(std::wstring{}),
            .devicePuid   = Common::Settings::GetWString(item, "devicePuid").value_or(std::wstring{}),
        });
    }

    return S_OK;
}

HRESULT ParseConnectionBrowseStoragesJson(std::string_view jsonUtf8, std::vector<FileSystemPluginManager::ConnectionBrowseStorage>& outStorages) noexcept
{
    outStorages.clear();

    Common::Settings::JsonValue root;
    const HRESULT parseHr = Common::Settings::ParseJsonValue(jsonUtf8, root);
    if (FAILED(parseHr))
    {
        return parseHr;
    }
    const HRESULT validateHr = ValidateConnectionBrowseRoot(root);
    if (FAILED(validateHr))
    {
        return validateHr;
    }

    const Common::Settings::JsonArray* storages = Common::Settings::GetArray(root, "storages");
    if (! storages)
    {
        return HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
    }

    outStorages.reserve(storages->items.size());
    for (const Common::Settings::JsonValue& item : storages->items)
    {
        auto name        = Common::Settings::GetWString(item, "name");
        auto initialPath = Common::Settings::GetWString(item, "initialPath");
        if (! name.has_value() || name->empty() || ! initialPath.has_value() || initialPath->empty())
        {
            return HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
        }

        outStorages.push_back(FileSystemPluginManager::ConnectionBrowseStorage{
            .name         = std::move(name.value()),
            .persistentId = Common::Settings::GetWString(item, "persistentId").value_or(std::wstring{}),
            .objectId     = Common::Settings::GetWString(item, "objectId").value_or(std::wstring{}),
            .initialPath  = std::move(initialPath.value()),
        });
    }

    return S_OK;
}

HRESULT RegisterPluginResourceOwner(const std::filesystem::path& path, HINSTANCE module) noexcept
{
    const std::wstring ownerName = path.stem().wstring();
    if (ownerName.empty())
    {
        return E_INVALIDARG;
    }

    return Localization::RegisterResourceOwner(ownerName, module);
}

bool IsValidShortId(std::wstring_view shortId) noexcept
{
    if (shortId.empty())
    {
        return false;
    }

    for (wchar_t ch : shortId)
    {
        if (std::iswalnum(static_cast<wint_t>(ch)) == 0)
        {
            return false;
        }
    }

    return true;
}

std::wstring ToLowerInvariant(std::wstring_view text)
{
    std::wstring lowered(text);
    std::transform(lowered.begin(), lowered.end(), lowered.begin(), [](wchar_t ch) { return static_cast<wchar_t>(std::towlower(static_cast<wint_t>(ch))); });
    return lowered;
}

bool EqualsNoCase(std::wstring_view a, std::wstring_view b) noexcept
{
    if (a.size() != b.size())
    {
        return false;
    }

    if (a.size() > static_cast<size_t>(std::numeric_limits<int>::max()))
    {
        return false;
    }

    return OrdinalString::EqualsNoCase(a, b);
}

void RemoveStringFromVector(std::vector<std::wstring>& values, std::wstring_view needle)
{
    values.erase(std::remove_if(values.begin(), values.end(), [&](const std::wstring& v) { return EqualsNoCase(v, needle); }), values.end());
}

void RemovePathFromVector(std::vector<std::filesystem::path>& values, const std::filesystem::path& needle)
{
    values.erase(std::remove_if(values.begin(), values.end(), [&](const std::filesystem::path& v) { return v == needle; }), values.end());
}

void PopulateEntryIdentityFromMetaData(FileSystemPluginManager::PluginEntry& entry, const PluginMetaData& metaData)
{
    entry.id      = SafeCoalesce(metaData.id);
    entry.shortId = SafeCoalesce(metaData.shortId);
}

void PopulateEntryPresentationFromMetaData(FileSystemPluginManager::PluginEntry& entry, const PluginMetaData& metaData)
{
    entry.name        = SafeCoalesce(metaData.name);
    entry.description = SafeCoalesce(metaData.description);
    entry.author      = SafeCoalesce(metaData.author);
    entry.version     = SafeCoalesce(metaData.version);
}

[[nodiscard]] std::wstring_view RequestedPluginId(const FileSystemPluginManager::PluginEntry& entry) noexcept
{
    if (! entry.factoryPluginId.empty())
    {
        return entry.factoryPluginId;
    }

    return entry.id;
}

struct EnumeratedPluginSet
{
    HRESULT hr = S_OK;
    std::wstring loadError;
    std::vector<FileSystemPluginManager::PluginEntry> entries;
};

[[nodiscard]] EnumeratedPluginSet EnumerateFileSystemPlugins(const std::filesystem::path& path, FileSystemPluginManager::PluginOrigin origin) noexcept
{
    EnumeratedPluginSet result;

    wil::unique_hmodule module(LoadLibraryExW(path.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH));
    if (! module)
    {
        const DWORD lastError = GetLastError();
        result.hr             = HRESULT_FROM_WIN32(lastError);
        result.loadError      = std::format(L"LoadLibraryExW failed (0x{:08X}).", lastError);
        return result;
    }

#pragma warning(push)
#pragma warning(disable : 4191) // unsafe conversion from FARPROC
    const auto enumerate = reinterpret_cast<EnumeratePluginsFunc>(GetProcAddress(module.get(), "RedSalamanderEnumeratePlugins"));
#pragma warning(pop)
    if (! enumerate)
    {
        DWORD lastError = GetLastError();
        if (lastError == ERROR_SUCCESS)
        {
            lastError = ERROR_PROC_NOT_FOUND;
        }

        result.hr        = HRESULT_FROM_WIN32(lastError);
        result.loadError = L"Missing export RedSalamanderEnumeratePlugins.";
        return result;
    }

    const PluginMetaData* metaData = nullptr;
    unsigned int count             = 0;
    const HRESULT enumHr           = enumerate(__uuidof(IFileSystem), &metaData, &count);
    if (FAILED(enumHr))
    {
        result.hr = enumHr;
        if (enumHr != E_NOINTERFACE)
        {
            result.loadError = std::format(L"RedSalamanderEnumeratePlugins failed (hr=0x{:08X}).", static_cast<unsigned long>(enumHr));
        }
        return result;
    }

    if (! IsValidEnumeratedPluginRange(metaData, count))
    {
        result.hr        = HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
        result.loadError = std::format(L"RedSalamanderEnumeratePlugins returned an invalid metadata range (pointer={}, count={}).",
                                       metaData != nullptr,
                                       count);
        return result;
    }

    result.entries.reserve(count);
    for (unsigned int i = 0; i < count; ++i)
    {
        FileSystemPluginManager::PluginEntry entry;
        entry.origin          = origin;
        entry.path            = path;
        entry.factoryPluginId = SafeCoalesce(metaData[i].id);
        PopulateEntryIdentityFromMetaData(entry, metaData[i]);
        result.entries.push_back(std::move(entry));
    }

    return result;
}
} // namespace

FileSystemPluginManager& FileSystemPluginManager::GetInstance() noexcept
{
    static FileSystemPluginManager instance;
    return instance;
}

HRESULT FileSystemPluginManager::ConnectionBrowseWork::Execute(std::vector<ConnectionBrowseDevice>& outDevices,
                                                               std::vector<ConnectionBrowseStorage>& outStorages) noexcept
{
    outDevices.clear();
    outStorages.clear();
    if (! module || browseConnectionTargets == nullptr || pluginPath.empty())
    {
        return E_UNEXPECTED;
    }

#pragma warning(push)
#pragma warning(disable : 4191) // unsafe conversion from FARPROC
    const auto browse = reinterpret_cast<BrowseConnectionTargetsExportFunc>(browseConnectionTargets);
#pragma warning(pop)

    FactoryConnectionBrowseRequest request{};
    request.sizeBytes      = sizeof(request);
    request.kind           = kind == Kind::Devices ? FACTORY_CONNECTION_BROWSE_DEVICES : FACTORY_CONNECTION_BROWSE_STORAGES;
    request.parentDeviceId = parentDeviceId.empty() ? nullptr : parentDeviceId.c_str();

    FactoryConnectionBrowseResult result{};
    result.sizeBytes = sizeof(result);

    const HRESULT browseHr = browse(__uuidof(IFileSystem), pluginId.empty() ? nullptr : pluginId.c_str(), &request, &result);
    wil::unique_cotaskmem_ptr<char> json(result.jsonUtf8);
    if (FAILED(browseHr))
    {
        return browseHr;
    }
    if (! json || std::strlen(json.get()) == 0u)
    {
        return HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
    }

    return kind == Kind::Devices ? ParseConnectionBrowseDevicesJson(json.get(), outDevices)
                                 : ParseConnectionBrowseStoragesJson(json.get(), outStorages);
}

void FileSystemPluginManager::AssertUiThread() const noexcept
{
#ifdef _DEBUG
    assert(_uiThreadId == 0u || _uiThreadId == GetCurrentThreadId());
#endif
}

HRESULT FileSystemPluginManager::Initialize(Common::Settings::Settings& settings) noexcept
{
    if (_uiThreadId == 0u)
    {
        _uiThreadId = GetCurrentThreadId();
    }
    AssertUiThread();
    if (_initialized)
    {
        return S_OK;
    }

    _exeDir = GetExecutableDirectory();
    if (_exeDir.empty())
    {
        Debug::ErrorWithLastError(L"Failed to get executable directory.");
        return E_FAIL;
    }

    const HRESULT hr = Refresh(settings);
    if (FAILED(hr))
    {
        Debug::Error(L"Failed to discover file system plugins (hr=0x{:08X}).", static_cast<unsigned long>(hr));
        return hr;
    }

    _initialized = true;
    return S_OK;
}

void FileSystemPluginManager::Shutdown(Common::Settings::Settings& settings) noexcept
{
    AssertUiThread();
    if (! _initialized)
    {
        return;
    }

    for (const PluginEntry& entry : _plugins)
    {
        PersistConfigurationToSettings(entry, settings);
    }

    UnloadAll(ModuleUnloadMode::ProcessShutdown);
    SweepDeferredUnloadEntries(ModuleUnloadMode::ProcessShutdown);

    _plugins.clear();
    _deferredUnloadEntries.clear();
    _activePluginId.clear();
    _initialized = false;
}

const std::vector<FileSystemPluginManager::PluginEntry>& FileSystemPluginManager::GetPlugins() const noexcept
{
    AssertUiThread();
    return _plugins;
}

std::wstring_view FileSystemPluginManager::GetActivePluginId() const noexcept
{
    AssertUiThread();
    return _activePluginId;
}

wil::com_ptr<IFileSystem> FileSystemPluginManager::GetActiveFileSystem() const noexcept
{
    AssertUiThread();
    const PluginEntry* entry = FindPluginById(_activePluginId);
    if (! entry)
    {
        return {};
    }

    return entry->fileSystem;
}

std::optional<std::filesystem::path> FileSystemPluginManager::TryGetPluginPath(std::wstring_view pluginId) const noexcept
{
    AssertUiThread();
    const PluginEntry* entry = FindPluginById(pluginId);
    if (! entry)
    {
        return std::nullopt;
    }

    if (entry->path.empty())
    {
        return std::nullopt;
    }

    return entry->path;
}

std::optional<std::filesystem::path> FileSystemPluginManager::TryGetActivePluginPath() const noexcept
{
    AssertUiThread();
    if (_activePluginId.empty())
    {
        return std::nullopt;
    }

    return TryGetPluginPath(_activePluginId);
}

HRESULT FileSystemPluginManager::Refresh(Common::Settings::Settings& settings) noexcept
{
    AssertUiThread();
    const HRESULT hr = Discover(settings);
    if (FAILED(hr))
    {
        return hr;
    }

    std::wstring_view wantedId = settings.plugins.currentFileSystemPluginId;

    const PluginEntry* wanted = FindPluginById(wantedId);
    if (! wanted || wanted->disabled || ! wanted->loadable)
    {
        wantedId = {};
    }

    if (wantedId.empty())
    {
        for (const PluginEntry& entry : _plugins)
        {
            if (entry.loadable && ! entry.disabled && ! entry.id.empty())
            {
                wantedId = entry.id;
                break;
            }
        }
    }

    if (! wantedId.empty())
    {
        return SetActivePlugin(wantedId, settings);
    }

    _activePluginId.clear();
    return S_OK;
}

HRESULT FileSystemPluginManager::SetActivePlugin(std::wstring_view pluginId, Common::Settings::Settings& settings) noexcept
{
    AssertUiThread();
    PluginEntry* entry = FindMutablePluginById(pluginId);
    if (! entry)
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }

    if (entry->disabled)
    {
        entry->disabled = false;
        RemoveStringFromVector(settings.plugins.disabledPluginIds, entry->id);
    }

    const HRESULT hr = EnsureLoaded(*entry, settings);
    if (FAILED(hr))
    {
        return hr;
    }

    _activePluginId                            = entry->id;
    settings.plugins.currentFileSystemPluginId = entry->id;
    SessionState::UpdateActiveFileSystemPluginIdsAndOperation({entry->id}, SessionState::OperationKind::Browse);
    return S_OK;
}

HRESULT FileSystemPluginManager::DisablePlugin(std::wstring_view pluginId, Common::Settings::Settings& settings) noexcept
{
    AssertUiThread();
    PluginEntry* entry = FindMutablePluginById(pluginId);
    if (! entry)
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }

    if (entry->id.empty())
    {
        return E_INVALIDARG;
    }

    if (entry->id == _activePluginId)
    {
        std::wstring_view fallback;
        for (const PluginEntry& candidate : _plugins)
        {
            if (candidate.id.empty() || candidate.id == entry->id)
            {
                continue;
            }
            if (candidate.loadable && ! candidate.disabled)
            {
                fallback = candidate.id;
                break;
            }
        }

        if (fallback.empty())
        {
            return HRESULT_FROM_WIN32(ERROR_ACCESS_DENIED);
        }

        const HRESULT switchHr = SetActivePlugin(fallback, settings);
        if (FAILED(switchHr))
        {
            return switchHr;
        }
    }

    if (! entry->disabled)
    {
        entry->disabled = true;
        settings.plugins.disabledPluginIds.push_back(entry->id);
    }

    return S_OK;
}

HRESULT FileSystemPluginManager::EnablePlugin(std::wstring_view pluginId, Common::Settings::Settings& settings) noexcept
{
    AssertUiThread();
    PluginEntry* entry = FindMutablePluginById(pluginId);
    if (! entry)
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }

    if (entry->id.empty())
    {
        return E_INVALIDARG;
    }

    if (entry->disabled)
    {
        entry->disabled = false;
        RemoveStringFromVector(settings.plugins.disabledPluginIds, entry->id);
    }

    return EnsureLoaded(*entry, settings);
}

HRESULT FileSystemPluginManager::RemoveCustomPlugin(std::wstring_view pluginId, Common::Settings::Settings& settings) noexcept
{
    AssertUiThread();
    PluginEntry* entry = FindMutablePluginById(pluginId);
    if (! entry)
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }

    if (entry->origin != PluginOrigin::Custom)
    {
        return E_INVALIDARG;
    }

    const std::filesystem::path path = entry->path;

    if (entry->id == _activePluginId)
    {
        std::wstring_view fallback;
        for (const PluginEntry& candidate : _plugins)
        {
            if (candidate.origin == PluginOrigin::Custom && candidate.path == path)
            {
                continue;
            }
            if (candidate.id.empty())
            {
                continue;
            }
            if (candidate.loadable && ! candidate.disabled)
            {
                fallback = candidate.id;
                break;
            }
        }

        if (! fallback.empty())
        {
            const HRESULT switchHr = SetActivePlugin(fallback, settings);
            if (FAILED(switchHr))
            {
                return switchHr;
            }
        }
        else
        {
            _activePluginId.clear();
        }
    }

    RemovePathFromVector(settings.plugins.customPluginPaths, path);
    return Refresh(settings);
}

HRESULT FileSystemPluginManager::AddCustomPluginPath(const std::filesystem::path& path, Common::Settings::Settings& settings) noexcept
{
    AssertUiThread();
    if (path.empty())
    {
        return E_INVALIDARG;
    }

    const auto exists =
        std::find(settings.plugins.customPluginPaths.begin(), settings.plugins.customPluginPaths.end(), path) != settings.plugins.customPluginPaths.end();
    if (exists)
    {
        return Refresh(settings);
    }

    if (! IsDllPath(path))
    {
        return E_INVALIDARG;
    }

    if (IsPluginPathDeferred(path))
    {
        SweepDeferredUnloadEntries(ModuleUnloadMode::FreeLibrary);
        if (IsPluginPathDeferred(path))
        {
            return HRESULT_FROM_WIN32(ERROR_BUSY);
        }
    }

    const HRESULT refreshHr = Refresh(settings);
    if (FAILED(refreshHr))
    {
        return refreshHr;
    }

    if (IsPluginPathDeferred(path))
    {
        return HRESULT_FROM_WIN32(ERROR_BUSY);
    }

    EnumeratedPluginSet enumeration = EnumerateFileSystemPlugins(path, PluginOrigin::Custom);
    if (FAILED(enumeration.hr))
    {
        return enumeration.hr;
    }

    std::unordered_set<std::wstring> seenProbeIds;
    std::unordered_set<std::wstring> seenProbeShortIds;
    Common::Settings::Settings scratch = settings;

    for (PluginEntry& probe : enumeration.entries)
    {
        if (probe.id.empty() || ! IsValidShortId(probe.shortId))
        {
            return E_INVALIDARG;
        }

        const std::wstring idKey    = ToLowerInvariant(probe.id);
        const std::wstring shortKey = ToLowerInvariant(probe.shortId);
        if (! seenProbeIds.insert(idKey).second || ! seenProbeShortIds.insert(shortKey).second)
        {
            return E_INVALIDARG;
        }

        if (FindPluginById(probe.id))
        {
            return HRESULT_FROM_WIN32(ERROR_ALREADY_EXISTS);
        }

        const bool duplicateShortId =
            std::any_of(_plugins.begin(), _plugins.end(), [&](const PluginEntry& entry) { return EqualsNoCase(entry.shortId, probe.shortId); });
        if (duplicateShortId)
        {
            return HRESULT_FROM_WIN32(ERROR_ALREADY_EXISTS);
        }

        const HRESULT probeHr = EnsureLoaded(probe, scratch);
        if (FAILED(probeHr))
        {
            return probeHr;
        }
    }

    settings.plugins.customPluginPaths.push_back(path);
    return Refresh(settings);
}

HRESULT
FileSystemPluginManager::GetConfigurationSchema(std::wstring_view pluginId, Common::Settings::Settings& settings, std::string& outSchemaJsonUtf8) noexcept
{
    AssertUiThread();
    PluginEntry* entry = FindMutablePluginById(pluginId);
    if (! entry)
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }

    static_cast<void>(settings);

    if (entry->unloadDeferred || IsPluginPathDeferred(entry->path))
    {
        return HRESULT_FROM_WIN32(ERROR_BUSY);
    }

    wil::unique_hmodule transientModule;
    HMODULE moduleHandle = entry->module.get();
    if (! moduleHandle)
    {
        transientModule.reset(LoadLibraryExW(entry->path.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH));
        if (! transientModule)
        {
            return HRESULT_FROM_WIN32(GetLastError());
        }

        moduleHandle = transientModule.get();
    }

#pragma warning(push)
#pragma warning(disable : 4191) // unsafe conversion from FARPROC
    const auto getConfigurationSchema = reinterpret_cast<GetConfigurationSchemaExportFunc>(GetProcAddress(moduleHandle, "RedSalamanderGetConfigurationSchema"));
#pragma warning(pop)
    if (! getConfigurationSchema)
    {
        DWORD lastError = GetLastError();
        if (lastError == ERROR_SUCCESS)
        {
            lastError = ERROR_PROC_NOT_FOUND;
        }

        return HRESULT_FROM_WIN32(lastError);
    }

    const std::wstring requestedPluginId(RequestedPluginId(*entry));
    const wchar_t* requestedPluginIdPtr = requestedPluginId.empty() ? nullptr : requestedPluginId.c_str();
    const char* schema                  = nullptr;
    const HRESULT schemaHr              = getConfigurationSchema(__uuidof(IFileSystem), requestedPluginIdPtr, &schema);
    if (FAILED(schemaHr))
    {
        return schemaHr;
    }

    outSchemaJsonUtf8 = SafeCoalesce(schema);
    return S_OK;
}

HRESULT
FileSystemPluginManager::GetConfiguration(std::wstring_view pluginId, Common::Settings::Settings& settings, std::string& outConfigurationJsonUtf8) noexcept
{
    AssertUiThread();
    PluginEntry* entry = FindMutablePluginById(pluginId);
    if (! entry)
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }

    const HRESULT hr = EnsureLoaded(*entry, settings);
    if (FAILED(hr))
    {
        return hr;
    }

    if (! entry->informations)
    {
        return E_NOINTERFACE;
    }

    const char* config  = nullptr;
    const HRESULT cfgHr = entry->informations->GetConfiguration(&config);
    if (FAILED(cfgHr))
    {
        return cfgHr;
    }

    outConfigurationJsonUtf8 = SafeCoalesce(config);
    return S_OK;
}

HRESULT
FileSystemPluginManager::ValidateConfiguration(std::wstring_view pluginId, std::string_view configurationJsonUtf8) noexcept
{
    AssertUiThread();
    PluginEntry* entry = FindMutablePluginById(pluginId);
    if (! entry)
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }
    if (entry->unloadDeferred || IsPluginPathDeferred(entry->path))
    {
        return HRESULT_FROM_WIN32(ERROR_BUSY);
    }

    // Validate on a throwaway instance: entry->informations belongs to mounted providers, and
    // SetConfiguration is allowed to clear their caches.
    wil::unique_hmodule transientModule;
    HMODULE moduleHandle = entry->module.get();
    if (! moduleHandle)
    {
        transientModule.reset(LoadLibraryExW(entry->path.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH));
        if (! transientModule)
        {
            return HRESULT_FROM_WIN32(GetLastError());
        }
        moduleHandle = transientModule.get();
    }

#pragma warning(push)
#pragma warning(disable : 4191) // unsafe conversion from FARPROC
    const auto createFactory = reinterpret_cast<CreateFactoryFunc>(GetProcAddress(moduleHandle, "RedSalamanderCreate"));
#pragma warning(pop)
    if (! createFactory)
    {
        return HRESULT_FROM_WIN32(ERROR_PROC_NOT_FOUND);
    }

    FactoryOptions options{};
    options.debugLevel = DEBUG_LEVEL_NONE;

    wil::com_ptr<IFileSystem> fileSystem;
    const HRESULT createHr =
        createFactory(__uuidof(IFileSystem), &options, GetHostServices(), entry->factoryPluginId.c_str(), fileSystem.put_void());
    if (FAILED(createHr))
    {
        return createHr;
    }

    wil::com_ptr<IInformations> infos;
    const HRESULT qiHr = fileSystem->QueryInterface(__uuidof(IInformations), infos.put_void());
    if (FAILED(qiHr) || ! infos)
    {
        return qiHr;
    }

    const std::string configText(configurationJsonUtf8);
    return infos->SetConfiguration(configText.empty() ? nullptr : configText.c_str());
}

HRESULT
FileSystemPluginManager::SetConfiguration(std::wstring_view pluginId, std::string_view configurationJsonUtf8, Common::Settings::Settings& settings) noexcept
{
    AssertUiThread();
    PluginEntry* entry = FindMutablePluginById(pluginId);
    if (! entry)
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }

    const HRESULT hr = EnsureLoaded(*entry, settings);
    if (FAILED(hr))
    {
        return hr;
    }

    if (! entry->informations)
    {
        return E_NOINTERFACE;
    }

    const std::string configText(configurationJsonUtf8);
    const HRESULT setHr = entry->informations->SetConfiguration(configText.empty() ? nullptr : configText.c_str());
    if (FAILED(setHr))
    {
        return setHr;
    }

    BOOL something            = FALSE;
    const HRESULT saveCheckHr = entry->informations->SomethingToSave(&something);
    if (SUCCEEDED(saveCheckHr) && ! something)
    {
        settings.plugins.configurationByPluginId.erase(entry->id);
        return S_OK;
    }

    const char* persistedConfig = nullptr;
    const HRESULT getHr         = entry->informations->GetConfiguration(&persistedConfig);

    const std::string persistedText = SUCCEEDED(getHr) ? SafeCoalesce(persistedConfig) : configText;

    Common::Settings::JsonValue persistedValue;
    HRESULT parseHr = Common::Settings::ParseJsonValue(persistedText, persistedValue);
    if (FAILED(parseHr))
    {
        parseHr = Common::Settings::ParseJsonValue(configText, persistedValue);
        if (FAILED(parseHr))
        {
            Debug::Warning(L"Failed to parse plugin configuration JSON for '{}' (hr=0x{:08X}); configuration will not be persisted.",
                           entry->id,
                           static_cast<unsigned long>(parseHr));
            return S_OK;
        }
    }

    settings.plugins.configurationByPluginId[entry->id] = std::move(persistedValue);
    return S_OK;
}

HRESULT FileSystemPluginManager::PrepareConnectionBrowseWork(std::wstring_view pluginId,
                                                             ConnectionBrowseWork::Kind kind,
                                                             std::wstring_view parentDeviceId,
                                                             ConnectionBrowseWork& outWork) noexcept
{
    AssertUiThread();
    outWork = {};

    PluginEntry* entry = FindMutablePluginById(pluginId);
    if (! entry)
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }
    if (entry->unloadDeferred || IsPluginPathDeferred(entry->path))
    {
        return HRESULT_FROM_WIN32(ERROR_BUSY);
    }
    if (entry->disabled || ! entry->loadable)
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }
    if (entry->path.empty())
    {
        return E_INVALIDARG;
    }

    wil::unique_hmodule module(LoadLibraryExW(entry->path.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH));
    if (! module)
    {
        return HRESULT_FROM_WIN32(GetLastError());
    }

    FARPROC browseConnectionTargets = GetProcAddress(module.get(), "RedSalamanderBrowseConnectionTargets");
    if (browseConnectionTargets == nullptr)
    {
        DWORD lastError = GetLastError();
        if (lastError == ERROR_SUCCESS)
        {
            lastError = ERROR_PROC_NOT_FOUND;
        }
        return HRESULT_FROM_WIN32(lastError);
    }

    outWork.kind                    = kind;
    outWork.pluginId                = std::wstring(RequestedPluginId(*entry));
    outWork.pluginPath              = entry->path;
    outWork.parentDeviceId          = std::wstring(parentDeviceId);
    outWork.module                  = std::move(module);
    outWork.browseConnectionTargets = browseConnectionTargets;
    return S_OK;
}

HRESULT FileSystemPluginManager::PrepareConnectionBrowseDevices(std::wstring_view pluginId, ConnectionBrowseWork& outWork) noexcept
{
    AssertUiThread();
    return PrepareConnectionBrowseWork(pluginId, ConnectionBrowseWork::Kind::Devices, {}, outWork);
}

HRESULT FileSystemPluginManager::PrepareConnectionBrowseStorages(std::wstring_view pluginId,
                                                                 std::wstring_view parentDeviceId,
                                                                 ConnectionBrowseWork& outWork) noexcept
{
    AssertUiThread();
    if (parentDeviceId.empty())
    {
        outWork = {};
        return E_INVALIDARG;
    }

    return PrepareConnectionBrowseWork(pluginId, ConnectionBrowseWork::Kind::Storages, parentDeviceId, outWork);
}

HRESULT FileSystemPluginManager::TestPlugin(std::wstring_view pluginId) noexcept
{
    AssertUiThread();
    PluginEntry* entry = FindMutablePluginById(pluginId);
    if (! entry)
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }

    Common::Settings::Settings dummySettings;
    return EnsureLoaded(*entry, dummySettings);
}

std::filesystem::path FileSystemPluginManager::GetExecutableDirectory() noexcept
{
    wil::unique_cotaskmem_string modulePath;
    const HRESULT hr = wil::GetModuleFileNameW<wil::unique_cotaskmem_string>(nullptr, modulePath);
    if (FAILED(hr) || ! modulePath)
    {
        return {};
    }
    return std::filesystem::path(modulePath.get()).parent_path();
}

std::filesystem::path FileSystemPluginManager::GetOptionalPluginsDirectory() noexcept
{
    if (_exeDir.empty())
    {
        return {};
    }
    return _exeDir / L"Plugins";
}

std::optional<size_t> FileSystemPluginManager::FindPluginIndexById(std::wstring_view pluginId) const noexcept
{
    if (pluginId.empty())
    {
        return std::nullopt;
    }

    for (size_t i = 0; i < _plugins.size(); ++i)
    {
        if (EqualsNoCase(_plugins[i].id, pluginId))
        {
            return i;
        }
    }

    return std::nullopt;
}

FileSystemPluginManager::PluginEntry* FileSystemPluginManager::FindMutablePluginById(std::wstring_view pluginId) noexcept
{
    const std::optional<size_t> index = FindPluginIndexById(pluginId);
    if (! index.has_value())
    {
        return nullptr;
    }

    return &_plugins[index.value()];
}

const FileSystemPluginManager::PluginEntry* FileSystemPluginManager::FindPluginById(std::wstring_view pluginId) const noexcept
{
    AssertUiThread();
    const std::optional<size_t> index = FindPluginIndexById(pluginId);
    if (! index.has_value())
    {
        return nullptr;
    }

    return &_plugins[index.value()];
}

HRESULT FileSystemPluginManager::Discover(Common::Settings::Settings& settings) noexcept
{
    SweepDeferredUnloadEntries(ModuleUnloadMode::FreeLibrary);
    UnloadAll(ModuleUnloadMode::FreeLibrary);
    _plugins.clear();

    if (_exeDir.empty())
    {
        _exeDir = GetExecutableDirectory();
    }

    if (_exeDir.empty())
    {
        return E_FAIL;
    }

    std::unordered_set<std::wstring> disabledIds;
    disabledIds.reserve(settings.plugins.disabledPluginIds.size());
    for (const auto& id : settings.plugins.disabledPluginIds)
    {
        if (! id.empty())
        {
            disabledIds.insert(ToLowerInvariant(id));
        }
    }

    struct Candidate
    {
        PluginOrigin origin = PluginOrigin::Embedded;
        std::filesystem::path path;
    };

    std::vector<Candidate> candidates;
    std::unordered_set<std::wstring> seenPaths;
    seenPaths.reserve(static_cast<size_t>(8) + settings.plugins.customPluginPaths.size());

    const auto tryAddCandidate = [&](PluginOrigin origin, const std::filesystem::path& path)
    {
        if (path.empty())
        {
            return;
        }

        if (IsPluginPathDeferred(path))
        {
            return;
        }

        const std::wstring key = ToLowerInvariant(path.wstring());
        if (! seenPaths.insert(key).second)
        {
            return;
        }

        candidates.push_back({origin, path});
    };

    tryAddCandidate(PluginOrigin::Embedded, _exeDir / L"Plugins" / L"FileSystem.dll");
    tryAddCandidate(PluginOrigin::Embedded, _exeDir / L"Plugins" / L"ViewerText.dll");

    const std::filesystem::path optionalDir = GetOptionalPluginsDirectory();
    std::error_code ec;
    if (! optionalDir.empty() && std::filesystem::exists(optionalDir, ec))
    {
        std::filesystem::directory_iterator item(optionalDir, ec);
        const std::filesystem::directory_iterator end;
        while (! ec && item != end)
        {
            const std::filesystem::path p = item->path();
            if (IsDllPath(p))
            {
                tryAddCandidate(PluginOrigin::Optional, p);
            }

            item.increment(ec);
        }
    }

    for (const auto& p : settings.plugins.customPluginPaths)
    {
        tryAddCandidate(PluginOrigin::Custom, p);
    }

    std::unordered_set<std::wstring> seenIds;
    std::unordered_set<std::wstring> seenShortIds;

    for (const PluginEntry& deferredEntry : _deferredUnloadEntries)
    {
        AddDeferredPlaceholder(deferredEntry);
        if (! deferredEntry.id.empty())
        {
            seenIds.insert(ToLowerInvariant(deferredEntry.id));
        }
        if (! deferredEntry.shortId.empty())
        {
            seenShortIds.insert(ToLowerInvariant(deferredEntry.shortId));
        }
    }

    const auto addLoadedEntry = [&](PluginEntry&& entry)
    {
        const std::wstring idKey    = ToLowerInvariant(entry.id);
        const std::wstring shortKey = ToLowerInvariant(entry.shortId);

        entry.disabled = ! entry.id.empty() && disabledIds.contains(idKey);

        bool conflict = false;

        if (entry.id.empty())
        {
            entry.loadError = L"Plugin id is missing.";
            conflict        = true;
        }
        else if (seenIds.contains(idKey))
        {
            entry.loadError = std::format(L"Duplicate plugin id '{}'.", entry.id);
            conflict        = true;
        }

        if (entry.shortId.empty())
        {
            entry.loadError = L"Short id is missing.";
            conflict        = true;
        }
        else if (seenShortIds.contains(shortKey))
        {
            entry.loadError = std::format(L"Duplicate short id '{}'.", entry.shortId);
            conflict        = true;
        }

        if (conflict)
        {
            entry.loadable = false;
            Debug::Error(L"Plugin '{}' skipped: {}", entry.path.wstring(), entry.loadError);
            if (! Unload(entry, ModuleUnloadMode::FreeLibrary))
            {
                _deferredUnloadEntries.push_back(std::move(entry));
                AddDeferredPlaceholder(_deferredUnloadEntries.back());
            }
            else
            {
                _plugins.push_back(std::move(entry));
            }
            return;
        }

        seenIds.insert(idKey);
        seenShortIds.insert(shortKey);

        if (entry.disabled && ! EqualsNoCase(entry.id, settings.plugins.currentFileSystemPluginId))
        {
            if (! Unload(entry, ModuleUnloadMode::FreeLibrary))
            {
                _deferredUnloadEntries.push_back(std::move(entry));
                AddDeferredPlaceholder(_deferredUnloadEntries.back());
                return;
            }
        }

        _plugins.push_back(std::move(entry));
    };

    const auto tryLoadAndAddEntry = [&](PluginEntry&& entry)
    {
        Common::Settings::Settings scratch = settings;
        const HRESULT loadHr               = EnsureLoaded(entry, scratch);
        if (FAILED(loadHr))
        {
            _plugins.push_back(std::move(entry));
            return;
        }

        addLoadedEntry(std::move(entry));
    };

    for (const Candidate& candidate : candidates)
    {
        if (! IsDllPath(candidate.path))
        {
            PluginEntry entry;
            entry.origin    = candidate.origin;
            entry.path      = candidate.path;
            entry.loadable  = false;
            entry.loadError = L"File is missing or not a DLL.";
            _plugins.push_back(std::move(entry));
            continue;
        }

        EnumeratedPluginSet enumeration = EnumerateFileSystemPlugins(candidate.path, candidate.origin);
        if (enumeration.hr == E_NOINTERFACE)
        {
            if (candidate.origin == PluginOrigin::Custom)
            {
                PluginEntry entry;
                entry.origin    = candidate.origin;
                entry.path      = candidate.path;
                entry.loadable  = false;
                entry.loadError = L"Custom plugin does not expose IFileSystem through RedSalamanderEnumeratePlugins.";
                _plugins.push_back(std::move(entry));
            }
            continue;
        }

        if (enumeration.hr == HRESULT_FROM_WIN32(ERROR_PROC_NOT_FOUND))
        {
            if (candidate.origin == PluginOrigin::Custom)
            {
                PluginEntry entry;
                entry.origin    = candidate.origin;
                entry.path      = candidate.path;
                entry.loadable  = false;
                entry.loadError = enumeration.loadError;
                _plugins.push_back(std::move(entry));
            }
            continue;
        }

        if (FAILED(enumeration.hr))
        {
            PluginEntry entry;
            entry.origin    = candidate.origin;
            entry.path      = candidate.path;
            entry.loadable  = false;
            entry.loadError = enumeration.loadError;
            _plugins.push_back(std::move(entry));
            continue;
        }

        for (PluginEntry& entry : enumeration.entries)
        {
            tryLoadAndAddEntry(std::move(entry));
        }
    }

    const auto byOriginNameId = [](const PluginEntry& a, const PluginEntry& b)
    {
        if (a.origin != b.origin)
        {
            return static_cast<int>(a.origin) < static_cast<int>(b.origin);
        }

        const std::wstring an = a.name.empty() ? a.path.filename().wstring() : a.name;
        const std::wstring bn = b.name.empty() ? b.path.filename().wstring() : b.name;

        const int cmp = _wcsicmp(an.c_str(), bn.c_str());
        if (cmp != 0)
        {
            return cmp < 0;
        }

        return a.id < b.id;
    };

    std::sort(_plugins.begin(), _plugins.end(), byOriginNameId);

    const bool hasLoadablePlugin = std::any_of(_plugins.begin(), _plugins.end(), [](const PluginEntry& entry) { return entry.loadable; });
    if (! hasLoadablePlugin)
    {
        Debug::Error(L"File system plugin discovery found zero loadable plugins under '{}'.", (_exeDir / L"Plugins").wstring());
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }

    return S_OK;
}

HRESULT FileSystemPluginManager::EnsureLoaded(PluginEntry& entry, Common::Settings::Settings& settings) noexcept
{
    if (entry.module && entry.fileSystem && entry.informations)
    {
        return S_OK;
    }

    entry.loadable = false;
    entry.loadError.clear();
    if (entry.module)
    {
        if (! Unload(entry, ModuleUnloadMode::FreeLibrary))
        {
            entry.loadError = L"Plugin unload is deferred until the plugin reports it can unload.";
            return HRESULT_FROM_WIN32(ERROR_BUSY);
        }
    }
    entry.fileSystem   = nullptr;
    entry.informations = nullptr;

    if (entry.unloadDeferred || IsPluginPathDeferred(entry.path))
    {
        SweepDeferredUnloadEntries(ModuleUnloadMode::FreeLibrary);
        if (IsPluginPathDeferred(entry.path))
        {
            entry.loadError = PluginModuleLifecycle::kDeferredUnloadError;
            return HRESULT_FROM_WIN32(ERROR_BUSY);
        }
        entry.unloadDeferred = false;
    }

    if (entry.path.empty())
    {
        entry.loadError = L"Plugin path is empty.";
        return E_INVALIDARG;
    }

    if (entry.factoryPluginId.empty())
    {
        entry.loadError = L"Plugin id is missing. File system plugins must be discovered via RedSalamanderEnumeratePlugins.";
        return E_INVALIDARG;
    }

    wil::unique_hmodule module(LoadLibraryExW(entry.path.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH));
    if (! module)
    {
        const DWORD lastError = GetLastError();
        entry.loadError       = std::format(L"LoadLibraryExW failed (0x{:08X}).", lastError);
        Debug::Error(L"Failed to load plugin '{}': {}", entry.path.wstring(), entry.loadError);
        return HRESULT_FROM_WIN32(lastError);
    }

    const HRESULT registerHr = RegisterPluginResourceOwner(entry.path, module.get());
    if (FAILED(registerHr))
    {
        entry.loadError = std::format(L"RegisterResourceOwner failed (0x{:08X}).", static_cast<unsigned int>(registerHr));
        return registerHr;
    }
    bool keepResourceOwnerRegistered = false;
    auto unregisterOnFailure         = wil::scope_exit([&]() noexcept
    {
        if (! keepResourceOwnerRegistered)
        {
            Localization::UnregisterResourceOwner(module.get());
        }
    });

#pragma warning(push)
#pragma warning(disable : 4191) // unsafe conversion from FARPROC
    const auto createFactory = reinterpret_cast<CreateFactoryFunc>(GetProcAddress(module.get(), "RedSalamanderCreate"));
#pragma warning(pop)
    if (! createFactory)
    {
        entry.loadError = L"Missing export RedSalamanderCreate.";
        return HRESULT_FROM_WIN32(ERROR_PROC_NOT_FOUND);
    }

    FactoryOptions options{};
    options.debugLevel = DEBUG_LEVEL_NONE;

    wil::com_ptr<IFileSystem> fileSystem;
    const HRESULT createHr = createFactory(__uuidof(IFileSystem), &options, GetHostServices(), entry.factoryPluginId.c_str(), fileSystem.put_void());
    if (FAILED(createHr))
    {
        entry.loadError = std::format(L"Factory failed (hr=0x{:08X}).", static_cast<unsigned long>(createHr));
        return createHr;
    }

    wil::com_ptr<IInformations> infos;
    const HRESULT qiHr = fileSystem->QueryInterface(__uuidof(IInformations), infos.put_void());
    if (FAILED(qiHr))
    {
        entry.loadError = std::format(L"IInformations not supported (hr=0x{:08X}).", static_cast<unsigned long>(qiHr));
        return qiHr;
    }

    const PluginMetaData* meta = nullptr;
    const HRESULT metaHr       = infos->GetMetaData(&meta);
    if (FAILED(metaHr))
    {
        entry.loadError = std::format(L"GetMetaData failed (hr=0x{:08X}).", static_cast<unsigned long>(metaHr));
        return metaHr;
    }

    if (meta)
    {
        const std::wstring reportedId = SafeCoalesce(meta->id);
        if (! reportedId.empty() && ! EqualsNoCase(entry.factoryPluginId, reportedId))
        {
            entry.loadError = std::format(L"Plugin id mismatch: requested '{}' but instance reported '{}'.", entry.factoryPluginId, reportedId);
            return E_FAIL;
        }

        if (entry.id.empty())
        {
            entry.id = reportedId;
        }

        if (! entry.id.empty() && reportedId.empty())
        {
            entry.loadError = L"Plugin id is missing.";
            return E_INVALIDARG;
        }

        const std::wstring reportedShortId = SafeCoalesce(meta->shortId);
        if (! reportedShortId.empty())
        {
            entry.shortId = std::move(reportedShortId);
        }

        PopulateEntryPresentationFromMetaData(entry, *meta);
    }

    if (entry.id.empty())
    {
        entry.loadError = L"Plugin id is missing.";
        return E_INVALIDARG;
    }

    if (! IsValidShortId(entry.shortId))
    {
        entry.loadError = std::format(L"Invalid or missing short id '{}'.", entry.shortId);
        return E_INVALIDARG;
    }

    entry.module                = std::move(module);
    entry.fileSystem            = std::move(fileSystem);
    entry.informations          = std::move(infos);
    entry.loadable              = true;
    keepResourceOwnerRegistered = true;

    static_cast<void>(ApplyConfigurationFromSettings(entry, settings));
    return S_OK;
}

void FileSystemPluginManager::UnloadAll(ModuleUnloadMode mode) noexcept
{
    PluginModuleLifecycle::UnloadAll(
        _plugins, _deferredUnloadEntries, mode, [this](PluginEntry& entry, ModuleUnloadMode unloadMode) noexcept { return Unload(entry, unloadMode); });
}

bool FileSystemPluginManager::Unload(PluginEntry& entry, ModuleUnloadMode mode) noexcept
{
    entry.informations = nullptr;
    entry.fileSystem   = nullptr;

    if (! entry.module)
    {
        entry.unloadDeferred = false;
        return true;
    }

    if (! PluginModuleLifecycle::UnloadModule(entry.module, mode, entry.path, L"File system plugin"))
    {
        PluginModuleLifecycle::MarkDeferred(entry);
        return false;
    }

    entry.unloadDeferred = false;
    return true;
}

void FileSystemPluginManager::SweepDeferredUnloadEntries(ModuleUnloadMode mode) noexcept
{
    PluginModuleLifecycle::SweepDeferred(
        _deferredUnloadEntries, mode, [this](PluginEntry& entry, ModuleUnloadMode unloadMode) noexcept { return Unload(entry, unloadMode); });
}

bool FileSystemPluginManager::IsPluginPathDeferred(const std::filesystem::path& path) const noexcept
{
    return PluginModuleLifecycle::IsPathDeferred(_deferredUnloadEntries, path);
}

void FileSystemPluginManager::AddDeferredPlaceholder(const PluginEntry& entry) noexcept
{
    _plugins.push_back(PluginModuleLifecycle::MakeDeferredPlaceholder(entry));
}

HRESULT FileSystemPluginManager::ApplyConfigurationFromSettings(PluginEntry& entry, const Common::Settings::Settings& settings) noexcept
{
    if (! entry.informations || entry.id.empty())
    {
        return S_FALSE;
    }

    const auto it = settings.plugins.configurationByPluginId.find(entry.id);
    if (it == settings.plugins.configurationByPluginId.end())
    {
        return entry.informations->SetConfiguration(nullptr);
    }

    const Common::Settings::JsonValue& configValue = it->second;
    if (std::holds_alternative<std::monostate>(configValue.value))
    {
        return entry.informations->SetConfiguration(nullptr);
    }

    std::string configText;
    const HRESULT serializeHr = Common::Settings::SerializeJsonValue(configValue, configText);
    if (FAILED(serializeHr))
    {
        Debug::Warning(L"Failed to serialize plugin configuration JSON for '{}' (hr=0x{:08X}); configuration will be ignored.",
                       entry.id,
                       static_cast<unsigned long>(serializeHr));
        return entry.informations->SetConfiguration(nullptr);
    }

    const HRESULT setHr = entry.informations->SetConfiguration(configText.empty() ? nullptr : configText.c_str());
    if (FAILED(setHr))
    {
        // A plugin that rejects its persisted configuration silently reverts to its compiled
        // defaults, which reads to the user as a setting that will not stick. Say so once here;
        // callers deliberately continue with defaults rather than failing plugin load.
        Debug::Warning(L"File system plugin '{}' rejected its persisted configuration (hr=0x{:08X}); compiled defaults are in effect.",
                       entry.id,
                       static_cast<unsigned long>(setHr));
    }
    return setHr;
}

void FileSystemPluginManager::PersistConfigurationToSettings(const PluginEntry& entry, Common::Settings::Settings& settings) noexcept
{
    if (! entry.informations || entry.id.empty())
    {
        return;
    }

    BOOL something            = FALSE;
    const HRESULT saveCheckHr = entry.informations->SomethingToSave(&something);
    if (FAILED(saveCheckHr))
    {
        return;
    }

    if (! something)
    {
        settings.plugins.configurationByPluginId.erase(entry.id);
        return;
    }

    const char* config  = nullptr;
    const HRESULT getHr = entry.informations->GetConfiguration(&config);
    if (FAILED(getHr))
    {
        return;
    }

    Common::Settings::JsonValue persistedValue;
    const HRESULT parseHr = Common::Settings::ParseJsonValue(SafeCoalesce(config), persistedValue);
    if (FAILED(parseHr))
    {
        Debug::Warning(L"Failed to parse plugin configuration JSON for '{}' (hr=0x{:08X}); configuration will not be persisted.",
                       entry.id,
                       static_cast<unsigned long>(parseHr));
        return;
    }

    settings.plugins.configurationByPluginId[entry.id] = std::move(persistedValue);
}
