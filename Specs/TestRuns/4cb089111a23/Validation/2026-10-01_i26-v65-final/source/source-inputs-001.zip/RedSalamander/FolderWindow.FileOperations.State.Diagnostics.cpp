#include "FolderWindow.FileOperations.State.Private.h"

#include "ConnectionProfileUtils.h"
#include "FileSystemPathIdentity.h"
#include "FolderWindow.FileOperations.IssuesPane.h"
#include "HostServices.h"
#include "NavigationLocation.h"
#include "SessionState.h"
#include "SettingsHotReload.h"
#include "SettingsSave.h"
#include "SettingsStore.h"
#include "WindowPlacementPersistence.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <cwchar>
#include <deque>
#include <functional>
#include <iterator>
#include <set>
#include <system_error>
#include <thread>
#include <unordered_map>
#include <utility>

#include <psapi.h>
#include <shellapi.h>

#pragma warning(push)
#pragma warning(disable : 6297 28182)
#include <yyjson.h>
#pragma warning(pop)

using namespace FolderWindowFileOperationsStateInternal;

FolderWindow::FileOperationState::QualifiedIssueFacts FolderWindow::FileOperationState::QualifyIssueFacts(const TaskDiagnosticEntry& issue) noexcept
{
    QualifiedIssueFacts facts{};
    // Raw typed presence prevents malformed typed observations from becoming
    // ordinary problems just because their diagnostic severity is Error.
    facts.originalProblem = (issue.severity == DiagnosticSeverity::Warning || issue.severity == DiagnosticSeverity::Error) &&
                            ! issue.acceptedDecision.has_value() && ! issue.conflictResult.has_value();
    if (issue.acceptedDecision.has_value())
    {
        const auto& choice = issue.acceptedDecision.value();
        if (choice.taskId == issue.taskId && choice.taskId != 0u && choice.promptGeneration != 0u && choice.action != FileOperations::ConflictAction::None &&
            (! issue.conflictPrompt.has_value() ||
             (issue.conflictPrompt.value().generation == choice.promptGeneration && issue.conflictPrompt.value().bucket == choice.scope.bucket &&
              issue.conflictPrompt.value().sourceItemIndex == choice.sourceItemIndex)))
            facts.acceptedDecision = &choice;
    }
    if (issue.conflictResult.has_value())
    {
        const auto& result    = issue.conflictResult.value();
        const auto& reference = result.reference;
        if (reference.taskId == issue.taskId && reference.taskId != 0u && reference.promptGeneration != 0u &&
            (! issue.conflictPrompt.has_value() || issue.conflictPrompt.value().generation == reference.promptGeneration) &&
            (! facts.acceptedDecision || facts.acceptedDecision->promptGeneration == reference.promptGeneration))
            facts.conflictResult = &result;
    }
    return facts;
}

void FolderWindow::FileOperationState::CollectProjectableIssueTaskIds(std::vector<uint64_t>& outTaskIds) noexcept
{
    outTaskIds.clear();
    // Mirror BuildRows' two retained reservoirs. Keep lock acquisition separate,
    // as CollectDiagnostics and CollectCompletedTasks do, and never retain a
    // borrowed fact pointer after leaving its entry's lock scope.
    {
        std::scoped_lock lock(_diagnosticsMutex);
        for (const auto& issue : _diagnosticsInMemory)
        {
            if (issue.taskId != 0u && QualifyIssueFacts(issue).ProjectsRow())
                outTaskIds.push_back(issue.taskId);
        }
    }
    {
        std::scoped_lock lock(_mutex);
        for (const auto& task : _completedTasks)
        {
            for (const auto& issue : task.issueDiagnostics)
            {
                if (issue.taskId != 0u && QualifyIssueFacts(issue).ProjectsRow())
                    outTaskIds.push_back(issue.taskId);
            }
        }
    }
    std::sort(outTaskIds.begin(), outTaskIds.end());
    outTaskIds.erase(std::unique(outTaskIds.begin(), outTaskIds.end()), outTaskIds.end());
}

namespace
{
[[nodiscard]] std::wstring ConflictPromptJson(const FileOperations::ConflictPromptObservation& prompt)
{
    return std::format(
        LR"({{"generation":{},"conflictClass":{},"sourceItemIndex":{},"sourceName":"{}","sourceParentPath":"{}","destinationName":"{}","destinationParentPath":"{}"}})",
        prompt.generation,
        static_cast<unsigned>(prompt.bucket),
        prompt.sourceItemIndex.has_value() ? std::to_wstring(prompt.sourceItemIndex.value()) : L"null",
        EscapeDiagnosticJsonString(prompt.sourceName),
        EscapeDiagnosticJsonString(prompt.sourceParentPath),
        EscapeDiagnosticJsonString(prompt.destinationName),
        EscapeDiagnosticJsonString(prompt.destinationParentPath));
}

// One additive projection for JSONL and tabular export; enum values are schema-v1 internal codes.
// Unknown/missing result facts deliberately have no success field.
[[nodiscard]] std::wstring AcceptedDecisionJson(const FileOperations::AcceptedConflictDecision& decision)
{
    const auto& scope = decision.scope;
    return std::format(
        LR"({{"version":1,"taskId":{},"promptGeneration":{},"sourceItemIndex":{},"action":{},"applyToAll":{},"origin":"{}","originatingPromptGeneration":{},"scope":{{"conflictClass":{},"sourceKind":{},"destinationKind":{},"destinationLinkKind":{},"sourceProfileId":"{}","destinationProfileId":"{}","destinationRootId":"{}","applyToAllEligible":{}}}}})",
        decision.taskId,
        decision.promptGeneration,
        decision.sourceItemIndex.has_value() ? std::to_wstring(decision.sourceItemIndex.value()) : L"null",
        static_cast<unsigned>(decision.action),
        decision.applyToAll ? L"true" : L"false",
        decision.origin == FileOperations::ConflictDecisionOrigin::User ? L"user" : L"cachedScope",
        decision.originatingPromptGeneration,
        static_cast<unsigned>(scope.bucket),
        static_cast<unsigned>(scope.sourceKind),
        static_cast<unsigned>(scope.destinationKind),
        static_cast<unsigned>(scope.destinationLinkKind),
        EscapeDiagnosticJsonString(scope.sourceProfileId),
        EscapeDiagnosticJsonString(scope.destinationProfileId),
        EscapeDiagnosticJsonString(scope.destinationRootId),
        scope.applyToAllEligible ? L"true" : L"false");
}
} // namespace

std::wstring FileOperations::FormatAcceptedConflictDecisionDiagnostic(const AcceptedConflictDecision& decision)
{
    return AcceptedDecisionJson(decision);
}

std::wstring FileOperations::FormatConflictResultDiagnostic(const ConflictResultObservation& result)
{
    return std::format(
        LR"({{"version":1,"taskId":{},"promptGeneration":{},"publication":{},"verification":{},"sourceDisposition":{},"completion":{},"ownedStageDisposition":{},"status":"0x{:08X}"}})",
        result.reference.taskId,
        result.reference.promptGeneration,
        static_cast<unsigned>(result.publication),
        static_cast<unsigned>(result.verification),
        static_cast<unsigned>(result.sourceDisposition),
        static_cast<unsigned>(result.completion),
        static_cast<unsigned>(result.ownedStageDisposition),
        static_cast<unsigned long>(result.status));
}

bool FolderWindow::FileOperationState::OpenDiagnosticsLogForTask(uint64_t taskId) noexcept
{
#ifdef ENABLE_TESTS
    {
        std::scoped_lock lock(_debugDiagnosticsLogRouteMutex);
        if (! _debugDiagnosticsLogDirectory.empty())
            ++_debugDiagnosticsLogRoute.attempts;
    }
#endif
    FlushDiagnostics(true);

    std::filesystem::path logPath;
    {
        std::scoped_lock lock(_mutex);
        for (const auto& summary : _completedTasks)
        {
            if (summary.taskId != taskId)
            {
                continue;
            }

            logPath = summary.diagnosticsLogPath;
            break;
        }
    }

    std::error_code ec;
    if (! logPath.empty() && ! std::filesystem::exists(logPath, ec))
    {
        logPath.clear();
    }

    if (logPath.empty())
    {
        std::scoped_lock lock(_mutex);
        logPath = GetLatestDiagnosticsLogPathUnlocked();
    }

    ec.clear();
    if (logPath.empty() || ! std::filesystem::exists(logPath, ec))
    {
        return false;
    }

#ifdef ENABLE_TESTS
    {
        std::scoped_lock lock(_debugDiagnosticsLogRouteMutex);
        if (! _debugDiagnosticsLogDirectory.empty())
        {
            ++_debugDiagnosticsLogRoute.suppressedLaunches;
            _debugDiagnosticsLogRoute.openedTaskId = taskId;
            _debugDiagnosticsLogRoute.openedPath   = logPath;
            return true;
        }
    }
#endif
    HINSTANCE hinst = ShellExecuteW(_owner.GetHwnd(), L"open", logPath.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    return reinterpret_cast<INT_PTR>(hinst) > 32;
}

#ifdef ENABLE_TESTS
void FolderWindow::FileOperationState::DebugConfigureDiagnosticsLogRouteForSelfTest(std::filesystem::path logDirectory) noexcept
{
    std::scoped_lock lock(_debugDiagnosticsLogRouteMutex);
    _debugDiagnosticsLogDirectory = std::move(logDirectory);
    _debugDiagnosticsLogRoute     = {};
}

FolderWindow::FileOperationState::DiagnosticsLogRouteDebugSnapshot FolderWindow::FileOperationState::DebugGetDiagnosticsLogRouteForSelfTest() noexcept
{
    std::scoped_lock lock(_debugDiagnosticsLogRouteMutex);
    return _debugDiagnosticsLogRoute;
}

void FolderWindow::FileOperationState::DebugConfigureIssuesExportRouteForSelfTest(std::filesystem::path reportDirectory, bool refuseCreate) noexcept
{
    std::scoped_lock lock(_mutex);
    _debugIssuesExportReportDirectory = std::move(reportDirectory);
    _debugIssuesExportRefuseCreate    = refuseCreate;
    _debugIssuesExportRoute           = {};
}

FolderWindow::FileOperationState::IssuesExportRouteDebugSnapshot FolderWindow::FileOperationState::DebugGetIssuesExportRouteForSelfTest() noexcept
{
    std::scoped_lock lock(_mutex);
    return _debugIssuesExportRoute;
}
#endif

bool FolderWindow::FileOperationState::ExportTaskIssuesReport(uint64_t taskId, std::filesystem::path* reportPathOut, bool openAfterExport) noexcept
{
    if (reportPathOut)
    {
        reportPathOut->clear();
    }

    FlushDiagnostics(true);

    CompletedTaskSummary summary{};
    bool found = false;
    {
        std::scoped_lock lock(_mutex);
        for (const auto& candidate : _completedTasks)
        {
            if (candidate.taskId != taskId)
            {
                continue;
            }

            summary = candidate;
            found   = true;
            break;
        }
    }

    if (! found)
    {
        return false;
    }

    if (summary.issueDiagnostics.empty() && summary.warningCount == 0 && summary.errorCount == 0)
    {
        return false;
    }

#ifdef ENABLE_TESTS
    std::filesystem::path testReportDirectory;
    bool testRefuseCreate = false;
    {
        std::scoped_lock lock(_mutex);
        testReportDirectory = _debugIssuesExportReportDirectory;
        testRefuseCreate    = _debugIssuesExportRefuseCreate;
        if (! testReportDirectory.empty())
            ++_debugIssuesExportRoute.attempts;
    }
    const std::filesystem::path logsDir = testReportDirectory.empty() ? GetDiagnosticsLogDirectory() : testReportDirectory;
#else
    const std::filesystem::path logsDir = GetDiagnosticsLogDirectory();
#endif
    if (logsDir.empty())
    {
        return false;
    }

    SYSTEMTIME localNow{};
    GetLocalTime(&localNow);

    wchar_t fileName[128]{};
    constexpr size_t fileNameMax                            = (sizeof(fileName) / sizeof(fileName[0])) - 1;
    const auto r                                            = std::format_to_n(fileName,
                                                                               fileNameMax,
                                                                               L"{}Task{}-{:04}{:02}{:02}-{:02}{:02}{:02}{:03}{}",
                                                                               kDiagnosticsIssueReportPrefix,
                                                                               static_cast<unsigned long long>(taskId),
                                                                               static_cast<unsigned>(localNow.wYear),
                                                                               static_cast<unsigned>(localNow.wMonth),
                                                                               static_cast<unsigned>(localNow.wDay),
                                                                               static_cast<unsigned>(localNow.wHour),
                                                                               static_cast<unsigned>(localNow.wMinute),
                                                                               static_cast<unsigned>(localNow.wSecond),
                                                                               static_cast<unsigned>(localNow.wMilliseconds),
                                                                               kDiagnosticsIssueReportExtension);
    fileName[(r.size < fileNameMax) ? r.size : fileNameMax] = L'\0';
    if (r.size > fileNameMax)
    {
        return false;
    }

    const std::filesystem::path reportPath = logsDir / fileName;

    std::error_code ec;
    std::filesystem::create_directories(logsDir, ec);
    if (ec)
    {
        return false;
    }

#ifdef ENABLE_TESTS
    if (! testReportDirectory.empty() && testRefuseCreate)
    {
        std::scoped_lock lock(_mutex);
        ++_debugIssuesExportRoute.refusedCreates;
        return false;
    }
#endif
    wil::unique_handle file(CreateFileW(
        reportPath.c_str(), GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr));
    if (! file)
    {
        return false;
    }

    constexpr wchar_t bom = 0xFEFF;
    DWORD written         = 0;
    if (! WriteFile(file.get(), &bom, sizeof(bom), &written, nullptr) || written != sizeof(bom))
    {
        return false;
    }

    const std::wstring header =
        std::format(L"Task {:#x} ({})\r\nResult: 0x{:08X}\r\nWarnings: {:L}  Errors: {:L}\r\nCompleted items: {:L}/{:L}\r\nCompleted bytes: {:L}/{:L}\r\nFrom: "
                    L"{}\r\nTo: {}\r\n\r\nTime\tSeverity\tHRESULT\tStatus text\tCategory\tMessage\tSource\tDestination\tAccepted decision (JSON v1)\tConflict "
                    L"prompt (JSON v1)\tConflict result (JSON v1)\r\n",
                    static_cast<unsigned long long>(summary.taskId),
                    OperationToString(summary.operation),
                    static_cast<unsigned long>(summary.resultHr),
                    summary.warningCount,
                    summary.errorCount,
                    summary.completedItems,
                    summary.totalItems,
                    summary.completedBytes,
                    summary.totalBytes,
                    summary.sourcePath.empty() ? L"-" : summary.sourcePath,
                    summary.destinationPath.empty() ? L"-" : summary.destinationPath);
    const size_t headerBytes = header.size() * sizeof(wchar_t);
    if (headerBytes > static_cast<size_t>(std::numeric_limits<DWORD>::max()))
    {
        return false;
    }
    if (! WriteFile(file.get(), header.data(), static_cast<DWORD>(headerBytes), &written, nullptr) || written != static_cast<DWORD>(headerBytes))
    {
        return false;
    }

    for (const TaskDiagnosticEntry& issue : summary.issueDiagnostics)
    {
        const std::wstring statusText = EscapeDiagnosticField(FormatDiagnosticStatusText(issue.status));
        std::wstring line             = std::format(L"{:04}-{:02}-{:02} {:02}:{:02}:{:02}.{:03}\t{}\t0x{:08X}\t{}\t{}\t{}\t{}\t{}\r\n",
                                                    static_cast<unsigned>(issue.localTime.wYear),
                                                    static_cast<unsigned>(issue.localTime.wMonth),
                                                    static_cast<unsigned>(issue.localTime.wDay),
                                                    static_cast<unsigned>(issue.localTime.wHour),
                                                    static_cast<unsigned>(issue.localTime.wMinute),
                                                    static_cast<unsigned>(issue.localTime.wSecond),
                                                    static_cast<unsigned>(issue.localTime.wMilliseconds),
                                                    DiagnosticSeverityToString(issue.severity),
                                                    static_cast<unsigned long>(issue.status),
                                                    statusText,
                                                    EscapeDiagnosticField(issue.category),
                                                    EscapeDiagnosticField(issue.message),
                                                    EscapeDiagnosticField(issue.sourcePath),
                                                    EscapeDiagnosticField(issue.destinationPath));

        line.resize(line.size() - 2u);
        line.append(L"\t");
        if (issue.acceptedDecision.has_value())
        {
            line.append(EscapeDiagnosticField(AcceptedDecisionJson(issue.acceptedDecision.value())));
        }
        line.append(L"\t");
        if (issue.conflictPrompt.has_value())
        {
            line.append(EscapeDiagnosticField(ConflictPromptJson(issue.conflictPrompt.value())));
        }
        line.append(L"\t");
        if (issue.conflictResult.has_value())
        {
            line.append(EscapeDiagnosticField(FileOperations::FormatConflictResultDiagnostic(issue.conflictResult.value())));
        }
        line.append(L"\r\n");

        const size_t bytesToWrite = line.size() * sizeof(wchar_t);
        if (bytesToWrite > static_cast<size_t>(std::numeric_limits<DWORD>::max()))
        {
            continue;
        }

        if (! WriteFile(file.get(), line.data(), static_cast<DWORD>(bytesToWrite), &written, nullptr) || written != static_cast<DWORD>(bytesToWrite))
        {
            return false;
        }
    }

    if (reportPathOut)
    {
        *reportPathOut = reportPath;
    }

    const DiagnosticsSettings diagnosticsSettings = GetDiagnosticsSettingsFromSettings(_owner._settings);
    CleanupDiagnosticsFilesInDirectory(
        logsDir, kDiagnosticsIssueReportPrefix, kDiagnosticsIssueReportExtension, diagnosticsSettings.maxDiagnosticsIssueReportFiles);

    if (! openAfterExport)
    {
        return true;
    }

#ifdef ENABLE_TESTS
    if (! testReportDirectory.empty())
    {
        std::scoped_lock lock(_mutex);
        ++_debugIssuesExportRoute.suppressedLaunches;
        return true;
    }
#endif
    HINSTANCE hinst = ShellExecuteW(_owner.GetHwnd(), L"open", reportPath.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    return reinterpret_cast<INT_PTR>(hinst) > 32;
}

void FolderWindow::FileOperationState::ToggleIssuesPane() noexcept
{
    HWND pane = nullptr;
    {
        std::scoped_lock lock(_mutex);
        pane = _issuesPane.get();
        if (pane && IsWindow(pane) == FALSE)
        {
            static_cast<void>(_issuesPane.release());
            pane = nullptr;
        }
    }

    if (pane)
    {
        if (IsWindowVisible(pane))
        {
            static_cast<void>(SendMessageW(pane, WM_CLOSE, 0, 0));
        }
        else
        {
            ShowWindow(pane, SW_SHOW);
            SetForegroundWindow(pane);
            PostMessageW(pane, WM_THEMECHANGED, 0, 0);
        }
        return;
    }

    HWND ownerWindow = _owner.GetHwnd();
    if (ownerWindow)
    {
        HWND rootWindow = GetAncestor(ownerWindow, GA_ROOT);
        if (rootWindow)
        {
            ownerWindow = rootWindow;
        }
    }

    if (! ownerWindow)
    {
        ownerWindow = GetParent(_owner.GetHwnd());
        if (! ownerWindow)
        {
            ownerWindow = _owner.GetHwnd();
        }
    }

    std::weak_ptr<void> uiLifetime;
    {
        std::scoped_lock lock(_mutex);
        uiLifetime = _uiLifetime;
    }

    HWND createdPane = FileOperationsIssuesPane::Create(this, &_owner, ownerWindow, std::move(uiLifetime));
    if (! createdPane)
    {
        return;
    }

    {
        std::scoped_lock lock(_mutex);
        _issuesPane.reset(createdPane);
    }
}

bool FolderWindow::FileOperationState::OpenIssuesForTask(uint64_t taskId) noexcept
{
    if (taskId == 0u)
        return false;
    std::vector<uint64_t> projectableTaskIds;
    CollectProjectableIssueTaskIds(projectableTaskIds);
    if (! std::binary_search(projectableTaskIds.begin(), projectableTaskIds.end(), taskId))
        return false;

    // ToggleIssuesPane closes an already-visible pane. Use it only to create
    // or reveal one, then select the originating task in its current sort order.
    if (! IsIssuesPaneVisible())
        ToggleIssuesPane();
    HWND pane = nullptr;
    {
        std::scoped_lock lock(_mutex);
        pane = _issuesPane.get();
    }
    if (! pane || IsWindow(pane) == FALSE || ! FileOperationsIssuesPane::SelectTask(pane, taskId))
        return false;
    if (IsIconic(pane) != FALSE)
        ShowWindow(pane, SW_RESTORE);
    SetForegroundWindow(pane);
    return true;
}

bool FolderWindow::FileOperationState::IsIssuesPaneVisible() noexcept
{
    std::scoped_lock lock(_mutex);
    return _issuesPane && IsWindowVisible(_issuesPane.get()) != FALSE;
}

bool FolderWindow::FileOperationState::TryGetIssuesPanePlacement(RECT& outRect, bool& outMaximized, UINT currentDpi) const noexcept
{
    outRect      = RECT{};
    outMaximized = false;

    if (! _owner._settings)
    {
        return false;
    }

    const std::wstring windowId(kFileOpsIssuesPaneWindowId);
    const auto it = _owner._settings->windows.find(windowId);
    if (it == _owner._settings->windows.end())
    {
        return false;
    }

    const Common::Settings::WindowPlacement normalized = Common::Settings::NormalizeWindowPlacement(it->second, currentDpi);
    outRect.left                                       = normalized.bounds.x;
    outRect.top                                        = normalized.bounds.y;
    outRect.right                                      = normalized.bounds.x + std::max(1, normalized.bounds.width);
    outRect.bottom                                     = normalized.bounds.y + std::max(1, normalized.bounds.height);
    outMaximized                                       = normalized.state == Common::Settings::WindowState::Maximized;
    return true;
}

void FolderWindow::FileOperationState::SaveIssuesPanePlacement(HWND hwnd) noexcept
{
    if (! hwnd || ! _owner._settings || IsIconic(hwnd))
    {
        return;
    }
    WindowPlacementPersistence::Save(*_owner._settings, kFileOpsIssuesPaneWindowId, hwnd);
}

bool FolderWindow::FileOperationState::TryGetIssuesPaneViewState(std::wstring& outSortColumnId,
                                                                 bool& outSortDescending,
                                                                 std::vector<Common::Settings::GridColumnLayoutEntry>& outGridLayout) const noexcept
{
    outSortColumnId.clear();
    outSortDescending = false;
    outGridLayout.clear();

    if (! _owner._settings || ! _owner._settings->fileOperations.has_value())
    {
        return false;
    }

    const auto& fileOperations = _owner._settings->fileOperations.value();
    outSortColumnId            = fileOperations.issuesPaneSortColumnId;
    outSortDescending          = fileOperations.issuesPaneSortDescending;
    outGridLayout              = fileOperations.issuesPaneGridLayout;
    return ! outSortColumnId.empty() || ! outGridLayout.empty();
}

void FolderWindow::FileOperationState::SaveIssuesPaneViewState(std::wstring_view sortColumnId,
                                                               bool sortDescending,
                                                               const std::vector<Common::Settings::GridColumnLayoutEntry>& gridLayout) noexcept
{
    if (! _owner._settings)
    {
        return;
    }

    if (! _owner._settings->fileOperations.has_value())
    {
        _owner._settings->fileOperations.emplace();
    }

    Common::Settings::FileOperationsSettings& fileOperations = _owner._settings->fileOperations.value();
    fileOperations.issuesPaneSortColumnId.assign(sortColumnId);
    fileOperations.issuesPaneSortDescending = ! fileOperations.issuesPaneSortColumnId.empty() && sortDescending;
    fileOperations.issuesPaneGridLayout     = gridLayout;
}

namespace
{
[[nodiscard]] bool TryGetFileOperationsWindowPlacement(
    const Common::Settings::Settings* settings, std::wstring_view windowId, RECT& outRect, bool& outMaximized, UINT currentDpi) noexcept
{
    outRect      = RECT{};
    outMaximized = false;

    if (! settings)
    {
        return false;
    }

    const auto it = settings->windows.find(std::wstring(windowId));
    if (it == settings->windows.end())
    {
        return false;
    }

    const Common::Settings::WindowPlacement normalized = Common::Settings::NormalizeWindowPlacement(it->second, currentDpi);
    outRect.left                                       = normalized.bounds.x;
    outRect.top                                        = normalized.bounds.y;
    outRect.right                                      = normalized.bounds.x + std::max(1, normalized.bounds.width);
    outRect.bottom                                     = normalized.bounds.y + std::max(1, normalized.bounds.height);
    outMaximized                                       = normalized.state == Common::Settings::WindowState::Maximized;
    return true;
}

void SaveFileOperationsWindowPlacement(Common::Settings::Settings* settings, std::wstring_view windowId, HWND hwnd) noexcept
{
    if (! settings || windowId.empty() || ! hwnd || IsIconic(hwnd))
    {
        return;
    }
    WindowPlacementPersistence::Save(*settings, windowId, hwnd);
}
} // namespace

bool FolderWindow::FileOperationState::TryGetPopupPlacement(RECT& outRect, bool& outMaximized, UINT currentDpi) const noexcept
{
    return TryGetFileOperationsWindowPlacement(_owner._settings, kFileOpsPopupWindowId, outRect, outMaximized, currentDpi);
}

bool FolderWindow::FileOperationState::TryGetPopupExpandedPlacement(RECT& outRect, UINT currentDpi) const noexcept
{
    bool maximized = false;
    return TryGetFileOperationsWindowPlacement(_owner._settings, kFileOpsPopupExpandedWindowId, outRect, maximized, currentDpi);
}

void FolderWindow::FileOperationState::SavePopupPlacement(HWND hwnd) noexcept
{
    SaveFileOperationsWindowPlacement(_owner._settings, kFileOpsPopupWindowId, hwnd);
    if (! GetPopupFooterOnly())
    {
        SaveFileOperationsWindowPlacement(_owner._settings, kFileOpsPopupExpandedWindowId, hwnd);
    }
}

void FolderWindow::FileOperationState::SavePopupExpandedPlacement(HWND hwnd) noexcept
{
    SaveFileOperationsWindowPlacement(_owner._settings, kFileOpsPopupExpandedWindowId, hwnd);
}

void FolderWindow::FileOperationState::OnPopupDestroyed(HWND hwnd) noexcept
{
    if (hwnd && _owner._settings)
    {
        SavePopupPlacement(hwnd);
        QueueSettingsSave(L"popup destroy");
    }

    std::scoped_lock lock(_mutex);
    if (_popup.get() == hwnd)
    {
        static_cast<void>(_popup.release());
    }
}

void FolderWindow::FileOperationState::OnIssuesPaneDestroyed(HWND hwnd) noexcept
{
    if (hwnd && _owner._settings)
    {
        SaveIssuesPanePlacement(hwnd);
        QueueSettingsSave(L"issues pane destroy");
    }

    std::scoped_lock lock(_mutex);
    if (_issuesPane.get() == hwnd)
    {
        static_cast<void>(_issuesPane.release());
    }
}

void FolderWindow::FileOperationState::UpdateLastPopupRect(const RECT& rect) noexcept
{
    std::scoped_lock lock(_mutex);
    _lastPopupRect = rect;
}

std::optional<RECT> FolderWindow::FileOperationState::GetLastPopupRect() noexcept
{
    std::scoped_lock lock(_mutex);
    return _lastPopupRect;
}

std::filesystem::path FolderWindow::FileOperationState::GetDiagnosticsLogDirectory() const noexcept
{
#ifdef ENABLE_TESTS
    {
        std::scoped_lock lock(_debugDiagnosticsLogRouteMutex);
        if (! _debugDiagnosticsLogDirectory.empty())
            return _debugDiagnosticsLogDirectory;
    }
#endif
    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kFileOpsAppId);
    if (settingsPath.empty())
    {
        return {};
    }

    const std::filesystem::path settingsDir = settingsPath.parent_path();
    if (settingsDir.empty())
    {
        return {};
    }

    const std::filesystem::path appRootDir = settingsDir.parent_path();
    if (appRootDir.empty())
    {
        return settingsDir / L"Logs";
    }

    // Keep diagnostics logs as a top-level sibling of Settings/Crashes.
    return appRootDir / L"Logs";
}

std::filesystem::path FolderWindow::FileOperationState::GetDiagnosticsLogPathForDate(const SYSTEMTIME& localTime) const noexcept
{
    const std::filesystem::path logsDir = GetDiagnosticsLogDirectory();
    if (logsDir.empty())
    {
        return {};
    }

    wchar_t fileName[64]{};
    constexpr size_t fileNameMax                            = (sizeof(fileName) / sizeof(fileName[0])) - 1;
    const auto r                                            = std::format_to_n(fileName,
                                                                               fileNameMax,
                                                                               L"{}{:04}{:02}{:02}{}",
                                                                               kDiagnosticsLogPrefix,
                                                                               static_cast<unsigned>(localTime.wYear),
                                                                               static_cast<unsigned>(localTime.wMonth),
                                                                               static_cast<unsigned>(localTime.wDay),
                                                                               kDiagnosticsLogExtension);
    fileName[(r.size < fileNameMax) ? r.size : fileNameMax] = L'\0';
    if (r.size > fileNameMax)
    {
        return {};
    }

    return logsDir / fileName;
}

std::filesystem::path FolderWindow::FileOperationState::GetLatestDiagnosticsLogPathUnlocked() const noexcept
{
    const std::filesystem::path logsDir = GetDiagnosticsLogDirectory();
    if (logsDir.empty())
    {
        return {};
    }

    std::error_code ec;
    std::filesystem::path newestPath;
    for (std::filesystem::directory_iterator it(logsDir, ec), end; ! ec && it != end; it.increment(ec))
    {
        const auto& de = *it;
        if (! de.is_regular_file(ec))
        {
            continue;
        }

        const std::wstring fileNameText = de.path().filename().wstring();
        if (fileNameText.size() < (kDiagnosticsLogPrefix.size() + kDiagnosticsLogExtension.size()))
        {
            continue;
        }
        if (fileNameText.rfind(kDiagnosticsLogPrefix.data(), 0) != 0)
        {
            continue;
        }
        if (de.path().extension().wstring() != kDiagnosticsLogExtension)
        {
            continue;
        }

        if (newestPath.empty() || de.path().filename().wstring() > newestPath.filename().wstring())
        {
            newestPath = de.path();
        }
    }

    return newestPath;
}

void FolderWindow::FileOperationState::FlushDiagnostics(bool force) noexcept
{
    const DiagnosticsSettings diagnosticsSettings = GetDiagnosticsSettingsFromSettings(_owner._settings);
    std::vector<TaskDiagnosticEntry> pending;
    ULONGLONG nowTick = GetTickCount64();

    {
        std::scoped_lock lock(_diagnosticsMutex);

        const bool flushIntervalReached =
            _lastDiagnosticsFlushTick == 0 ||
            (nowTick >= _lastDiagnosticsFlushTick && (nowTick - _lastDiagnosticsFlushTick) >= diagnosticsSettings.diagnosticsFlushIntervalMs);

        if (! force && ! flushIntervalReached && _diagnosticsPendingFlush.size() < diagnosticsSettings.maxDiagnosticsPerFlush)
        {
            return;
        }

        if (_diagnosticsPendingFlush.empty())
        {
            return;
        }

        pending.assign(std::make_move_iterator(_diagnosticsPendingFlush.begin()), std::make_move_iterator(_diagnosticsPendingFlush.end()));
        _diagnosticsPendingFlush.clear();
        _lastDiagnosticsFlushTick = nowTick;
    }

    const auto requeuePending = [&](size_t startIndex) noexcept
    {
        if (startIndex >= pending.size())
        {
            return;
        }

        std::scoped_lock lock(_diagnosticsMutex);
        const auto startIt = std::next(pending.begin(), static_cast<std::ptrdiff_t>(startIndex));
        _diagnosticsPendingFlush.insert(_diagnosticsPendingFlush.begin(), std::make_move_iterator(startIt), std::make_move_iterator(pending.end()));
    };

    SYSTEMTIME localNow{};
    GetLocalTime(&localNow);
    const std::filesystem::path logPath = GetDiagnosticsLogPathForDate(localNow);
    if (logPath.empty())
    {
        requeuePending(0);
        return;
    }

    const std::filesystem::path logsDir = logPath.parent_path();

    std::error_code ec;
    std::filesystem::create_directories(logsDir, ec);
    if (ec)
    {
        requeuePending(0);
        return;
    }

    wil::unique_handle file(CreateFileW(
        logPath.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr));
    if (! file)
    {
        requeuePending(0);
        return;
    }

    LARGE_INTEGER fileSize{};
    bool shouldWriteBom = false;
    if (GetFileSizeEx(file.get(), &fileSize) && fileSize.QuadPart == 0)
    {
        shouldWriteBom = true;
    }

    if (SetFilePointer(file.get(), 0, nullptr, FILE_END) == INVALID_SET_FILE_POINTER && GetLastError() != NO_ERROR)
    {
        requeuePending(0);
        return;
    }

    if (shouldWriteBom)
    {
        constexpr wchar_t bom = 0xFEFF;
        DWORD written         = 0;
        if (! WriteFile(file.get(), &bom, sizeof(bom), &written, nullptr) || written != sizeof(bom))
        {
            requeuePending(0);
            return;
        }
    }

    for (size_t index = 0; index < pending.size(); ++index)
    {
        const TaskDiagnosticEntry& entry = pending[index];
        const wchar_t* categoryText      = entry.category.empty() ? L"general" : entry.category.c_str();
        const unsigned long hrU32        = static_cast<unsigned long>(entry.status);

        const std::wstring timeText = std::format(L"{:04}-{:02}-{:02} {:02}:{:02}:{:02}.{:03}",
                                                  static_cast<unsigned>(entry.localTime.wYear),
                                                  static_cast<unsigned>(entry.localTime.wMonth),
                                                  static_cast<unsigned>(entry.localTime.wDay),
                                                  static_cast<unsigned>(entry.localTime.wHour),
                                                  static_cast<unsigned>(entry.localTime.wMinute),
                                                  static_cast<unsigned>(entry.localTime.wSecond),
                                                  static_cast<unsigned>(entry.localTime.wMilliseconds));
        const std::wstring hrHex    = std::format(L"0x{:08X}", hrU32);

        const std::wstring escapedCategory        = EscapeDiagnosticJsonString(categoryText);
        const std::wstring escapedMessage         = EscapeDiagnosticJsonString(entry.message);
        const std::wstring escapedSource          = EscapeDiagnosticJsonString(entry.sourcePath);
        const std::wstring escapedDest            = EscapeDiagnosticJsonString(entry.destinationPath);
        const std::wstring escapedHrName          = EscapeDiagnosticJsonString(FormatDiagnosticHresultName(entry.status));
        const std::wstring escapedConcurrencyMode = EscapeDiagnosticJsonString(entry.concurrencyMode);
        const std::wstring escapedStorageType     = EscapeDiagnosticJsonString(entry.storageType);
        const std::wstring escapedDestStorageType = EscapeDiagnosticJsonString(entry.destinationStorageType);

        std::wstring escapedHrText;
        if (entry.status != S_OK)
        {
            escapedHrText = EscapeDiagnosticJsonString(FormatDiagnosticStatusText(entry.status));
        }

        std::wstring line;
        line.reserve(256u + timeText.size() + hrHex.size() + escapedHrName.size() + escapedCategory.size() + escapedMessage.size() + escapedSource.size() +
                     escapedDest.size() + escapedHrText.size());

        line.append(L"{\"ts\":\"");
        line.append(timeText);
        line.append(L"\",\"level\":\"");
        line.append(DiagnosticSeverityToString(entry.severity));
        line.append(L"\",\"task\":");
        line.append(std::to_wstring(static_cast<unsigned long long>(entry.taskId)));
        line.append(L",\"op\":\"");
        line.append(OperationToString(entry.operation));
        line.append(L"\",\"category\":\"");
        line.append(escapedCategory);
        line.append(L"\",\"hr\":\"");
        line.append(hrHex);
        line.append(L"\",\"hrName\":\"");
        line.append(escapedHrName);
        line.append(L"\"");
        if (! escapedHrText.empty())
        {
            line.append(L",\"hrText\":\"");
            line.append(escapedHrText);
            line.append(L"\"");
        }
        if (entry.processWorkingSetBytes != 0 || entry.processPrivateBytes != 0)
        {
            line.append(L",\"memWorkingSetBytes\":");
            line.append(std::to_wstring(entry.processWorkingSetBytes));
            line.append(L",\"memPrivateBytes\":");
            line.append(std::to_wstring(entry.processPrivateBytes));
        }
        if (! entry.concurrencyMode.empty())
        {
            line.append(L",\"concurrencyMode\":\"");
            line.append(escapedConcurrencyMode);
            line.append(L"\"");
        }
        if (! entry.storageType.empty())
        {
            line.append(L",\"storageType\":\"");
            line.append(escapedStorageType);
            line.append(L"\"");
        }
        if (! entry.destinationStorageType.empty())
        {
            line.append(L",\"destinationStorageType\":\"");
            line.append(escapedDestStorageType);
            line.append(L"\"");
        }
        if (entry.autoTunedConcurrency != 0)
        {
            line.append(L",\"autoTunedConcurrency\":");
            line.append(std::to_wstring(entry.autoTunedConcurrency));
        }
        if (entry.effectiveConcurrencyBudget != 0)
        {
            line.append(L",\"effectiveConcurrencyBudget\":");
            line.append(std::to_wstring(entry.effectiveConcurrencyBudget));
        }
        line.append(L",\"message\":\"");
        line.append(escapedMessage);
        line.append(L"\"");

        if (! entry.sourcePath.empty())
        {
            line.append(L",\"src\":\"");
            line.append(escapedSource);
            line.append(L"\"");

            const std::wstring_view leaf = GetPathLeaf(entry.sourcePath);
            if (! leaf.empty())
            {
                line.append(L",\"srcLeaf\":\"");
                line.append(EscapeDiagnosticJsonString(leaf));
                line.append(L"\"");
            }
        }
        else
        {
            line.append(L",\"src\":null");
        }

        if (! entry.destinationPath.empty())
        {
            line.append(L",\"dst\":\"");
            line.append(escapedDest);
            line.append(L"\"");

            const std::wstring_view leaf = GetPathLeaf(entry.destinationPath);
            if (! leaf.empty())
            {
                line.append(L",\"dstLeaf\":\"");
                line.append(EscapeDiagnosticJsonString(leaf));
                line.append(L"\"");
            }
        }
        else
        {
            line.append(L",\"dst\":null");
        }

        if (entry.conflictPrompt.has_value())
        {
            line.append(L",\"conflictPrompt\":");
            line.append(ConflictPromptJson(entry.conflictPrompt.value()));
        }
        if (entry.acceptedDecision.has_value())
        {
            line.append(L",\"acceptedDecision\":");
            line.append(AcceptedDecisionJson(entry.acceptedDecision.value()));
        }
        if (entry.conflictResult.has_value())
        {
            line.append(L",\"conflictResult\":");
            line.append(FileOperations::FormatConflictResultDiagnostic(entry.conflictResult.value()));
        }
        line.append(L"}\r\n");

        const size_t bytesToWrite = line.size() * sizeof(wchar_t);
        if (bytesToWrite > static_cast<size_t>(std::numeric_limits<DWORD>::max()))
        {
            continue;
        }

        DWORD written = 0;
        if (! WriteFile(file.get(), line.data(), static_cast<DWORD>(bytesToWrite), &written, nullptr) || written != static_cast<DWORD>(bytesToWrite))
        {
            requeuePending(index);
            return;
        }
    }

    bool runCleanup = force;
    {
        std::scoped_lock lock(_diagnosticsMutex);
        if (! runCleanup)
        {
            runCleanup = _lastDiagnosticsCleanupTick == 0 || (nowTick >= _lastDiagnosticsCleanupTick &&
                                                              (nowTick - _lastDiagnosticsCleanupTick) >= diagnosticsSettings.diagnosticsCleanupIntervalMs);
        }
        if (runCleanup)
        {
            _lastDiagnosticsCleanupTick = nowTick;
        }
    }

    if (! runCleanup)
    {
        return;
    }

    CleanupDiagnosticsFilesInDirectory(logsDir, kDiagnosticsLogPrefix, kDiagnosticsLogExtension, diagnosticsSettings.maxDiagnosticsLogFiles);
    CleanupDiagnosticsFilesInDirectory(
        logsDir, kDiagnosticsIssueReportPrefix, kDiagnosticsIssueReportExtension, diagnosticsSettings.maxDiagnosticsIssueReportFiles);
}

void FolderWindow::FileOperationState::RecordTaskDiagnostic(uint64_t taskId,
                                                            FileSystemOperation operation,
                                                            DiagnosticSeverity severity,
                                                            HRESULT status,
                                                            std::wstring_view category,
                                                            std::wstring_view message,
                                                            std::wstring_view sourcePath,
                                                            std::wstring_view destinationPath) noexcept
{
    const DiagnosticsSettings diagnosticsSettings = GetDiagnosticsSettingsFromSettings(_owner._settings);
    if (severity == DiagnosticSeverity::Info && ! diagnosticsSettings.infoEnabled)
    {
        return;
    }
    if (severity == DiagnosticSeverity::Debug && ! diagnosticsSettings.debugEnabled)
    {
        return;
    }

    TaskDiagnosticEntry entry{};
    GetLocalTime(&entry.localTime);
    entry.taskId    = taskId;
    entry.operation = operation;
    entry.severity  = severity;
    entry.status    = status;
    if (severity == DiagnosticSeverity::Debug || severity == DiagnosticSeverity::Error)
    {
        const ProcessMemorySnapshot snapshot = CaptureProcessMemorySnapshot();
        entry.processWorkingSetBytes         = snapshot.workingSetBytes;
        entry.processPrivateBytes            = snapshot.privateBytes;
    }
    entry.category        = std::wstring(category);
    entry.message         = std::wstring(message);
    entry.sourcePath      = std::wstring(sourcePath);
    entry.destinationPath = std::wstring(destinationPath);
    EnqueueTaskDiagnostic(std::move(entry));
}

void FolderWindow::FileOperationState::EnqueueTaskDiagnostic(TaskDiagnosticEntry entry) noexcept
{
    const DiagnosticsSettings diagnosticsSettings = GetDiagnosticsSettingsFromSettings(_owner._settings);
    if (entry.severity == DiagnosticSeverity::Info && ! diagnosticsSettings.infoEnabled && ! entry.acceptedDecision.has_value() &&
        ! entry.conflictResult.has_value())
    {
        return;
    }
    if (entry.severity == DiagnosticSeverity::Debug && ! diagnosticsSettings.debugEnabled)
    {
        return;
    }

    if (entry.localTime.wYear == 0)
    {
        GetLocalTime(&entry.localTime);
    }

    if ((entry.severity == DiagnosticSeverity::Debug || entry.severity == DiagnosticSeverity::Error) && entry.processWorkingSetBytes == 0 &&
        entry.processPrivateBytes == 0)
    {
        const ProcessMemorySnapshot snapshot = CaptureProcessMemorySnapshot();
        entry.processWorkingSetBytes         = snapshot.workingSetBytes;
        entry.processPrivateBytes            = snapshot.privateBytes;
    }

    const ULONGLONG nowTick = GetTickCount64();
    bool shouldFlush        = false;
    {
        std::scoped_lock lock(_diagnosticsMutex);

        _diagnosticsInMemory.push_back(entry);
        while (_diagnosticsInMemory.size() > diagnosticsSettings.maxDiagnosticsInMemory)
        {
            _diagnosticsInMemory.pop_front();
        }

        _diagnosticsPendingFlush.push_back(entry);
        const size_t maxPendingFlush = std::max(diagnosticsSettings.maxDiagnosticsInMemory, diagnosticsSettings.maxDiagnosticsPerFlush);
        if (_diagnosticsPendingFlush.size() > maxPendingFlush)
        {
            const size_t overflow = _diagnosticsPendingFlush.size() - maxPendingFlush;
            _diagnosticsPendingFlush.erase(_diagnosticsPendingFlush.begin(), _diagnosticsPendingFlush.begin() + static_cast<std::ptrdiff_t>(overflow));
        }

        if (entry.severity == DiagnosticSeverity::Warning || entry.severity == DiagnosticSeverity::Error)
        {
            auto& counts = _taskDiagnosticCounts[entry.taskId];
            if (entry.severity == DiagnosticSeverity::Warning)
            {
                ++counts.first;
            }
            else
            {
                ++counts.second;
            }

            if (! entry.message.empty())
            {
                _taskLastDiagnosticMessage[entry.taskId] = entry.message;
            }
        }
        if (entry.severity == DiagnosticSeverity::Warning || entry.severity == DiagnosticSeverity::Error || entry.acceptedDecision.has_value() ||
            entry.conflictResult.has_value())
        {
            auto& issues = _taskIssueDiagnostics[entry.taskId];
            issues.push_back(entry);
            while (issues.size() > kMaxTaskIssueDiagnostics)
            {
                issues.pop_front();
            }
        }

        const bool flushIntervalReached =
            _lastDiagnosticsFlushTick == 0 ||
            (nowTick >= _lastDiagnosticsFlushTick && (nowTick - _lastDiagnosticsFlushTick) >= diagnosticsSettings.diagnosticsFlushIntervalMs);
        shouldFlush = flushIntervalReached || _diagnosticsPendingFlush.size() >= diagnosticsSettings.maxDiagnosticsPerFlush;
    }

    if (shouldFlush)
    {
        FlushDiagnostics(false);
    }
}

FolderWindow::FileOperationState::CompletedTaskSummary FolderWindow::FileOperationState::RecordCompletedTask(Task& task) noexcept
{
    const auto selectedAdmission = task.LoadSelectedAdmission();
    CompletedTaskSummary summary{};
    SYSTEMTIME localNow{};
    GetLocalTime(&localNow);
    summary.taskId                                   = task._taskId;
    summary.operation                                = task._operation;
    summary.sourcePane                               = task._sourcePane;
    summary.sourcePluginId                           = task._sourcePluginId;
    summary.sourcePluginShortId                      = task._sourcePluginShortId;
    summary.sourceInstanceContext                    = task._sourceInstanceContext;
    summary.destinationPane                          = selectedAdmission->destination->pane;
    summary.destinationPluginId                      = selectedAdmission->destination->pluginId;
    summary.destinationPluginShortId                 = selectedAdmission->destination->pluginShortId;
    summary.destinationInstanceContext               = selectedAdmission->destination->instanceContext;
    summary.destinationFolder                        = selectedAdmission->destination->folder;
    summary.flags                                    = task._flags;
    summary.diagnosticsLogPath                       = GetDiagnosticsLogPathForDate(localNow);
    summary.resultHr                                 = task.GetResult();
    summary.completedTick                            = GetTickCount64();
    const PublishedProgressSnapshot progressSnapshot = LoadPublishedProgressSnapshot(task);
    summary.totalItems                               = progressSnapshot.totalItems;
    summary.completedItems                           = progressSnapshot.completedItems;
    summary.totalBytes                               = progressSnapshot.totalBytes;
    summary.completedBytes                           = progressSnapshot.completedBytes;
    summary.discoverySkipped                         = task._discoverySkipped.load(std::memory_order_acquire);
    summary.discoveryClosed                          = task._discoveryClosed.load(std::memory_order_acquire);
    summary.completedFiles                           = progressSnapshot.completedFiles;
    summary.completedFolders                         = progressSnapshot.completedFolders;
    summary.autoConcurrencyUsed                      = task._autoConcurrencyUsed.load(std::memory_order_acquire);
    summary.autoConcurrencyStorageKind               = task._autoConcurrencyStorageKind.load(std::memory_order_acquire);
    summary.autoConcurrencyDestinationStorageKind    = task._autoConcurrencyDestinationStorageKind.load(std::memory_order_acquire);
    summary.autoTunedConcurrency                     = task._autoTunedConcurrency.load(std::memory_order_acquire);
    summary.effectiveConcurrencyBudget               = task._effectiveConcurrencyBudget.load(std::memory_order_acquire);
    summary.clipboardMoveAdmission                   = task._clipboardMoveAdmission;
    summary.clipboardMoveConsumed                    = task._clipboardMoveConsumed.load(std::memory_order_acquire);
    summary.clipboardMoveConsumptionStatus           = task._clipboardMoveConsumptionStatus.load(std::memory_order_acquire);

    bool anySkipped = false;
    {
        std::scoped_lock lock(task._sourceItemStatusMutex);
        const auto increment = [](unsigned long& value) noexcept
        {
            if (value < std::numeric_limits<unsigned long>::max())
            {
                ++value;
            }
        };
        for (size_t sourceIndex = 0u; sourceIndex < task._sourceItemResultBuilders.size(); ++sourceIndex)
        {
            const std::optional<FileOperations::FileOperationItemResult>& item = task._sourceItemResultBuilders[sourceIndex].terminal;
            if (! item.has_value())
            {
                increment(summary.unknownPublicationItemCount);
                increment(summary.unknownSourceCount);
                increment(summary.indeterminateItemCount);
                if (sourceIndex < task._sourcePaths.size())
                {
                    summary.unknownSourcePaths.push_back(task._sourcePaths[sourceIndex]);
                }
                continue;
            }
            if (item->publication == FileOperations::PublicationState::Published)
            {
                increment(summary.publishedItemCount);
            }
            else if (item->publication == FileOperations::PublicationState::Unknown)
            {
                increment(summary.unknownPublicationItemCount);
            }
            // A resolved DirectoryShell publishes a folder and moves no source object: it is a merge
            // instruction, neither a removed nor a kept source.
            const bool mergeInstruction =
                sourceIndex < selectedAdmission->destination->resolvedItems.size() &&
                selectedAdmission->destination->resolvedItems[sourceIndex].kind == FolderWindow::ResolvedFileOperationItemKind::DirectoryShell;
            if (! mergeInstruction)
            {
                switch (item->sourceDisposition)
                {
                    case FileOperations::SourceDisposition::Removed: increment(summary.removedSourceCount); break;
                    case FileOperations::SourceDisposition::Retained:
                    {
                        increment(summary.retainedSourceCount);
                        if (item->strategy == FileOperations::OperationStrategy::Native)
                        {
                            increment(summary.retainedSourceNativeCount);
                        }
                        std::filesystem::path retainedPath(item->finalSourcePath);
                        if (retainedPath.empty() && sourceIndex < task._sourcePaths.size())
                        {
                            retainedPath = task._sourcePaths[sourceIndex];
                        }
                        if (! retainedPath.empty())
                        {
                            summary.retainedSourcePaths.push_back(retainedPath);
                            if (item->retainedSourceIdentity.has_value())
                            {
                                summary.exactRetainedSourceItems.push_back(CompletedTaskSummary::RetainedSourceActionItem{
                                    .providerPath = std::move(retainedPath),
                                    .identity     = item->retainedSourceIdentity.value(),
                                });
                            }
                        }
                        break;
                    }
                    case FileOperations::SourceDisposition::Unknown:
                    {
                        increment(summary.unknownSourceCount);
                        std::filesystem::path unknownPath(item->finalSourcePath);
                        if (unknownPath.empty() && sourceIndex < task._sourcePaths.size())
                        {
                            unknownPath = task._sourcePaths[sourceIndex];
                        }
                        if (! unknownPath.empty())
                        {
                            summary.unknownSourcePaths.push_back(std::move(unknownPath));
                        }
                        break;
                    }
                }
            }
            if (item->verification == FileOperations::VerificationState::Verified)
            {
                increment(summary.verifiedItemCount);
            }
            else if (item->verification == FileOperations::VerificationState::Failed || item->verification == FileOperations::VerificationState::Unavailable ||
                     item->verification == FileOperations::VerificationState::Canceled)
            {
                increment(summary.verificationProblemItemCount);
                if (item->verification == FileOperations::VerificationState::Failed)
                {
                    increment(summary.verificationFailedItemCount);
                }
                else if (item->verification == FileOperations::VerificationState::Unavailable)
                {
                    increment(summary.verificationUnavailableItemCount);
                }
                else
                {
                    increment(summary.verificationCanceledItemCount);
                }
            }
            anySkipped = anySkipped || item->completion == FileOperations::ItemCompletion::Skipped;
            if (item->ownedStageDisposition == FileOperations::OwnedStageDisposition::Retained ||
                item->ownedStageDisposition == FileOperations::OwnedStageDisposition::RetainedIncomplete)
            {
                increment(summary.retainedOwnedStageCount);
            }
            else if (item->ownedStageDisposition == FileOperations::OwnedStageDisposition::Unknown)
            {
                increment(summary.unknownOwnedStageCount);
            }
            if (item->completion == FileOperations::ItemCompletion::Indeterminate || item->publication == FileOperations::PublicationState::Unknown ||
                item->sourceDisposition == FileOperations::SourceDisposition::Unknown)
            {
                increment(summary.indeterminateItemCount);
            }
        }
    }

    if (summary.unknownPublicationItemCount > 0u || summary.unknownSourceCount > 0u)
    {
        summary.resultSummary = LoadStringResource(nullptr, IDS_FILEOPS_RESULT_UNKNOWN);
    }
    else if (summary.verificationFailedItemCount > 0u)
    {
        summary.resultSummary = LoadStringResource(nullptr, IDS_FILEOPS_RESULT_VERIFICATION_FAILED);
    }
    else if (summary.verificationCanceledItemCount > 0u)
    {
        summary.resultSummary = LoadStringResource(nullptr, IDS_FILEOPS_RESULT_VERIFICATION_CANCELED);
    }
    else if (summary.verificationUnavailableItemCount > 0u)
    {
        summary.resultSummary = LoadStringResource(nullptr, IDS_FILEOPS_RESULT_VERIFICATION_UNAVAILABLE);
    }
    else if (summary.indeterminateItemCount == 0u && summary.retainedOwnedStageCount > 0u)
    {
        summary.resultSummary = LoadStringResource(nullptr, IDS_FILEOPS_RESULT_COMPLETED_CLEANUP_RETAINED);
    }
    else if (summary.verifiedItemCount > 0u && summary.verificationProblemItemCount == 0u && summary.operation == FILESYSTEM_COPY)
    {
        summary.resultSummary = LoadStringResource(nullptr, IDS_FILEOPS_RESULT_VERIFIED);
    }
    else if (summary.operation == FILESYSTEM_MOVE && summary.publishedItemCount > 0u && summary.retainedSourceCount > 0u)
    {
        summary.resultSummary =
            LoadStringResource(nullptr,
                               summary.retainedSourceNativeCount == summary.retainedSourceCount ? IDS_FILEOPS_RESULT_MOVED_SOURCE_FOLDER_KEPT
                                                                                                : IDS_FILEOPS_RESULT_COPIED_SOURCE_KEPT);
    }
    else if (anySkipped && summary.publishedItemCount == 0u)
    {
        summary.resultSummary = LoadStringResource(nullptr, IDS_FILEOPS_RESULT_SKIPPED);
    }
    else if (summary.operation == FILESYSTEM_COPY && summary.publishedItemCount > 0u)
    {
        summary.resultSummary = LoadStringResource(nullptr, IDS_FILEOPS_RESULT_COPIED);
    }
    else if ((summary.operation == FILESYSTEM_MOVE || summary.operation == FILESYSTEM_RENAME) && summary.removedSourceCount > 0u)
    {
        summary.resultSummary = LoadStringResource(nullptr, IDS_FILEOPS_RESULT_MOVED);
    }

    {
        std::scoped_lock lock(task._progressPathMutex);
        summary.lastProgressCallbackTick = task._lastProgressCallbackTick;
        summary.sourcePath               = task._progressSourcePath;
        summary.destinationPath          = task._progressDestinationPath;
    }

    if ((summary.operation == FILESYSTEM_COPY || summary.operation == FILESYSTEM_MOVE) && summary.destinationPane.has_value() &&
        ! summary.destinationFolder.empty() && task._sourcePaths.size() == 1u)
    {
        const bool destinationPathOnlyNamesFolder =
            summary.destinationPath.empty() || NavigationLocation::EqualsNoCase(summary.destinationPath, summary.destinationFolder.native());
        if (destinationPathOnlyNamesFolder)
        {
            if (selectedAdmission->destination->resolvedItems.size() == task._sourcePaths.size() &&
                ! selectedAdmission->destination->resolvedItems.front().destinationPath.empty())
            {
                summary.destinationPath = selectedAdmission->destination->resolvedItems.front().destinationPath.native();
            }
            else
            {
                summary.destinationPath = JoinFolderAndLeaf(summary.destinationFolder.native(), GetPathLeaf(task._sourcePaths.front().native()));
            }
        }
    }

    {
        std::scoped_lock lock(_diagnosticsMutex);
        const auto countsIt = _taskDiagnosticCounts.find(summary.taskId);
        if (countsIt != _taskDiagnosticCounts.end())
        {
            summary.warningCount = countsIt->second.first;
            summary.errorCount   = countsIt->second.second;
            _taskDiagnosticCounts.erase(countsIt);
        }

        const auto messageIt = _taskLastDiagnosticMessage.find(summary.taskId);
        if (messageIt != _taskLastDiagnosticMessage.end())
        {
            summary.lastDiagnosticMessage = messageIt->second;
            _taskLastDiagnosticMessage.erase(messageIt);
        }

        const auto issuesIt = _taskIssueDiagnostics.find(summary.taskId);
        if (issuesIt != _taskIssueDiagnostics.end())
        {
            summary.issueDiagnostics.assign(issuesIt->second.begin(), issuesIt->second.end());
            _taskIssueDiagnostics.erase(issuesIt);
        }
    }

    if (summary.clipboardMoveAdmission && (summary.retainedSourceCount > 0u || summary.unknownSourceCount > 0u))
    {
        if (summary.warningCount == 0u)
        {
            summary.warningCount = 1u;
        }
        if (summary.clipboardMoveConsumed && summary.unknownSourceCount > 0u)
        {
            summary.lastDiagnosticMessage = LoadStringResource(nullptr, IDS_FILEOPS_CLIPBOARD_SOURCE_UNKNOWN);
        }
        else if (summary.clipboardMoveConsumed)
        {
            summary.lastDiagnosticMessage = LoadStringResource(nullptr, IDS_FILEOPS_CLIPBOARD_SOURCES_REMAIN);
        }
        else if (summary.lastDiagnosticMessage.empty())
        {
            summary.lastDiagnosticMessage = LoadStringResource(nullptr, IDS_FILEOPS_CLIPBOARD_MOVE_CLEAR_FAILED);
        }
    }

    if (FAILED(summary.resultHr) && summary.warningCount == 0 && summary.errorCount == 0)
    {
        const HRESULT partialHr = HRESULT_FROM_WIN32(ERROR_PARTIAL_COPY);
        if (summary.resultHr == partialHr)
        {
            summary.warningCount = 1;
            if (summary.lastDiagnosticMessage.empty())
            {
                summary.lastDiagnosticMessage = LoadStringResource(nullptr, IDS_FILEOPS_DIAG_SKIPPED_ITEMS);
            }
        }
        else if (! IsCancellationStatus(summary.resultHr))
        {
            summary.errorCount = 1;
            if (summary.lastDiagnosticMessage.empty())
            {
                summary.lastDiagnosticMessage =
                    FormatStringResource(nullptr, IDS_FMT_FILEOPS_DIAG_FAILED_NO_DETAILS, static_cast<unsigned long>(summary.resultHr));
            }
        }
    }

    if ((summary.warningCount > 0 || summary.errorCount > 0) && summary.issueDiagnostics.empty())
    {
        TaskDiagnosticEntry synthetic{};
        synthetic.localTime       = localNow;
        synthetic.taskId          = summary.taskId;
        synthetic.operation       = summary.operation;
        synthetic.severity        = summary.errorCount > 0 ? DiagnosticSeverity::Error : DiagnosticSeverity::Warning;
        synthetic.status          = summary.resultHr;
        synthetic.category        = L"task.summary";
        synthetic.message         = summary.lastDiagnosticMessage.empty() ? L"Task completed with diagnostics." : summary.lastDiagnosticMessage;
        synthetic.sourcePath      = summary.sourcePath;
        synthetic.destinationPath = summary.destinationPath;
        summary.issueDiagnostics.push_back(std::move(synthetic));
    }

    std::wstring completedStatus = L"success";
    if (summary.resultHr == S_FALSE || summary.resultHr == HRESULT_FROM_WIN32(ERROR_PARTIAL_COPY))
    {
        completedStatus = L"partial";
    }
    else if (IsCancellationStatus(summary.resultHr))
    {
        completedStatus = L"canceled";
    }
    else if (FAILED(summary.resultHr))
    {
        completedStatus = L"failed";
    }

    const std::wstring completedMessage = std::format(L"Task completed: status={}, op={}, hr=0x{:08X}, items={:L}/{:L}, bytes={:L}/{:L}.",
                                                      completedStatus,
                                                      OperationToString(summary.operation),
                                                      static_cast<unsigned long>(summary.resultHr),
                                                      summary.completedItems,
                                                      summary.totalItems,
                                                      summary.completedBytes,
                                                      summary.totalBytes);
    RecordTaskDiagnostic(summary.taskId,
                         summary.operation,
                         DiagnosticSeverity::Info,
                         summary.resultHr,
                         L"task.completed",
                         completedMessage,
                         summary.sourcePath,
                         summary.destinationPath);

    const bool autoConcurrencyUsed                = task._autoConcurrencyUsed.load(std::memory_order_acquire);
    const uint32_t autoStorageKind                = task._autoConcurrencyStorageKind.load(std::memory_order_acquire);
    const uint32_t destinationStorageKind         = task._autoConcurrencyDestinationStorageKind.load(std::memory_order_acquire);
    const unsigned int autoTunedConcurrency       = task._autoTunedConcurrency.load(std::memory_order_acquire);
    const unsigned int effectiveConcurrencyBudget = task._effectiveConcurrencyBudget.load(std::memory_order_acquire);

    if (autoConcurrencyUsed && autoTunedConcurrency > 0u)
    {
        TaskDiagnosticEntry autoEntry{};
        autoEntry.taskId               = summary.taskId;
        autoEntry.operation            = summary.operation;
        autoEntry.severity             = DiagnosticSeverity::Info;
        autoEntry.status               = summary.resultHr;
        autoEntry.category             = L"task.autoConcurrency";
        autoEntry.message              = std::format(L"Resolved {} concurrency: storageType={}, autoTunedConcurrency={:L}, effectiveConcurrencyBudget={:L}.",
                                                     ConcurrencyModeToString(FileSystemConcurrencyMode::Auto),
                                                     StorageKindToString(autoStorageKind),
                                                     static_cast<unsigned long>(autoTunedConcurrency),
                                                     static_cast<unsigned long>(effectiveConcurrencyBudget));
        autoEntry.sourcePath           = summary.sourcePath;
        autoEntry.destinationPath      = summary.destinationPath;
        autoEntry.concurrencyMode      = ConcurrencyModeToString(FileSystemConcurrencyMode::Auto);
        autoEntry.storageType          = StorageKindToString(autoStorageKind);
        autoEntry.autoTunedConcurrency = autoTunedConcurrency;
        autoEntry.effectiveConcurrencyBudget = effectiveConcurrencyBudget;
        if (destinationStorageKind != FILESYSTEM_STORAGE_UNKNOWN)
        {
            autoEntry.destinationStorageType = StorageKindToString(destinationStorageKind);
        }
        EnqueueTaskDiagnostic(std::move(autoEntry));
    }

    const bool cleanCompletion = summary.resultHr == S_OK && summary.warningCount == 0u && summary.errorCount == 0u && summary.indeterminateItemCount == 0u;
    const bool inlineRenameSilentCompletion = task._suppressCleanCompletionSummary && cleanCompletion && summary.operation == FILESYSTEM_RENAME &&
                                              summary.publishedItemCount == 1u && summary.removedSourceCount == 1u && summary.retainedSourceCount == 0u &&
                                              summary.unknownSourceCount == 0u;
    const bool routineSilentPresentation    = ! task._suppressCleanCompletionSummary && cleanCompletion;
    bool completedWhilePresentationHidden   = false;
    if (inlineRenameSilentCompletion || routineSilentPresentation)
    {
        Task::TaskPresentationState expected = Task::TaskPresentationState::Hidden;
        completedWhilePresentationHidden     = task._presentationState.compare_exchange_strong(
            expected, Task::TaskPresentationState::SuppressedCleanSuccess, std::memory_order_acq_rel, std::memory_order_acquire);
        if (completedWhilePresentationHidden)
        {
            const ULONGLONG admittedTick              = task._presentationDeadlineTick >= FileOperations::kTaskCardRevealDelayMs
                                                            ? task._presentationDeadlineTick - FileOperations::kTaskCardRevealDelayMs
                                                            : 0u;
            const ULONGLONG completedPresentationTick = TaskPresentationNowTick();
            Debug::Perf::Emit(L"FileOps.TaskPresentation.SilentCleanSuccessMs",
                              L"hidden-completion",
                              completedPresentationTick >= admittedTick ? completedPresentationTick - admittedTick : 0u,
                              FileOperations::kTaskCardRevealDelayMs,
                              1u,
                              S_OK);
            if (inlineRenameSilentCompletion)
            {
                Debug::Perf::Emit(L"FileOps.InlineRename.SilentCleanSuccessMs",
                                  L"hidden-completion",
                                  completedPresentationTick >= admittedTick ? completedPresentationTick - admittedTick : 0u,
                                  FileOperations::kInlineRenameCardRevealDelayMs,
                                  1u,
                                  S_OK);
            }
        }
#ifdef ENABLE_TESTS
        if (completedWhilePresentationHidden && inlineRenameSilentCompletion)
        {
            _debugInlineRenameSilentCleanCompletionCount.fetch_add(1u, std::memory_order_relaxed);
        }
#endif
    }

    const bool suppressCompletedSummary = completedWhilePresentationHidden && inlineRenameSilentCompletion;
    if (! suppressCompletedSummary)
    {
        if (! completedWhilePresentationHidden)
        {
            task.RequestPresentationReveal();
        }
        std::scoped_lock lock(_mutex);
        _completedTasks.push_front(summary);
        while (_completedTasks.size() > kMaxCompletedTaskSummaries)
        {
            _completedTasks.pop_back();
        }
    }

    FlushDiagnostics(true);
    return summary;
}
