// Commands.SelfTest.Settings.cpp
// Included from Commands.SelfTest.cpp — NOT compiled standalone.
// Settings test family: settings, diagnostics, and icon-cache infrastructure checks.

namespace
{
[[nodiscard]] Common::Settings::FileActionMatch TestExtensionMatch(std::wstring extension)
{
    return Common::Settings::FileActionMatch{.kind = Common::Settings::FileActionMatchKind::Extension, .value = std::move(extension)};
}

void TestSetActionExtensions(Common::Settings::FileActionDefinition& action, std::initializer_list<const wchar_t*> extensions)
{
    action.appliesTo.matches.clear();
    action.appliesTo.matches.reserve(extensions.size());
    for (const wchar_t* extension : extensions)
    {
        if (extension && extension[0] != L'\0')
        {
            action.appliesTo.matches.push_back(TestExtensionMatch(extension));
        }
    }
}

[[nodiscard]] Common::Settings::ViewerAssociationRule TestViewerAssociation(std::wstring extension,
                                                                            std::wstring viewActionId,
                                                                            std::wstring alternateViewActionId = {})
{
    Common::Settings::ViewerAssociationRule rule{};
    rule.match                 = TestExtensionMatch(std::move(extension));
    rule.viewActionId          = std::move(viewActionId);
    rule.alternateViewActionId = std::move(alternateViewActionId);
    return rule;
}

[[nodiscard]] Common::Settings::ViewerAssociationRule TestDefaultViewerAssociation(std::wstring viewActionId, std::wstring alternateViewActionId = {})
{
    Common::Settings::ViewerAssociationRule rule{};
    rule.match.kind            = Common::Settings::FileActionMatchKind::Default;
    rule.viewActionId          = std::move(viewActionId);
    rule.alternateViewActionId = std::move(alternateViewActionId);
    return rule;
}

[[nodiscard]] bool TestWriteTinyBmpFile(const std::filesystem::path& path) noexcept
{
    static constexpr std::array<unsigned char, 58> kBmp{{0x42, 0x4D, 0x3A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x36, 0x00, 0x00, 0x00, 0x28,
                                                         0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x18, 0x00,
                                                         0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x13, 0x0B, 0x00, 0x00, 0x13, 0x0B, 0x00,
                                                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0x00}};
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (! output)
    {
        return false;
    }

    output.write(reinterpret_cast<const char*>(kBmp.data()), static_cast<std::streamsize>(kBmp.size()));
    return output.good();
}

[[nodiscard]] std::string ReadSettingsTestBytes(const std::filesystem::path& path)
{
    std::ifstream input(path, std::ios::binary);
    return std::string((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
}

[[nodiscard]] HRESULT SucceedSessionEndSettingsWrite(std::wstring_view, const Common::Settings::Settings&) noexcept
{
    return S_OK;
}

[[nodiscard]] bool TestAppSessionEndPersistsRuntimeStateWithoutTeardown(HWND mainWindow, CaseState& state) noexcept
{
    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Session-end persistence requires the live main window.");
        return false;
    }

    const Common::Settings::Settings settingsBefore = g_settings;
    const FolderWindow::Pane activePaneBefore       = g_folderWindow.GetFocusedPane();
    bool menuBarToggled                             = false;
    bool functionBarToggled                         = false;
    const auto restoreState                         = wil::scope_exit([&]
    {
        if (functionBarToggled)
        {
            SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(IDM_VIEW_FUNCTIONBAR, 0), 0);
        }
        if (menuBarToggled)
        {
            SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(IDM_VIEW_MENUBAR, 0), 0);
        }
        g_folderWindow.SetActivePane(activePaneBefore);
        static_cast<void>(SetFocus(g_folderWindow.GetFolderViewHwnd(activePaneBefore)));
        g_settings = settingsBefore;
        DebugResetSessionEndSettingsSaveForSelfTest();
    });

    SendMessageW(mainWindow, WndMsg::kPreferencesRequestSettingsSnapshot, 0, 0);
    state.Require(g_settings.mainMenu.has_value(), L"Runtime snapshot should expose the current menu state before the session-end test.");
    if (! g_settings.mainMenu.has_value())
    {
        return false;
    }

    const bool menuBarVisibleBefore     = g_settings.mainMenu->menuBarVisible;
    const bool functionBarVisibleBefore = g_settings.mainMenu->functionBarVisible;
    const FolderWindow::Pane targetPane = activePaneBefore == FolderWindow::Pane::Left ? FolderWindow::Pane::Right : FolderWindow::Pane::Left;
    const std::wstring_view targetSlot  = targetPane == FolderWindow::Pane::Left ? L"left" : L"right";

    SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(IDM_VIEW_MENUBAR, 0), 0);
    menuBarToggled = true;
    SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(IDM_VIEW_FUNCTIONBAR, 0), 0);
    functionBarToggled = true;
    g_folderWindow.SetActivePane(targetPane);
    const HWND targetFolderView = g_folderWindow.GetFolderViewHwnd(targetPane);
    state.Require(targetFolderView && IsWindow(targetFolderView) != FALSE, L"Changed pane should expose a live folder-view window.");
    static_cast<void>(SetFocus(targetFolderView));
    state.Require(g_folderWindow.GetFocusedPane() == targetPane, L"Session-end test setup did not activate the requested pane.");

    DebugResetSessionEndSettingsSaveForSelfTest();
    DebugSetSessionEndSettingsWriterForSelfTest(&SucceedSessionEndSettingsWrite);

    const auto queryStartedAt      = std::chrono::steady_clock::now();
    const LRESULT queryResult      = SendMessageW(mainWindow, WM_QUERYENDSESSION, 0, ENDSESSION_CLOSEAPP);
    const uint64_t queryDurationUs = Debug::Perf::ElapsedUs(queryStartedAt);
    state.Require(queryResult == TRUE, L"WM_QUERYENDSESSION should return TRUE without entering normal close handling.");
    state.Require(queryDurationUs < 500'000u, L"WM_QUERYENDSESSION should return promptly without a modal prompt.");

    SendMessageW(mainWindow, WM_ENDSESSION, FALSE, ENDSESSION_CLOSEAPP);
    const SessionEndSettingsDebugSnapshot canceled = DebugGetSessionEndSettingsSnapshotForSelfTest();
    state.Require(canceled.writerCallCount == 0u, L"A canceled WM_ENDSESSION notification must not save settings.");
    state.Require(canceled.normalTeardownCallCount == 0u, L"A canceled WM_ENDSESSION notification must not close viewers or enter plugin shutdown.");

    SendMessageW(mainWindow, WM_ENDSESSION, TRUE, ENDSESSION_CLOSEAPP);
    SendMessageW(mainWindow, WM_ENDSESSION, TRUE, ENDSESSION_CLOSEAPP);
    const SessionEndSettingsDebugSnapshot saved = DebugGetSessionEndSettingsSnapshotForSelfTest();
    state.Require(saved.writerCallCount == 1u, L"Repeated confirmed WM_ENDSESSION delivery should perform one settings write.");
    state.Require(saved.normalTeardownCallCount == 0u, L"Confirmed WM_ENDSESSION persistence must not close viewers or enter plugin shutdown.");
    state.Require(saved.lastResult == S_OK, L"The session-end settings writer seam should report the injected successful result.");
    state.Require(saved.settings.mainMenu.has_value(), L"The session-end snapshot should contain menu state.");
    if (saved.settings.mainMenu.has_value())
    {
        state.Require(saved.settings.mainMenu->menuBarVisible == ! menuBarVisibleBefore,
                      L"The session-end snapshot should contain the changed menu-bar visibility.");
        state.Require(saved.settings.mainMenu->functionBarVisible == ! functionBarVisibleBefore,
                      L"The session-end snapshot should contain the changed function-bar visibility.");
    }
    state.Require(saved.settings.folders.has_value(), L"The session-end snapshot should contain pane state.");
    if (saved.settings.folders.has_value())
    {
        state.Require(saved.settings.folders->active == targetSlot, L"The session-end snapshot should contain the changed active pane.");
    }
    state.Require(IsWindow(mainWindow) != FALSE, L"Session-end persistence should leave the main window alive.");
    const HWND focusedFolderView = g_folderWindow.GetFocusedFolderViewHwnd();
    state.Require(focusedFolderView && IsWindow(focusedFolderView) != FALSE, L"Session-end persistence should leave the active folder view alive.");

    const std::wstring artifactText          = std::format(L"{{\n"
                                                           L"  \"scenario\": \"app/windows-session-end-settings-save\",\n"
                                                           L"  \"query_end_session_us\": {},\n"
                                                           L"  \"end_session_save_us\": {},\n"
                                                           L"  \"writer_call_count\": {},\n"
                                                           L"  \"normal_teardown_call_count\": {},\n"
                                                           L"  \"result_hr\": {}\n"
                                                           L"}}\n",
                                                           queryDurationUs,
                                                           saved.durationUs,
                                                           saved.writerCallCount,
                                                           saved.normalTeardownCallCount,
                                                           static_cast<uint32_t>(saved.lastResult));
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"session_end_settings_metrics.json");
    const bool artifactWriteOk               = ! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, artifactText);
    state.Require(artifactWriteOk && SelfTest::PathExists(artifactPath), L"Failed to write the session-end settings perf artifact.");

    return state.failure.empty();
}

[[nodiscard]] HRESULT BuildExtendedPathForPreviewPropertiesTest(const std::filesystem::path& path, std::wstring& outPath) noexcept
{
    outPath.clear();
    if (path.empty())
    {
        return E_INVALIDARG;
    }

    std::filesystem::path absolutePath = path;
    if (! absolutePath.is_absolute())
    {
        std::error_code ec;
        absolutePath = std::filesystem::absolute(path, ec);
        if (ec)
        {
            return HRESULT_FROM_WIN32(ec.value() != 0 ? static_cast<DWORD>(ec.value()) : ERROR_INVALID_NAME);
        }
    }

    absolutePath = absolutePath.lexically_normal();
    outPath      = absolutePath.wstring();
    std::replace(outPath.begin(), outPath.end(), L'/', L'\\');
    if (outPath.rfind(LR"(\\?\)", 0u) != 0u && outPath.rfind(LR"(\\.\)", 0u) != 0u)
    {
        if (outPath.rfind(LR"(\\)", 0u) == 0u)
        {
            outPath = std::wstring(LR"(\\?\UNC\)") + outPath.substr(2u);
        }
        else
        {
            outPath.insert(0u, LR"(\\?\)");
        }
    }
    return S_OK;
}

[[nodiscard]] HRESULT EnsureExtendedDirectoryForPreviewPropertiesTest(const std::filesystem::path& path) noexcept
{
    std::wstring extendedPath;
    const HRESULT pathHr = BuildExtendedPathForPreviewPropertiesTest(path, extendedPath);
    if (FAILED(pathHr))
    {
        return pathHr;
    }
    return wil::CreateDirectoryDeepNoThrow(extendedPath.c_str());
}

[[nodiscard]] HRESULT WriteExtendedTextFileForPreviewPropertiesTest(const std::filesystem::path& path, std::string_view payload) noexcept
{
    if (path.empty() || payload.size() > static_cast<size_t>((std::numeric_limits<DWORD>::max)()))
    {
        return E_INVALIDARG;
    }

    if (path.has_parent_path())
    {
        const HRESULT directoryHr = EnsureExtendedDirectoryForPreviewPropertiesTest(path.parent_path());
        if (FAILED(directoryHr))
        {
            return directoryHr;
        }
    }

    std::wstring extendedPath;
    const HRESULT pathHr = BuildExtendedPathForPreviewPropertiesTest(path, extendedPath);
    if (FAILED(pathHr))
    {
        return pathHr;
    }

    wil::unique_handle file(CreateFileW(
        extendedPath.c_str(), GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr));
    if (! file)
    {
        const DWORD lastError = GetLastError();
        return HRESULT_FROM_WIN32(lastError != ERROR_SUCCESS ? lastError : ERROR_GEN_FAILURE);
    }

    DWORD written            = 0u;
    const DWORD bytesToWrite = static_cast<DWORD>(payload.size());
    if (bytesToWrite != 0u && (WriteFile(file.get(), payload.data(), bytesToWrite, &written, nullptr) == FALSE || written != bytesToWrite))
    {
        const DWORD lastError = GetLastError();
        return HRESULT_FROM_WIN32(lastError != ERROR_SUCCESS ? lastError : ERROR_WRITE_FAULT);
    }
    return S_OK;
}

[[nodiscard]] HRESULT QueryNamedStreamSupportForPreviewPropertiesTest(const std::filesystem::path& path, bool& outSupported) noexcept
{
    outSupported = false;

    std::wstring extendedPath;
    const HRESULT pathHr = BuildExtendedPathForPreviewPropertiesTest(path, extendedPath);
    if (FAILED(pathHr))
    {
        return pathHr;
    }

    wil::unique_handle baseFile(CreateFileW(extendedPath.c_str(),
                                            FILE_READ_ATTRIBUTES,
                                            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                                            nullptr,
                                            OPEN_EXISTING,
                                            FILE_ATTRIBUTE_NORMAL,
                                            nullptr));
    if (! baseFile)
    {
        const DWORD lastError = GetLastError();
        return HRESULT_FROM_WIN32(lastError != ERROR_SUCCESS ? lastError : ERROR_GEN_FAILURE);
    }

    DWORD fileSystemFlags = 0u;
    if (GetVolumeInformationByHandleW(baseFile.get(), nullptr, 0u, nullptr, nullptr, &fileSystemFlags, nullptr, 0u) == FALSE)
    {
        const DWORD lastError = GetLastError();
        return HRESULT_FROM_WIN32(lastError != ERROR_SUCCESS ? lastError : ERROR_GEN_FAILURE);
    }

    outSupported = (fileSystemFlags & FILE_NAMED_STREAMS) != 0u;
    return S_OK;
}

[[nodiscard]] HRESULT WriteAlternateStreamForPreviewPropertiesTest(const std::filesystem::path& path,
                                                                   std::wstring_view streamName,
                                                                   std::string_view payload) noexcept
{
    if (path.empty() || streamName.empty())
    {
        return E_INVALIDARG;
    }

    std::wstring streamPath;
    const HRESULT pathHr = BuildExtendedPathForPreviewPropertiesTest(path, streamPath);
    if (FAILED(pathHr))
    {
        return pathHr;
    }
    streamPath.push_back(L':');
    streamPath.append(streamName);

    wil::unique_handle stream(CreateFileW(
        streamPath.c_str(), GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr));
    if (! stream)
    {
        const DWORD lastError = GetLastError();
        return HRESULT_FROM_WIN32(lastError != 0u ? lastError : ERROR_GEN_FAILURE);
    }

    if (payload.empty())
    {
        return S_OK;
    }
    if (payload.size() > static_cast<size_t>((std::numeric_limits<DWORD>::max)()))
    {
        return HRESULT_FROM_WIN32(ERROR_INVALID_DATA);
    }

    DWORD written            = 0u;
    const DWORD bytesToWrite = static_cast<DWORD>(payload.size());
    if (WriteFile(stream.get(), payload.data(), bytesToWrite, &written, nullptr) == 0 || written != bytesToWrite)
    {
        const DWORD lastError = GetLastError();
        return HRESULT_FROM_WIN32(lastError != 0u ? lastError : ERROR_WRITE_FAULT);
    }

    return S_OK;
}

[[nodiscard]] bool WaitForPreviewPaneText(std::wstring_view expected,
                                          std::wstring_view forbidden,
                                          FolderWindow::PreviewPaneDebugSnapshot& outSnapshot,
                                          std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(outSnapshot) && outSnapshot.previewText.find(expected) != std::wstring::npos &&
            (forbidden.empty() || outSnapshot.previewText.find(forbidden) == std::wstring::npos))
        {
            return true;
        }

        std::this_thread::sleep_for(10ms);
    }

    return false;
}

[[nodiscard]] bool WaitForMakeFileListWorkerIdle(std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        if (! DebugIsMakeFileListWorkerActive())
        {
            for (size_t index = 0u; index < 5u; ++index)
            {
                std::this_thread::sleep_for(10ms);
                PumpPendingMessages();
            }
            return ! DebugIsMakeFileListWorkerActive();
        }
        std::this_thread::sleep_for(10ms);
    }

    PumpPendingMessages();
    return ! DebugIsMakeFileListWorkerActive();
}

[[nodiscard]] bool WaitForPreviewPaneTextAndFocus(std::wstring_view expected,
                                                  std::wstring_view forbidden,
                                                  HWND expectedFocus,
                                                  FolderWindow::PreviewPaneDebugSnapshot& outSnapshot,
                                                  std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(outSnapshot) && outSnapshot.previewText.find(expected) != std::wstring::npos &&
            (forbidden.empty() || outSnapshot.previewText.find(forbidden) == std::wstring::npos) && g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus)
        {
            return true;
        }

        std::this_thread::sleep_for(10ms);
    }

    return g_folderWindow.DebugGetPreviewPaneSnapshot(outSnapshot) && outSnapshot.previewText.find(expected) != std::wstring::npos &&
           (forbidden.empty() || outSnapshot.previewText.find(forbidden) == std::wstring::npos) && g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus;
}

[[nodiscard]] bool CloseActivePreviewPaneForSelfTest(std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    FolderWindow::PreviewPaneDebugSnapshot preview{};
    if (! g_folderWindow.DebugGetPreviewPaneSnapshot(preview))
    {
        return true;
    }

    if (preview.active)
    {
        g_folderWindow.TogglePreviewPane(preview.sourcePane);
    }

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(preview) && ! preview.active && preview.previewDirectChildCount == 0u)
        {
            return true;
        }

        std::this_thread::sleep_for(10ms);
    }

    return g_folderWindow.DebugGetPreviewPaneSnapshot(preview) && ! preview.active && preview.previewDirectChildCount == 0u;
}

[[nodiscard]] Common::Settings::EditorAssociationRule TestEditorAssociation(std::wstring extension,
                                                                            std::wstring editActionId,
                                                                            std::wstring alternateEditActionId = {},
                                                                            std::wstring editNewActionId       = {})
{
    Common::Settings::EditorAssociationRule rule{};
    rule.match                 = TestExtensionMatch(std::move(extension));
    rule.editActionId          = std::move(editActionId);
    rule.alternateEditActionId = std::move(alternateEditActionId);
    rule.editNewActionId       = std::move(editNewActionId);
    return rule;
}

[[nodiscard]] Common::Settings::EditorAssociationRule TestDefaultEditorAssociation(std::wstring editActionId,
                                                                                   std::wstring alternateEditActionId = {},
                                                                                   std::wstring editNewActionId       = {})
{
    Common::Settings::EditorAssociationRule rule{};
    rule.match.kind            = Common::Settings::FileActionMatchKind::Default;
    rule.editActionId          = std::move(editActionId);
    rule.alternateEditActionId = std::move(alternateEditActionId);
    rule.editNewActionId       = std::move(editNewActionId);
    return rule;
}

void TestSetViewerAssociationRows(std::initializer_list<std::pair<const wchar_t*, const wchar_t*>> rows)
{
    auto defaultViewers                    = Common::Settings::DefaultViewerFileActionsSettings();
    g_settings.fileActions.viewers.actions = std::move(defaultViewers.actions);
    g_settings.fileActions.viewers.associations.clear();
    g_settings.fileActions.viewers.associations.reserve(rows.size());
    for (const auto& [extension, actionId] : rows)
    {
        g_settings.fileActions.viewers.associations.push_back(TestViewerAssociation(extension, actionId));
    }
}

[[nodiscard]] const Common::Settings::ViewerAssociationRule* TestFindDefaultViewerAssociationForRead(
    const Common::Settings::ViewerFileActionsSettings& settings) noexcept
{
    for (const auto& rule : settings.associations)
    {
        if (rule.match.kind == Common::Settings::FileActionMatchKind::Default)
        {
            return &rule;
        }
    }

    return nullptr;
}

[[nodiscard]] size_t TestVisibleViewerAssociationRowCount(const Common::Settings::ViewerFileActionsSettings& settings) noexcept
{
    return settings.associations.size();
}

[[nodiscard]] const Common::Settings::EditorAssociationRule* TestFindDefaultEditorAssociationForRead(
    const Common::Settings::EditorFileActionsSettings& settings) noexcept
{
    for (const auto& rule : settings.associations)
    {
        if (rule.match.kind == Common::Settings::FileActionMatchKind::Default)
        {
            return &rule;
        }
    }

    return nullptr;
}
} // namespace

[[nodiscard]] bool TestSettingsHotReloadMergePreservesRuntimeSession(CaseState& state) noexcept
{
    Common::Settings::Settings diskSettings;
    diskSettings.windows.emplace(L"MainWindow",
                                 Common::Settings::WindowPlacement{
                                     .state = Common::Settings::WindowState::Normal, .bounds = {.x = 10, .y = 20, .width = 800, .height = 600}, .dpi = 96u});
    diskSettings.windows.emplace(L"PreferencesWindow",
                                 Common::Settings::WindowPlacement{
                                     .state = Common::Settings::WindowState::Normal, .bounds = {.x = 50, .y = 60, .width = 640, .height = 480}, .dpi = 96u});
    diskSettings.windows.emplace(
        L"DiskOnlyWindow",
        Common::Settings::WindowPlacement{.state = Common::Settings::WindowState::Maximized, .bounds = {.x = 1, .y = 2, .width = 3, .height = 4}, .dpi = 144u});

    Common::Settings::FoldersSettings diskFolders;
    diskFolders.active            = L"left";
    diskFolders.layout.splitRatio = 0.75f;
    diskFolders.showHiddenFiles   = false;
    diskFolders.showSystemFiles   = false;
    diskFolders.historyMax        = 42;
    diskFolders.history           = {std::filesystem::path(L"C:\\disk-history")};
    diskFolders.historyFilters.push_back({std::filesystem::path(L"C:\\disk-filter"), true, L"*.disk"});
    diskFolders.items.push_back(Common::Settings::FolderPane{
        .slot = L"left", .current = std::filesystem::path(L"C:\\disk-left"), .view = {.display = Common::Settings::FolderDisplayMode::Detailed}});
    diskFolders.items.push_back(Common::Settings::FolderPane{
        .slot = L"right", .current = std::filesystem::path(L"C:\\disk-right"), .view = {.display = Common::Settings::FolderDisplayMode::Brief}});
    diskSettings.folders = diskFolders;

    Common::Settings::Settings runtimeSettings             = diskSettings;
    runtimeSettings.windows[L"MainWindow"].bounds.x        = 101;
    runtimeSettings.windows[L"PreferencesWindow"].bounds.x = 202;
    runtimeSettings.windows.emplace(L"ConnectionManagerWindow",
                                    Common::Settings::WindowPlacement{.state  = Common::Settings::WindowState::Normal,
                                                                      .bounds = {.x = 303, .y = 404, .width = 505, .height = 606},
                                                                      .dpi    = 120u});

    Common::Settings::FoldersSettings runtimeFolders = diskFolders;
    runtimeFolders.active                            = L"right";
    runtimeFolders.layout.splitRatio                 = 0.25f;
    runtimeFolders.history                           = {std::filesystem::path(L"C:\\runtime-history-1"), std::filesystem::path(L"C:\\runtime-history-2")};
    runtimeFolders.historyFilters                    = {{std::filesystem::path(L"C:\\runtime-filter"), true, L"*.runtime"}};
    runtimeFolders.items[0].current                  = std::filesystem::path(L"C:\\runtime-left");
    runtimeFolders.items[1].current                  = std::filesystem::path(L"C:\\runtime-right");
    runtimeSettings.folders                          = runtimeFolders;

    const std::array<std::wstring_view, 2> runtimeWindowIds = {L"MainWindow", L"PreferencesWindow"};
    const Common::Settings::Settings merged = SettingsHotReload::MergeDiskSettingsWithRuntimeSession(diskSettings, runtimeSettings, runtimeWindowIds);

    state.Require(merged.windows.contains(L"DiskOnlyWindow"), L"Expected disk-only window placement to be preserved.");
    state.Require(merged.windows.at(L"MainWindow").bounds.x == 101, L"Expected runtime main window placement to win.");
    state.Require(merged.windows.at(L"PreferencesWindow").bounds.x == 202, L"Expected runtime preferences placement to win.");
    state.Require(! merged.windows.contains(L"ConnectionManagerWindow"), L"Unexpected runtime-only window placement merge.");

    state.Require(merged.folders.has_value(), L"Expected merged folders settings.");
    if (! merged.folders.has_value())
    {
        return false;
    }

    const auto& folders = merged.folders.value();
    state.Require(folders.active == L"right", L"Expected runtime active pane to be preserved.");
    state.Require(std::abs(folders.layout.splitRatio - 0.25f) < 0.001f, L"Expected runtime folder layout split ratio to be preserved.");
    state.Require(folders.history.size() == 2, L"Expected runtime folder history to be preserved.");
    state.Require(folders.historyFilters.size() == 1 && folders.historyFilters.front().text == L"*.runtime",
                  L"Expected runtime folder history filters to be preserved.");
    state.Require(folders.showHiddenFiles == false && folders.showSystemFiles == false, L"Expected disk folder preference flags to remain authoritative.");
    state.Require(folders.historyMax == 42, L"Expected disk folder historyMax to remain authoritative.");
    state.Require(folders.items.size() == 2, L"Expected both folder pane entries after merge.");
    state.Require(folders.items[0].current == std::filesystem::path(L"C:\\runtime-left"), L"Expected runtime left pane current path.");
    state.Require(folders.items[1].current == std::filesystem::path(L"C:\\runtime-right"), L"Expected runtime right pane current path.");
    state.Require(folders.items[0].view.display == Common::Settings::FolderDisplayMode::Detailed,
                  L"Expected disk folder view preferences to remain authoritative.");
    return true;
}

[[nodiscard]] bool TestSettingsHotReloadMergeKeepsDiskPreferences(CaseState& state) noexcept
{
    Common::Settings::Settings diskSettings;
    diskSettings.theme.currentThemeId = L"builtin/dark";
    diskSettings.compareDirectories =
        Common::Settings::CompareDirectoriesSettings{.compareContent = true, .ignoreFiles = true, .ignoreFilesPatterns = L"*.bak"};
    diskSettings.windows[L"MainWindow"].bounds.width = 700;

    Common::Settings::FoldersSettings diskFolders;
    diskFolders.items.push_back(Common::Settings::FolderPane{.slot = L"left", .current = std::filesystem::path(L"C:\\disk-left")});
    diskSettings.folders = diskFolders;

    Common::Settings::Settings runtimeSettings          = diskSettings;
    runtimeSettings.theme.currentThemeId                = L"builtin/light";
    runtimeSettings.compareDirectories                  = Common::Settings::CompareDirectoriesSettings{.compareContent = false, .ignoreFiles = false};
    runtimeSettings.windows[L"MainWindow"].bounds.width = 900;

    Common::Settings::FoldersSettings runtimeFolders = diskFolders;
    runtimeFolders.items[0].current                  = std::filesystem::path(L"C:\\runtime-left");
    runtimeSettings.folders                          = runtimeFolders;

    const std::array<std::wstring_view, 1> runtimeWindowIds = {L"MainWindow"};
    const Common::Settings::Settings merged = SettingsHotReload::MergeDiskSettingsWithRuntimeSession(diskSettings, runtimeSettings, runtimeWindowIds);

    state.Require(merged.theme.currentThemeId == L"builtin/dark", L"Expected disk theme to remain authoritative.");
    state.Require(merged.compareDirectories.has_value() && merged.compareDirectories->compareContent,
                  L"Expected disk compare-directories settings to remain authoritative.");
    state.Require(merged.compareDirectories->ignoreFilesPatterns == L"*.bak", L"Expected disk compare ignore patterns to remain authoritative.");
    state.Require(merged.windows.at(L"MainWindow").bounds.width == 900, L"Expected runtime window placement to still be merged.");
    state.Require(merged.folders.has_value() && merged.folders->items.front().current == std::filesystem::path(L"C:\\runtime-left"),
                  L"Expected runtime folder current path to still be merged.");
    return true;
}

[[nodiscard]] bool TestSettingsStoreNoRecoveryAndFileStamp(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestSettingsStore";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::SettingsFileStamp missingStamp{};
    const HRESULT missingHr = Common::Settings::TryGetSettingsFileStamp(kTestAppId, missingStamp);
    state.Require(missingHr == S_FALSE, L"Expected missing settings stamp query to return S_FALSE.");

    Common::Settings::Settings settings{};
    settings.theme.currentThemeId = L"builtin/light";
    const HRESULT saveHr          = Common::Settings::SaveSettings(kTestAppId, settings);
    state.Require(SUCCEEDED(saveHr), L"Failed to save baseline test settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::SettingsFileStamp stampBefore{};
    const HRESULT stampBeforeHr = Common::Settings::TryGetSettingsFileStamp(kTestAppId, stampBefore);
    state.Require(stampBeforeHr == S_OK, L"Failed to query baseline settings file stamp.");

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"TryLoadSettingsNoRecovery should succeed for valid settings.");
    state.Require(loaded.theme.currentThemeId == L"builtin/light", L"TryLoadSettingsNoRecovery loaded unexpected theme id.");

    std::this_thread::sleep_for(SelfTest::Scale(std::chrono::milliseconds{50}));

    settings.theme.currentThemeId = L"builtin/dark";
    Common::Settings::SettingsFileStamp writtenStamp{};
    const HRESULT saveUpdatedHr = Common::Settings::SaveSettingsValuesOnlyWithStamp(kTestAppId, settings, writtenStamp);
    state.Require(SUCCEEDED(saveUpdatedHr), L"Failed to save updated test settings.");
    if (FAILED(saveUpdatedHr))
    {
        return false;
    }

    Common::Settings::SettingsFileStamp stampAfter{};
    const HRESULT stampAfterHr = Common::Settings::TryGetSettingsFileStamp(kTestAppId, stampAfter);
    state.Require(stampAfterHr == S_OK, L"Failed to query updated settings file stamp.");
    state.Require(! (stampAfter == stampBefore), L"Expected settings file stamp to change after save.");
    state.Require(writtenStamp == stampAfter, L"Atomic settings save must return the exact finalized file stamp observed at the destination path.");

    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);
    state.Require(! settingsPath.empty(), L"Test settings path unavailable.");
    state.Require(SelfTest::WriteTextFile(settingsPath, "{ invalid json"), L"Failed to write invalid settings file for no-recovery test.");

    Common::Settings::Settings invalidLoaded{};
    const HRESULT invalidHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, invalidLoaded);
    state.Require(FAILED(invalidHr), L"TryLoadSettingsNoRecovery should fail for invalid JSON.");
    state.Require(SelfTest::PathExists(settingsPath), L"Invalid no-recovery load should keep the original settings file in place.");
    state.Require(FindSettingsBackupArtifact(kTestAppId).empty(), L"No-recovery load should not create a .bad backup file.");
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreGridLayoutParsingParity(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestGridLayoutParsing";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup                       = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });
    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);

    constexpr std::string_view kFixture = R"json({
        "schemaVersion": 16,
        "fileOperations": { "issuesPaneGridLayout": [
            { "columnId": "status", "displayIndex": 2, "widthDip": -5, "future": true },
            { "displayIndex": 9, "widthDip": 90 },
            { "columnId": 42, "displayIndex": 8 },
            { "columnId": "status", "displayIndex": 3, "widthDip": 10001 },
            "invalid"
        ] },
        "search": { "resultsGridLayout": [
            { "columnId": "path", "displayIndex": "invalid", "widthDip": 321.5, "future": { "x": 1 } }
        ] },
        "batchRename": { "previewGridLayout": [
            { "columnId": "new\u007fName", "displayIndex": 1, "widthDip": 222 }
        ] },
        "shortcuts": { "gridLayout": [
            { "columnId": "key", "displayIndex": 0, "widthDip": 144 },
            { "columnId": "key", "displayIndex": 1, "widthDip": 155 }
        ] },
        "futureSection": { "retained": true }
    })json";
    state.Require(SelfTest::WriteTextFile(settingsPath, kFixture), L"Failed to write the grid-layout parser fixture.");

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"The shared grid-layout fixture should load without recovery.");
    state.Require(loaded.fileOperations.has_value(), L"The issues-pane grid layout should be present.");
    state.Require(loaded.search.has_value(), L"The Search grid layout should be present.");
    state.Require(loaded.batchRename.has_value(), L"The Batch Rename grid layout should be present.");
    state.Require(loaded.shortcuts.has_value(), L"The Shortcuts grid layout should be present.");

    if (loaded.fileOperations.has_value())
    {
        const auto& layout = loaded.fileOperations->issuesPaneGridLayout;
        state.Require(layout.size() == 2u, L"Missing, wrong-type, and non-object grid entries must be skipped.");
        if (layout.size() == 2u)
        {
            state.Require(layout[0].columnId == L"status" && layout[1].columnId == L"status",
                          L"Duplicate grid column IDs must retain their input order for caller validation.");
            state.Require(layout[0].displayIndex == 2u && layout[1].displayIndex == 3u, L"Valid grid display indexes must be preserved.");
            state.Require(layout[0].widthDip == 0.0f && layout[1].widthDip == 10000.0f, L"Grid widths must retain the established 0..10000 DIP clamp.");
        }
    }
    if (loaded.search.has_value() && ! loaded.search->resultsGridLayout.empty())
    {
        const auto& entry = loaded.search->resultsGridLayout.front();
        state.Require(entry.columnId == L"path" && entry.displayIndex == 0u && std::abs(entry.widthDip - 321.5f) < 0.01f,
                      L"Wrong-type optional fields must keep defaults while unknown future fields are ignored.");
    }
    if (loaded.batchRename.has_value() && ! loaded.batchRename->previewGridLayout.empty())
    {
        state.Require(loaded.batchRename->previewGridLayout.front().columnId == L"newName",
                      L"Batch Rename must retain its section-specific control-character normalization.");
    }
    if (loaded.shortcuts.has_value())
    {
        state.Require(loaded.shortcuts->gridLayout.size() == 2u, L"The shared parser must preserve duplicate Shortcuts entries for caller validation.");
    }

    constexpr std::string_view kInvalidShortcutsFixture = R"json({
        "schemaVersion": 16,
        "shortcuts": { "functionBar": "invalid", "gridLayout": [{ "columnId": "key" }] },
        "search": { "resultsGridLayout": [{ "columnId": "path", "widthDip": 240 }] }
    })json";
    state.Require(SelfTest::WriteTextFile(settingsPath, kInvalidShortcutsFixture), L"Failed to write the section-recovery grid fixture.");
    Common::Settings::Settings recovered{};
    Common::Settings::SettingsLoadRecoveryInfo recovery{};
    const HRESULT recoveryHr = Common::Settings::LoadSettingsWithRecoveryInfo(kTestAppId, recovered, &recovery);
    state.Require(recoveryHr == S_FALSE && ! recovered.shortcuts.has_value(), L"An invalid Shortcuts section must recover only Shortcuts.");
    state.Require(recovered.search.has_value() && recovered.search->resultsGridLayout.size() == 1u &&
                      recovered.search->resultsGridLayout.front().columnId == L"path",
                  L"Section-scoped recovery must retain unrelated parsed grid layouts.");
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreSearchRoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestSearchRoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings settings{};
    Common::Settings::SearchDialogSettings search{};
    search.recentRoots           = {L"C:\\search-root", L"D:\\archive"};
    search.recentNamePatterns    = {L"*.jsonl", L"*.txt"};
    search.recentContentPatterns = {L"needle", L"todo"};
    search.lastRoot              = L"C:\\search-root";
    search.lastNamePattern       = L"*.jsonl";
    search.lastContentPattern    = L"needle";
    search.recursive             = false;
    search.includeFiles          = true;
    search.includeDirectories    = true;
    search.followSymlinks        = true;
    search.matchCaseName         = true;
    search.matchCaseContent      = true;
    search.preferIndex           = false;
    search.wantSnippets          = true;
    search.nameMode              = Common::Settings::SearchNameMode::Regex;
    search.contentMode           = Common::Settings::SearchContentMode::TextRegex;
    search.maxResults            = 77u;
    search.resultsGridLayout     = {
        Common::Settings::GridColumnLayoutEntry{.columnId = L"path", .displayIndex = 0u, .widthDip = 420.0f},
        Common::Settings::GridColumnLayoutEntry{.columnId = L"name", .displayIndex = 1u, .widthDip = 260.0f},
        Common::Settings::GridColumnLayoutEntry{.columnId = L"modified", .displayIndex = 2u, .widthDip = 180.0f},
    };
    settings.search = search;

    Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
    state.Require(prepared.search.has_value(), L"Search settings should survive canonical save preparation when non-default.");

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, prepared);
    state.Require(SUCCEEDED(saveHr), L"Failed to save search round-trip settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Failed to load search round-trip settings.");
    state.Require(loaded.search.has_value(), L"Search settings block missing after round-trip.");
    if (FAILED(loadHr) || ! loaded.search.has_value())
    {
        return false;
    }

    const Common::Settings::SearchDialogSettings& actual = loaded.search.value();
    state.Require(actual.recentRoots == search.recentRoots, L"Search recent roots did not round-trip.");
    state.Require(actual.recentNamePatterns == search.recentNamePatterns, L"Search recent name patterns did not round-trip.");
    state.Require(actual.recentContentPatterns == search.recentContentPatterns, L"Search recent content patterns did not round-trip.");
    state.Require(actual.lastRoot == search.lastRoot, L"Search last root did not round-trip.");
    state.Require(actual.lastNamePattern == search.lastNamePattern, L"Search last name pattern did not round-trip.");
    state.Require(actual.lastContentPattern == search.lastContentPattern, L"Search last content pattern did not round-trip.");
    state.Require(actual.recursive == search.recursive, L"Search recursive flag did not round-trip.");
    state.Require(actual.includeFiles == search.includeFiles, L"Search includeFiles flag did not round-trip.");
    state.Require(actual.includeDirectories == search.includeDirectories, L"Search includeDirectories flag did not round-trip.");
    state.Require(actual.followSymlinks == search.followSymlinks, L"Search followSymlinks flag did not round-trip.");
    state.Require(actual.matchCaseName == search.matchCaseName, L"Search matchCaseName flag did not round-trip.");
    state.Require(actual.matchCaseContent == search.matchCaseContent, L"Search matchCaseContent flag did not round-trip.");
    state.Require(actual.preferIndex == search.preferIndex, L"Search preferIndex flag did not round-trip.");
    state.Require(actual.wantSnippets == search.wantSnippets, L"Search wantSnippets flag did not round-trip.");
    state.Require(actual.nameMode == search.nameMode, L"Search nameMode did not round-trip.");
    state.Require(actual.contentMode == search.contentMode, L"Search contentMode did not round-trip.");
    state.Require(actual.maxResults == search.maxResults, L"Search maxResults did not round-trip.");
    state.Require(actual.resultsGridLayout.size() == search.resultsGridLayout.size(), L"Search results-grid layout entry count did not round-trip.");
    if (actual.resultsGridLayout.size() == search.resultsGridLayout.size())
    {
        for (size_t index = 0; index < search.resultsGridLayout.size(); ++index)
        {
            const auto& expectedEntry = search.resultsGridLayout[index];
            const auto& actualEntry   = actual.resultsGridLayout[index];
            state.Require(actualEntry.columnId == expectedEntry.columnId, L"Search results-grid layout columnId did not round-trip.");
            state.Require(actualEntry.displayIndex == expectedEntry.displayIndex, L"Search results-grid layout displayIndex did not round-trip.");
            state.Require(std::fabs(actualEntry.widthDip - expectedEntry.widthDip) <= 0.01f, L"Search results-grid layout widthDip did not round-trip.");
        }
    }

    const auto appendHiddenControl = [](std::wstring value)
    {
        value.push_back(static_cast<wchar_t>(0x7F));
        return value;
    };
    const auto containsControl = [](std::wstring_view text)
    { return std::any_of(text.begin(), text.end(), [](const wchar_t ch) noexcept { return std::iswcntrl(static_cast<wint_t>(ch)) != 0; }); };
    const auto searchContainsControl = [&](const Common::Settings::SearchDialogSettings& value)
    {
        const auto historyContainsControl = [&](const std::vector<std::wstring>& history)
        { return std::any_of(history.begin(), history.end(), [&](const std::wstring& entry) { return containsControl(entry); }); };

        return historyContainsControl(value.recentRoots) || historyContainsControl(value.recentNamePatterns) ||
               historyContainsControl(value.recentContentPatterns) || containsControl(value.lastRoot) || containsControl(value.lastNamePattern) ||
               containsControl(value.lastContentPattern);
    };

    Common::Settings::SearchDialogSettings dirtySearch{};
    dirtySearch.recentRoots           = {appendHiddenControl(L"C:\\dirty-root"),
                                         std::wstring(1, static_cast<wchar_t>(0x7F)),
                                         appendHiddenControl(L"C:\\DIRTY-ROOT"),
                                         appendHiddenControl(L"D:\\dirty-root")};
    dirtySearch.recentNamePatterns    = {appendHiddenControl(L"*"), std::wstring(1, static_cast<wchar_t>(0x7F)), appendHiddenControl(L"*.txt")};
    dirtySearch.recentContentPatterns = {appendHiddenControl(L"needle"), std::wstring(1, static_cast<wchar_t>(0x7F))};
    dirtySearch.lastRoot              = appendHiddenControl(L"C:\\dirty-root");
    dirtySearch.lastNamePattern       = appendHiddenControl(L"*");
    dirtySearch.lastContentPattern    = appendHiddenControl(L"needle");
    prepared.search                   = dirtySearch;

    const HRESULT dirtySaveHr = Common::Settings::SaveSettings(kTestAppId, prepared);
    state.Require(SUCCEEDED(dirtySaveHr), L"Failed to save dirty search settings for sanitization test.");
    if (FAILED(dirtySaveHr))
    {
        return false;
    }

    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);
    std::ifstream rawSettingsInput(settingsPath, std::ios::binary);
    state.Require(static_cast<bool>(rawSettingsInput), L"Failed to open saved settings for hidden-control verification.");
    if (rawSettingsInput)
    {
        const std::string rawSettings((std::istreambuf_iterator<char>(rawSettingsInput)), std::istreambuf_iterator<char>());
        state.Require(rawSettings.find('\x7F') == std::string::npos && rawSettings.find("\\u007f") == std::string::npos &&
                          rawSettings.find("\\u007F") == std::string::npos,
                      L"Saved search settings must not contain hidden control characters.");
    }

    Common::Settings::Settings sanitizedLoaded{};
    const HRESULT sanitizedLoadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, sanitizedLoaded);
    state.Require(sanitizedLoadHr == S_OK, L"Failed to load sanitized search settings.");
    state.Require(sanitizedLoaded.search.has_value(), L"Sanitized search settings block missing after save.");
    if (FAILED(sanitizedLoadHr) || ! sanitizedLoaded.search.has_value())
    {
        return false;
    }

    const Common::Settings::SearchDialogSettings& sanitizedActual = sanitizedLoaded.search.value();
    const std::vector<std::wstring> expectedSanitizedRoots{L"C:\\dirty-root", L"D:\\dirty-root"};
    const std::vector<std::wstring> expectedSanitizedNamePatterns{L"*", L"*.txt"};
    const std::vector<std::wstring> expectedSanitizedContentPatterns{L"needle"};
    state.Require(! searchContainsControl(sanitizedActual), L"Loaded saved search settings retained hidden control characters.");
    state.Require(sanitizedActual.recentRoots == expectedSanitizedRoots, L"Search recent roots were not sanitized before save.");
    state.Require(sanitizedActual.recentNamePatterns == expectedSanitizedNamePatterns, L"Search recent name patterns were not sanitized before save.");
    state.Require(sanitizedActual.recentContentPatterns == expectedSanitizedContentPatterns, L"Search recent content patterns were not sanitized before save.");
    state.Require(sanitizedActual.lastRoot == L"C:\\dirty-root", L"Search last root was not sanitized before save.");
    state.Require(sanitizedActual.lastNamePattern == L"*", L"Search last name pattern was not sanitized before save.");
    state.Require(sanitizedActual.lastContentPattern == L"needle", L"Search last content pattern was not sanitized before save.");

    constexpr std::string_view kDirtySearchJson =
        R"({"schemaVersion":16,"search":{"recentRoots":["C:\\raw-root\u007f","\u007f","C:\\RAW-ROOT\u007f","D:\\raw-root"],"recentNamePatterns":["*\u007f"],"recentContentPatterns":["needle\u007f"],"lastRoot":"C:\\raw-root\u007f","lastNamePattern":"*\u007f","lastContentPattern":"needle\u007f","recursive":true}})";
    state.Require(SelfTest::WriteTextFile(settingsPath, kDirtySearchJson), L"Failed to write dirty search settings fixture.");

    Common::Settings::Settings migratedLoaded{};
    const HRESULT migratedLoadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, migratedLoaded);
    state.Require(migratedLoadHr == S_OK, L"Failed to load dirty search settings fixture.");
    state.Require(migratedLoaded.search.has_value(), L"Migrated search settings block missing.");
    if (FAILED(migratedLoadHr) || ! migratedLoaded.search.has_value())
    {
        return false;
    }

    const Common::Settings::SearchDialogSettings& migratedActual = migratedLoaded.search.value();
    const std::vector<std::wstring> expectedMigratedRoots{L"C:\\raw-root", L"D:\\raw-root"};
    state.Require(! searchContainsControl(migratedActual), L"Dirty search settings fixture retained hidden control characters after load.");
    state.Require(migratedActual.recentRoots == expectedMigratedRoots, L"Dirty search recent roots were not sanitized on load.");
    state.Require(migratedActual.recentNamePatterns == std::vector<std::wstring>{L"*"}, L"Dirty search recent name patterns were not sanitized on load.");
    state.Require(migratedActual.recentContentPatterns == std::vector<std::wstring>{L"needle"},
                  L"Dirty search recent content patterns were not sanitized on load.");
    state.Require(migratedActual.lastRoot == L"C:\\raw-root", L"Dirty search last root was not sanitized on load.");
    state.Require(migratedActual.lastNamePattern == L"*", L"Dirty search last name pattern was not sanitized on load.");
    state.Require(migratedActual.lastContentPattern == L"needle", L"Dirty search last content pattern was not sanitized on load.");
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreBatchRenameRoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestBatchRenameRoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings settings{};
    Common::Settings::BatchRenameSettings batchRename{};
    batchRename.lastRoot              = L"C:\\batch-root";
    batchRename.recentMasks           = {L"*.cpp", L"*.h"};
    batchRename.recentNameTemplates   = {L"{counter:000}_{stem}{ext}", L"{stem}_copy{ext}"};
    batchRename.recentSearchPatterns  = {L"episode", L"\\d+"};
    batchRename.recentReplacePatterns = {L"clip", L"$1"};
    batchRename.includeSubdirectories = true;
    batchRename.includeFiles          = true;
    batchRename.includeFolders        = true;
    batchRename.regexEnabled          = true;
    batchRename.caseSensitive         = false;
    batchRename.wholeWords            = true;
    batchRename.replaceOnce           = true;
    batchRename.excludeExtension      = true;
    batchRename.flattenSeparator      = L"__";
    batchRename.fileNameCaseStyle     = Common::Settings::BatchRenameCaseStyle::Mixed;
    batchRename.extensionCaseStyle    = Common::Settings::BatchRenameCaseStyle::Lower;
    batchRename.previewSortColumnId   = L"newName";
    batchRename.previewSortDescending = true;
    batchRename.previewGridLayout     = {
        Common::Settings::GridColumnLayoutEntry{.columnId = L"originalName", .displayIndex = 0u, .widthDip = 300.0f},
        Common::Settings::GridColumnLayoutEntry{.columnId = L"newName", .displayIndex = 1u, .widthDip = 320.0f},
    };
    settings.batchRename = batchRename;

    const Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
    state.Require(prepared.batchRename.has_value(), L"Batch Rename settings should survive canonical save preparation when non-default.");

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, prepared);
    state.Require(SUCCEEDED(saveHr), L"Failed to save Batch Rename round-trip settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);
    std::ifstream rawInput(settingsPath, std::ios::binary);
    state.Require(static_cast<bool>(rawInput), L"Failed to open saved Batch Rename settings.");
    if (rawInput)
    {
        const std::string rawSettings((std::istreambuf_iterator<char>(rawInput)), std::istreambuf_iterator<char>());
        state.Require(rawSettings.find("manual") == std::string::npos, L"Batch Rename settings must not persist manual multiline names.");
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Failed to load Batch Rename round-trip settings.");
    state.Require(loaded.batchRename.has_value(), L"Batch Rename settings block missing after round-trip.");
    if (FAILED(loadHr) || ! loaded.batchRename.has_value())
    {
        return false;
    }

    const Common::Settings::BatchRenameSettings& actual = loaded.batchRename.value();
    state.Require(actual.lastRoot == batchRename.lastRoot, L"Batch Rename last root did not round-trip.");
    state.Require(actual.recentMasks == batchRename.recentMasks, L"Batch Rename recent masks did not round-trip.");
    state.Require(actual.recentNameTemplates == batchRename.recentNameTemplates, L"Batch Rename recent name templates did not round-trip.");
    state.Require(actual.recentSearchPatterns == batchRename.recentSearchPatterns, L"Batch Rename recent search patterns did not round-trip.");
    state.Require(actual.recentReplacePatterns == batchRename.recentReplacePatterns, L"Batch Rename recent replace patterns did not round-trip.");
    state.Require(actual.includeSubdirectories == batchRename.includeSubdirectories, L"Batch Rename recursive flag did not round-trip.");
    state.Require(actual.includeFiles == batchRename.includeFiles, L"Batch Rename includeFiles flag did not round-trip.");
    state.Require(actual.includeFolders == batchRename.includeFolders, L"Batch Rename includeFolders flag did not round-trip.");
    state.Require(actual.regexEnabled == batchRename.regexEnabled, L"Batch Rename regexEnabled flag did not round-trip.");
    state.Require(actual.caseSensitive == batchRename.caseSensitive, L"Batch Rename caseSensitive flag did not round-trip.");
    state.Require(actual.wholeWords == batchRename.wholeWords, L"Batch Rename wholeWords flag did not round-trip.");
    state.Require(actual.replaceOnce == batchRename.replaceOnce, L"Batch Rename replaceOnce flag did not round-trip.");
    state.Require(actual.excludeExtension == batchRename.excludeExtension, L"Batch Rename excludeExtension flag did not round-trip.");
    state.Require(actual.flattenSeparator == batchRename.flattenSeparator, L"Batch Rename flatten separator did not round-trip.");
    state.Require(actual.fileNameCaseStyle == batchRename.fileNameCaseStyle, L"Batch Rename file-name case style did not round-trip.");
    state.Require(actual.extensionCaseStyle == batchRename.extensionCaseStyle, L"Batch Rename extension case style did not round-trip.");
    state.Require(actual.previewSortColumnId == batchRename.previewSortColumnId, L"Batch Rename preview sort column did not round-trip.");
    state.Require(actual.previewSortDescending == batchRename.previewSortDescending, L"Batch Rename preview sort direction did not round-trip.");
    state.Require(actual.previewGridLayout.size() == batchRename.previewGridLayout.size(), L"Batch Rename preview grid layout count did not round-trip.");
    if (actual.previewGridLayout.size() == batchRename.previewGridLayout.size())
    {
        for (size_t index = 0; index < batchRename.previewGridLayout.size(); ++index)
        {
            const auto& expectedEntry = batchRename.previewGridLayout[index];
            const auto& actualEntry   = actual.previewGridLayout[index];
            state.Require(actualEntry.columnId == expectedEntry.columnId, L"Batch Rename preview grid columnId did not round-trip.");
            state.Require(actualEntry.displayIndex == expectedEntry.displayIndex, L"Batch Rename preview grid displayIndex did not round-trip.");
            state.Require(std::fabs(actualEntry.widthDip - expectedEntry.widthDip) <= 0.01f, L"Batch Rename preview grid widthDip did not round-trip.");
        }
    }

    Common::Settings::Settings defaultSettings{};
    defaultSettings.batchRename                      = Common::Settings::BatchRenameSettings{};
    const Common::Settings::Settings preparedDefault = SettingsSave::PrepareForSave(defaultSettings);
    state.Require(! preparedDefault.batchRename.has_value(), L"Default Batch Rename settings should be suppressed during canonical save preparation.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreFileActionsV16RoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestFileActionsV16RoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings settings{};
    settings.schemaVersion = 16u;

    Common::Settings::FileActionDefinition textViewer{};
    textViewer.id                = L"builtin/viewer-text";
    textViewer.displayName       = L"Text Viewer";
    textViewer.kind              = Common::Settings::FileActionKind::ViewerPlugin;
    textViewer.pluginId          = L"builtin/viewer-text";
    textViewer.appliesTo.matches = {{Common::Settings::FileActionMatchKind::Extension, L".txt"}, {Common::Settings::FileActionMatchKind::Extension, L".md"}};
    textViewer.appliesTo.computerNames = {L"DEV-PC"};

    Common::Settings::FileActionDefinition hexViewer{};
    hexViewer.id                = L"hex-viewer";
    hexViewer.displayName       = L"Hex Viewer";
    hexViewer.kind              = Common::Settings::FileActionKind::ViewerPlugin;
    hexViewer.pluginId          = L"builtin/viewer-hex";
    hexViewer.appliesTo.matches = {{Common::Settings::FileActionMatchKind::Default, L""}};

    Common::Settings::FileActionDefinition externalPngViewer{};
    externalPngViewer.id                = L"irfanview";
    externalPngViewer.displayName       = L"IrfanView";
    externalPngViewer.kind              = Common::Settings::FileActionKind::ExternalProgram;
    externalPngViewer.executablePath    = L"C:\\Tools\\IrfanView\\i_view64.exe";
    externalPngViewer.arguments         = L"{FullPath}";
    externalPngViewer.workingDirectory  = L"{Path}";
    externalPngViewer.enabled           = false;
    externalPngViewer.appliesTo.matches = {{Common::Settings::FileActionMatchKind::Extension, L".png"},
                                           {Common::Settings::FileActionMatchKind::Extension, L".jpg"}};

    settings.fileActions.viewers.actions = {textViewer, hexViewer, externalPngViewer};

    Common::Settings::ViewerAssociationRule txtViewerRule{};
    txtViewerRule.match.kind            = Common::Settings::FileActionMatchKind::Extension;
    txtViewerRule.match.value           = L".txt";
    txtViewerRule.computerName          = L"DEV-PC";
    txtViewerRule.viewActionId          = L"builtin/viewer-text";
    txtViewerRule.alternateViewActionId = L"hex-viewer";

    Common::Settings::ViewerAssociationRule defaultViewerRule{};
    defaultViewerRule.match.kind            = Common::Settings::FileActionMatchKind::Default;
    defaultViewerRule.viewActionId          = L"hex-viewer";
    defaultViewerRule.alternateViewActionId = L"";

    settings.fileActions.viewers.associations = {txtViewerRule, defaultViewerRule};

    Common::Settings::FileActionDefinition notepad{};
    notepad.id                = L"notepad";
    notepad.displayName       = L"Notepad";
    notepad.kind              = Common::Settings::FileActionKind::ExternalProgram;
    notepad.executablePath    = L"C:\\Windows\\System32\\notepad.exe";
    notepad.arguments         = L"{FullPath}";
    notepad.workingDirectory  = L"{Path}";
    notepad.appliesTo.matches = {{Common::Settings::FileActionMatchKind::Default, L""}};

    Common::Settings::FileActionDefinition vscode{};
    vscode.id                = L"vscode";
    vscode.displayName       = L"VS Code";
    vscode.kind              = Common::Settings::FileActionKind::ExternalProgram;
    vscode.executablePath    = L"C:\\Tools\\VSCode\\code.cmd";
    vscode.arguments         = L"--reuse-window {FullPath}";
    vscode.workingDirectory  = L"{Path}";
    vscode.appliesTo.matches = {{Common::Settings::FileActionMatchKind::Default, L""}};

    Common::Settings::FileActionDefinition visualStudio{};
    visualStudio.id                      = L"Visual-Studio";
    visualStudio.displayName             = L"Visual Studio";
    visualStudio.kind                    = Common::Settings::FileActionKind::ExternalProgram;
    visualStudio.executablePath          = L"C:\\Program Files\\Microsoft Visual Studio\\Common7\\IDE\\devenv.exe";
    visualStudio.arguments               = L"{FullPath}";
    visualStudio.workingDirectory        = L"{Path}";
    visualStudio.appliesTo.matches       = {{Common::Settings::FileActionMatchKind::Extension, L".cpp"},
                                            {Common::Settings::FileActionMatchKind::Extension, L".h"},
                                            {Common::Settings::FileActionMatchKind::Extension, L".vcxproj"}};
    visualStudio.appliesTo.computerNames = {L"DEV-PC"};

    settings.fileActions.editors.actions = {notepad, vscode, visualStudio};

    Common::Settings::EditorAssociationRule txtEditorRule{};
    txtEditorRule.match.kind            = Common::Settings::FileActionMatchKind::Extension;
    txtEditorRule.match.value           = L".txt";
    txtEditorRule.editActionId          = L"notepad";
    txtEditorRule.alternateEditActionId = L"vscode";
    txtEditorRule.editNewActionId       = L"notepad";

    Common::Settings::EditorAssociationRule cppEditorRule{};
    cppEditorRule.match.kind            = Common::Settings::FileActionMatchKind::Extension;
    cppEditorRule.match.value           = L".cpp";
    cppEditorRule.computerName          = L"DEV-PC";
    cppEditorRule.editActionId          = L"visual-studio";
    cppEditorRule.alternateEditActionId = L"vscode";
    cppEditorRule.editNewActionId       = L"visual-studio";

    Common::Settings::EditorAssociationRule defaultEditorRule{};
    defaultEditorRule.match.kind            = Common::Settings::FileActionMatchKind::Default;
    defaultEditorRule.editActionId          = L"notepad";
    defaultEditorRule.alternateEditActionId = L"";
    defaultEditorRule.editNewActionId       = L"notepad";

    settings.fileActions.editors.associations = {txtEditorRule, cppEditorRule, defaultEditorRule};

    Common::Settings::FileActionDefinition terminalAction{};
    terminalAction.id               = L"open-terminal";
    terminalAction.displayName      = L"Open Terminal Here";
    terminalAction.kind             = Common::Settings::FileActionKind::ExternalProgram;
    terminalAction.executablePath   = L"C:\\Windows\\System32\\wt.exe";
    terminalAction.arguments        = L"-d {Path}";
    terminalAction.workingDirectory = L"{Path}";

    settings.userMenu.actions = {terminalAction};

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, settings);
    state.Require(SUCCEEDED(saveHr), L"Failed to save v16 file action settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Failed to load v16 file action settings.");
    if (FAILED(loadHr))
    {
        return false;
    }

    state.Require(loaded.schemaVersion == 16u, L"File Actions should persist through settings schema v16.");
    state.Require(loaded.fileActions.viewers.actions.size() == 3, L"Viewer actions did not round-trip through fileActions.");
    state.Require(loaded.fileActions.viewers.associations.size() == 2, L"Viewer associations did not round-trip.");
    state.Require(loaded.fileActions.viewers.associations.at(0).alternateViewActionId == L"hex-viewer", L"Alternate viewer association did not round-trip.");
    state.Require(loaded.fileActions.viewers.actions.at(0).appliesTo.matches.size() == 2, L"Viewer action applicability matches did not round-trip.");
    state.Require(loaded.fileActions.viewers.actions.at(0).appliesTo.computerNames == std::vector<std::wstring>{L"DEV-PC"},
                  L"Viewer action computer applicability did not round-trip.");

    state.Require(loaded.fileActions.editors.actions.size() == 3, L"Editor actions did not round-trip through fileActions.");
    state.Require(loaded.fileActions.editors.associations.size() == 3, L"Editor associations did not round-trip.");
    state.Require(loaded.fileActions.editors.associations.at(1).editNewActionId == L"visual-studio",
                  L"Edit New association did not round-trip independently from Edit.");
    state.Require(loaded.fileActions.editors.actions.at(2).appliesTo.matches.at(2).value == L".vcxproj",
                  L"Editor action extension applicability did not round-trip.");
    FileActionResolver::Request cppRequest{};
    cppRequest.command                                       = FileActionResolver::Command::Edit;
    cppRequest.filePath                                      = std::filesystem::path(L"C:\\Src\\main.cpp");
    cppRequest.computerName                                  = L"dev-pc";
    const FileActionResolver::Resolution loadedCppResolution = FileActionResolver::ResolveEditorAction(loaded.fileActions.editors, cppRequest);
    state.Require(loadedCppResolution.action && loadedCppResolution.action->id == L"Visual-Studio",
                  L"Persisted editor action references should resolve case-insensitively.");

    state.Require(loaded.userMenu.actions.size() == 1, L"User Menu actions did not round-trip through the dedicated userMenu shape.");
    state.Require(loaded.userMenu.actions.at(0).arguments == L"-d {Path}", L"User Menu macro arguments did not round-trip.");

    const std::string_view schema = Common::Settings::GetSettingsStoreSchemaJsonUtf8();
    state.Require(schema.find("\"fileActions\"") != std::string_view::npos, L"Settings schema should expose the fileActions root.");
    state.Require(schema.find("\"associations\"") != std::string_view::npos, L"Settings schema should expose action associations.");
    state.Require(schema.find("\"editNewActionId\"") != std::string_view::npos, L"Settings schema should expose Edit New mappings.");
    state.Require(schema.find("\"appliesTo\"") != std::string_view::npos, L"Settings schema should expose action applicability.");
    state.Require(schema.find("openWithViewerByExtension") == std::string_view::npos, L"Settings schema should not expose legacy viewer extension mappings.");
    state.Require(schema.find("defaultPrimaryActionId") == std::string_view::npos, L"Settings schema should not expose legacy primary default action ids.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreFileActionsV16DisablesRelativeExecutables(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestFileActionsV16RelativeExecutables";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);
    state.Require(! settingsPath.empty(), L"Relative-executable File Actions test settings path unavailable.");
    if (settingsPath.empty())
    {
        return false;
    }

    constexpr std::string_view kSettings = R"json({
  "schemaVersion": 16,
  "fileActions": {
    "editors": {
      "actions": [
        { "id": "legacy-relative", "kind": "externalProgram", "executablePath": "notepad.exe", "enabled": true },
        { "id": "explicit-absolute", "kind": "externalProgram", "executablePath": "C:\\Tools\\Editor.exe", "enabled": true }
      ]
    }
  }
})json";
    state.Require(SelfTest::WriteTextFile(settingsPath, kSettings), L"Failed to write relative-executable File Actions settings.");
    if (! state.failure.empty())
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Relative executable should not force whole-settings recovery.");
    state.Require(loaded.fileActions.editors.actions.size() == 2u, L"Relative and absolute executable actions should both remain available for repair.");
    if (FAILED(loadHr) || loaded.fileActions.editors.actions.size() != 2u)
    {
        return false;
    }

    const Common::Settings::FileActionDefinition& relative = loaded.fileActions.editors.actions[0];
    const Common::Settings::FileActionDefinition& absolute = loaded.fileActions.editors.actions[1];
    state.Require(relative.executablePath == L"notepad.exe", L"Relative executable text should be preserved verbatim for repair.");
    state.Require(! relative.enabled, L"Relative executable action should be disabled during load.");
    state.Require(absolute.enabled, L"Explicit absolute executable action should remain enabled.");

    state.Require(SUCCEEDED(Common::Settings::SaveSettings(kTestAppId, loaded)), L"Disabled relative executable should remain serializable.");
    Common::Settings::Settings reloaded{};
    const HRESULT reloadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, reloaded);
    state.Require(reloadHr == S_OK && reloaded.fileActions.editors.actions.size() == 2u,
                  L"Disabled relative executable should survive a canonical save and reload.");
    if (reloadHr == S_OK && reloaded.fileActions.editors.actions.size() == 2u)
    {
        state.Require(reloaded.fileActions.editors.actions[0].executablePath == L"notepad.exe" && ! reloaded.fileActions.editors.actions[0].enabled,
                      L"Canonical save must preserve the relative path while keeping the action disabled.");
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreFileActionsV16RejectsLegacyShape(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestFileActionsV16RejectLegacy";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);
    state.Require(! settingsPath.empty(), L"Legacy File Actions test settings path unavailable.");
    if (settingsPath.empty())
    {
        return false;
    }

    constexpr std::string_view kLegacySettings = R"json({
  "schemaVersion": 16,
  "viewers": {
    "actions": [
      { "id": "legacy-text-viewer", "displayName": "Text Viewer", "kind": "viewerPlugin", "pluginId": "builtin/viewer-text" }
    ],
    "defaultPrimaryActionId": "legacy-text-viewer",
    "primaryActionIdByExtension": { ".txt": "legacy-text-viewer" }
  },
  "editors": {
    "actions": [
      { "id": "legacy-editor", "displayName": "Editor", "kind": "externalProgram", "executablePath": "notepad.exe" }
    ],
    "defaultPrimaryActionId": "legacy-editor"
  },
  "extensions": {
    "openWithViewerByExtension": {
      ".txt": "builtin/viewer-text"
    }
  }
})json";

    state.Require(SelfTest::WriteTextFile(settingsPath, kLegacySettings), L"Failed to write legacy File Actions settings shape.");

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(FAILED(loadHr), L"v16 settings with legacy root viewers/editors should be rejected.");
    state.Require(loadHr == HRESULT_FROM_WIN32(ERROR_INVALID_DATA), L"Legacy v16 File Actions shape should surface ERROR_INVALID_DATA.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreLoadSettingsReportsUnsupportedSchemaBackup(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestSettingsUnsupportedSchemaBackup";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);
    state.Require(! settingsPath.empty(), L"Unsupported-schema backup test settings path unavailable.");
    if (settingsPath.empty())
    {
        return false;
    }

    constexpr std::string_view kV15Settings = R"json({
  "schemaVersion": 15,
  "theme": { "currentThemeId": "builtin/dark" }
})json";
    state.Require(SelfTest::WriteTextFile(settingsPath, kV15Settings), L"Failed to write v15 settings fixture.");

    Common::Settings::Settings loaded{};
    Common::Settings::SettingsLoadRecoveryInfo recovery{};
    const HRESULT loadHr = Common::Settings::LoadSettingsWithRecoveryInfo(kTestAppId, loaded, &recovery);
    state.Require(loadHr == S_FALSE, L"Unsupported schema should load defaults with S_FALSE recovery status.");
    state.Require(loaded.schemaVersion == 16u, L"Unsupported schema recovery should restore current default settings.");
    state.Require(recovery.reason == Common::Settings::SettingsLoadRecoveryReason::UnsupportedSchemaVersion,
                  L"Unsupported schema recovery should report the unsupported-schema reason.");
    state.Require(recovery.unsupportedSchemaVersion == 15, L"Unsupported schema recovery should report the legacy schema version.");
    state.Require(recovery.backedUp, L"Unsupported schema recovery should report that the old settings file was backed up.");
    state.Require(recovery.settingsPath == settingsPath, L"Unsupported schema recovery should report the original settings path.");
    state.Require(! recovery.backupPath.empty(), L"Unsupported schema recovery should report the backup path.");
    state.Require(SelfTest::PathExists(recovery.backupPath), L"Unsupported schema recovery backup file should exist.");
    const std::wstring recoveryMessage = FormatStringResource(nullptr,
                                                              IDS_FMT_SETTINGS_RESTORED_DEFAULTS_UNSUPPORTED_SCHEMA_BACKUP,
                                                              recovery.unsupportedSchemaVersion,
                                                              recovery.settingsPath.wstring(),
                                                              recovery.backupPath.wstring());
    state.Require(recoveryMessage.find(L"schema version 15") != std::wstring::npos,
                  L"Unsupported schema recovery warning should name the rejected schema version.");
    state.Require(recoveryMessage.find(L"not migrated automatically") != std::wstring::npos,
                  L"Unsupported schema recovery warning should say the old settings were not migrated automatically.");
    state.Require(recoveryMessage.find(recovery.settingsPath.wstring()) != std::wstring::npos,
                  L"Unsupported schema recovery warning should include the original settings path.");
    state.Require(recoveryMessage.find(recovery.backupPath.wstring()) != std::wstring::npos,
                  L"Unsupported schema recovery warning should include the backup path.");
    state.Require(! SelfTest::PathExists(settingsPath), L"Unsupported schema recovery should move the bad settings file out of the active path.");
    std::ifstream backupInput(recovery.backupPath, std::ios::binary);
    const std::string backupText((std::istreambuf_iterator<char>(backupInput)), {});
    state.Require(backupText.find("\"schemaVersion\": 15") != std::string::npos,
                  L"Unsupported schema recovery backup should contain the previous settings payload.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreInvalidFileActionsPreservesUnrelatedSections(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestSectionRecoveryFileActions";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup                       = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });
    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);

    constexpr std::string_view kSettings = R"json({
  "schemaVersion": 16,
  "theme": { "currentThemeId": "builtin/dark" },
  "ui": { "compactMode": false, "language": "fr-FR" },
  "fileActions": {
    "viewers": { "actions": [{ "id": "future-action", "kind": "futureViewerKind" }] }
  }
})json";
    state.Require(SelfTest::WriteTextFile(settingsPath, kSettings), L"Failed to write invalid File Actions recovery fixture.");

    Common::Settings::Settings loaded{};
    Common::Settings::SettingsLoadRecoveryInfo recovery{};
    const HRESULT loadHr = Common::Settings::LoadSettingsWithRecoveryInfo(kTestAppId, loaded, &recovery);
    state.Require(loadHr == S_FALSE, L"Section-scoped File Actions recovery should report partial default use.");
    state.Require(loaded.theme.currentThemeId == L"builtin/dark", L"Invalid File Actions must not discard the theme section.");
    state.Require(loaded.ui.has_value() && ! loaded.ui->compactMode && loaded.ui->language == L"fr-FR",
                  L"Invalid File Actions must not discard the UI section.");
    state.Require(recovery.sectionRecoveries.size() == 1u &&
                      recovery.sectionRecoveries[0].reason == Common::Settings::SettingsLoadRecoveryReason::FileActionsInvalid,
                  L"File Actions recovery must expose structured section evidence.");
    state.Require(! recovery.backedUp && SelfTest::PathExists(settingsPath), L"Section recovery must leave the source settings file in place.");
    state.Require(loaded.persistence.opaqueTopLevelMembers.size() == 1u && loaded.persistence.opaqueTopLevelMembers[0].first == "fileActions",
                  L"Invalid File Actions JSON must be retained as an owned opaque top-level member.");

    state.Require(SUCCEEDED(Common::Settings::SaveSettings(kTestAppId, loaded)), L"Recovered settings should remain saveable.");
    const std::string saved = ReadSettingsTestBytes(settingsPath);
    state.Require(saved.find("futureViewerKind") != std::string::npos, L"A canonical save must retain the invalid File Actions payload for repair.");
    state.Require(saved.find("builtin/dark") != std::string::npos && saved.find("fr-FR") != std::string::npos,
                  L"A canonical save lost unrelated valid sections after File Actions recovery.");
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreInvalidShortcutsPreservesUnrelatedSections(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestSectionRecoveryShortcuts";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup                       = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });
    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);

    constexpr std::string_view kSettings = R"json({
  "schemaVersion": 16,
  "theme": { "currentThemeId": "builtin/light" },
  "startup": { "showSplash": false },
  "shortcuts": {
    "functionBar": [{ "vk": "F3", "ctrl": "true", "commandId": "cmd/pane/view" }]
  }
})json";
    state.Require(SelfTest::WriteTextFile(settingsPath, kSettings), L"Failed to write invalid Shortcuts recovery fixture.");

    Common::Settings::Settings loaded{};
    Common::Settings::SettingsLoadRecoveryInfo recovery{};
    const HRESULT loadHr = Common::Settings::LoadSettingsWithRecoveryInfo(kTestAppId, loaded, &recovery);
    state.Require(loadHr == S_FALSE, L"Section-scoped Shortcuts recovery should report partial default use.");
    state.Require(loaded.theme.currentThemeId == L"builtin/light", L"Invalid Shortcuts must not discard the theme section.");
    state.Require(loaded.startup.has_value() && ! loaded.startup->showSplash, L"Invalid Shortcuts must not discard startup settings.");
    state.Require(! loaded.shortcuts.has_value(), L"Invalid Shortcuts must reset only the Shortcuts section.");
    state.Require(recovery.sectionRecoveries.size() == 1u &&
                      recovery.sectionRecoveries[0].reason == Common::Settings::SettingsLoadRecoveryReason::ShortcutsInvalid,
                  L"Shortcuts recovery must expose structured section evidence.");
    state.Require(! recovery.backedUp && SelfTest::PathExists(settingsPath), L"Shortcuts recovery must not back up the whole settings file.");

    state.Require(SUCCEEDED(Common::Settings::SaveSettings(kTestAppId, loaded)), L"Shortcuts-recovered settings should remain saveable.");
    const std::string saved = ReadSettingsTestBytes(settingsPath);
    state.Require(saved.find("\"ctrl\": \"true\"") != std::string::npos, L"A canonical save must retain the invalid Shortcuts payload for repair.");
    state.Require(saved.find("builtin/light") != std::string::npos && saved.find("showSplash") != std::string::npos,
                  L"A canonical save lost unrelated valid sections after Shortcuts recovery.");
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreUnsupportedFutureSchemaNeverOverwritesSource(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestFutureSchemaSaveBlock";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup                         = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });
    const std::filesystem::path settingsPath   = Common::Settings::GetSettingsPath(kTestAppId);
    constexpr std::string_view kFutureSettings = "{\r\n  \"schemaVersion\": 17,\r\n  \"futureData\": { \"keep\": true }\r\n}\r\n";
    state.Require(SelfTest::WriteTextFile(settingsPath, kFutureSettings), L"Failed to write future-schema settings fixture.");
    const std::string before = ReadSettingsTestBytes(settingsPath);

    Common::Settings::Settings loaded{};
    Common::Settings::SettingsLoadRecoveryInfo recovery{};
    const HRESULT loadHr = Common::Settings::LoadSettingsWithRecoveryInfo(kTestAppId, loaded, &recovery);
    state.Require(loadHr == S_FALSE, L"Future-schema startup load should use blocked defaults.");
    state.Require(recovery.reason == Common::Settings::SettingsLoadRecoveryReason::UnsupportedSchemaVersion && recovery.unsupportedSchemaVersion == 17,
                  L"Future-schema recovery should report the unsupported source version.");
    state.Require(! recovery.backedUp && recovery.backupPath.empty(), L"Future-schema startup must not move or back up the source implicitly.");
    state.Require(loaded.persistence.savePermission == Common::Settings::SettingsSavePermission::ExplicitReplacementRequired,
                  L"Future-schema startup must block automatic persistence.");
    state.Require(loaded.persistence.sourceSchemaVersion == 17, L"The blocked snapshot should retain its source schema version.");

    const HRESULT saveHr = SettingsHotReload::SaveSettingsAndSchema(kTestAppId, loaded);
    state.Require(saveHr == HRESULT_FROM_WIN32(ERROR_REVISION_MISMATCH), L"The serialized save coordinator must reject a blocked future-schema save.");
    const HRESULT queueHr = SettingsHotReload::QueueSettingsSave(kTestAppId, loaded, L"SelfTest.FutureSchema", L"blocked");
    state.Require(queueHr == HRESULT_FROM_WIN32(ERROR_REVISION_MISMATCH), L"The asynchronous save queue must reject a blocked future-schema save.");
    state.Require(Common::Settings::SaveSettings(kTestAppId, loaded) == HRESULT_FROM_WIN32(ERROR_REVISION_MISMATCH),
                  L"The low-level writer must provide defense in depth for the future-schema save block.");
    state.Require(ReadSettingsTestBytes(settingsPath) == before, L"Every blocked save path must leave future-schema source bytes unchanged.");
    state.Require(FindSettingsBackupArtifact(kTestAppId).empty(), L"Blocked automatic saves must not create a replacement backup.");

    constexpr std::string_view kConcurrentFutureSettings =
        "{\r\n  \"schemaVersion\": 18,\r\n  \"futureData\": { \"keepNewer\": true, \"revision\": 2 }\r\n}\r\n";
    state.Require(SelfTest::WriteTextFile(settingsPath, kConcurrentFutureSettings),
                  L"Failed to publish the newer future-schema revision before explicit replacement.");
    std::filesystem::path staleBackupPath;
    const HRESULT staleReplaceHr = SettingsHotReload::ReplaceBlockedSettingsAndSchema(kTestAppId, loaded, staleBackupPath);
    state.Require(staleReplaceHr == HRESULT_FROM_WIN32(ERROR_REVISION_MISMATCH),
                  L"A stale explicit-replacement confirmation must reject a newer settings revision.");
    state.Require(staleBackupPath.empty() && FindSettingsBackupArtifact(kTestAppId).empty(),
                  L"A stale explicit-replacement confirmation must not create a backup from the newer revision.");
    state.Require(ReadSettingsTestBytes(settingsPath) == kConcurrentFutureSettings,
                  L"A stale explicit-replacement confirmation must leave the newer revision canonical.");

    CleanupSettingsArtifacts(kTestAppId);
    state.Require(SelfTest::WriteTextFile(settingsPath, kFutureSettings), L"Failed to restore the future-schema fixture for explicit replacement.");
    loaded   = Common::Settings::Settings{};
    recovery = Common::Settings::SettingsLoadRecoveryInfo{};
    state.Require(Common::Settings::LoadSettingsWithRecoveryInfo(kTestAppId, loaded, &recovery) == S_FALSE &&
                      loaded.persistence.savePermission == Common::Settings::SettingsSavePermission::ExplicitReplacementRequired,
                  L"Failed to reload the restored future-schema fixture for explicit replacement.");

    state.Require(DeleteFileW(settingsPath.c_str()) != FALSE, L"Failed to delete the presented future-schema revision before explicit replacement.");
    std::filesystem::path deletedSourceBackupPath;
    const HRESULT deletedSourceReplaceHr = SettingsHotReload::ReplaceBlockedSettingsAndSchema(kTestAppId, loaded, deletedSourceBackupPath);
    state.Require(deletedSourceReplaceHr == HRESULT_FROM_WIN32(ERROR_REVISION_MISMATCH) && deletedSourceBackupPath.empty(),
                  L"Explicit replacement must reject a presented revision that was already removed.");

    state.Require(SelfTest::WriteTextFile(settingsPath, kFutureSettings), L"Failed to restore the deleted future-schema fixture for explicit replacement.");
    loaded   = Common::Settings::Settings{};
    recovery = Common::Settings::SettingsLoadRecoveryInfo{};
    state.Require(Common::Settings::LoadSettingsWithRecoveryInfo(kTestAppId, loaded, &recovery) == S_FALSE &&
                      loaded.persistence.savePermission == Common::Settings::SettingsSavePermission::ExplicitReplacementRequired,
                  L"Failed to reload the deleted future-schema fixture for explicit replacement.");

    std::filesystem::path explicitBackupPath;
    const HRESULT replaceHr = SettingsHotReload::ReplaceBlockedSettingsAndSchema(kTestAppId, loaded, explicitBackupPath);
    state.Require(replaceHr == S_OK, L"A user-approved future-schema replacement should succeed after backup.");
    state.Require(! explicitBackupPath.empty() && SelfTest::PathExists(explicitBackupPath),
                  L"Explicit future-schema replacement must create its backup first.");
    state.Require(ReadSettingsTestBytes(explicitBackupPath) == before, L"The explicit replacement backup must preserve the exact future-schema bytes.");
    state.Require(loaded.persistence.savePermission == Common::Settings::SettingsSavePermission::Automatic,
                  L"The save block should clear only after explicit backup succeeds.");
    state.Require(ReadSettingsTestBytes(settingsPath) != before, L"Explicit replacement should install the current schema after preserving the source.");
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreUnknownTopLevelMembersSurviveSave(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestOpaqueRootRoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup                       = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });
    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);
    constexpr std::string_view kSettings     = R"json({
  "schemaVersion": 16,
  "theme": { "currentThemeId": "builtin/light" },
  "futureFeature": { "mode": "preserve-me", "items": [1, true, null] }
})json";
    state.Require(SelfTest::WriteTextFile(settingsPath, kSettings), L"Failed to write opaque-root round-trip fixture.");

    Common::Settings::Settings loaded{};
    state.Require(Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded) == S_OK, L"Failed to load settings with an unknown top-level member.");
    state.Require(loaded.persistence.opaqueTopLevelMembers.size() == 1u && loaded.persistence.opaqueTopLevelMembers[0].first == "futureFeature",
                  L"Unknown top-level JSON must be copied into owned opaque storage.");
    loaded.theme.currentThemeId = L"builtin/dark";
    state.Require(SUCCEEDED(Common::Settings::SaveSettings(kTestAppId, loaded)), L"Failed to save settings containing opaque root data.");

    Common::Settings::JsonValue root;
    state.Require(SUCCEEDED(Common::Settings::ParseJsonValue(ReadSettingsTestBytes(settingsPath), root)), L"Failed to parse the opaque-root saved output.");
    const Common::Settings::JsonValue* future = Common::Settings::FindMember(root, "futureFeature");
    state.Require(future != nullptr, L"Unknown top-level data did not survive a canonical save.");
    if (future)
    {
        state.Require(Common::Settings::GetString(*future, "mode").value_or("") == "preserve-me", L"The opaque object payload changed during canonical save.");
        const Common::Settings::JsonArray* items = Common::Settings::GetArray(*future, "items");
        state.Require(items != nullptr && items->items.size() == 3u, L"Nested opaque array data did not survive the yyjson document lifetime.");
    }
    return state.failure.empty();
}

[[nodiscard]] bool TestHResultDetailsResourceUsesValidFormatString(CaseState& state) noexcept
{
    try
    {
        const std::wstring details =
            FormatEmbeddedStringResource(nullptr, IDS_FMT_HRESULT_DETAILS, 0x80070002u, std::wstring(L"The system cannot find the file specified."));
        state.Require(details.find(L"80070002") != std::wstring::npos, L"HRESULT details should include the formatted HRESULT.");
        state.Require(details.find(L"The system cannot find the file specified.") != std::wstring::npos,
                      L"HRESULT details should include the system error text.");
    }
    catch (const std::format_error&)
    {
        state.Require(false, L"IDS_FMT_HRESULT_DETAILS must be a valid std::format resource string.");
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestInvalidResourceFormatStringReturnsRawFallback(CaseState& state) noexcept
{
    try
    {
        constexpr std::wstring_view kInvalidFormat = L"0x{0:08X}: {1";
        const std::wstring details = FormatLoadedStringResource(0u, kInvalidFormat, 0x80070002u, std::wstring(L"The system cannot find the file specified."));
        state.Require(details == kInvalidFormat, L"Invalid runtime resource format strings should fall back to the raw resource text.");
    }
    catch (const std::format_error&)
    {
        state.Require(false, L"Invalid runtime resource format strings must not escape as std::format_error.");
    }

    return state.failure.empty();
}

struct ResourcePlaceholderFinding
{
    std::filesystem::path path;
    size_t lineNumber = 0;
    std::string field;
    std::string literal;
};

[[nodiscard]] bool IsAllowedLiteralBraceMacro(std::string_view value) noexcept
{
    static constexpr std::array<std::string_view, 7> kLiteralMacros{{
        "Path",
        "FullPath",
        "PathAndFilename",
        "Filename",
        "SelectedPathsFile",
        "OppositePanePath",
        "ComputerName",
    }};

    return std::ranges::find(kLiteralMacros, value) != kLiteralMacros.end();
}

[[nodiscard]] bool IsPositionalFormatField(std::string_view value) noexcept
{
    return ! value.empty() && value.front() >= '0' && value.front() <= '9';
}

[[nodiscard]] std::wstring WidenAscii(std::string_view value)
{
    std::wstring result;
    result.reserve(value.size());
    for (const char ch : value)
    {
        result.push_back(static_cast<wchar_t>(static_cast<unsigned char>(ch)));
    }

    return result;
}

void ScanResourceLiteralForFormatFields(const std::filesystem::path& path,
                                        size_t lineNumber,
                                        const std::string& literal,
                                        std::vector<ResourcePlaceholderFinding>& findings)
{
    for (size_t index = 0; index < literal.size();)
    {
        const char ch = literal[index];
        if (ch == '{')
        {
            if (index + 1 < literal.size() && literal[index + 1] == '{')
            {
                index += 2;
                continue;
            }

            const size_t close = literal.find('}', index + 1);
            if (close == std::string::npos)
            {
                findings.push_back({path, lineNumber, literal.substr(index), literal});
                ++index;
                continue;
            }

            const std::string_view field(literal.data() + index + 1, close - index - 1);
            if (! IsPositionalFormatField(field) && ! IsAllowedLiteralBraceMacro(field))
            {
                findings.push_back({path, lineNumber, literal.substr(index, close - index + 1), literal});
            }

            index = close + 1;
            continue;
        }

        if (ch == '}')
        {
            if (index + 1 < literal.size() && literal[index + 1] == '}')
            {
                index += 2;
                continue;
            }

            findings.push_back({path, lineNumber, std::string(1, ch), literal});
        }

        ++index;
    }
}

void ScanResourceLineForFormatFields(const std::filesystem::path& path,
                                     size_t lineNumber,
                                     std::string_view line,
                                     std::vector<ResourcePlaceholderFinding>& findings)
{
    bool inString = false;
    std::string literal;

    for (size_t index = 0; index < line.size(); ++index)
    {
        const char ch = line[index];
        if (! inString)
        {
            if (ch == '"')
            {
                inString = true;
                literal.clear();
            }
            continue;
        }

        if (ch == '"')
        {
            if (index + 1 < line.size() && line[index + 1] == '"')
            {
                literal.push_back('"');
                ++index;
                continue;
            }

            ScanResourceLiteralForFormatFields(path, lineNumber, literal, findings);
            inString = false;
            continue;
        }

        literal.push_back(ch);
    }
}

[[nodiscard]] std::filesystem::path TryFindResourceAuditRepoRoot() noexcept
{
    // The audits read tracked sources and resources only, so the shared checkout-layout rule
    // (.git, RedSalamander.sln, or RedSalamander/RedSalamander.vcxproj) is sufficient. Requiring the
    // gitignored Specs/TestRuns evidence archive here left every fresh clone, including the
    // hosted runners, with "Repository root unavailable".
    return SelfTest::TryFindRepoRoot();
}

[[nodiscard]] bool TestResourceFormatPlaceholdersArePositional(CaseState& state) noexcept
{
    const std::filesystem::path repoRoot = TryFindResourceAuditRepoRoot();
    state.Require(! repoRoot.empty(), L"Repository root unavailable for resource placeholder audit.");
    if (repoRoot.empty())
    {
        return false;
    }

    static constexpr std::array<std::wstring_view, 4> kResourceRoots{{L"Common", L"Plugins", L"RedSalamander", L"RedSalamanderMonitor"}};
    std::vector<ResourcePlaceholderFinding> findings;
    std::error_code ec;

    for (const std::wstring_view resourceRoot : kResourceRoots)
    {
        const std::filesystem::path root = repoRoot / resourceRoot;
        if (! std::filesystem::exists(root, ec) || ec)
        {
            ec.clear();
            continue;
        }

        std::filesystem::recursive_directory_iterator it(root, std::filesystem::directory_options::skip_permission_denied, ec);
        const std::filesystem::recursive_directory_iterator end;
        while (! ec && it != end)
        {
            const std::filesystem::directory_entry entry = *it;
            if (entry.is_regular_file(ec) && ! ec && entry.path().extension() == L".rc")
            {
                std::ifstream input(entry.path(), std::ios::binary);
                std::string line;
                size_t lineNumber = 0;
                while (std::getline(input, line))
                {
                    ++lineNumber;
                    ScanResourceLineForFormatFields(entry.path(), lineNumber, line, findings);
                }
            }

            it.increment(ec);
        }
        ec.clear();
    }

    if (! findings.empty())
    {
        const ResourcePlaceholderFinding& first = findings.front();
        state.Require(false,
                      std::format(L"Resource format placeholders must be positional. First offender: {}:{} field {} in \"{}\".",
                                  first.path.wstring(),
                                  first.lineNumber,
                                  WidenAscii(first.field),
                                  WidenAscii(first.literal)));
    }

    return state.failure.empty();
}

struct LocalizedWindowTitleFinding
{
    std::filesystem::path path;
    size_t lineNumber = 0;
    std::wstring message;
};

[[nodiscard]] std::string ReadAuditTextFile(const std::filesystem::path& path)
{
    std::ifstream input(path, std::ios::binary);
    if (! input)
    {
        return {};
    }

    return std::string(std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>());
}

[[nodiscard]] std::string CompactAsciiForAudit(std::string_view value)
{
    std::string result;
    result.reserve(value.size());
    for (const char ch : value)
    {
        if (ch != ' ' && ch != '\t' && ch != '\r' && ch != '\n')
        {
            result.push_back(ch);
        }
    }

    return result;
}

[[nodiscard]] bool IsResourceDialogDefinitionLine(std::string_view line) noexcept
{
    const size_t first = line.find_first_not_of(" \t");
    if (first == std::string_view::npos)
    {
        return false;
    }

    if (first + 1 < line.size() && line[first] == '/' && line[first + 1] == '/')
    {
        return false;
    }

    const size_t idEnd = line.find_first_of(" \t", first);
    if (idEnd == std::string_view::npos)
    {
        return false;
    }

    const size_t typeStart = line.find_first_not_of(" \t", idEnd);
    if (typeStart == std::string_view::npos)
    {
        return false;
    }

    return line.compare(typeStart, 6, "DIALOG") == 0;
}

void ScanResourceDialogCaptions(const std::filesystem::path& path, std::vector<LocalizedWindowTitleFinding>& findings)
{
    std::ifstream input(path, std::ios::binary);
    std::string line;
    std::string dialogId;
    size_t lineNumber = 0;
    bool inDialog     = false;

    while (std::getline(input, line))
    {
        ++lineNumber;
        const std::string compact = CompactAsciiForAudit(line);
        if (IsResourceDialogDefinitionLine(line))
        {
            const size_t firstSpace = line.find_first_of(" \t");
            dialogId                = firstSpace == std::string::npos ? line : line.substr(0, firstSpace);
            inDialog                = true;
            continue;
        }

        if (! inDialog)
        {
            continue;
        }

        if (compact == "CAPTION\"\"")
        {
            findings.push_back({path, lineNumber, std::format(L"{} has an empty dialog caption.", WidenAscii(dialogId))});
        }
        else if (compact == "END")
        {
            inDialog = false;
            dialogId.clear();
        }
    }
}

void ScanStandaloneViewerWindowTitles(const std::filesystem::path& repoRoot, std::vector<LocalizedWindowTitleFinding>& findings)
{
    struct Target
    {
        std::wstring_view relativePath;
        std::string_view forbiddenPattern;
        std::wstring_view message;
    };

    static constexpr std::array<Target, 6> kTargets{{
        {L"Plugins/ViewerImgRaw/ViewerImgRaw.cpp",
         "CreateWindowExW(0,kClassName,embeddedMode?L\"\":(_metaName.empty()?L\"\":_metaName.c_str()),style,",
         L"ViewerImgRaw creates a standalone viewer window with an empty initial title fallback."},
        {L"Plugins/ViewerPE/ViewerPE.cpp",
         "CreateWindowExW(0,kClassName,L\"\",style,",
         L"ViewerPE creates a standalone viewer window with an empty initial title."},
        {L"Plugins/ViewerSpace/ViewerSpace.cpp",
         "CreateWindowExW(0,kClassName,embeddedMode?L\"\":(_metaName.empty()?L\"\":_metaName.c_str()),style,",
         L"ViewerSpace creates a standalone viewer window with an empty initial title fallback."},
        {L"Plugins/ViewerSqlite/ViewerSqlite.cpp",
         "CreateWindowExW(0,GetWindowClassName().c_str(),embeddedMode?L\"\":_metaName.c_str(),style,",
         L"ViewerSqlite creates a standalone viewer window with an empty initial title fallback."},
        {L"Plugins/ViewerWeb/ViewerWeb.cpp",
         "CreateWindowExW(0,kClassName,L\"\",style,",
         L"ViewerWeb creates a standalone viewer window with an empty initial title."},
        {L"Plugins/ViewerText/ViewerText.cpp",
         "CreateWindowExW(0,kClassName,L\"\",WS_OVERLAPPEDWINDOW",
         L"ViewerText creates a standalone viewer window with an empty initial title."},
    }};

    for (const Target& target : kTargets)
    {
        const std::filesystem::path path = repoRoot / std::filesystem::path(std::wstring(target.relativePath));
        const std::string compact        = CompactAsciiForAudit(ReadAuditTextFile(path));
        if (! compact.empty() && compact.find(target.forbiddenPattern) != std::string::npos)
        {
            findings.push_back({path, 0, std::wstring(target.message)});
        }
    }
}

void ScanEmbeddedViewerContextMenuContracts(const std::filesystem::path& repoRoot, std::vector<LocalizedWindowTitleFinding>& findings)
{
    struct Target
    {
        std::wstring_view relativePath;
        std::string_view className;
        std::string_view menuResourceId;
        const std::string_view* previewExcludedCommands;
        size_t previewExcludedCommandCount;
    };

    static constexpr std::array<std::string_view, 8> kViewerTextExcluded{{
        "IDM_VIEWER_FILE_OPEN",
        "IDM_VIEWER_FILE_EXIT",
        "IDM_VIEWER_OTHER_NEXT",
        "IDM_VIEWER_OTHER_PREVIOUS",
        "IDM_VIEWER_OTHER_FIRST",
        "IDM_VIEWER_OTHER_LAST",
        "IDM_VIEWER_ENCODING_NEXT",
        "IDM_VIEWER_ENCODING_PREVIOUS",
    }};
    static constexpr std::array<std::string_view, 5> kViewerRawExcluded{{
        "IDM_VIEWERRAW_FILE_EXIT",
        "IDM_VIEWERRAW_OTHER_NEXT",
        "IDM_VIEWERRAW_OTHER_PREVIOUS",
        "IDM_VIEWERRAW_OTHER_FIRST",
        "IDM_VIEWERRAW_OTHER_LAST",
    }};
    static constexpr std::array<std::string_view, 5> kViewerWebExcluded{{
        "IDM_VIEWERWEB_FILE_EXIT",
        "IDM_VIEWERWEB_OTHER_NEXT",
        "IDM_VIEWERWEB_OTHER_PREVIOUS",
        "IDM_VIEWERWEB_OTHER_FIRST",
        "IDM_VIEWERWEB_OTHER_LAST",
    }};
    static constexpr std::array<std::string_view, 5> kViewerPeExcluded{{
        "IDM_VIEWERPE_FILE_EXIT",
        "IDM_VIEWERPE_OTHER_NEXT",
        "IDM_VIEWERPE_OTHER_PREVIOUS",
        "IDM_VIEWERPE_OTHER_FIRST",
        "IDM_VIEWERPE_OTHER_LAST",
    }};
    static constexpr std::array<std::string_view, 1> kViewerSpaceExcluded{{
        "IDM_VIEWERSPACE_FILE_EXIT",
    }};

    static constexpr std::array<Target, 5> kTargets{{
        {L"Plugins/ViewerText/ViewerText.cpp", "ViewerText", "IDR_VIEWERTEXT_MENU", kViewerTextExcluded.data(), kViewerTextExcluded.size()},
        {L"Plugins/ViewerImgRaw/ViewerImgRaw.cpp", "ViewerImgRaw", "IDR_VIEWERRAW_MENU", kViewerRawExcluded.data(), kViewerRawExcluded.size()},
        {L"Plugins/ViewerWeb/ViewerWeb.cpp", "ViewerWeb", "IDR_VIEWERWEB_MENU", kViewerWebExcluded.data(), kViewerWebExcluded.size()},
        {L"Plugins/ViewerPE/ViewerPE.cpp", "ViewerPE", "IDR_VIEWERPE_MENU", kViewerPeExcluded.data(), kViewerPeExcluded.size()},
        {L"Plugins/ViewerSpace/ViewerSpace.cpp", "ViewerSpace", "IDR_VIEWERSPACE_MENU", kViewerSpaceExcluded.data(), kViewerSpaceExcluded.size()},
    }};

    for (const Target& target : kTargets)
    {
        const std::filesystem::path path = repoRoot / std::filesystem::path(std::wstring(target.relativePath));
        const std::string compact        = CompactAsciiForAudit(ReadAuditTextFile(path));
        if (compact.empty())
        {
            findings.push_back({path, 0, L"Embedded viewer context-menu audit could not read the source file."});
            continue;
        }

        const std::string handlerSignature = std::format("void{}::OnContextMenu(HWNDhwnd,POINTscreenPt)noexcept", target.className);
        const std::string menuLoadPattern  = std::format("Localization::LoadMenuResource(g_hInstance,{})", target.menuResourceId);

        if (compact.find("caseWM_CONTEXTMENU:") == std::string::npos)
        {
            findings.push_back({path, 0, L"Embedded-capable viewer does not handle WM_CONTEXTMENU."});
        }
        if (compact.find(handlerSignature) == std::string::npos)
        {
            findings.push_back({path, 0, L"Embedded-capable viewer does not route context-menu work through an OnContextMenu handler."});
        }
        if (compact.find(menuLoadPattern) == std::string::npos)
        {
            findings.push_back(
                {path, 0, std::format(L"Embedded-capable viewer does not load its localized {} menu model.", WidenAscii(target.menuResourceId))});
        }
        if (compact.find("ShowNativeHMenuContextMenu(hwnd,screenPt,menu,") == std::string::npos)
        {
            findings.push_back({path, 0, L"Embedded-capable viewer does not expose its native menu model through the DxUi context menu."});
        }
        if (compact.find("includeAcceleratorText=false") == std::string::npos)
        {
            findings.push_back({path, 0, L"Embedded Preview context menus must not advertise standalone viewer keyboard shortcuts."});
        }
        if (compact.find("excludedCommandIds=kPreviewContextMenuExcludedCommandIds") == std::string::npos)
        {
            findings.push_back({path, 0, L"Embedded Preview context menus must use the curated Preview-only exclusion list."});
        }
        if (compact.find("omitEmptySubmenus=true") == std::string::npos || compact.find("trimSeparators=true") == std::string::npos)
        {
            findings.push_back({path, 0, L"Embedded Preview context menus must trim removed standalone-only entries cleanly."});
        }
        for (size_t index = 0; index < target.previewExcludedCommandCount; ++index)
        {
            const std::string_view commandId = target.previewExcludedCommands[index];
            if (compact.find(commandId) == std::string::npos)
            {
                findings.push_back(
                    {path, 0, std::format(L"Embedded Preview context menu does not exclude standalone-only command {}.", WidenAscii(commandId))});
            }
        }
    }
}

void ScanEmbeddedVlcAudioPreviewContracts(const std::filesystem::path& repoRoot, std::vector<LocalizedWindowTitleFinding>& findings)
{
    const std::filesystem::path path = repoRoot / L"Plugins/ViewerVLC/ViewerVLC.cpp";
    const std::string compact        = CompactAsciiForAudit(ReadAuditTextFile(path));
    if (compact.empty())
    {
        findings.push_back({path, 0, L"Embedded VLC audio-preview audit could not read ViewerVLC.cpp."});
        return;
    }

    if (compact.find("libvlc_media_add_option") == std::string::npos || compact.find("\":audio-visual={}\"") == std::string::npos ||
        compact.find("_isAudioFile&&!_config.audioVisualization.empty()&&_config.audioVisualization!=\"off\"") == std::string::npos)
    {
        findings.push_back({path,
                            0,
                            L"Embedded VLC audio previews must apply audio visualization as an audio-file media option so video previews do not get an extra "
                            L"visualizer vout."});
    }
    if (compact.find("\"--audio-visual={}\"") != std::string::npos ||
        compact.find("constboolenableAudioVisualization=!_config.audioVisualization.empty()&&_config.audioVisualization!=\"off\";") != std::string::npos)
    {
        findings.push_back({path,
                            0,
                            L"ViewerVLC must not pass audio visualization as a global VLC instance argument because that can create top-level vout windows for "
                            L"video preview."});
    }
    if (compact.find("!_embeddedMode&&_isAudioFile&&") != std::string::npos)
    {
        findings.push_back(
            {path,
             0,
             L"Embedded VLC audio previews must not suppress audio visualization to avoid top-level windows; contain playback inside Preview instead."});
    }
}

[[nodiscard]] bool TestPopupAndDialogTitlesAreLocalized(CaseState& state) noexcept
{
    const std::filesystem::path repoRoot = TryFindResourceAuditRepoRoot();
    state.Require(! repoRoot.empty(), L"Repository root unavailable for popup/dialog title audit.");
    if (repoRoot.empty())
    {
        return false;
    }

    static constexpr std::array<std::wstring_view, 4> kResourceRoots{{L"Common", L"Plugins", L"RedSalamander", L"RedSalamanderMonitor"}};
    std::vector<LocalizedWindowTitleFinding> findings;
    std::error_code ec;

    for (const std::wstring_view resourceRoot : kResourceRoots)
    {
        const std::filesystem::path root = repoRoot / resourceRoot;
        if (! std::filesystem::exists(root, ec) || ec)
        {
            ec.clear();
            continue;
        }

        std::filesystem::recursive_directory_iterator it(root, std::filesystem::directory_options::skip_permission_denied, ec);
        const std::filesystem::recursive_directory_iterator end;
        while (! ec && it != end)
        {
            const std::filesystem::directory_entry entry = *it;
            if (entry.is_regular_file(ec) && ! ec && entry.path().extension() == L".rc")
            {
                ScanResourceDialogCaptions(entry.path(), findings);
            }

            it.increment(ec);
        }
        ec.clear();
    }

    ScanStandaloneViewerWindowTitles(repoRoot, findings);

    if (! findings.empty())
    {
        const LocalizedWindowTitleFinding& first = findings.front();
        state.Require(
            false,
            std::format(
                L"Popup and dialog titles must be localized and non-empty. First offender: {}:{} {}", first.path.wstring(), first.lineNumber, first.message));
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestEmbeddedViewerContextMenusExposeMenuActions(CaseState& state) noexcept
{
    const std::filesystem::path repoRoot = TryFindResourceAuditRepoRoot();
    state.Require(! repoRoot.empty(), L"Repository root unavailable for embedded viewer context-menu audit.");
    if (repoRoot.empty())
    {
        return false;
    }

    std::vector<LocalizedWindowTitleFinding> findings;
    ScanEmbeddedViewerContextMenuContracts(repoRoot, findings);

    if (! findings.empty())
    {
        const LocalizedWindowTitleFinding& first = findings.front();
        state.Require(false,
                      std::format(L"Embedded viewer context menus must expose the viewer menu actions. First offender: {}:{} {}",
                                  first.path.wstring(),
                                  first.lineNumber,
                                  first.message));
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestEmbeddedVlcAudioPreviewKeepsPlaybackInsidePreview(CaseState& state) noexcept
{
    const std::filesystem::path repoRoot = TryFindResourceAuditRepoRoot();
    state.Require(! repoRoot.empty(), L"Repository root unavailable for embedded VLC audio-preview audit.");
    if (repoRoot.empty())
    {
        return false;
    }

    std::vector<LocalizedWindowTitleFinding> findings;
    ScanEmbeddedVlcAudioPreviewContracts(repoRoot, findings);

    if (! findings.empty())
    {
        const LocalizedWindowTitleFinding& first = findings.front();
        state.Require(
            false,
            std::format(
                L"Embedded VLC audio preview must stay inside Preview. First offender: {}:{} {}", first.path.wstring(), first.lineNumber, first.message));
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreFileActionsV16RejectsMalformedDefinitions(CaseState& state) noexcept
{
    struct MalformedCase
    {
        std::wstring_view appId;
        std::string_view json;
        std::wstring_view message;
    };

    constexpr std::array<MalformedCase, 11> kCases = {{
        {L"RedSalamanderSelfTestMalformedFileActionMissingPlugin",
         R"json({
  "schemaVersion": 16,
  "fileActions": {
    "viewers": {
      "actions": [
        { "id": "missing-plugin", "kind": "viewerPlugin" }
      ]
    }
  }
})json",
         L"viewerPlugin file actions without pluginId should be rejected."},
        {L"RedSalamanderSelfTestMalformedFileActionViewerWithExecutable",
         R"json({
  "schemaVersion": 16,
  "fileActions": {
    "viewers": {
      "actions": [
        { "id": "viewer-with-exe", "kind": "viewerPlugin", "pluginId": "builtin/viewer-text", "executablePath": "notepad.exe" }
      ]
    }
  }
})json",
         L"viewerPlugin file actions with executablePath should be rejected."},
        {L"RedSalamanderSelfTestMalformedFileActionViewerWithEmptyExecutable",
         R"json({
  "schemaVersion": 16,
  "fileActions": {
    "viewers": {
      "actions": [
        { "id": "viewer-with-empty-exe", "kind": "viewerPlugin", "pluginId": "builtin/viewer-text", "executablePath": "" }
      ]
    }
  }
})json",
         L"viewerPlugin file actions with an executablePath field should be rejected even when empty."},
        {L"RedSalamanderSelfTestMalformedFileActionMissingExecutable",
         R"json({
  "schemaVersion": 16,
  "fileActions": {
    "editors": {
      "actions": [
        { "id": "missing-executable", "kind": "externalProgram" }
      ]
    }
  }
})json",
         L"externalProgram file actions without executablePath should be rejected."},
        {L"RedSalamanderSelfTestMalformedFileActionExternalWithPlugin",
         R"json({
  "schemaVersion": 16,
  "fileActions": {
    "viewers": {
      "actions": [
        { "id": "external-with-plugin", "kind": "externalProgram", "executablePath": "notepad.exe", "pluginId": "builtin/viewer-text" }
      ]
    }
  }
})json",
         L"externalProgram file actions with pluginId should be rejected."},
        {L"RedSalamanderSelfTestMalformedFileActionExternalWithEmptyPlugin",
         R"json({
  "schemaVersion": 16,
  "fileActions": {
    "viewers": {
      "actions": [
        { "id": "external-with-empty-plugin", "kind": "externalProgram", "executablePath": "notepad.exe", "pluginId": "" }
      ]
    }
  }
})json",
         L"externalProgram file actions with a pluginId field should be rejected even when empty."},
        {L"RedSalamanderSelfTestMalformedFileActionUnknownKind",
         R"json({
  "schemaVersion": 16,
  "fileActions": {
    "viewers": {
      "actions": [
        { "id": "unknown-kind", "kind": "internalThing", "pluginId": "builtin/viewer-text" }
      ]
    }
  }
})json",
         L"file actions with unknown kind should be rejected."},
        {L"RedSalamanderSelfTestMalformedFileActionBadExtension",
         R"json({
  "schemaVersion": 16,
  "fileActions": {
    "viewers": {
      "actions": [
        {
          "id": "bad-extension",
          "kind": "viewerPlugin",
          "pluginId": "builtin/viewer-text",
          "appliesTo": {
            "matches": [
              { "kind": "extension", "value": "txt" }
            ]
          }
        }
      ]
    }
  }
})json",
         L"extension file-action matches without a leading dot should be rejected."},
        {L"RedSalamanderSelfTestMalformedFileActionMissingReference",
         R"json({
  "schemaVersion": 16,
  "fileActions": {
    "viewers": {
      "actions": [
        { "id": "text-viewer", "kind": "viewerPlugin", "pluginId": "builtin/viewer-text" }
      ],
      "associations": [
        {
          "match": { "kind": "extension", "value": ".txt" },
          "viewActionId": "missing-action"
        }
      ]
         }
  }
})json",
         L"viewer associations that reference missing action ids should be rejected."},
        {L"RedSalamanderSelfTestMalformedFileActionDuplicateCaseOnlyId",
         R"json({
  "schemaVersion": 16,
  "fileActions": {
    "editors": {
      "actions": [
        { "id": "CaseTool", "kind": "externalProgram", "executablePath": "notepad.exe" },
        { "id": "casetool", "kind": "externalProgram", "executablePath": "notepad.exe" }
      ]
    }
  }
})json",
         L"file actions whose IDs differ only by case should be rejected."},
        {L"RedSalamanderSelfTestMalformedEditorViewerPlugin",
         R"json({
  "schemaVersion": 16,
  "fileActions": {
    "editors": {
      "actions": [
        { "id": "editor-plugin", "kind": "viewerPlugin", "pluginId": "builtin/viewer-text" }
      ]
    }
  }
})json",
         L"editor file actions must reject viewerPlugin actions."},
    }};

    for (const MalformedCase& item : kCases)
    {
        CleanupSettingsArtifacts(item.appId);
    }
    const auto cleanup = wil::scope_exit([&]
    {
        for (const MalformedCase& item : kCases)
        {
            CleanupSettingsArtifacts(item.appId);
        }
    });

    for (const MalformedCase& item : kCases)
    {
        const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(item.appId);
        state.Require(! settingsPath.empty(), std::format(L"Malformed File Actions settings path unavailable for {}.", item.appId));
        if (settingsPath.empty())
        {
            return false;
        }

        state.Require(SelfTest::WriteTextFile(settingsPath, item.json), std::format(L"Failed to write malformed File Actions settings for {}.", item.appId));
        if (! state.failure.empty())
        {
            return false;
        }

        Common::Settings::Settings loaded{};
        const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(item.appId, loaded);
        state.Require(loadHr == S_OK, item.message);
        state.Require(! loaded.persistence.opaqueTopLevelMembers.empty() && loaded.persistence.opaqueTopLevelMembers[0].first == "fileActions",
                      std::format(L"Malformed File Actions JSON should remain available for repair for {}.", item.appId));
    }

    constexpr std::wstring_view kLongPatternAppId = L"RedSalamanderSelfTestMalformedFileActionLongPattern";
    CleanupSettingsArtifacts(kLongPatternAppId);
    const auto cleanupLongPattern = wil::scope_exit([&] { CleanupSettingsArtifacts(kLongPatternAppId); });

    const std::filesystem::path longPatternPath = Common::Settings::GetSettingsPath(kLongPatternAppId);
    state.Require(! longPatternPath.empty(), L"Long-pattern File Actions settings path unavailable.");
    if (longPatternPath.empty())
    {
        return false;
    }

    std::string longPatternJson = R"json({
  "schemaVersion": 16,
  "fileActions": {
    "viewers": {
      "actions": [
        {
          "id": "long-pattern",
          "kind": "viewerPlugin",
          "pluginId": "builtin/viewer-text",
          "appliesTo": {
            "matches": [
              { "kind": "pattern", "value": ")json";
    longPatternJson.append(513u, 'a');
    longPatternJson.append(R"json(" }
            ]
          }
        }
      ]
    }
  }
})json");

    state.Require(SelfTest::WriteTextFile(longPatternPath, longPatternJson), L"Failed to write long-pattern File Actions settings.");
    Common::Settings::Settings longPatternLoaded{};
    const HRESULT longPatternHr = Common::Settings::TryLoadSettingsNoRecovery(kLongPatternAppId, longPatternLoaded);
    state.Require(longPatternHr == S_OK && ! longPatternLoaded.persistence.opaqueTopLevelMembers.empty(),
                  L"Overlong pattern File Actions should reset that section and retain the source payload.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreFileActionsV16EmptyViewersRoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestFileActionsV16EmptyViewers";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings settings{};
    settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    settings.fileActions.editors = Common::Settings::EditorFileActionsSettings{};

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, settings);
    state.Require(SUCCEEDED(saveHr), L"Failed to save empty File Actions settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Failed to load empty File Actions settings.");
    if (FAILED(loadHr))
    {
        return false;
    }

    state.Require(loaded.fileActions.viewers.actions.empty(), L"Empty viewer actions should survive round-trip instead of restoring defaults.");
    state.Require(loaded.fileActions.viewers.associations.empty(), L"Empty viewer associations should survive round-trip instead of restoring defaults.");
    state.Require(loaded.fileActions.editors.actions.empty(), L"Empty editor actions should survive round-trip.");
    state.Require(loaded.fileActions.editors.associations.empty(), L"Empty editor associations should survive round-trip.");
    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionResolutionV16ExplainsPriority(CaseState& state) noexcept
{
    Common::Settings::EditorFileActionsSettings editors{};

    Common::Settings::FileActionDefinition globalDefault{};
    globalDefault.id                = L"global-default";
    globalDefault.enabled           = true;
    globalDefault.appliesTo.matches = {{Common::Settings::FileActionMatchKind::Default, L""}};

    Common::Settings::FileActionDefinition computerDefault{};
    computerDefault.id                      = L"computer-default";
    computerDefault.enabled                 = true;
    computerDefault.appliesTo.matches       = {{Common::Settings::FileActionMatchKind::Default, L""}};
    computerDefault.appliesTo.computerNames = {L"DEV-PC"};

    Common::Settings::FileActionDefinition globalCpp{};
    globalCpp.id                = L"global-cpp";
    globalCpp.enabled           = true;
    globalCpp.appliesTo.matches = {{Common::Settings::FileActionMatchKind::Extension, L".cpp"}};

    Common::Settings::FileActionDefinition computerCpp{};
    computerCpp.id                      = L"computer-cpp";
    computerCpp.enabled                 = true;
    computerCpp.appliesTo.matches       = {{Common::Settings::FileActionMatchKind::Extension, L".cpp"}};
    computerCpp.appliesTo.computerNames = {L"DEV-PC"};

    editors.actions = {globalDefault, computerDefault, globalCpp, computerCpp};

    Common::Settings::EditorAssociationRule globalDefaultRule{};
    globalDefaultRule.match.kind   = Common::Settings::FileActionMatchKind::Default;
    globalDefaultRule.editActionId = L"global-default";

    Common::Settings::EditorAssociationRule computerDefaultRule{};
    computerDefaultRule.match.kind   = Common::Settings::FileActionMatchKind::Default;
    computerDefaultRule.computerName = L"DEV-PC";
    computerDefaultRule.editActionId = L"computer-default";

    Common::Settings::EditorAssociationRule globalCppRule{};
    globalCppRule.match.kind   = Common::Settings::FileActionMatchKind::Extension;
    globalCppRule.match.value  = L".cpp";
    globalCppRule.editActionId = L"global-cpp";

    Common::Settings::EditorAssociationRule computerCppRule{};
    computerCppRule.match.kind   = Common::Settings::FileActionMatchKind::Extension;
    computerCppRule.match.value  = L".cpp";
    computerCppRule.computerName = L"DEV-PC";
    computerCppRule.editActionId = L"computer-cpp";

    editors.associations = {globalDefaultRule, computerDefaultRule, globalCppRule, computerCppRule};

    FileActionResolver::Request request{};
    request.command      = FileActionResolver::Command::Edit;
    request.filePath     = std::filesystem::path(L"C:\\Src\\MAIN.CPP");
    request.computerName = L"dev-pc";

    const FileActionResolver::Resolution computerCppResolution = FileActionResolver::ResolveEditorAction(editors, request);
    state.Require(computerCppResolution.action && computerCppResolution.action->id == L"computer-cpp",
                  L"Computer + extension association should win for matching editor command.");
    state.Require(computerCppResolution.reason == FileActionResolver::Reason::ComputerExtensionRule,
                  L"Computer + extension editor resolution should explain the winning priority.");
    state.Require(computerCppResolution.reasonText.find(L".cpp") != std::wstring::npos &&
                      computerCppResolution.reasonText.find(L"DEV-PC") != std::wstring::npos,
                  L"Editor resolution explanation should include the extension and computer.");

    request.computerName                                     = L"OTHER-PC";
    const FileActionResolver::Resolution globalCppResolution = FileActionResolver::ResolveEditorAction(editors, request);
    state.Require(globalCppResolution.action && globalCppResolution.action->id == L"global-cpp",
                  L"Global extension association should win when the computer override does not match.");
    state.Require(globalCppResolution.reason == FileActionResolver::Reason::GlobalExtensionRule,
                  L"Global extension editor resolution should explain the winning priority.");

    request.filePath                                               = std::filesystem::path(L"C:\\Src\\README.md");
    request.computerName                                           = L"DEV-PC";
    const FileActionResolver::Resolution computerDefaultResolution = FileActionResolver::ResolveEditorAction(editors, request);
    state.Require(computerDefaultResolution.action && computerDefaultResolution.action->id == L"computer-default",
                  L"Computer default association should win when no extension association matches.");
    state.Require(computerDefaultResolution.reason == FileActionResolver::Reason::ComputerDefaultRule,
                  L"Computer default editor resolution should explain the winning priority.");

    request.computerName                                         = L"OTHER-PC";
    const FileActionResolver::Resolution globalDefaultResolution = FileActionResolver::ResolveEditorAction(editors, request);
    state.Require(globalDefaultResolution.action && globalDefaultResolution.action->id == L"global-default",
                  L"Global default association should be the final editor fallback.");
    state.Require(globalDefaultResolution.reason == FileActionResolver::Reason::GlobalDefaultRule,
                  L"Global default editor resolution should explain the winning priority.");

    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionResolutionV16ActionIdsAreCaseInsensitive(CaseState& state) noexcept
{
    Common::Settings::EditorFileActionsSettings editors{};

    Common::Settings::FileActionDefinition action{};
    action.id      = L"CaseTool";
    action.enabled = true;
    TestSetActionExtensions(action, {L".case"});

    editors.actions = {action};

    Common::Settings::EditorAssociationRule globalRule{};
    globalRule.match.kind   = Common::Settings::FileActionMatchKind::Extension;
    globalRule.match.value  = L".case";
    globalRule.editActionId = L"CASETOOL";

    Common::Settings::EditorAssociationRule computerRule{};
    computerRule.match.kind   = Common::Settings::FileActionMatchKind::Extension;
    computerRule.match.value  = L".case";
    computerRule.computerName = L"DEV-PC";
    computerRule.editActionId = L"casetool";

    editors.associations = {globalRule, computerRule};

    FileActionResolver::Request request{};
    request.command      = FileActionResolver::Command::Edit;
    request.filePath     = std::filesystem::path(L"C:\\Temp\\sample.case");
    request.computerName = L"dev-pc";

    const FileActionResolver::Resolution resolution = FileActionResolver::ResolveEditorAction(editors, request);
    state.Require(resolution.action && resolution.action->id == L"CaseTool", L"Editor association action IDs should resolve case-insensitively.");

    const std::vector<const Common::Settings::FileActionDefinition*> actions = FileActionResolver::CollectAssociatedEditorActions(editors, request);
    state.Require(actions.size() == 1u, L"Editor action collection should collapse case-only action-id references to the same logical action.");
    if (actions.size() == 1u)
    {
        state.Require(actions[0] && actions[0]->id == L"CaseTool", L"Editor action collection should preserve the configured action definition casing.");
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionResolutionV16CommandKeysAreDistinct(CaseState& state) noexcept
{
    Common::Settings::ViewerFileActionsSettings viewers{};

    Common::Settings::FileActionDefinition textViewer{};
    textViewer.id      = L"text-viewer";
    textViewer.enabled = true;

    Common::Settings::FileActionDefinition hexViewer{};
    hexViewer.id      = L"hex-viewer";
    hexViewer.enabled = true;

    viewers.actions = {textViewer, hexViewer};

    Common::Settings::ViewerAssociationRule viewerRule{};
    viewerRule.match.kind            = Common::Settings::FileActionMatchKind::Extension;
    viewerRule.match.value           = L".txt";
    viewerRule.viewActionId          = L"text-viewer";
    viewerRule.alternateViewActionId = L"hex-viewer";
    viewers.associations             = {viewerRule};

    FileActionResolver::Request viewerRequest{};
    viewerRequest.command      = FileActionResolver::Command::View;
    viewerRequest.filePath     = std::filesystem::path(L"C:\\Temp\\note.txt");
    viewerRequest.computerName = L"DEV-PC";

    const FileActionResolver::Resolution viewResolution          = FileActionResolver::ResolveViewerAction(viewers, viewerRequest);
    viewerRequest.command                                        = FileActionResolver::Command::AlternateView;
    const FileActionResolver::Resolution alternateViewResolution = FileActionResolver::ResolveViewerAction(viewers, viewerRequest);
    state.Require(viewResolution.action && viewResolution.action->id == L"text-viewer", L"F3 View should resolve to the primary viewer action.");
    state.Require(alternateViewResolution.action && alternateViewResolution.action->id == L"hex-viewer",
                  L"Alt+F3 Alternate View should resolve independently from F3.");

    Common::Settings::EditorFileActionsSettings editors{};

    Common::Settings::FileActionDefinition notepad{};
    notepad.id      = L"notepad";
    notepad.enabled = true;

    Common::Settings::FileActionDefinition vscode{};
    vscode.id      = L"vscode";
    vscode.enabled = true;

    Common::Settings::FileActionDefinition visualStudio{};
    visualStudio.id      = L"visual-studio";
    visualStudio.enabled = true;

    editors.actions = {notepad, vscode, visualStudio};

    Common::Settings::EditorAssociationRule editorRule{};
    editorRule.match.kind            = Common::Settings::FileActionMatchKind::Extension;
    editorRule.match.value           = L".cpp";
    editorRule.editActionId          = L"visual-studio";
    editorRule.alternateEditActionId = L"vscode";
    editorRule.editNewActionId       = L"notepad";
    editors.associations             = {editorRule};

    FileActionResolver::Request editorRequest{};
    editorRequest.command      = FileActionResolver::Command::Edit;
    editorRequest.filePath     = std::filesystem::path(L"C:\\Src\\new.cpp");
    editorRequest.computerName = L"DEV-PC";

    const FileActionResolver::Resolution editResolution          = FileActionResolver::ResolveEditorAction(editors, editorRequest);
    editorRequest.command                                        = FileActionResolver::Command::AlternateEdit;
    const FileActionResolver::Resolution alternateEditResolution = FileActionResolver::ResolveEditorAction(editors, editorRequest);
    editorRequest.command                                        = FileActionResolver::Command::EditNew;
    const FileActionResolver::Resolution editNewResolution       = FileActionResolver::ResolveEditorAction(editors, editorRequest);

    state.Require(editResolution.action && editResolution.action->id == L"visual-studio", L"F4 Edit should resolve to editActionId.");
    state.Require(alternateEditResolution.action && alternateEditResolution.action->id == L"vscode",
                  L"Ctrl+Shift+F4 Alternate Edit should resolve to alternateEditActionId.");
    state.Require(editNewResolution.action && editNewResolution.action->id == L"notepad",
                  L"Shift+F4 Edit New should resolve to editNewActionId, not the regular Edit action.");

    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionDefaultsV16RouteViewerExtensions(CaseState& state) noexcept
{
    Common::Settings::Settings settings{};

    FileActionResolver::Request request{};
    request.command      = FileActionResolver::Command::View;
    request.filePath     = std::filesystem::path(L"C:\\Images\\photo.PNG");
    request.computerName = L"DEV-PC";

    const FileActionResolver::Resolution imageResolution = FileActionResolver::ResolveViewerAction(settings.fileActions.viewers, request);
    state.Require(imageResolution.action && imageResolution.action->pluginId == L"builtin/viewer-imgraw",
                  L"Fresh v16 settings should route default image extensions through fileActions viewer associations.");

    request.filePath                                  = std::filesystem::path(L"C:\\Windows\\System32\\notepad.EXE");
    const FileActionResolver::Resolution peResolution = FileActionResolver::ResolveViewerAction(settings.fileActions.viewers, request);
    state.Require(peResolution.action && peResolution.action->pluginId == L"builtin/viewer-pe",
                  L"Fresh v16 settings should route default Windows executable extensions through the PE viewer.");

    request.filePath                                     = std::filesystem::path(L"C:\\Media\\clip.MP4");
    const FileActionResolver::Resolution mediaResolution = FileActionResolver::ResolveViewerAction(settings.fileActions.viewers, request);
    state.Require(mediaResolution.action && mediaResolution.action->pluginId == L"builtin/viewer-vlc",
                  L"Fresh v16 settings should route default media extensions through the VLC viewer.");

    request.filePath                                        = std::filesystem::path(L"C:\\Temp\\unknown.noassociation");
    const FileActionResolver::Resolution fallbackResolution = FileActionResolver::ResolveViewerAction(settings.fileActions.viewers, request);
    state.Require(fallbackResolution.action && fallbackResolution.action->pluginId == L"builtin/viewer-text",
                  L"Fresh v16 settings should keep the default text-viewer fallback in fileActions.");

    request.command                                          = FileActionResolver::Command::AlternateView;
    const FileActionResolver::Resolution alternateResolution = FileActionResolver::ResolveViewerAction(settings.fileActions.viewers, request);
    state.Require(! alternateResolution.IsResolved(), L"Fresh v16 settings should not invent an Alternate View default.");

    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionExternalLaunchPlanMacros(CaseState& state) noexcept
{
    Common::Settings::FileActionDefinition action{};
    action.id             = L"external-viewer";
    action.kind           = Common::Settings::FileActionKind::ExternalProgram;
    action.executablePath = L"C:\\Tools\\Viewer.exe";
    action.arguments = L"--dir {Path} --file {Filename} --full {FullPath} --same {PathAndFilename} --selected {SelectedPathsFile} --other {OppositePanePath} "
                       L"--pc {ComputerName} --literal {{FullPath}}";
    action.workingDirectory = L"{Path}";

    FileActionLauncher::ExternalActionPathReferences pathReferences{};
    const HRESULT pathReferencesHr = FileActionLauncher::GetExternalActionPathReferences(action, pathReferences);
    state.Require(SUCCEEDED(pathReferencesHr), L"Valid external-action macros should produce a touch-scope description.");
    state.Require(pathReferences.itemPath && pathReferences.currentDirectory && pathReferences.oppositePanePath && pathReferences.selectedPathsFile,
                  L"External-action touch scope should include every referenced provider-path macro family.");

    Common::Settings::FileActionDefinition nonPathAction{};
    nonPathAction.executablePath      = L"C:\\Tools\\Viewer.exe";
    nonPathAction.arguments           = L"--pc {ComputerName}";
    pathReferences                    = {};
    const HRESULT nonPathReferencesHr = FileActionLauncher::GetExternalActionPathReferences(nonPathAction, pathReferences);
    state.Require(SUCCEEDED(nonPathReferencesHr) && ! pathReferences.itemPath && ! pathReferences.currentDirectory && ! pathReferences.oppositePanePath &&
                      ! pathReferences.selectedPathsFile,
                  L"Non-path external-action macros should not add unrelated objects to an artifact receipt.");

    Common::Settings::FileActionDefinition invalidPathAction = nonPathAction;
    invalidPathAction.arguments                              = L"{FullPath";
    const HRESULT invalidPathReferencesHr                    = FileActionLauncher::GetExternalActionPathReferences(invalidPathAction, pathReferences);
    state.Require(FAILED(invalidPathReferencesHr), L"Malformed macro syntax must fail before artifact consent or launch-plan side effects.");

    FileActionLauncher::MacroContext context{};
    context.itemPath          = std::filesystem::path(L"C:\\Data Set\\alpha beta.txt");
    context.oppositePanePath  = std::filesystem::path(L"D:\\Reference Pane");
    context.selectedPathsFile = std::filesystem::path(L"C:\\Temp\\selected paths.txt");
    context.computerName      = L"BUILD-BOX";

    FileActionLauncher::LaunchPlan plan{};
    const HRESULT hr = FileActionLauncher::BuildExternalLaunchPlan(action, context, plan);
    state.Require(SUCCEEDED(hr), L"External file-action launch plan should build from valid macros.");
    state.Require(plan.executablePath == L"C:\\Tools\\Viewer.exe", L"Executable path macro expansion mismatch.");
    state.Require(plan.workingDirectory == L"C:\\Data Set", L"Working directory should expand from {Path}.");
    state.Require(plan.arguments.find(L"--dir \"C:\\Data Set\"") != std::wstring::npos, L"{Path} macro should be quoted in arguments.");
    state.Require(plan.arguments.find(L"--file \"alpha beta.txt\"") != std::wstring::npos, L"{Filename} macro should be quoted in arguments.");
    state.Require(plan.arguments.find(L"--full \"C:\\Data Set\\alpha beta.txt\"") != std::wstring::npos, L"{FullPath} macro should be quoted in arguments.");
    state.Require(plan.arguments.find(L"--same \"C:\\Data Set\\alpha beta.txt\"") != std::wstring::npos,
                  L"{PathAndFilename} macro should be quoted in arguments.");
    state.Require(plan.arguments.find(L"--selected \"C:\\Temp\\selected paths.txt\"") != std::wstring::npos,
                  L"{SelectedPathsFile} macro should be quoted in arguments.");
    state.Require(plan.arguments.find(L"--other \"D:\\Reference Pane\"") != std::wstring::npos, L"{OppositePanePath} macro should be quoted in arguments.");
    state.Require(plan.arguments.find(L"--pc \"BUILD-BOX\"") != std::wstring::npos, L"{ComputerName} macro should be quoted in arguments.");
    state.Require(plan.arguments.find(L"--literal {FullPath}") != std::wstring::npos, L"Escaped brace literal did not round-trip.");

    std::wstring commandLine = L"launcher.exe ";
    commandLine.append(plan.arguments);
    int argc = 0;
    wil::unique_hlocal_ptr<wchar_t*> argv(CommandLineToArgvW(commandLine.c_str(), &argc));
    state.Require(argv != nullptr, L"Quoted file-action arguments should parse through CommandLineToArgvW.");
    state.Require(argc == 17, L"Quoted file-action arguments should preserve macro values as single argv entries.");
    if (argv && argc == 17)
    {
        state.Require(std::wstring_view(argv.get()[2]) == L"C:\\Data Set", L"{Path} should parse as one argument.");
        state.Require(std::wstring_view(argv.get()[4]) == L"alpha beta.txt", L"{Filename} should parse as one argument.");
        state.Require(std::wstring_view(argv.get()[6]) == L"C:\\Data Set\\alpha beta.txt", L"{FullPath} should parse as one argument.");
        state.Require(std::wstring_view(argv.get()[8]) == L"C:\\Data Set\\alpha beta.txt", L"{PathAndFilename} should parse as one argument.");
        state.Require(std::wstring_view(argv.get()[10]) == L"C:\\Temp\\selected paths.txt", L"{SelectedPathsFile} should parse as one argument.");
        state.Require(std::wstring_view(argv.get()[12]) == L"D:\\Reference Pane", L"{OppositePanePath} should parse as one argument.");
        state.Require(std::wstring_view(argv.get()[14]) == L"BUILD-BOX", L"{ComputerName} should parse as one argument.");
    }

    Common::Settings::FileActionDefinition injectionAction = action;
    injectionAction.arguments                              = L"--full {FullPath} --file {Filename}";
    FileActionLauncher::MacroContext injectionContext{};
    injectionContext.itemPath = std::filesystem::path(L"C:\\Data Set\\foo\" & calc.exe & \"bar.txt");
    FileActionLauncher::LaunchPlan injectionPlan{};
    const HRESULT injectionHr = FileActionLauncher::BuildExternalLaunchPlan(injectionAction, injectionContext, injectionPlan);
    state.Require(SUCCEEDED(injectionHr), L"External file-action launch plan should build for quoted filenames.");
    if (SUCCEEDED(injectionHr))
    {
        std::wstring injectionCommandLine = L"launcher.exe ";
        injectionCommandLine.append(injectionPlan.arguments);
        int injectionArgc = 0;
        wil::unique_hlocal_ptr<wchar_t*> injectionArgv(CommandLineToArgvW(injectionCommandLine.c_str(), &injectionArgc));
        state.Require(injectionArgv != nullptr, L"Quoted filename arguments should parse through CommandLineToArgvW.");
        state.Require(injectionArgc == 5, L"Quoted filename arguments should not split on spaces or embedded quotes.");
        if (injectionArgv && injectionArgc == 5)
        {
            state.Require(std::wstring_view(injectionArgv.get()[2]) == injectionContext.itemPath.wstring(),
                          L"{FullPath} with quotes should parse as one literal argument.");
            state.Require(std::wstring_view(injectionArgv.get()[4]) == injectionContext.itemPath.filename().wstring(),
                          L"{Filename} with quotes should parse as one literal argument.");
        }
    }

    std::wstring expanded;
    const HRESULT unknownMacroHr = FileActionLauncher::ExpandMacros(L"{UnknownMacro}", context, expanded);
    state.Require(FAILED(unknownMacroHr), L"Unknown external-action macro should fail validation.");

    Common::Settings::FileActionDefinition missingSelectionFile = action;
    missingSelectionFile.arguments                              = L"{SelectedPathsFile}";
    FileActionLauncher::MacroContext missingContext             = context;
    missingContext.selectedPathsFile.clear();
    missingContext.selectedPaths = {};
    missingContext.itemPath.clear();
    const HRESULT missingHr = FileActionLauncher::BuildExternalLaunchPlan(missingSelectionFile, missingContext, plan);
    state.Require(FAILED(missingHr), L"Selected-paths macro should fail when no selected paths file, selected path, or focused path is supplied.");

    Common::Settings::FileActionDefinition executableMacroAction = action;
    executableMacroAction.executablePath                         = L"{Path}\\Viewer.exe";
    const HRESULT executableMacroHr                              = FileActionLauncher::BuildExternalLaunchPlan(executableMacroAction, context, plan);
    state.Require(SUCCEEDED(executableMacroHr), L"Supported executable-path macros should remain launchable when they expand to explicit absolute paths.");
    if (SUCCEEDED(executableMacroHr))
    {
        state.Require(plan.executablePath == L"C:\\Data Set\\Viewer.exe", L"Executable-path macros should expand before absolute-path validation.");
    }

    Common::Settings::FileActionDefinition bareExecutable = action;
    bareExecutable.executablePath                         = L"Viewer.exe";
    const HRESULT bareHr                                  = FileActionLauncher::BuildExternalLaunchPlan(bareExecutable, context, plan);
    state.Require(FAILED(bareHr), L"Bare external-action executable names must not resolve through PATH or the working directory.");

    Common::Settings::FileActionDefinition relativeExecutable = action;
    relativeExecutable.executablePath                         = L".\\Viewer.exe";
    const HRESULT relativeHr                                  = FileActionLauncher::BuildExternalLaunchPlan(relativeExecutable, context, plan);
    state.Require(FAILED(relativeHr), L"Relative external-action executable paths must not resolve through the working directory.");

    Common::Settings::FileActionDefinition macroBareExecutable = action;
    macroBareExecutable.executablePath                         = L"{Filename}";
    const HRESULT macroBareHr                                  = FileActionLauncher::BuildExternalLaunchPlan(macroBareExecutable, context, plan);
    state.Require(FAILED(macroBareHr), L"Executable validation must run after macro expansion.");

    Common::Settings::FileActionDefinition uncExecutable = action;
    uncExecutable.executablePath                         = LR"(\\server\share\Viewer.exe)";
    const HRESULT uncHr                                  = FileActionLauncher::BuildExternalLaunchPlan(uncExecutable, context, plan);
    state.Require(SUCCEEDED(uncHr) && plan.executablePath == uncExecutable.executablePath,
                  L"An explicit absolute UNC executable path should remain launchable.");

    state.Require(Common::Paths::IsExplicitAbsoluteExecutablePath(LR"(C:\Tools\Viewer.exe)"), L"Drive-absolute executable should be accepted.");
    state.Require(Common::Paths::IsExplicitAbsoluteExecutablePath(LR"(\\?\C:\Tools\Viewer.exe)"), L"Extended drive executable should be accepted.");
    state.Require(Common::Paths::IsExplicitAbsoluteExecutablePath(LR"(\\?\UNC\server\share\Viewer.exe)"), L"Extended UNC executable should be accepted.");
    state.Require(! Common::Paths::IsExplicitAbsoluteExecutablePath(LR"(C:Viewer.exe)"), L"Drive-relative executable should be rejected.");
    state.Require(! Common::Paths::IsExplicitAbsoluteExecutablePath(LR"(\Viewer.exe)"), L"Rooted executable without a drive should be rejected.");
    state.Require(! Common::Paths::IsExplicitAbsoluteExecutablePath(LR"(\\.\PhysicalDrive0)"), L"Device namespace paths should be rejected.");

    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionExecutablePathTemplateMacroDetection(CaseState& state) noexcept
{
    state.Require(FileActionLauncher::TemplateContainsSupportedMacro(L"{Path}\\Viewer.exe"),
                  L"Executable-path templates should detect supported absolute-path macros.");
    state.Require(FileActionLauncher::TemplateContainsSupportedMacro(LR"(C:\Tools\{Filename}.cmd)"),
                  L"Executable-path templates should detect supported macros embedded inside absolute literal paths.");
    state.Require(! FileActionLauncher::TemplateContainsSupportedMacro(L"Viewer.exe"),
                  L"Literal executable names should not be treated as supported executable-path templates.");
    state.Require(! FileActionLauncher::TemplateContainsSupportedMacro(L"{{Path}}"),
                  L"Escaped literal braces should not be treated as supported executable-path macros.");
    state.Require(! FileActionLauncher::TemplateContainsSupportedMacro(LR"(C:\Tools\{UnknownMacro}.exe)"),
                  L"Unknown brace tokens should not bypass Preferences executable-path validation.");

    return state.failure.empty();
}

[[nodiscard]] std::wstring ResolveCommandProcessorPath() noexcept
{
    std::array<wchar_t, MAX_PATH> buffer{};
    DWORD length = GetEnvironmentVariableW(L"ComSpec", buffer.data(), static_cast<DWORD>(buffer.size()));
    if (length > 0u && length < buffer.size())
    {
        return std::wstring(buffer.data(), length);
    }

    length = GetSystemDirectoryW(buffer.data(), static_cast<UINT>(buffer.size()));
    if (length > 0u && length < buffer.size())
    {
        std::filesystem::path path(buffer.data());
        path /= L"cmd.exe";
        return path.wstring();
    }

    return L"cmd.exe";
}

[[nodiscard]] std::wstring ResolveSiblingExecutablePath(std::wstring_view fileName) noexcept
{
    std::array<wchar_t, 32'768> modulePath{};
    const DWORD length = GetModuleFileNameW(nullptr, modulePath.data(), static_cast<DWORD>(modulePath.size()));
    if (length == 0u || length >= modulePath.size())
    {
        return {};
    }

    return (std::filesystem::path(std::wstring_view(modulePath.data(), length)).parent_path() / fileName).wstring();
}

#if defined(ENABLE_TESTS)
[[nodiscard]] Common::Settings::FileActionDefinition MakeSelectedPathsManifestTestAction()
{
    Common::Settings::FileActionDefinition action{};
    action.kind             = Common::Settings::FileActionKind::ExternalProgram;
    action.executablePath   = ResolveSiblingExecutablePath(L"RedSalamanderSearchService.exe");
    action.arguments        = L"{SelectedPathsFile}";
    action.workingDirectory = L"{Path}";
    return action;
}

[[nodiscard]] std::string BuildExpectedSelectedPathsManifestBytes(const std::vector<std::filesystem::path>& paths)
{
    std::string bytes;
    bytes.push_back(static_cast<char>(0xFFu));
    bytes.push_back(static_cast<char>(0xFEu));
    for (const std::filesystem::path& path : paths)
    {
        if (path.empty())
        {
            continue;
        }
        for (const wchar_t character : path.native())
        {
            const uint16_t codeUnit = static_cast<uint16_t>(character);
            bytes.push_back(static_cast<char>(codeUnit & 0xFFu));
            bytes.push_back(static_cast<char>((codeUnit >> 8u) & 0xFFu));
        }
        bytes.append("\r\0\n\0", 4u);
    }
    return bytes;
}

[[nodiscard]] bool TestFileActionSelectedPathsCreationContract(CaseState& state) noexcept
{
    const SelfTest::TestSandbox sandbox = SelfTest::AcquireTestSandbox(SelfTest::SelfTestSuite::Commands, L"file_action_selected_paths_creation_contract");
    state.Require(sandbox.IsValid(), L"Selected-path creation contract requires a TestSandbox root.");
    if (! sandbox.IsValid())
    {
        return false;
    }
    const auto cleanup = wil::scope_exit([&] noexcept { static_cast<void>(SelfTest::RemoveAll(sandbox.root)); });

    const std::filesystem::path manifestRoot = sandbox.root / L"private-manifests";
    state.Require(SelfTest::EnsureDirectory(manifestRoot), L"Selected-path creation contract could not create its private root.");

    FileActionLauncher::Testing::SelectedPathsFileObservation observation{};
    FileActionLauncher::Testing::SelectedPathsFileOptions testOptions{};
    testOptions.rootOverride             = manifestRoot;
    testOptions.injectedCreateCollisions = 1u;
    testOptions.maximumCreateAttempts    = 3u;
    testOptions.observation              = &observation;

    const std::array selectedPaths{sandbox.root / L"selected.txt"};
    FileActionLauncher::MacroContext context{};
    context.itemPath                 = sandbox.root / L"focused.txt";
    context.currentDirectory         = sandbox.root;
    context.selectedPaths            = selectedPaths;
    context.selectedPathsFileOptions = &testOptions;

    FileActionLauncher::LaunchPlan plan{};
    const HRESULT collisionHr       = FileActionLauncher::BuildExternalLaunchPlan(MakeSelectedPathsManifestTestAction(), context, plan);
    const std::string collidedBytes = observation.collidedPath.empty() ? std::string{} : ReadSettingsTestBytes(observation.collidedPath);
    const bool collisionSurvived    = collidedBytes == "selected-path collision sentinel";
    state.Require(SUCCEEDED(collisionHr) && plan.selectedPathsFileLease.HasValue() && ! observation.collidedPath.empty() &&
                      plan.selectedPathsFileLease.Path() != observation.collidedPath && collisionSurvived && observation.createAttempts == 2u,
                  std::format(L"Exclusive selected-path creation must preserve an injected collision and retry once "
                              L"(hr=0x{:08X}, attempts={}, samePath={}, collisionSurvived={}).",
                              static_cast<unsigned>(collisionHr),
                              observation.createAttempts,
                              plan.selectedPathsFileLease.HasValue() && plan.selectedPathsFileLease.Path() == observation.collidedPath,
                              collisionSurvived));
    plan = {};

    observation                          = {};
    testOptions.injectedCreateCollisions = testOptions.maximumCreateAttempts;
    FileActionLauncher::LaunchPlan exhaustedPlan{};
    const HRESULT exhaustedHr = FileActionLauncher::BuildExternalLaunchPlan(MakeSelectedPathsManifestTestAction(), context, exhaustedPlan);
    state.Require(exhaustedHr == HRESULT_FROM_WIN32(ERROR_FILE_EXISTS) && ! exhaustedPlan.selectedPathsFileLease.HasValue() &&
                      observation.createAttempts == testOptions.maximumCreateAttempts,
                  L"Selected-path exclusive creation must stop after the configured collision-attempt bound without truncating a candidate.");
    exhaustedPlan = {};

    std::filesystem::path longRoot = sandbox.root / L"long-root";
    while (longRoot.native().size() < 300u)
    {
        longRoot /= L"selected-path-long-root-segment";
    }
    const HRESULT ensureLongRootHr = EnsureExtendedDirectoryForPreviewPropertiesTest(longRoot);
    std::wstring extendedLongRoot;
    const HRESULT extendLongRootHr = BuildExtendedPathForPreviewPropertiesTest(longRoot, extendedLongRoot);
    state.Require(SUCCEEDED(ensureLongRootHr) && SUCCEEDED(extendLongRootHr), L"Selected-path creation contract could not create its long private root.");
    observation                          = {};
    testOptions.rootOverride             = std::filesystem::path(extendedLongRoot);
    testOptions.injectedCreateCollisions = 0u;
    FileActionLauncher::LaunchPlan longPlan{};
    const HRESULT longHr = FileActionLauncher::BuildExternalLaunchPlan(MakeSelectedPathsManifestTestAction(), context, longPlan);
    state.Require(SUCCEEDED(longHr) && longPlan.selectedPathsFileLease.HasValue(),
                  std::format(L"Selected-path exclusive creation must support an extended private root (hr=0x{:08X}).", static_cast<unsigned>(longHr)));

    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionSelectedPathsRecordContract(CaseState& state) noexcept
{
    const SelfTest::TestSandbox sandbox = SelfTest::AcquireTestSandbox(SelfTest::SelfTestSuite::Commands, L"file_action_selected_paths_record_contract");
    state.Require(sandbox.IsValid(), L"Selected-path record contract requires a TestSandbox root.");
    if (! sandbox.IsValid())
    {
        return false;
    }
    const auto cleanup                       = wil::scope_exit([&] noexcept { static_cast<void>(SelfTest::RemoveAll(sandbox.root)); });
    const std::filesystem::path manifestRoot = sandbox.root / L"private-manifests";
    state.Require(SelfTest::EnsureDirectory(manifestRoot), L"Selected-path record contract could not create its private root.");

    FileActionLauncher::Testing::SelectedPathsFileObservation observation{};
    FileActionLauncher::Testing::SelectedPathsFileOptions testOptions{};
    testOptions.rootOverride = manifestRoot;
    testOptions.observation  = &observation;

    std::filesystem::path longSelectedPath = sandbox.root / L"long-selected-path";
    while (longSelectedPath.native().size() < 600u)
    {
        longSelectedPath /= L"record-segment";
    }
    const std::vector<std::filesystem::path> selectedPaths{
        sandbox.root / L"first path.txt", {}, sandbox.root / L"Unicode-測試-U0001F642.txt", longSelectedPath, sandbox.root / L"first path.txt"};
    FileActionLauncher::MacroContext context{};
    context.itemPath                 = sandbox.root / L"focused.txt";
    context.currentDirectory         = sandbox.root;
    context.selectedPaths            = selectedPaths;
    context.selectedPathsFileOptions = &testOptions;

    FileActionLauncher::LaunchPlan validPlan{};
    const HRESULT validHr = FileActionLauncher::BuildExternalLaunchPlan(MakeSelectedPathsManifestTestAction(), context, validPlan);
    const std::string actualBytes =
        validPlan.selectedPathsFileLease.HasValue() ? ReadSettingsTestBytes(validPlan.selectedPathsFileLease.Path()) : std::string{};
    const std::string expectedBytes = BuildExpectedSelectedPathsManifestBytes(selectedPaths);
    state.Require(SUCCEEDED(validHr) && actualBytes == expectedBytes,
                  L"Selected-path manifest bytes must be exact UTF-16LE BOM plus ordered, duplicate-preserving CRLF records, including long paths.");
    validPlan = {};

    const std::vector<std::filesystem::path> singleSelectedPath{sandbox.root / L"single Unicode-測試.txt"};
    context.selectedPaths = singleSelectedPath;
    FileActionLauncher::LaunchPlan singlePlan{};
    const HRESULT singleHr = FileActionLauncher::BuildExternalLaunchPlan(MakeSelectedPathsManifestTestAction(), context, singlePlan);
    const std::string singleBytes =
        singlePlan.selectedPathsFileLease.HasValue() ? ReadSettingsTestBytes(singlePlan.selectedPathsFileLease.Path()) : std::string{};
    state.Require(SUCCEEDED(singleHr) && singleBytes == BuildExpectedSelectedPathsManifestBytes(singleSelectedPath),
                  L"A single selected path must use the same exact BOM and CRLF-terminated record grammar.");
    singlePlan            = {};
    context.selectedPaths = selectedPaths;

    const auto requireRejected = [&](std::filesystem::path invalidPath, std::wstring_view label) noexcept
    {
        observation = {};
        const std::array invalidSelectedPaths{std::move(invalidPath)};
        context.selectedPaths = invalidSelectedPaths;
        FileActionLauncher::LaunchPlan invalidPlan{};
        const HRESULT invalidHr = FileActionLauncher::BuildExternalLaunchPlan(MakeSelectedPathsManifestTestAction(), context, invalidPlan);
        context.selectedPaths   = selectedPaths;
        state.Require(invalidHr == HRESULT_FROM_WIN32(ERROR_INVALID_DATA) && ! invalidPlan.selectedPathsFileLease.HasValue() &&
                          observation.createAttempts == 0u,
                      std::format(L"Selected-path manifest must reject {} before creating a file (hr=0x{:08X}, attempts={}).",
                                  label,
                                  static_cast<unsigned>(invalidHr),
                                  observation.createAttempts));
    };

    std::wstring embeddedNul = (sandbox.root / L"nul").native();
    embeddedNul.push_back(L'\0');
    embeddedNul.append(L"tail.txt");
    requireRejected(std::filesystem::path(embeddedNul), L"embedded NUL");
    requireRejected(std::filesystem::path((sandbox.root / L"line").native() + L"\nfeed.txt"), L"embedded LF");
    requireRejected(std::filesystem::path((sandbox.root / L"carriage").native() + L"\rreturn.txt"), L"embedded CR");

    observation = {};
    const std::array<std::filesystem::path, 2u> emptySelectedPaths{};
    context.selectedPaths = emptySelectedPaths;
    FileActionLauncher::LaunchPlan emptyPlan{};
    const HRESULT emptyHr = FileActionLauncher::BuildExternalLaunchPlan(MakeSelectedPathsManifestTestAction(), context, emptyPlan);
    state.Require(emptyHr == HRESULT_FROM_WIN32(ERROR_BAD_ARGUMENTS) && ! emptyPlan.selectedPathsFileLease.HasValue() && observation.createAttempts == 0u,
                  L"An all-empty selected-path list must fail before creating a manifest.");

    return state.failure.empty();
}

struct LegacySelectedPathsReferenceObservation final
{
    uint64_t buildUs               = 0u;
    uint64_t writeUs               = 0u;
    uint64_t pathBytes             = 0u;
    uint64_t writeCallCount        = 0u;
    uint64_t peakAdditionalBytes   = 0u;
    uint64_t selectionCopyBytes    = 0u;
    uint64_t aggregatePayloadBytes = 0u;
    bool usedAggregatePayload      = false;
};

// Test-only Release reference for the reviewed implementation's extra vector copy,
// aggregate UTF-16 payload, and two-write shape. The sandboxed CREATE_NEW file avoids
// reproducing the reviewed GetTempFileNameW/CREATE_ALWAYS ownership defect.
[[nodiscard]] HRESULT RunLegacySelectedPathsAggregateReference(std::span<const std::filesystem::path> selectedPaths,
                                                               const std::filesystem::path& sandboxRoot,
                                                               LegacySelectedPathsReferenceObservation& observation) noexcept
{
    observation               = {};
    const auto buildStartedAt = std::chrono::steady_clock::now();

    const std::vector<std::filesystem::path> copiedPaths(selectedPaths.begin(), selectedPaths.end());
    std::wstring aggregatePayload;
    for (const std::filesystem::path& selectedPath : copiedPaths)
    {
        if (selectedPath.empty())
        {
            continue;
        }

        const uint64_t pathBytes = static_cast<uint64_t>(selectedPath.native().size()) * sizeof(wchar_t);
        observation.pathBytes += pathBytes;
        aggregatePayload.append(selectedPath.native());
        aggregatePayload.append(L"\r\n");
    }
    if (aggregatePayload.empty())
    {
        return HRESULT_FROM_WIN32(ERROR_BAD_ARGUMENTS);
    }

    observation.selectionCopyBytes    = observation.pathBytes * 2u; // Read plus write traffic for the redundant owning copy.
    observation.aggregatePayloadBytes = static_cast<uint64_t>(aggregatePayload.size()) * sizeof(wchar_t);
    observation.peakAdditionalBytes   = static_cast<uint64_t>(aggregatePayload.capacity()) * sizeof(wchar_t);
    observation.usedAggregatePayload  = true;

    const std::filesystem::path referencePath = sandboxRoot / L"legacy-selected-paths-reference.bin";
    wil::unique_hfile referenceFile(
        CreateFileW(referencePath.c_str(), GENERIC_WRITE, 0u, nullptr, CREATE_NEW, FILE_ATTRIBUTE_TEMPORARY | FILE_FLAG_DELETE_ON_CLOSE, nullptr));
    if (! referenceFile)
    {
        const DWORD error = GetLastError();
        return HRESULT_FROM_WIN32(error == ERROR_SUCCESS ? ERROR_OPEN_FAILED : error);
    }

    const auto writeStartedAt = std::chrono::steady_clock::now();
    constexpr std::array<std::byte, 2u> kUtf16LeBom{{std::byte{0xFFu}, std::byte{0xFEu}}};
    HRESULT hr = Common::HandleIo::WriteAll(referenceFile.get(), kUtf16LeBom.data(), kUtf16LeBom.size());
    if (SUCCEEDED(hr))
    {
        ++observation.writeCallCount;
        hr = Common::HandleIo::WriteAll(referenceFile.get(), aggregatePayload.data(), static_cast<size_t>(observation.aggregatePayloadBytes));
        if (SUCCEEDED(hr))
        {
            ++observation.writeCallCount;
        }
    }
    observation.writeUs = Debug::Perf::ElapsedUs(writeStartedAt);
    observation.buildUs = Debug::Perf::ElapsedUs(buildStartedAt);

    Debug::Perf::EmitDurationUs(
        L"fileaction.selected_paths_file.reference_write_us", observation.writeUs, observation.writeCallCount, observation.aggregatePayloadBytes, hr);
    Debug::Perf::EmitDurationUs(
        L"fileaction.selected_paths_file.reference_build_us", observation.buildUs, static_cast<uint64_t>(copiedPaths.size()), observation.pathBytes, hr);
    Debug::Perf::EmitValue(L"fileaction.selected_paths_file.reference_write_calls", observation.writeCallCount);
    Debug::Perf::EmitValue(L"fileaction.selected_paths_file.reference_peak_additional_bytes", observation.peakAdditionalBytes);
    Debug::Perf::EmitValue(L"fileaction.selected_paths_file.reference_selection_copy_bytes", observation.selectionCopyBytes);
    Debug::Perf::EmitValue(L"fileaction.selected_paths_file.reference_aggregate_payload_bytes", observation.aggregatePayloadBytes);
    return hr;
}

[[nodiscard]] bool TestFileActionSelectedPathsStreamingPerf(CaseState& state) noexcept
{
    const SelfTest::TestSandbox sandbox = SelfTest::AcquireTestSandbox(SelfTest::SelfTestSuite::Commands, L"file_action_selected_paths_streaming_perf");
    state.Require(sandbox.IsValid(), L"Selected-path streaming scenario requires a TestSandbox root.");
    if (! sandbox.IsValid())
    {
        return false;
    }
    const auto cleanup                       = wil::scope_exit([&] noexcept { static_cast<void>(SelfTest::RemoveAll(sandbox.root)); });
    const std::filesystem::path manifestRoot = sandbox.root / L"private-manifests";
    state.Require(SelfTest::EnsureDirectory(manifestRoot), L"Selected-path streaming scenario could not create its private root.");

    constexpr size_t kRecordCount = 10'000u;
    std::vector<std::filesystem::path> selectedPaths;
    selectedPaths.reserve(kRecordCount);
    uint64_t expectedPathBytes = 0u;
    for (size_t index = 0u; index < kRecordCount; ++index)
    {
        std::filesystem::path path = sandbox.root / std::format(L"selected-item-{:05}-Unicode-測試.txt", index);
        const uint64_t pathBytes   = static_cast<uint64_t>(path.native().size()) * sizeof(wchar_t);
        expectedPathBytes += pathBytes;
        selectedPaths.push_back(std::move(path));
    }

    FileActionLauncher::MacroContext context{};
    context.itemPath         = sandbox.root / L"focused.txt";
    context.currentDirectory = sandbox.root;
    context.selectedPaths    = selectedPaths;

    FileActionLauncher::Testing::SelectedPathsFileObservation observation{};
    FileActionLauncher::Testing::SelectedPathsFileOptions testOptions{};
    testOptions.rootOverride         = manifestRoot;
    testOptions.observation          = &observation;
    context.selectedPathsFileOptions = &testOptions;

    FileActionLauncher::LaunchPlan plan{};
    const auto startedAt   = std::chrono::steady_clock::now();
    const HRESULT buildHr  = FileActionLauncher::BuildExternalLaunchPlan(MakeSelectedPathsManifestTestAction(), context, plan);
    const uint64_t buildUs = Debug::Perf::ElapsedUs(startedAt);
    Debug::Perf::EmitDurationUs(L"fileaction.selected_paths_file.scenario_us", buildUs, observation.recordCount, observation.pathBytes, buildHr);

    LegacySelectedPathsReferenceObservation legacyReference{};
    const HRESULT legacyReferenceHr = RunLegacySelectedPathsAggregateReference(selectedPaths, sandbox.root, legacyReference);

    const std::wstring artifact              = std::format(L"{{\n"
                                                           L"  \"scenario\": \"fileaction/selected-paths-10000\",\n"
                                                           L"  \"comparison_order\": \"candidate_then_legacy_release_reference\",\n"
                                                           L"  \"record_count\": {},\n"
                                                           L"  \"build_us\": {},\n"
                                                           L"  \"path_bytes\": {},\n"
                                                           L"  \"write_calls\": {},\n"
                                                           L"  \"peak_additional_bytes\": {},\n"
                                                           L"  \"selection_copy_bytes\": {},\n"
                                                           L"  \"aggregate_payload\": {},\n"
                                                           L"  \"result_hr\": {},\n"
                                                           L"  \"legacy_release_reference\": {{\n"
                                                           L"    \"build_us\": {},\n"
                                                           L"    \"write_us\": {},\n"
                                                           L"    \"path_bytes\": {},\n"
                                                           L"    \"write_calls\": {},\n"
                                                           L"    \"peak_additional_bytes\": {},\n"
                                                           L"    \"selection_copy_bytes\": {},\n"
                                                           L"    \"aggregate_payload_bytes\": {},\n"
                                                           L"    \"aggregate_payload\": {},\n"
                                                           L"    \"result_hr\": {}\n"
                                                           L"  }}\n"
                                                           L"}}\n",
                                                           observation.recordCount,
                                                           buildUs,
                                                           observation.pathBytes,
                                                           observation.writeCallCount,
                                                           observation.peakAdditionalBytes,
                                                           observation.selectionCopyBytes,
                                                           observation.usedAggregatePayload ? L"true" : L"false",
                                                           static_cast<uint32_t>(buildHr),
                                                           legacyReference.buildUs,
                                                           legacyReference.writeUs,
                                                           legacyReference.pathBytes,
                                                           legacyReference.writeCallCount,
                                                           legacyReference.peakAdditionalBytes,
                                                           legacyReference.selectionCopyBytes,
                                                           legacyReference.aggregatePayloadBytes,
                                                           legacyReference.usedAggregatePayload ? L"true" : L"false",
                                                           static_cast<uint32_t>(legacyReferenceHr));
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"file_action_selected_paths_manifest_metrics.json");
    state.Require(! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, artifact) && SelfTest::PathExists(artifactPath),
                  L"Selected-path streaming scenario must write its deterministic performance artifact.");

    constexpr uint64_t kMaximumWriteBufferBytes = 64u * 1024u;
    const uint64_t expectedTotalBytes           = 2u + expectedPathBytes + (kRecordCount * 2u * sizeof(wchar_t));
    const uint64_t expectedWriteCalls           = (expectedTotalBytes + kMaximumWriteBufferBytes - 1u) / kMaximumWriteBufferBytes;
    state.Require(SUCCEEDED(buildHr) && plan.selectedPathsFileLease.HasValue() && observation.recordCount == kRecordCount &&
                      observation.pathBytes == expectedPathBytes && observation.writeCallCount == expectedWriteCalls &&
                      observation.peakAdditionalBytes == kMaximumWriteBufferBytes && observation.selectionCopyBytes == 0u && ! observation.usedAggregatePayload,
                  std::format(L"The 10,000-record selected-path path must stream without a selection copy or aggregate payload "
                              L"(hr=0x{:08X}, records={}, pathBytes={}, writes={}, peak={}, copyBytes={}, aggregate={}).",
                              static_cast<unsigned>(buildHr),
                              observation.recordCount,
                              observation.pathBytes,
                              observation.writeCallCount,
                              observation.peakAdditionalBytes,
                              observation.selectionCopyBytes,
                              observation.usedAggregatePayload));
    state.Require(SUCCEEDED(legacyReferenceHr) && legacyReference.pathBytes == expectedPathBytes && legacyReference.writeCallCount == 2u &&
                      legacyReference.peakAdditionalBytes >= expectedPathBytes && legacyReference.selectionCopyBytes == expectedPathBytes * 2u &&
                      legacyReference.aggregatePayloadBytes == expectedPathBytes + (kRecordCount * 2u * sizeof(wchar_t)) &&
                      legacyReference.usedAggregatePayload,
                  std::format(L"The Release comparison reference must preserve the reviewed copy-plus-aggregate/two-write shape "
                              L"without recreating its unsafe pathname reservation "
                              L"(hr=0x{:08X}, pathBytes={}, writes={}, peak={}, copyBytes={}, aggregateBytes={}, aggregate={}).",
                              static_cast<unsigned>(legacyReferenceHr),
                              legacyReference.pathBytes,
                              legacyReference.writeCallCount,
                              legacyReference.peakAdditionalBytes,
                              legacyReference.selectionCopyBytes,
                              legacyReference.aggregatePayloadBytes,
                              legacyReference.usedAggregatePayload));

    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionSelectedPathsChildParsesRecords(CaseState& state) noexcept
{
    const SelfTest::TestSandbox sandbox = SelfTest::AcquireTestSandbox(SelfTest::SelfTestSuite::Commands, L"file_action_selected_paths_child_parse");
    state.Require(sandbox.IsValid(), L"Selected-path child parse requires a TestSandbox root.");
    if (! sandbox.IsValid())
    {
        return false;
    }
    const auto cleanup                       = wil::scope_exit([&] noexcept { static_cast<void>(SelfTest::RemoveAll(sandbox.root)); });
    const std::filesystem::path manifestRoot = sandbox.root / L"private-manifests";
    const std::filesystem::path marker       = sandbox.root / L"child-marker.txt";
    state.Require(SelfTest::EnsureDirectory(manifestRoot), L"Selected-path child parse could not create its private root.");

    Common::Settings::FileActionDefinition action = MakeSelectedPathsManifestTestAction();
    action.arguments                              = L"--test-support-child-probe=file-action-lease \"{SelectedPathsFile}\" \"{FullPath}\" 0 0";

    FileActionLauncher::Testing::SelectedPathsFileObservation observation{};
    FileActionLauncher::Testing::SelectedPathsFileOptions testOptions{};
    testOptions.rootOverride = manifestRoot;
    testOptions.observation  = &observation;
    const std::array selectedPaths{sandbox.root / L"first selected.txt", sandbox.root / L"Unicode-測試-U0001F642.txt"};
    FileActionLauncher::MacroContext context{};
    context.itemPath                 = marker;
    context.currentDirectory         = sandbox.root;
    context.selectedPaths            = selectedPaths;
    context.selectedPathsFileOptions = &testOptions;

    FileActionLauncher::LaunchPlan plan{};
    const HRESULT buildHr = FileActionLauncher::BuildExternalLaunchPlan(action, context, plan);
    FileActionLauncher::LaunchOptions launchOptions{};
    launchOptions.showCommand   = SW_HIDE;
    launchOptions.waitForExit   = true;
    launchOptions.waitTimeoutMs = static_cast<DWORD>(SelfTest::Scale(std::chrono::milliseconds{5000}).count());
    FileActionLauncher::LaunchResult result{};
    const HRESULT launchHr = SUCCEEDED(buildHr) ? FileActionLauncher::LaunchExternalPlan(std::move(plan), launchOptions, &result) : buildHr;

    std::ifstream markerInput(marker);
    std::string markerText;
    std::getline(markerInput, markerText);
    state.Require(SUCCEEDED(buildHr) && SUCCEEDED(launchHr) && result.exitCodeAvailable && result.exitCode == 0u && markerText == "parsed:2",
                  std::format(L"The representative external child must parse the exact selected-path record stream "
                              L"(build=0x{:08X}, launch=0x{:08X}, exit={}, marker='{}').",
                              static_cast<unsigned>(buildHr),
                              static_cast<unsigned>(launchHr),
                              result.exitCode,
                              Common::Strings::Utf16FromUtf8StrictOrEmpty(markerText)));

    const std::filesystem::path replacementMarker            = sandbox.root / L"child-replacement-marker.txt";
    Common::Settings::FileActionDefinition replacementAction = MakeSelectedPathsManifestTestAction();
    replacementAction.arguments = L"--test-support-child-probe=file-action-lease \"{SelectedPathsFile}\" \"{FullPath}\" 0 0 replace";
    context.itemPath            = replacementMarker;
    FileActionLauncher::LaunchPlan replacementPlan{};
    const HRESULT replacementBuildHr = FileActionLauncher::BuildExternalLaunchPlan(replacementAction, context, replacementPlan);
    const std::filesystem::path replacementManifest =
        replacementPlan.selectedPathsFileLease.HasValue() ? replacementPlan.selectedPathsFileLease.Path() : std::filesystem::path{};
    FileActionLauncher::LaunchResult replacementResult{};
    const HRESULT replacementLaunchHr  = SUCCEEDED(replacementBuildHr)
                                             ? FileActionLauncher::LaunchExternalPlan(std::move(replacementPlan), launchOptions, &replacementResult)
                                             : replacementBuildHr;
    const std::string replacementBytes = replacementManifest.empty() ? std::string{} : ReadSettingsTestBytes(replacementManifest);
    std::ifstream replacementMarkerInput(replacementMarker);
    std::string replacementMarkerText;
    std::getline(replacementMarkerInput, replacementMarkerText);
    state.Require(SUCCEEDED(replacementBuildHr) && SUCCEEDED(replacementLaunchHr) && replacementResult.exitCodeAvailable && replacementResult.exitCode == 0u &&
                      replacementMarkerText == "parsed:2" && replacementBytes == "child replacement sentinel",
                  std::format(L"The real child must parse, replace the manifest, and leave the different-identity replacement intact "
                              L"(build=0x{:08X}, launch=0x{:08X}, exit={}, marker='{}', replacementBytes={}).",
                              static_cast<unsigned>(replacementBuildHr),
                              static_cast<unsigned>(replacementLaunchHr),
                              replacementResult.exitCode,
                              Common::Strings::Utf16FromUtf8StrictOrEmpty(replacementMarkerText),
                              replacementBytes.size()));

    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionSelectedPathsIdentityCleanup(CaseState& state) noexcept
{
    const SelfTest::TestSandbox sandbox = SelfTest::AcquireTestSandbox(SelfTest::SelfTestSuite::Commands, L"file_action_selected_paths_identity_cleanup");
    state.Require(sandbox.IsValid(), L"Selected-path identity cleanup requires a TestSandbox root.");
    if (! sandbox.IsValid())
    {
        return false;
    }
    const auto cleanup = wil::scope_exit([&] noexcept { static_cast<void>(SelfTest::RemoveAll(sandbox.root)); });

    const std::filesystem::path manifestRoot = sandbox.root / L"private-manifests";
    state.Require(SelfTest::EnsureDirectory(manifestRoot), L"Selected-path identity cleanup could not create its private root.");
    FileActionLauncher::Testing::SelectedPathsFileOptions testOptions{};
    testOptions.rootOverride = manifestRoot;
    const std::array selectedPaths{sandbox.root / L"selected.txt"};
    FileActionLauncher::MacroContext context{};
    context.itemPath                 = sandbox.root / L"focused.txt";
    context.currentDirectory         = sandbox.root;
    context.selectedPaths            = selectedPaths;
    context.selectedPathsFileOptions = &testOptions;

    const auto buildLease = [&](FileActionLauncher::LaunchPlan& plan) noexcept
    { return FileActionLauncher::BuildExternalLaunchPlan(MakeSelectedPathsManifestTestAction(), context, plan); };

    FileActionLauncher::LaunchPlan exactPlan{};
    const HRESULT exactBuildHr            = buildLease(exactPlan);
    const std::filesystem::path exactPath = exactPlan.selectedPathsFileLease.HasValue() ? exactPlan.selectedPathsFileLease.Path() : std::filesystem::path{};
    exactPlan.selectedPathsFileLease.Reset();
    std::error_code ec;
    state.Require(SUCCEEDED(exactBuildHr) && ! exactPath.empty() && ! std::filesystem::exists(exactPath, ec) && ! ec,
                  L"Identity cleanup must delete the exact live manifest through its verified handle.");

    FileActionLauncher::LaunchPlan replacementPlan{};
    const HRESULT replacementBuildHr = buildLease(replacementPlan);
    const std::filesystem::path replacementPath =
        replacementPlan.selectedPathsFileLease.HasValue() ? replacementPlan.selectedPathsFileLease.Path() : std::filesystem::path{};
    const bool removedOriginal = ! replacementPath.empty() && DeleteFileW(replacementPath.c_str()) != FALSE;
    wil::unique_hfile replacement(CreateFileW(
        replacementPath.c_str(), GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr));
    constexpr std::string_view kReplacementPayload{"same-path replacement sentinel"};
    const HRESULT replacementWriteHr = replacement ? Common::HandleIo::WriteAll(replacement.get(), kReplacementPayload.data(), kReplacementPayload.size())
                                                   : HRESULT_FROM_WIN32(GetLastError());
    replacement.reset();
    replacementPlan.selectedPathsFileLease.Reset();
    const std::string replacementBytes = replacementPath.empty() ? std::string{} : ReadSettingsTestBytes(replacementPath);
    state.Require(SUCCEEDED(replacementBuildHr) && removedOriginal && SUCCEEDED(replacementWriteHr) && replacementBytes == kReplacementPayload,
                  L"A same-path different-identity replacement must survive lease cleanup.");

    FileActionLauncher::LaunchPlan rootReplacementPlan{};
    const HRESULT rootReplacementBuildHr = buildLease(rootReplacementPlan);
    const std::filesystem::path originalRootPath =
        rootReplacementPlan.selectedPathsFileLease.HasValue() ? rootReplacementPlan.selectedPathsFileLease.Path() : std::filesystem::path{};
    const std::filesystem::path movedRoot = sandbox.root / L"moved-original-root";
    const bool movedOriginalRoot = SUCCEEDED(rootReplacementBuildHr) && MoveFileExW(manifestRoot.c_str(), movedRoot.c_str(), MOVEFILE_WRITE_THROUGH) != FALSE;
    const bool createdReplacementRoot               = movedOriginalRoot && SelfTest::EnsureDirectory(manifestRoot);
    const std::filesystem::path replacementRootPath = manifestRoot / originalRootPath.filename();
    const bool wroteRootReplacement                 = createdReplacementRoot && SelfTest::WriteTextFile(replacementRootPath, "root replacement sentinel");
    rootReplacementPlan.selectedPathsFileLease.Reset();
    state.Require(movedOriginalRoot && createdReplacementRoot && wroteRootReplacement && SelfTest::PathExists(movedRoot / originalRootPath.filename()) &&
                      ReadSettingsTestBytes(replacementRootPath) == "root replacement sentinel",
                  L"Cleanup must preserve both an original manifest moved with its root and a same-path replacement under a different root identity.");

    FileActionLauncher::LaunchPlan reparsePlan{};
    const HRESULT reparseBuildHr = buildLease(reparsePlan);
    const std::filesystem::path reparsePath =
        reparsePlan.selectedPathsFileLease.HasValue() ? reparsePlan.selectedPathsFileLease.Path() : std::filesystem::path{};
    const std::filesystem::path reparseTarget = sandbox.root / L"reparse-target.txt";
    const bool wroteReparseTarget             = SelfTest::WriteTextFile(reparseTarget, "reparse target sentinel");
    const bool removedReparseOriginal         = ! reparsePath.empty() && DeleteFileW(reparsePath.c_str()) != FALSE;
    const bool createdReparse = wroteReparseTarget && removedReparseOriginal &&
                                CreateSymbolicLinkW(reparsePath.c_str(), reparseTarget.c_str(), SYMBOLIC_LINK_FLAG_ALLOW_UNPRIVILEGED_CREATE) != FALSE;
    reparsePlan.selectedPathsFileLease.Reset();
    const DWORD reparseAttributes = GetFileAttributesW(reparsePath.c_str());
    state.Require(SUCCEEDED(reparseBuildHr) && createdReparse && reparseAttributes != INVALID_FILE_ATTRIBUTES &&
                      (reparseAttributes & FILE_ATTRIBUTE_REPARSE_POINT) != 0u && ReadSettingsTestBytes(reparseTarget) == "reparse target sentinel",
                  L"A same-path reparse replacement and its target must survive no-follow identity cleanup.");

    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionSelectedPathsRecoveryBounds(CaseState& state) noexcept
{
    const SelfTest::TestSandbox sandbox = SelfTest::AcquireTestSandbox(SelfTest::SelfTestSuite::Commands, L"file_action_selected_paths_recovery_bounds");
    state.Require(sandbox.IsValid(), L"Selected-path recovery bounds require a TestSandbox root.");
    if (! sandbox.IsValid())
    {
        return false;
    }
    const auto cleanup   = wil::scope_exit([&] noexcept { static_cast<void>(SelfTest::RemoveAll(sandbox.root)); });
    const auto startedAt = std::chrono::steady_clock::now();

    const std::filesystem::path privateRoot = sandbox.root / L"private-manifests";
    state.Require(SelfTest::EnsureDirectory(privateRoot), L"Selected-path recovery could not create its private root.");
    const auto oldTime     = std::filesystem::file_time_type::clock::now() - std::chrono::hours{48};
    const auto makeOldFile = [&](const std::filesystem::path& path, std::string_view payload) noexcept
    {
        if (! SelfTest::WriteTextFile(path, payload))
        {
            return false;
        }
        std::error_code timeError;
        std::filesystem::last_write_time(path, oldTime, timeError);
        return ! timeError;
    };

    std::vector<std::filesystem::path> oldRegularFiles;
    for (size_t index = 0u; index < 6u; ++index)
    {
        const std::filesystem::path path = privateRoot / std::format(L"selected-paths-old-{:02}.txt", index);
        state.Require(makeOldFile(path, "old manifest"), L"Selected-path recovery could not create an old regular manifest.");
        oldRegularFiles.push_back(path);
    }

    std::vector<std::filesystem::path> freshFiles;
    for (size_t index = 0u; index < 4u; ++index)
    {
        const std::filesystem::path path = privateRoot / std::format(L"selected-paths-fresh-{:02}.txt", index);
        state.Require(SelfTest::WriteTextFile(path, "fresh manifest"), L"Selected-path recovery could not create a fresh manifest.");
        freshFiles.push_back(path);
    }

    const std::filesystem::path lockedPath = privateRoot / L"selected-paths-locked.txt";
    state.Require(makeOldFile(lockedPath, "locked manifest"), L"Selected-path recovery could not create its locked fixture.");
    wil::unique_hfile lockedFile(
        CreateFileW(lockedPath.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr));
    state.Require(static_cast<bool>(lockedFile), L"Selected-path recovery could not hold its no-delete-share live fixture.");

    const std::filesystem::path directoryPath = privateRoot / L"selected-paths-directory.txt";
    state.Require(SelfTest::EnsureDirectory(directoryPath), L"Selected-path recovery could not create its directory fixture.");

    const std::filesystem::path reparseTarget = sandbox.root / L"recovery-reparse-target.txt";
    const std::filesystem::path reparsePath   = privateRoot / L"selected-paths-reparse.txt";
    state.Require(SelfTest::WriteTextFile(reparseTarget, "recovery target") &&
                      CreateSymbolicLinkW(reparsePath.c_str(), reparseTarget.c_str(), SYMBOLIC_LINK_FLAG_ALLOW_UNPRIVILEGED_CREATE) != FALSE,
                  L"Selected-path recovery could not create its no-follow reparse fixture.");

    const std::filesystem::path sharedTempShape = sandbox.root / L"rsa0001.tmp";
    const std::filesystem::path outOfRoot       = sandbox.root / L"selected-paths-outside.txt";
    state.Require(makeOldFile(sharedTempShape, "shared-temp shape") && makeOldFile(outOfRoot, "outside private root"),
                  L"Selected-path recovery could not create its out-of-root fixtures.");

    std::wstring cursor;
    FileActionLauncher::Testing::SelectedPathsRecoveryObservation timeBound{};
    const HRESULT timeBoundHr =
        FileActionLauncher::Testing::RunSelectedPathsRecoveryPassForTest(privateRoot, 60ull * 60ull * 1000ull, 128u, 128u, 0u, cursor, timeBound);
    state.Require(timeBoundHr == S_OK && timeBound.deleted == 0u && timeBound.inspected == 0u && timeBound.stoppedByTimeBound,
                  L"A zero-duration recovery pass must stop before inspecting or deleting an entry.");

    cursor = L"selected-paths-missing-cursor.txt";
    FileActionLauncher::Testing::SelectedPathsRecoveryObservation missingCursor{};
    const HRESULT missingCursorHr =
        FileActionLauncher::Testing::RunSelectedPathsRecoveryPassForTest(privateRoot, 60ull * 60ull * 1000ull, 3u, 1u, 1000u, cursor, missingCursor);
    state.Require(missingCursorHr == S_OK && missingCursor.resetMissingCursor && cursor.empty(),
                  L"Recovery must reset a vanished continuation anchor instead of stalling permanently.");

    uint64_t totalInspected = 0u;
    uint64_t totalDeleted   = 0u;
    uint64_t totalSkipped   = 0u;
    uint64_t totalErrors    = 0u;
    uint64_t boundHits      = 0u;
    size_t passes           = 0u;
    bool sawEntryBound      = false;
    bool sawDeleteBound     = false;
    HRESULT recoveryHr      = S_OK;
    cursor.clear();
    for (; passes < 32u; ++passes)
    {
        FileActionLauncher::Testing::SelectedPathsRecoveryObservation current{};
        recoveryHr = FileActionLauncher::Testing::RunSelectedPathsRecoveryPassForTest(privateRoot, 60ull * 60ull * 1000ull, 3u, 1u, 1000u, cursor, current);
        totalInspected += current.inspected;
        totalDeleted += current.deleted;
        totalSkipped += current.skipped;
        totalErrors += current.errors;
        sawEntryBound       = sawEntryBound || current.stoppedByEntryBound;
        sawDeleteBound      = sawDeleteBound || current.stoppedByDeleteBound;
        const bool hitBound = current.stoppedByEntryBound || current.stoppedByDeleteBound || current.stoppedByTimeBound;
        boundHits += hitBound ? 1u : 0u;
        state.Require(current.inspected <= 3u && current.deleted <= 1u, L"Every recovery pass must obey its explicit entry and delete bounds.");
        if (FAILED(recoveryHr) || ! hitBound)
        {
            ++passes;
            break;
        }
    }

    lockedFile.reset();
    bool allOldRegularDeleted = true;
    std::error_code ec;
    for (const std::filesystem::path& path : oldRegularFiles)
    {
        allOldRegularDeleted = allOldRegularDeleted && ! std::filesystem::exists(path, ec) && ! ec;
        ec.clear();
    }
    bool allFreshPreserved = true;
    for (const std::filesystem::path& path : freshFiles)
    {
        allFreshPreserved = allFreshPreserved && std::filesystem::exists(path, ec) && ! ec;
        ec.clear();
    }
    const DWORD reparseAttributes = GetFileAttributesW(reparsePath.c_str());
    state.Require(SUCCEEDED(recoveryHr) && passes < 32u && cursor.empty() && totalDeleted == oldRegularFiles.size() && totalErrors == 0u && sawEntryBound &&
                      sawDeleteBound && allOldRegularDeleted && allFreshPreserved && std::filesystem::exists(lockedPath, ec) &&
                      std::filesystem::is_directory(directoryPath, ec) && reparseAttributes != INVALID_FILE_ATTRIBUTES &&
                      (reparseAttributes & FILE_ATTRIBUTE_REPARSE_POINT) != 0u && ReadSettingsTestBytes(reparseTarget) == "recovery target" &&
                      ReadSettingsTestBytes(sharedTempShape) == "shared-temp shape" && ReadSettingsTestBytes(outOfRoot) == "outside private root",
                  std::format(L"Bounded private-root recovery must converge without touching fresh/live/directory/reparse/out-of-root entries "
                              L"(hr=0x{:08X}, passes={}, inspected={}, deleted={}, skipped={}, errors={}, bounds={}).",
                              static_cast<unsigned>(recoveryHr),
                              passes,
                              totalInspected,
                              totalDeleted,
                              totalSkipped,
                              totalErrors,
                              boundHits));

    const uint64_t elapsedUs = Debug::Perf::ElapsedUs(startedAt);
    Debug::Perf::EmitDurationUs(L"fileaction.selected_paths_recovery.selftest_us", elapsedUs, totalInspected, totalDeleted, recoveryHr);
    Debug::Perf::EmitValue(L"fileaction.selected_paths_recovery.selftest_passes", static_cast<uint64_t>(passes));
    Debug::Perf::EmitValue(L"fileaction.selected_paths_recovery.selftest_skipped", totalSkipped);
    Debug::Perf::EmitValue(L"fileaction.selected_paths_recovery.selftest_errors", totalErrors);
    Debug::Perf::EmitValue(L"fileaction.selected_paths_recovery.selftest_bound_hits", boundHits);
    const std::wstring artifact              = std::format(L"{{\n"
                                                           L"  \"scenario\": \"fileaction/selected-paths-recovery-bounds\",\n"
                                                           L"  \"passes\": {},\n"
                                                           L"  \"inspected\": {},\n"
                                                           L"  \"deleted\": {},\n"
                                                           L"  \"skipped\": {},\n"
                                                           L"  \"errors\": {},\n"
                                                           L"  \"bound_hits\": {},\n"
                                                           L"  \"elapsed_us\": {},\n"
                                                           L"  \"result_hr\": {}\n"
                                                           L"}}\n",
                                                           passes,
                                                           totalInspected,
                                                           totalDeleted,
                                                           totalSkipped,
                                                           totalErrors,
                                                           boundHits,
                                                           elapsedUs,
                                                           static_cast<uint32_t>(recoveryHr));
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"file_action_selected_paths_recovery_metrics.json");
    state.Require(! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, artifact) && SelfTest::PathExists(artifactPath),
                  L"Selected-path recovery scenario must write its deterministic content-free performance artifact.");

    return state.failure.empty();
}
#endif

[[nodiscard]] bool TestFileActionExternalLaunchStartsProcess(CaseState& state) noexcept
{
    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root   = suiteRoot / L"work" / (L"file_action_launch_" + NewGuidText());
    const std::filesystem::path marker = root / L"launch marker.txt";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create external-launch action test folder.");
    if (! state.failure.empty())
    {
        return false;
    }

    Common::Settings::FileActionDefinition action{};
    action.kind             = Common::Settings::FileActionKind::ExternalProgram;
    action.executablePath   = ResolveCommandProcessorPath();
    action.arguments        = L"/C echo launched>\"{FullPath}\"";
    action.workingDirectory = L"{Path}";

    FileActionLauncher::MacroContext context{};
    context.itemPath     = marker;
    context.computerName = L"BUILD-BOX";

    FileActionLauncher::LaunchPlan plan{};
    const HRESULT buildHr = FileActionLauncher::BuildExternalLaunchPlan(action, context, plan);
    state.Require(SUCCEEDED(buildHr), L"External launch action should build a command processor plan.");
    if (FAILED(buildHr))
    {
        return false;
    }

    FileActionLauncher::LaunchOptions options{};
    options.showCommand   = SW_HIDE;
    options.waitForExit   = true;
    options.waitTimeoutMs = static_cast<DWORD>(SelfTest::Scale(std::chrono::milliseconds{5000}).count());

    FileActionLauncher::LaunchResult result{};
    const HRESULT launchHr = FileActionLauncher::LaunchExternalPlan(std::move(plan), options, &result);
    state.Require(SUCCEEDED(launchHr),
                  std::format(L"External launch action should start and wait successfully (hr=0x{:08X}).", static_cast<unsigned>(launchHr)));
    state.Require(result.exitCodeAvailable && result.exitCode == 0u, L"External launch action should expose a zero process exit code.");
    state.Require(std::filesystem::exists(marker, ec), L"External launch action should create the marker file.");
    ec.clear();

    std::ifstream input(marker);
    std::string text;
    std::getline(input, text);
    state.Require(text == "launched", L"External launch action should write the expected marker contents.");

    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionSelectedPathsFileLifecycle(CaseState& state) noexcept
{
    const SelfTest::TestSandbox sandbox = SelfTest::AcquireTestSandbox(SelfTest::SelfTestSuite::Commands, L"file_action_selected_paths_file_lifecycle");
    state.Require(sandbox.IsValid(), L"Selected-path lifecycle requires a TestSandbox root.");
    if (! sandbox.IsValid())
    {
        return false;
    }
    const auto cleanup = wil::scope_exit([&] noexcept { static_cast<void>(SelfTest::RemoveAll(sandbox.root)); });

    const std::filesystem::path root       = sandbox.root;
    const std::filesystem::path firstFile  = root / L"one selected.txt";
    const std::filesystem::path secondFile = root / L"two selected.txt";
    const std::filesystem::path marker     = root / L"selected paths marker.tmp";
    const auto markerCleanup               = wil::scope_exit([&] noexcept
    {
        std::error_code markerError;
        static_cast<void>(std::filesystem::remove(marker, markerError));
    });
    std::error_code ec;
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create selected-paths action test folder.");
    state.Require(SelfTest::WriteTextFile(firstFile, "one"), L"Failed to create first selected-paths fixture.");
    state.Require(SelfTest::WriteTextFile(secondFile, "two"), L"Failed to create second selected-paths fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    Common::Settings::FileActionDefinition action{};
    action.kind             = Common::Settings::FileActionKind::ExternalProgram;
    action.executablePath   = ResolveSiblingExecutablePath(L"RedSalamanderSearchService.exe");
    action.arguments        = L"--test-support-child-probe=file-action-lease \"{SelectedPathsFile}\" \"{FullPath}\" 0 0";
    action.workingDirectory = L"{Path}";

    const std::array selectedPaths{firstFile, secondFile};
    FileActionLauncher::MacroContext context{};
    context.itemPath         = marker;
    context.currentDirectory = root;
    context.selectedPaths    = selectedPaths;
    context.oppositePanePath = root;
    context.computerName     = L"BUILD-BOX";

    FileActionLauncher::LaunchPlan plan{};
    const HRESULT buildHr = FileActionLauncher::BuildExternalLaunchPlan(action, context, plan);
    state.Require(SUCCEEDED(buildHr),
                  std::format(L"Selected-paths external action should build a temporary list file (hr=0x{:08X}).", static_cast<unsigned>(buildHr)));
    state.Require(plan.selectedPathsFileLease.HasValue(), L"Selected-paths external action should own one temporary file lease.");
    if (FAILED(buildHr) || ! plan.selectedPathsFileLease.HasValue())
    {
        return false;
    }

    const std::filesystem::path selectedPathsFile = plan.selectedPathsFileLease.Path();
    state.Require(std::filesystem::exists(selectedPathsFile, ec), L"Selected paths file should exist after launch-plan build.");
    ec.clear();

    std::ifstream selectedInput(selectedPathsFile, std::ios::binary);
    std::string selectedBytes((std::istreambuf_iterator<char>(selectedInput)), std::istreambuf_iterator<char>());
    selectedInput.close();
    state.Require(selectedBytes.size() >= 2u && static_cast<unsigned char>(selectedBytes[0]) == 0xFFu && static_cast<unsigned char>(selectedBytes[1]) == 0xFEu,
                  L"Selected paths file should be UTF-16LE with a BOM.");

    std::wstring selectedText;
    for (size_t index = 2u; index + 1u < selectedBytes.size(); index += 2u)
    {
        const wchar_t ch =
            static_cast<wchar_t>(static_cast<unsigned char>(selectedBytes[index]) | (static_cast<unsigned char>(selectedBytes[index + 1u]) << 8u));
        selectedText.push_back(ch);
    }
    state.Require(selectedText.find(firstFile.wstring()) != std::wstring::npos, L"Selected paths file should contain the first selected path.");
    state.Require(selectedText.find(secondFile.wstring()) != std::wstring::npos, L"Selected paths file should contain the second selected path.");

    FileActionLauncher::LaunchOptions options{};
    options.showCommand   = SW_HIDE;
    options.waitForExit   = true;
    options.waitTimeoutMs = static_cast<DWORD>(SelfTest::Scale(std::chrono::milliseconds{5000}).count());

    FileActionLauncher::LaunchResult result{};
    const HRESULT launchHr = FileActionLauncher::LaunchExternalPlan(std::move(plan), options, &result);
    state.Require(SUCCEEDED(launchHr),
                  std::format(L"Selected-paths external action should launch and wait successfully (hr=0x{:08X}).", static_cast<unsigned>(launchHr)));
    state.Require(result.exitCodeAvailable && result.exitCode == 0u,
                  std::format(L"Selected-paths external action should expose a zero process exit code (available={}, code={}).",
                              result.exitCodeAvailable,
                              result.exitCode));
    state.Require(std::filesystem::exists(marker, ec), L"Selected-paths external action should receive a valid selected-paths file path.");
    ec.clear();
    std::ifstream markerInput(marker);
    std::string markerText;
    std::getline(markerInput, markerText);
    state.Require(markerText == "parsed:2", L"Selected-paths child should parse both exact manifest records before process exit.");
    state.Require(! std::filesystem::exists(selectedPathsFile, ec), L"Selected paths file should be deleted after the waited process exits.");
    ec.clear();

    Common::Settings::FileActionDefinition noMacroAction = action;
    noMacroAction.arguments                              = L"/C echo no-macro";
    FileActionLauncher::LaunchPlan noMacroPlan{};
    const HRESULT noMacroHr = FileActionLauncher::BuildExternalLaunchPlan(noMacroAction, context, noMacroPlan);
    state.Require(SUCCEEDED(noMacroHr), L"External action without {SelectedPathsFile} should still build.");
    state.Require(! noMacroPlan.selectedPathsFileLease.HasValue(), L"External action without {SelectedPathsFile} should not create a cleanup lease.");

#if defined(ENABLE_TESTS)
    struct RemovalWaitResult final
    {
        bool removed     = false;
        bool stillExists = true;
        std::error_code finalError;
        size_t observationCount = 0u;
    };

    const auto waitUntilRemoved = [&](const std::filesystem::path& path) noexcept
    {
        RemovalWaitResult waitResult{};
        const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(std::chrono::milliseconds{5000});
        while (std::chrono::steady_clock::now() < deadline)
        {
            waitResult.finalError.clear();
            waitResult.stillExists = std::filesystem::exists(path, waitResult.finalError);
            ++waitResult.observationCount;
            if (! waitResult.finalError && ! waitResult.stillExists)
            {
                waitResult.removed = true;
                return waitResult;
            }

            std::this_thread::sleep_for(SelfTest::Scale(std::chrono::milliseconds{10}));
        }

        waitResult.finalError.clear();
        waitResult.stillExists = std::filesystem::exists(path, waitResult.finalError);
        ++waitResult.observationCount;
        waitResult.removed = ! waitResult.finalError && ! waitResult.stillExists;
        return waitResult;
    };

    const auto exerciseFault = [&](FileActionLauncher::Testing::ExternalLaunchFault fault, bool waitForExit, HRESULT expectedHr, bool deferred) noexcept
    {
        FileActionLauncher::LaunchPlan faultPlan{};
        const HRESULT faultBuildHr = FileActionLauncher::BuildExternalLaunchPlan(action, context, faultPlan);
        state.Require(SUCCEEDED(faultBuildHr) && faultPlan.selectedPathsFileLease.HasValue(), L"Faulted selected-path launch should first acquire one lease.");
        if (FAILED(faultBuildHr) || ! faultPlan.selectedPathsFileLease.HasValue())
        {
            return;
        }

        const std::filesystem::path leasePath = faultPlan.selectedPathsFileLease.Path();
        FileActionLauncher::LaunchOptions faultOptions{};
        faultOptions.showCommand                     = SW_HIDE;
        faultOptions.waitForExit                     = waitForExit;
        faultOptions.waitTimeoutMs                   = static_cast<DWORD>(SelfTest::Scale(std::chrono::milliseconds{5000}).count());
        faultOptions.selectedPathsMaximumRetentionMs = static_cast<DWORD>(SelfTest::Scale(std::chrono::milliseconds{250}).count());
        FileActionLauncher::Testing::SetNextExternalLaunchFault(fault);
        const HRESULT faultHr = FileActionLauncher::LaunchExternalPlan(std::move(faultPlan), faultOptions);
        state.Require(faultHr == expectedHr,
                      std::format(L"Faulted selected-path launch returned 0x{:08X}, expected 0x{:08X}.",
                                  static_cast<unsigned>(faultHr),
                                  static_cast<unsigned>(expectedHr)));
        if (deferred)
        {
            const RemovalWaitResult removal = waitUntilRemoved(leasePath);
            state.Require(removal.removed,
                          std::format(L"Deferred selected-path cleanup should reach its bounded process/timeout quiet point "
                                      L"(fault={}, path='{}', stillExists={}, finalError={}, observations={}).",
                                      static_cast<unsigned>(fault),
                                      leasePath.wstring(),
                                      removal.stillExists ? L"yes" : L"no",
                                      removal.finalError.value(),
                                      removal.observationCount));
        }
        else
        {
            std::error_code removedError;
            state.Require(! std::filesystem::exists(leasePath, removedError) && ! removedError,
                          L"Prelaunch or waited failure should release the selected-path lease immediately.");
        }
    };

    exerciseFault(FileActionLauncher::Testing::ExternalLaunchFault::DeferredCleanupAllocation, false, E_OUTOFMEMORY, false);
    exerciseFault(FileActionLauncher::Testing::ExternalLaunchFault::DeferredCleanupWaitCreation, false, HRESULT_FROM_WIN32(ERROR_NOT_ENOUGH_MEMORY), false);
    exerciseFault(FileActionLauncher::Testing::ExternalLaunchFault::ShellExecute, false, HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND), false);
    exerciseFault(FileActionLauncher::Testing::ExternalLaunchFault::NullProcessHandle, false, S_OK, true);
    exerciseFault(FileActionLauncher::Testing::ExternalLaunchFault::WaitFailure, true, HRESULT_FROM_WIN32(ERROR_GEN_FAILURE), true);
    exerciseFault(FileActionLauncher::Testing::ExternalLaunchFault::ExitCodeQuery, true, HRESULT_FROM_WIN32(ERROR_GEN_FAILURE), false);

    Common::Settings::FileActionDefinition timeoutAction = action;
    timeoutAction.arguments                              = L"--test-support-child-probe=file-action-lease \"{SelectedPathsFile}\" \"{FullPath}\" 750 0";
    FileActionLauncher::LaunchPlan timeoutPlan{};
    const HRESULT timeoutBuildHr = FileActionLauncher::BuildExternalLaunchPlan(timeoutAction, context, timeoutPlan);
    state.Require(SUCCEEDED(timeoutBuildHr) && timeoutPlan.selectedPathsFileLease.HasValue(), L"Timeout selected-path launch should acquire one lease.");
    if (SUCCEEDED(timeoutBuildHr) && timeoutPlan.selectedPathsFileLease.HasValue())
    {
        const std::filesystem::path timeoutLeasePath = timeoutPlan.selectedPathsFileLease.Path();
        FileActionLauncher::LaunchOptions timeoutOptions{};
        timeoutOptions.showCommand                     = SW_HIDE;
        timeoutOptions.waitForExit                     = true;
        timeoutOptions.waitTimeoutMs                   = 1u;
        timeoutOptions.selectedPathsMaximumRetentionMs = static_cast<DWORD>(SelfTest::Scale(std::chrono::milliseconds{3000}).count());
        const HRESULT timeoutHr                        = FileActionLauncher::LaunchExternalPlan(std::move(timeoutPlan), timeoutOptions);
        state.Require(timeoutHr == HRESULT_FROM_WIN32(ERROR_TIMEOUT), L"Wait timeout should be surfaced while cleanup ownership is retained.");
        const RemovalWaitResult timeoutRemoval = waitUntilRemoved(timeoutLeasePath);
        state.Require(timeoutRemoval.removed,
                      std::format(L"Timed-out selected-path launch should clean after exit or bounded retention "
                                  L"(path='{}', stillExists={}, finalError={}, observations={}).",
                                  timeoutLeasePath.wstring(),
                                  timeoutRemoval.stillExists ? L"yes" : L"no",
                                  timeoutRemoval.finalError.value(),
                                  timeoutRemoval.observationCount));
    }

    Common::Settings::FileActionDefinition nonzeroAction = action;
    nonzeroAction.arguments                              = L"--test-support-child-probe=file-action-lease \"{SelectedPathsFile}\" \"{FullPath}\" 0 7";
    FileActionLauncher::LaunchPlan nonzeroPlan{};
    const HRESULT nonzeroBuildHr = FileActionLauncher::BuildExternalLaunchPlan(nonzeroAction, context, nonzeroPlan);
    if (SUCCEEDED(nonzeroBuildHr) && nonzeroPlan.selectedPathsFileLease.HasValue())
    {
        const std::filesystem::path nonzeroLeasePath = nonzeroPlan.selectedPathsFileLease.Path();
        FileActionLauncher::LaunchOptions nonzeroOptions{};
        nonzeroOptions.showCommand   = SW_HIDE;
        nonzeroOptions.waitForExit   = true;
        nonzeroOptions.waitTimeoutMs = static_cast<DWORD>(SelfTest::Scale(std::chrono::milliseconds{5000}).count());
        FileActionLauncher::LaunchResult nonzeroResult{};
        const HRESULT nonzeroHr = FileActionLauncher::LaunchExternalPlan(std::move(nonzeroPlan), nonzeroOptions, &nonzeroResult);
        std::error_code nonzeroError;
        state.Require(nonzeroHr == S_OK && nonzeroResult.exitCodeAvailable && nonzeroResult.exitCode == 7u &&
                          ! std::filesystem::exists(nonzeroLeasePath, nonzeroError) && ! nonzeroError,
                      L"Nonzero child exit should still release the selected-path lease after reporting the exit code.");
    }
    else
    {
        state.Require(false, L"Nonzero-exit selected-path launch should acquire one lease.");
    }

#endif

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreShortcutDefaultsRoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestShortcutDefaultsRoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings settings{};
    ShortcutDefaults::EnsureShortcutsInitialized(settings);

    const Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
    state.Require(! prepared.shortcuts.has_value(), L"Canonical save path should omit default shortcuts.");

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, prepared);
    state.Require(SUCCEEDED(saveHr), L"Failed to save shortcut-default round-trip test settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"TryLoadSettingsNoRecovery should succeed for shortcut-default round-trip settings.");
    state.Require(! loaded.shortcuts.has_value(), L"Loading canonical settings without a shortcuts block should keep shortcuts absent until initialization.");
    if (FAILED(loadHr))
    {
        return false;
    }

    ShortcutDefaults::EnsureShortcutsInitialized(loaded);
    state.Require(loaded.shortcuts.has_value(), L"Shortcut initialization should restore default shortcuts after loading canonical settings.");
    if (! loaded.shortcuts.has_value())
    {
        return false;
    }

    ShortcutManager manager;
    manager.Load(loaded.shortcuts.value());

    const auto folderCommand = manager.FindFolderViewCommand(VK_INSERT, ShortcutManager::kModCtrl);
    state.Require(folderCommand.has_value() && folderCommand.value() == std::wstring_view{L"cmd/pane/clipboardCopy"},
                  L"Ctrl+Insert should be restored after initializing missing shortcuts.");

    const auto functionCommand = manager.FindFunctionBarCommand(VK_F3, 0u);
    state.Require(functionCommand.has_value() && functionCommand.value() == std::wstring_view{L"cmd/pane/view"},
                  L"F3 should be restored after initializing missing shortcuts.");
    return state.failure.empty();
}

[[nodiscard]] Common::Settings::ShortcutBinding* FindTestShortcutBinding(std::vector<Common::Settings::ShortcutBinding>& bindings,
                                                                         uint32_t vk,
                                                                         uint32_t modifiers) noexcept
{
    for (Common::Settings::ShortcutBinding& binding : bindings)
    {
        if (binding.vk == vk && (binding.modifiers & 0x7u) == (modifiers & 0x7u))
        {
            return &binding;
        }
    }
    return nullptr;
}

[[nodiscard]] Common::Settings::ShortcutBinding* FindTestShortcutBinding(std::vector<Common::Settings::ShortcutBinding>& bindings,
                                                                         Common::Keyboard::KeyPosition keyPosition,
                                                                         uint32_t modifiers) noexcept
{
    for (Common::Settings::ShortcutBinding& binding : bindings)
    {
        if (binding.keyPosition == keyPosition && (binding.modifiers & 0x7u) == (modifiers & 0x7u))
        {
            return &binding;
        }
    }
    return nullptr;
}

void RemoveTestShortcutBinding(std::vector<Common::Settings::ShortcutBinding>& bindings, uint32_t vk, uint32_t modifiers) noexcept
{
    bindings.erase(std::remove_if(bindings.begin(),
                                  bindings.end(),
                                  [=](const Common::Settings::ShortcutBinding& binding) noexcept
    { return binding.vk == vk && (binding.modifiers & 0x7u) == (modifiers & 0x7u); }),
                   bindings.end());
}

[[nodiscard]] bool TestShortcutDefaultsRestoreMissingF3View(CaseState& state) noexcept
{
    Common::Settings::Settings settings{};
    settings.shortcuts = ShortcutDefaults::CreateDefaultShortcuts();

    auto& functionBar = settings.shortcuts.value().functionBar;
    RemoveTestShortcutBinding(functionBar, VK_F3, 0u);

    ShortcutDefaults::EnsureShortcutsInitialized(settings);
    state.Require(settings.shortcuts.has_value(), L"Shortcut initialization should preserve the existing shortcuts block.");
    if (! settings.shortcuts.has_value())
    {
        return false;
    }

    ShortcutManager manager;
    manager.Load(settings.shortcuts.value());

    const auto functionCommand = manager.FindFunctionBarCommand(VK_F3, 0u);
    state.Require(functionCommand.has_value() && functionCommand.value() == std::wstring_view{L"cmd/pane/view"},
                  L"Missing plain F3 should be restored to cmd/pane/view when existing shortcuts are initialized.");
    return state.failure.empty();
}

[[nodiscard]] bool TestShortcutDefaultsRestoreMissingDefaultsAndPreserveUnassigned(CaseState& state) noexcept
{
    static constexpr std::wstring_view kUnassignedCommandId = L"cmd/shortcut/unassigned";

    Common::Settings::Settings settings{};
    settings.shortcuts = ShortcutDefaults::CreateDefaultShortcuts();
    auto& shortcuts    = settings.shortcuts.value();

    RemoveTestShortcutBinding(shortcuts.functionBar, VK_F4, 0u);
    RemoveTestShortcutBinding(shortcuts.functionBar, VK_F12, ShortcutManager::kModCtrl);
    RemoveTestShortcutBinding(shortcuts.folderView, VK_RETURN, 0u);
    RemoveTestShortcutBinding(shortcuts.folderView, static_cast<uint32_t>('1'), ShortcutManager::kModCtrl);
    RemoveTestShortcutBinding(shortcuts.application, static_cast<uint32_t>('P'), ShortcutManager::kModCtrl | ShortcutManager::kModShift);
    RemoveTestShortcutBinding(shortcuts.terminal, static_cast<uint32_t>('F'), ShortcutManager::kModCtrl | ShortcutManager::kModShift);

    Common::Settings::ShortcutBinding* unassignedFunction = FindTestShortcutBinding(shortcuts.functionBar, VK_F5, 0u);
    state.Require(unassignedFunction != nullptr, L"Shortcut default fixture should include plain F5 before marking it unassigned.");
    if (unassignedFunction)
    {
        unassignedFunction->commandId = kUnassignedCommandId;
    }

    Common::Settings::ShortcutBinding* unassignedFolder = FindTestShortcutBinding(shortcuts.folderView, VK_INSERT, ShortcutManager::kModCtrl);
    state.Require(unassignedFolder != nullptr, L"Shortcut default fixture should include Ctrl+Insert before marking it unassigned.");
    if (unassignedFolder)
    {
        unassignedFolder->commandId = kUnassignedCommandId;
    }

    ShortcutDefaults::EnsureShortcutsInitialized(settings);
    state.Require(settings.shortcuts.has_value(), L"Shortcut initialization should preserve a customized shortcuts block.");
    if (! settings.shortcuts.has_value())
    {
        return false;
    }

    ShortcutManager manager;
    manager.Load(settings.shortcuts.value());

    const auto f4Command = manager.FindFunctionBarCommand(VK_F4, 0u);
    state.Require(f4Command.has_value() && f4Command.value() == std::wstring_view{L"cmd/pane/edit"}, L"Missing plain F4 should be restored to cmd/pane/edit.");

    const auto ctrlF12Command = manager.FindFunctionBarCommand(VK_F12, ShortcutManager::kModCtrl);
    state.Require(ctrlF12Command.has_value() && ctrlF12Command.value() == std::wstring_view{L"cmd/pane/filter"},
                  L"Missing Ctrl+F12 should be restored to cmd/pane/filter.");

    const auto enterCommand = manager.FindFolderViewCommand(VK_RETURN, 0u);
    state.Require(enterCommand.has_value() && enterCommand.value() == std::wstring_view{L"cmd/pane/executeOpen"},
                  L"Missing Enter should be restored to cmd/pane/executeOpen.");

    const auto hotPathCommand = manager.FindFolderViewCommand(static_cast<uint32_t>('1'), ShortcutManager::kModCtrl);
    state.Require(hotPathCommand.has_value() && hotPathCommand.value() == std::wstring_view{L"cmd/pane/hotPath/1"},
                  L"Missing Ctrl+1 should be restored to cmd/pane/hotPath/1.");

    const auto paletteCommand = manager.FindApplicationCommand(static_cast<uint32_t>('P'), ShortcutManager::kModCtrl | ShortcutManager::kModShift);
    state.Require(paletteCommand.has_value() && paletteCommand.value() == std::wstring_view{L"cmd/app/commandPalette"},
                  L"Missing global Ctrl+Shift+P should be restored to cmd/app/commandPalette.");

    const auto terminalFindCommand = manager.FindTerminalCommand(static_cast<uint32_t>('F'), ShortcutManager::kModCtrl | ShortcutManager::kModShift, 0u, false);
    state.Require(terminalFindCommand.has_value() && terminalFindCommand.value() == std::wstring_view{L"cmd/terminal/find"},
                  L"Missing terminal Ctrl+Shift+F should be restored to cmd/terminal/find.");

    const auto f5Command = manager.FindFunctionBarCommand(VK_F5, 0u);
    state.Require(f5Command.has_value() && f5Command.value() == kUnassignedCommandId,
                  L"Plain F5 marked unassigned should remain an explicit no-op instead of restoring its default command.");

    const auto ctrlInsertCommand = manager.FindFolderViewCommand(VK_INSERT, ShortcutManager::kModCtrl);
    state.Require(ctrlInsertCommand.has_value() && ctrlInsertCommand.value() == kUnassignedCommandId,
                  L"Ctrl+Insert marked unassigned should remain an explicit no-op instead of restoring its default command.");

    const auto sentinelShortcut = manager.TryGetShortcutForCommand(kUnassignedCommandId);
    state.Require(! sentinelShortcut.has_value(), L"The internal unassigned sentinel should not be exposed as a reverse shortcut for a command.");

    return state.failure.empty();
}

[[nodiscard]] bool TestTerminalShortcutDefaultsAndPhysicalPositions(CaseState& state) noexcept
{
    Common::Settings::ShortcutsSettings defaults = ShortcutDefaults::CreateDefaultShortcuts();
    state.Require(ShortcutDefaults::kWindowsTerminalReviewCoverage.p1Mapped == 48u &&
                      ShortcutDefaults::kWindowsTerminalReviewCoverage.deferredPassThrough == 12u &&
                      ShortcutDefaults::kWindowsTerminalReviewCoverage.notApplicable == 8u && ShortcutDefaults::kWindowsTerminalReviewCoverage.Total() == 68u,
                  L"The upstream Windows Terminal review must retain its exact 48 + 12 + 8 = 68 partition.");
    state.Require(defaults.application.size() == 4u, L"Application scope should contain exactly the four reviewed global defaults.");
    state.Require(defaults.terminal.size() == 46u, L"Terminal scope should contain exactly the 46 reviewed defaults.");
    Common::Settings::ShortcutBinding* physicalPlus =
        FindTestShortcutBinding(defaults.terminal, Common::Keyboard::KeyPosition::NumberRowPlus, ShortcutManager::kModCtrl);
    state.Require(physicalPlus != nullptr && physicalPlus->vk == 0u,
                  L"The terminal Ctrl+number-row-plus default must persist a physical position instead of a layout character.");

    ShortcutManager manager;
    manager.Load(defaults);
    state.Require(manager.GetApplicationConflicts().empty(), L"Default application shortcuts have conflicts.");
    state.Require(manager.GetTerminalConflicts().empty(), L"Default terminal shortcuts have conflicts.");

    std::unordered_set<std::wstring_view> terminalCommandIds;
    for (const Common::Settings::ShortcutBinding& terminalBinding : defaults.terminal)
    {
        const std::wstring_view commandId = CanonicalizeCommandId(terminalBinding.commandId);
        const CommandInfo* const command  = FindCommandInfo(commandId);
        state.Require(command != nullptr, std::format(L"Terminal default {} is missing its command definition.", commandId));
        if (! command)
        {
            continue;
        }
        state.Require(IsCommandShortcutEligible(*command, CommandShortcutScope::Terminal),
                      std::format(L"Terminal default {} is not Terminal-scope eligible.", commandId));
        state.Require(command->executorOwner != CommandExecutorOwner::LegacyHost,
                      std::format(L"Terminal command {} is missing typed executor ownership.", commandId));
        state.Require(command->dispatchPath != CommandDispatchPath::Legacy, std::format(L"Terminal command {} is missing a typed dispatch path.", commandId));
        state.Require(command->visualId != CommandVisualId::None, std::format(L"Terminal command {} is missing a visual ID.", commandId));
        state.Require(command->paletteVisible, std::format(L"Terminal command {} should be visible in the global command palette.", commandId));
        state.Require(! command->searchKeywords.empty(), std::format(L"Terminal command {} is missing search keywords.", commandId));
        terminalCommandIds.emplace(commandId);
    }
    state.Require(terminalCommandIds.size() == 39u, L"The 46 Terminal defaults should resolve to exactly 39 Terminal-scope-eligible command definitions.");

    for (const std::wstring_view commandId : {L"cmd/terminal/close", L"cmd/terminal/contextMenu", L"cmd/terminal/sessionMenu"})
    {
        const CommandInfo* const command = FindCommandInfo(commandId);
        state.Require(command != nullptr && command->executorOwner == CommandExecutorOwner::TerminalHost &&
                          command->dispatchPath == CommandDispatchPath::StableCommandId && command->stateSource == CommandStateSource::ApplicationHost,
                      std::format(L"{} must use host-owned dispatch and state instead of the Terminal action ABI.", commandId));
    }
    if (const CommandInfo* const copy = FindCommandInfo(L"cmd/terminal/copy"))
    {
        state.Require(copy->executorOwner == CommandExecutorOwner::TerminalPlugin && copy->dispatchPath == CommandDispatchPath::TerminalActions &&
                          copy->stateSource == CommandStateSource::TerminalActions,
                      L"Terminal Copy must retain plugin-owned action dispatch and state.");
    }
    else
    {
        state.Require(false, L"Terminal Copy is missing from the command registry.");
    }

    for (const Common::Settings::ShortcutBinding& applicationBinding : defaults.application)
    {
        const CommandInfo* const command = FindCommandInfo(applicationBinding.commandId);
        state.Require(command != nullptr, std::format(L"Application default {} is missing its command definition.", applicationBinding.commandId));
        if (command)
        {
            state.Require(IsCommandShortcutEligible(*command, CommandShortcutScope::Application),
                          std::format(L"Application default {} is not Application-scope eligible.", applicationBinding.commandId));
        }
    }

    const auto plus = manager.FindTerminalCommand(static_cast<uint32_t>('Q'), ShortcutManager::kModCtrl, Common::Keyboard::kNumberRowPlusScanCode, false);
    state.Require(plus.has_value() && plus.value() == std::wstring_view{L"cmd/terminal/font/increase"},
                  L"Ctrl+number-row-plus should resolve by scan-code position, independently of its layout character.");

    const auto minus = manager.FindTerminalCommand(static_cast<uint32_t>('W'), ShortcutManager::kModCtrl, Common::Keyboard::kNumberRowMinusScanCode, false);
    state.Require(minus.has_value() && minus.value() == std::wstring_view{L"cmd/terminal/font/decrease"},
                  L"Ctrl+number-row-minus should resolve by scan-code position, independently of its layout character.");

    state.Require(! manager.FindTerminalCommand(VK_OEM_PLUS, ShortcutManager::kModCtrl, Common::Keyboard::kNumberRowPlusScanCode, true).has_value(),
                  L"An extended key with the number-row scan code must not match a physical number-row shortcut.");

    const auto folderPlus =
        manager.FindFolderViewCommand(static_cast<uint32_t>('Q'), ShortcutManager::kModCtrl, Common::Keyboard::kNumberRowPlusScanCode, false);
    state.Require(folderPlus.has_value() && folderPlus.value() == std::wstring_view{L"cmd/pane/selection/selectDialog"},
                  L"Folder-view Ctrl+number-row-plus should use the same physical-key identity.");

    const auto numpadPlus = manager.FindTerminalCommand(VK_ADD, ShortcutManager::kModCtrl, 0u, true);
    state.Require(numpadPlus.has_value() && numpadPlus.value() == std::wstring_view{L"cmd/terminal/font/increase"},
                  L"Ctrl+NumpadPlus should remain an explicit virtual-key alias.");

    state.Require(! manager.FindTerminalCommand(VK_F11, 0u, 0u, false).has_value(), L"Plain F11 must not be claimed by terminal fullscreen.");
    const auto connect = manager.FindFunctionBarCommand(VK_F11, 0u);
    state.Require(connect.has_value() && connect.value() == std::wstring_view{L"cmd/pane/connect"}, L"Plain F11 must remain the Salamander Connect command.");

    const auto globalPalette = manager.FindApplicationCommand(static_cast<uint32_t>('P'), ShortcutManager::kModCtrl | ShortcutManager::kModShift);
    state.Require(globalPalette.has_value() && globalPalette.value() == std::wstring_view{L"cmd/app/commandPalette"},
                  L"Ctrl+Shift+P must remain the global RedSalamander Command Palette.");

    Common::Settings::ShortcutsSettings physicalApplication = defaults;
    physicalApplication.application.push_back(Common::Settings::ShortcutBinding{
        .modifiers   = ShortcutManager::kModCtrl,
        .commandId   = L"cmd/app/commandPalette",
        .keyPosition = Common::Keyboard::KeyPosition::NumberRowPlus,
    });
    ShortcutManager physicalApplicationManager;
    physicalApplicationManager.Load(physicalApplication);
    const auto physicalApplicationCommand = physicalApplicationManager.FindApplicationCommand(
        static_cast<uint32_t>('Q'), ShortcutManager::kModCtrl, Common::Keyboard::kNumberRowPlusScanCode, false);
    state.Require(physicalApplicationCommand.has_value() && physicalApplicationCommand.value() == L"cmd/app/commandPalette" &&
                      ! physicalApplicationManager.FindApplicationCommand(static_cast<uint32_t>('Q'), ShortcutManager::kModCtrl).has_value(),
                  L"Application physical shortcuts must dispatch from scan-code identity and not from the current layout character alone.");

    return state.failure.empty();
}

[[nodiscard]] bool TestTerminalShortcutPassThroughRoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestTerminalShortcutPassThroughRoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings settings{};
    settings.shortcuts = ShortcutDefaults::CreateDefaultShortcuts();
    Common::Settings::ShortcutBinding binding{};
    binding.vk        = static_cast<uint32_t>('P');
    binding.modifiers = ShortcutManager::kModCtrl | ShortcutManager::kModShift;
    binding.commandId = ShortcutIds::kPassThroughCommandId;
    settings.shortcuts->terminal.push_back(std::move(binding));

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, SettingsSave::PrepareForSave(settings));
    state.Require(SUCCEEDED(saveHr), L"Failed to save terminal pass-through shortcut settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Failed to load terminal pass-through shortcut settings.");
    if (FAILED(loadHr))
    {
        return false;
    }

    ShortcutDefaults::EnsureShortcutsInitialized(loaded);
    state.Require(loaded.shortcuts.has_value(), L"Loaded terminal pass-through shortcut block is missing.");
    if (! loaded.shortcuts.has_value())
    {
        return false;
    }
    state.Require(loaded.shortcuts->migrationVersion == 1u, L"Shortcut migration version should survive a customized shortcut save/load round trip.");

    ShortcutManager manager;
    manager.Load(loaded.shortcuts.value());
    const auto terminalCommand = manager.FindTerminalCommand(static_cast<uint32_t>('P'), ShortcutManager::kModCtrl | ShortcutManager::kModShift, 0u, false);
    state.Require(terminalCommand.has_value() && terminalCommand.value() == ShortcutIds::kPassThroughCommandId,
                  L"Terminal Ctrl+Shift+P pass-through should survive save, load, and default merging.");
    const auto globalCommand = manager.FindApplicationCommand(static_cast<uint32_t>('P'), ShortcutManager::kModCtrl | ShortcutManager::kModShift);
    state.Require(globalCommand.has_value() && globalCommand.value() == std::wstring_view{L"cmd/app/commandPalette"},
                  L"A terminal pass-through override must not remove the global palette binding from application scope.");
    state.Require(! manager.TryGetShortcutForCommand(ShortcutIds::kPassThroughCommandId).has_value(),
                  L"The pass-through pseudo-command must not appear in reverse command lookup.");

    for (const std::string_view invalidScope : {"application", "functionBar", "folderView"})
    {
        const std::wstring invalidScopeWide = Common::Strings::Utf16FromUtf8StrictOrEmpty(invalidScope);
        const std::wstring invalidAppId     = std::format(L"RedSalamanderSelfTestPassThroughScope_{}", invalidScopeWide);
        CleanupSettingsArtifacts(invalidAppId);
        const auto invalidCleanup               = wil::scope_exit([&] { CleanupSettingsArtifacts(invalidAppId); });
        const std::filesystem::path invalidPath = Common::Settings::GetSettingsPath(invalidAppId);
        const std::string invalidJson =
            std::format(R"json({{"schemaVersion":16,"shortcuts":{{"{}":[{{"vk":"F24","commandId":"cmd/shortcut/passthrough"}}]}}}})json", invalidScope);
        state.Require(SelfTest::WriteTextFile(invalidPath, invalidJson), L"Failed to write an invalid non-Terminal pass-through fixture.");
        Common::Settings::Settings invalidLoaded{};
        const HRESULT invalidHr = Common::Settings::TryLoadSettingsNoRecovery(invalidAppId, invalidLoaded);
        state.Require(invalidHr == S_OK && ! invalidLoaded.shortcuts.has_value(),
                      std::format(L"{} pass-through must recover only the invalid shortcuts section.", invalidScopeWide));
    }

    constexpr std::string_view kInvalidFunctionPhysicalImport =
        R"json({"shortcuts":{"functionBar":[{"keyPosition":"numberRowPlus","commandId":"cmd/pane/connect"}]}})json";
    constexpr std::string_view kInvalidApplicationPassThroughImport =
        R"json({"shortcuts":{"application":[{"vk":"F24","commandId":"cmd/shortcut/passthrough"}]}})json";
    constexpr std::string_view kValidTerminalPassThroughImport = R"json({"shortcuts":{"terminal":[{"vk":"F24","commandId":"cmd/shortcut/passthrough"}]}})json";
    Common::Settings::ShortcutsSettings imported{};
    std::wstring importError;
    state.Require(! DebugParsePreferencesShortcutImport(kInvalidFunctionPhysicalImport, imported, importError) && ! importError.empty(),
                  L"Preferences import must reject a physical Function Bar shortcut.");
    state.Require(! DebugParsePreferencesShortcutImport(kInvalidApplicationPassThroughImport, imported, importError) && ! importError.empty(),
                  L"Preferences import must reject pass-through outside Terminal scope.");
    state.Require(DebugParsePreferencesShortcutImport(kValidTerminalPassThroughImport, imported, importError) && imported.terminal.size() == 1u &&
                      imported.terminal.front().commandId == ShortcutIds::kPassThroughCommandId,
                  L"Preferences import must preserve a valid Terminal pass-through shortcut.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreShortcutUnassignedSentinelRoundTrip(CaseState& state) noexcept
{
    static constexpr std::wstring_view kTestAppId           = L"RedSalamanderSelfTestShortcutUnassignedSentinelRoundTrip";
    static constexpr std::wstring_view kUnassignedCommandId = L"cmd/shortcut/unassigned";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings settings{};
    settings.shortcuts = ShortcutDefaults::CreateDefaultShortcuts();
    auto& shortcuts    = settings.shortcuts.value();

    Common::Settings::ShortcutBinding* functionBinding = FindTestShortcutBinding(shortcuts.functionBar, VK_F5, 0u);
    state.Require(functionBinding != nullptr, L"Shortcut default fixture should include plain F5 before saving an explicit unassignment.");
    if (functionBinding)
    {
        functionBinding->commandId = kUnassignedCommandId;
    }

    Common::Settings::ShortcutBinding* folderBinding = FindTestShortcutBinding(shortcuts.folderView, VK_INSERT, ShortcutManager::kModCtrl);
    state.Require(folderBinding != nullptr, L"Shortcut default fixture should include Ctrl+Insert before saving an explicit unassignment.");
    if (folderBinding)
    {
        folderBinding->commandId = kUnassignedCommandId;
    }

    const Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
    state.Require(prepared.shortcuts.has_value(), L"Canonical save path should persist explicit unassigned shortcut sentinels.");
    if (! prepared.shortcuts.has_value())
    {
        return false;
    }

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, prepared);
    state.Require(SUCCEEDED(saveHr), L"Failed to save shortcut unassigned sentinel round-trip test settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"TryLoadSettingsNoRecovery should succeed for shortcut unassigned sentinel round-trip settings.");
    if (FAILED(loadHr))
    {
        return false;
    }

    ShortcutDefaults::EnsureShortcutsInitialized(loaded);
    state.Require(loaded.shortcuts.has_value(), L"Shortcut initialization should keep loaded sentinel shortcuts.");
    if (! loaded.shortcuts.has_value())
    {
        return false;
    }

    ShortcutManager manager;
    manager.Load(loaded.shortcuts.value());

    const auto f5Command = manager.FindFunctionBarCommand(VK_F5, 0u);
    state.Require(f5Command.has_value() && f5Command.value() == kUnassignedCommandId,
                  L"Plain F5 explicit unassignment should survive save/load and shortcut initialization.");

    const auto ctrlInsertCommand = manager.FindFolderViewCommand(VK_INSERT, ShortcutManager::kModCtrl);
    state.Require(ctrlInsertCommand.has_value() && ctrlInsertCommand.value() == kUnassignedCommandId,
                  L"Ctrl+Insert explicit unassignment should survive save/load and shortcut initialization.");

    const auto sentinelShortcut = manager.TryGetShortcutForCommand(kUnassignedCommandId);
    state.Require(! sentinelShortcut.has_value(), L"The internal unassigned sentinel should not be exposed as a reverse shortcut after load.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreShortcutsViewStateRoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestShortcutsViewStateRoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings settings{};
    ShortcutDefaults::EnsureShortcutsInitialized(settings);
    state.Require(settings.shortcuts.has_value(), L"Shortcut defaults should initialize before shortcuts view-state round-trip.");
    if (! settings.shortcuts.has_value())
    {
        return false;
    }

    auto& shortcuts                = settings.shortcuts.value();
    shortcuts.functionBarCollapsed = true;
    shortcuts.folderViewCollapsed  = true;
    shortcuts.applicationCollapsed = true;
    shortcuts.terminalCollapsed    = true;
    shortcuts.sortColumnId         = L"key";
    shortcuts.sortDescending       = true;
    shortcuts.gridLayout           = {
        Common::Settings::GridColumnLayoutEntry{.columnId = L"key", .displayIndex = 0u, .widthDip = 180.0f},
        Common::Settings::GridColumnLayoutEntry{.columnId = L"command", .displayIndex = 1u, .widthDip = 360.0f},
    };

    const Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
    state.Require(prepared.shortcuts.has_value(), L"Canonical save path should keep shortcuts when persisted shortcuts view state differs from defaults.");
    if (! prepared.shortcuts.has_value())
    {
        return false;
    }

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, prepared);
    state.Require(SUCCEEDED(saveHr), L"Failed to save shortcuts view-state round-trip settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"TryLoadSettingsNoRecovery should succeed for shortcuts view-state round-trip settings.");
    state.Require(loaded.shortcuts.has_value(), L"Shortcuts settings block missing after view-state round-trip.");
    if (FAILED(loadHr) || ! loaded.shortcuts.has_value())
    {
        return false;
    }

    const Common::Settings::ShortcutsSettings& actual = loaded.shortcuts.value();
    state.Require(actual.functionBarCollapsed, L"functionBarCollapsed did not round-trip.");
    state.Require(actual.folderViewCollapsed, L"folderViewCollapsed did not round-trip.");
    state.Require(actual.applicationCollapsed, L"applicationCollapsed did not round-trip.");
    state.Require(actual.terminalCollapsed, L"terminalCollapsed did not round-trip.");
    state.Require(actual.sortColumnId == shortcuts.sortColumnId, L"sortColumnId did not round-trip.");
    state.Require(actual.sortDescending == shortcuts.sortDescending, L"sortDescending did not round-trip.");
    state.Require(actual.gridLayout.size() == shortcuts.gridLayout.size(), L"gridLayout entry count did not round-trip.");
    if (actual.gridLayout.size() == shortcuts.gridLayout.size())
    {
        for (size_t index = 0u; index < shortcuts.gridLayout.size(); ++index)
        {
            const auto& expected = shortcuts.gridLayout[index];
            const auto& entry    = actual.gridLayout[index];
            state.Require(entry.columnId == expected.columnId, std::format(L"gridLayout[{}].columnId did not round-trip.", index));
            state.Require(entry.displayIndex == expected.displayIndex, std::format(L"gridLayout[{}].displayIndex did not round-trip.", index));
            state.Require(std::abs(entry.widthDip - expected.widthDip) < 0.01f, std::format(L"gridLayout[{}].widthDip did not round-trip.", index));
        }
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreFileOperationsRoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestFileOpsRoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    const std::filesystem::path settingsPath               = Common::Settings::GetSettingsPath(kTestAppId);
    constexpr std::string_view kCollapsedThroughputFixture = R"json({"schemaVersion":16,"fileOperations":{"popupThroughputExpanded":false}})json";
    state.Require(SelfTest::WriteTextFile(settingsPath, kCollapsedThroughputFixture),
                  L"Failed to write the collapsed-throughput file-operations settings fixture.");
    Common::Settings::Settings collapsedThroughput{};
    const HRESULT collapsedLoadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, collapsedThroughput);
    state.Require(collapsedLoadHr == S_OK && collapsedThroughput.fileOperations.has_value(),
                  L"Explicit collapsed-throughput settings should load without recovery.");
    state.Require(collapsedThroughput.fileOperations.has_value() && ! collapsedThroughput.fileOperations->popupThroughputExpanded,
                  L"Explicit popupThroughputExpanded=false should parse as collapsed.");
    const Common::Settings::Settings preparedCollapsedThroughput = SettingsSave::PrepareForSave(collapsedThroughput);
    state.Require(preparedCollapsedThroughput.fileOperations.has_value(),
                  L"Explicit popupThroughputExpanded=false must be retained as the sole non-default file-operations setting.");

    CleanupSettingsArtifacts(kTestAppId);
    constexpr std::string_view kExpandedAndInvalidThroughputFixtures[]{
        R"json({"schemaVersion":16,"fileOperations":{"popupThroughputExpanded":true}})json",
        R"json({"schemaVersion":16,"fileOperations":{"popupThroughputExpanded":"collapsed"}})json",
        R"json({"schemaVersion":16,"fileOperations":{}})json",
    };
    for (const std::string_view fixture : kExpandedAndInvalidThroughputFixtures)
    {
        state.Require(SelfTest::WriteTextFile(settingsPath, fixture), L"Failed to write an expanded/default-throughput settings fixture.");
        Common::Settings::Settings expandedThroughput{};
        const HRESULT expandedLoadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, expandedThroughput);
        state.Require(expandedLoadHr == S_OK && expandedThroughput.fileOperations.has_value(),
                      L"Expanded/default-throughput settings should load without recovery.");
        state.Require(expandedThroughput.fileOperations.has_value() && expandedThroughput.fileOperations->popupThroughputExpanded,
                      L"Absent, explicit true, and invalid-type throughput preferences should use expanded=true.");
        state.Require(! SettingsSave::PrepareForSave(expandedThroughput).fileOperations.has_value(),
                      L"Expanded=true should remain the omitted canonical default when it is the only file-operations value.");
    }

    using FileOperationsSettings = Common::Settings::FileOperationsSettings;
    struct FieldCase final
    {
        std::wstring_view name;
        void (*mutate)(FileOperationsSettings&) noexcept;
        bool (*matches)(const FileOperationsSettings&) noexcept;
    };

    const std::array fieldCases{
        FieldCase{L"autoDismissSuccess",
                  [](FileOperationsSettings& value) noexcept { value.autoDismissSuccess = true; },
                  [](const FileOperationsSettings& value) noexcept { return value.autoDismissSuccess; }},
        FieldCase{L"popupFooterOnly",
                  [](FileOperationsSettings& value) noexcept { value.popupFooterOnly = true; },
                  [](const FileOperationsSettings& value) noexcept { return value.popupFooterOnly; }},
        FieldCase{L"popupCompactDensity",
                  [](FileOperationsSettings& value) noexcept { value.popupCompactDensity = true; },
                  [](const FileOperationsSettings& value) noexcept { return value.popupCompactDensity; }},
        FieldCase{L"popupThroughputExpanded",
                  [](FileOperationsSettings& value) noexcept { value.popupThroughputExpanded = false; },
                  [](const FileOperationsSettings& value) noexcept { return ! value.popupThroughputExpanded; }},
        FieldCase{L"verifyAfterCopy",
                  [](FileOperationsSettings& value) noexcept { value.verifyAfterCopy = true; },
                  [](const FileOperationsSettings& value) noexcept { return value.verifyAfterCopy; }},
        FieldCase{L"crossFsBridgeBufferSizeKB",
                  [](FileOperationsSettings& value) noexcept { value.crossFsBridgeBufferSizeKB = 8192u; },
                  [](const FileOperationsSettings& value) noexcept { return value.crossFsBridgeBufferSizeKB == 8192u; }},
        FieldCase{L"defaultBandwidthLimitBytesPerSecond",
                  [](FileOperationsSettings& value) noexcept { value.defaultBandwidthLimitBytesPerSecond = 3ull * 1024ull * 1024ull; },
                  [](const FileOperationsSettings& value) noexcept { return value.defaultBandwidthLimitBytesPerSecond == 3ull * 1024ull * 1024ull; }},
        FieldCase{L"maxDiagnosticsLogFiles",
                  [](FileOperationsSettings& value) noexcept { value.maxDiagnosticsLogFiles = 21u; },
                  [](const FileOperationsSettings& value) noexcept { return value.maxDiagnosticsLogFiles == 21u; }},
        FieldCase{L"diagnosticsInfoEnabled",
                  [](FileOperationsSettings& value) noexcept { value.diagnosticsInfoEnabled = ! value.diagnosticsInfoEnabled; },
                  [](const FileOperationsSettings& value) noexcept { return value.diagnosticsInfoEnabled != FileOperationsSettings{}.diagnosticsInfoEnabled; }},
        FieldCase{L"diagnosticsDebugEnabled",
                  [](FileOperationsSettings& value) noexcept { value.diagnosticsDebugEnabled = ! value.diagnosticsDebugEnabled; },
                  [](const FileOperationsSettings& value) noexcept
    { return value.diagnosticsDebugEnabled != FileOperationsSettings{}.diagnosticsDebugEnabled; }},
        FieldCase{L"maxIssueReportFiles",
                  [](FileOperationsSettings& value) noexcept { value.maxIssueReportFiles = 9u; },
                  [](const FileOperationsSettings& value) noexcept { return value.maxIssueReportFiles == 9u; }},
        FieldCase{L"maxDiagnosticsInMemory",
                  [](FileOperationsSettings& value) noexcept { value.maxDiagnosticsInMemory = 257u; },
                  [](const FileOperationsSettings& value) noexcept { return value.maxDiagnosticsInMemory == 257u; }},
        FieldCase{L"maxDiagnosticsPerFlush",
                  [](FileOperationsSettings& value) noexcept { value.maxDiagnosticsPerFlush = 33u; },
                  [](const FileOperationsSettings& value) noexcept { return value.maxDiagnosticsPerFlush == 33u; }},
        FieldCase{L"diagnosticsFlushIntervalMs",
                  [](FileOperationsSettings& value) noexcept { value.diagnosticsFlushIntervalMs = 1750u; },
                  [](const FileOperationsSettings& value) noexcept { return value.diagnosticsFlushIntervalMs == 1750u; }},
        FieldCase{L"diagnosticsCleanupIntervalMs",
                  [](FileOperationsSettings& value) noexcept { value.diagnosticsCleanupIntervalMs = 2750u; },
                  [](const FileOperationsSettings& value) noexcept { return value.diagnosticsCleanupIntervalMs == 2750u; }},
        FieldCase{L"issuesPaneSortColumnId",
                  [](FileOperationsSettings& value) noexcept { value.issuesPaneSortColumnId = L"status"; },
                  [](const FileOperationsSettings& value) noexcept { return value.issuesPaneSortColumnId == L"status"; }},
        FieldCase{L"issuesPaneSortDescending",
                  [](FileOperationsSettings& value) noexcept { value.issuesPaneSortDescending = true; },
                  [](const FileOperationsSettings& value) noexcept { return value.issuesPaneSortDescending && value.issuesPaneSortColumnId.empty(); }},
        FieldCase{L"issuesPaneGridLayout",
                  [](FileOperationsSettings& value) noexcept
    { value.issuesPaneGridLayout.push_back(Common::Settings::GridColumnLayoutEntry{.columnId = L"status", .displayIndex = 2u, .widthDip = 144.0f}); },
                  [](const FileOperationsSettings& value) noexcept
    {
        return value.issuesPaneGridLayout.size() == 1u && value.issuesPaneGridLayout.front().columnId == L"status" &&
               value.issuesPaneGridLayout.front().displayIndex == 2u && std::abs(value.issuesPaneGridLayout.front().widthDip - 144.0f) < 0.01f;
    }},
    };

    for (const FieldCase& fieldCase : fieldCases)
    {
        CleanupSettingsArtifacts(kTestAppId);

        Common::Settings::Settings settings{};
        FileOperationsSettings fileOperations{};
        fieldCase.mutate(fileOperations);
        settings.fileOperations = fileOperations;

        const Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
        state.Require(prepared.fileOperations.has_value(),
                      std::format(L"{}-only file-operations settings should survive canonical save preparation.", fieldCase.name));
        if (! prepared.fileOperations.has_value())
        {
            continue;
        }

        const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, prepared);
        state.Require(SUCCEEDED(saveHr), std::format(L"Failed to save {}-only file-operations settings.", fieldCase.name));
        if (FAILED(saveHr))
        {
            continue;
        }

        Common::Settings::Settings loaded{};
        const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
        state.Require(loadHr == S_OK, std::format(L"Failed to load {}-only file-operations settings.", fieldCase.name));
        state.Require(loaded.fileOperations.has_value(), std::format(L"{}-only file-operations settings block was pruned during round-trip.", fieldCase.name));
        if (loadHr != S_OK || ! loaded.fileOperations.has_value())
        {
            continue;
        }

        state.Require(fieldCase.matches(loaded.fileOperations.value()), std::format(L"{}-only file-operations value did not round-trip.", fieldCase.name));
    }
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreUiCustomizationRoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestUiCustomizationRoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings defaultSettings{};
    defaultSettings.ui                                = Common::Settings::UiSettings{};
    const Common::Settings::Settings preparedDefaults = SettingsSave::PrepareForSave(defaultSettings);
    state.Require(! preparedDefaults.ui.has_value(), L"Canonical save path should omit default DxUI customization settings.");

    Common::Settings::Settings settings{};
    settings.ui = Common::Settings::UiSettings{
        .compactMode    = false,
        .reducedMotion  = Common::Settings::ReducedMotionMode::Off,
        .windowBackdrop = Common::Settings::WindowBackdropMode::MicaAlt,
    };

    const Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
    state.Require(prepared.ui.has_value(), L"DxUI customization settings should survive canonical save preparation when non-default.");
    if (! prepared.ui.has_value())
    {
        return false;
    }

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, prepared);
    state.Require(SUCCEEDED(saveHr), L"Failed to save DxUI customization round-trip settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Failed to load DxUI customization round-trip settings.");
    state.Require(loaded.ui.has_value(), L"DxUI customization settings block missing after round-trip.");
    if (FAILED(loadHr) || ! loaded.ui.has_value())
    {
        return false;
    }

    const Common::Settings::UiSettings& actual = loaded.ui.value();
    state.Require(actual.compactMode == settings.ui->compactMode, L"compactMode did not round-trip.");
    state.Require(actual.reducedMotion == settings.ui->reducedMotion, L"reducedMotion did not round-trip.");
    state.Require(actual.windowBackdrop == settings.ui->windowBackdrop, L"windowBackdrop did not round-trip.");
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreUiDefaultsUseCompactMode(CaseState& state) noexcept
{
    Common::Settings::Settings missingUi{};
    const Common::Settings::Settings preparedMissing = SettingsSave::PrepareForSave(missingUi);
    state.Require(! preparedMissing.ui.has_value(), L"Canonical save path should keep missing UI settings omitted.");

    const Common::Settings::UiSettings defaults{};
    state.Require(defaults.compactMode, L"Missing ui.compactMode should default to compact mode.");

    AppTheme missingTheme{};
    SettingsHotReload::ApplyUiPreferencesToTheme(missingUi, missingTheme);
    state.Require(missingTheme.compactMode, L"Runtime theme should use compact density when ui.compactMode is missing.");

    Common::Settings::Settings explicitStandard{};
    explicitStandard.ui = Common::Settings::UiSettings{.compactMode = false};
    AppTheme standardTheme{};
    SettingsHotReload::ApplyUiPreferencesToTheme(explicitStandard, standardTheme);
    state.Require(! standardTheme.compactMode, L"Explicit ui.compactMode=false should opt runtime theme back into standard density.");

    Common::Settings::Settings explicitDefaults{};
    explicitDefaults.ui                               = defaults;
    const Common::Settings::Settings preparedExplicit = SettingsSave::PrepareForSave(explicitDefaults);
    state.Require(! preparedExplicit.ui.has_value(), L"Explicit default UI settings should be omitted by canonical save.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreMouseFocusFollowsPointerRoundTrip(CaseState& state) noexcept
{
    Common::Settings::Settings defaultSettings{};
    defaultSettings.mouse                             = Common::Settings::MouseSettings{};
    const Common::Settings::Settings preparedDefaults = SettingsSave::PrepareForSave(defaultSettings);
    state.Require(! preparedDefaults.mouse.has_value(), L"Canonical save path should omit default mouse focus settings.");

    struct ModeCase
    {
        std::wstring_view appId;
        Common::Settings::MouseSettings mouse;
    };
    constexpr std::array<ModeCase, 3> kModeCases{{
        {L"RedSalamanderSelfTestMouseFocusAlways", {.focusFollowsPointer = true}},
        {L"RedSalamanderSelfTestMouseFocusTerminalOpenOnly", {.focusFollowsPointerWhenTerminalOpen = true}},
        {L"RedSalamanderSelfTestMouseFocusBoth", {.focusFollowsPointer = true, .focusFollowsPointerWhenTerminalOpen = true}},
    }};

    for (const ModeCase& modeCase : kModeCases)
    {
        CleanupSettingsArtifacts(modeCase.appId);
        Common::Settings::Settings settings{};
        settings.mouse                            = modeCase.mouse;
        const Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
        state.Require(prepared.mouse.has_value(), L"Non-default mouse focus settings should survive canonical save preparation.");
        if (! prepared.mouse.has_value())
        {
            continue;
        }

        const HRESULT saveHr = Common::Settings::SaveSettings(modeCase.appId, prepared);
        state.Require(SUCCEEDED(saveHr), std::format(L"Failed to save mouse focus mode for '{}'.", modeCase.appId));
        if (FAILED(saveHr))
        {
            CleanupSettingsArtifacts(modeCase.appId);
            continue;
        }

        Common::Settings::Settings loaded{};
        const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(modeCase.appId, loaded);
        state.Require(loadHr == S_OK, std::format(L"Failed to load mouse focus mode for '{}'.", modeCase.appId));
        state.Require(loaded.mouse.has_value() && loaded.mouse.value() == modeCase.mouse,
                      std::format(L"Mouse focus settings did not round-trip for '{}'.", modeCase.appId));
        CleanupSettingsArtifacts(modeCase.appId);
    }

    constexpr Common::Settings::MouseSettings disabled{};
    constexpr Common::Settings::MouseSettings always{.focusFollowsPointer = true};
    constexpr Common::Settings::MouseSettings terminalDisplayedOnly{.focusFollowsPointerWhenTerminalOpen = true};
    constexpr Common::Settings::MouseSettings both{
        .focusFollowsPointer                 = true,
        .focusFollowsPointerWhenTerminalOpen = true,
    };
    state.Require(! Common::Settings::ShouldPaneFocusFollowPointer(disabled, false) && ! Common::Settings::ShouldPaneFocusFollowPointer(disabled, true),
                  L"Disabled mouse focus settings must never follow the pointer.");
    state.Require(Common::Settings::ShouldPaneFocusFollowPointer(always, false) && Common::Settings::ShouldPaneFocusFollowPointer(always, true),
                  L"Always mouse focus setting must not depend on terminal state.");
    state.Require(! Common::Settings::ShouldPaneFocusFollowPointer(terminalDisplayedOnly, false) &&
                      Common::Settings::ShouldPaneFocusFollowPointer(terminalDisplayedOnly, true),
                  L"Terminal mouse focus setting must follow the pointer exactly while a Terminal tab is displayed.");
    state.Require(Common::Settings::ShouldPaneFocusFollowPointer(both, false) && Common::Settings::ShouldPaneFocusFollowPointer(both, true),
                  L"Enabling both independent mouse focus settings must preserve the always-on behavior.");
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreRejectsMalformedShortcutSection(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestShortcutInvalid";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);
    state.Require(! settingsPath.empty(), L"Malformed-shortcuts test settings path unavailable.");
    if (settingsPath.empty())
    {
        return false;
    }

    constexpr std::string_view kMalformedSettings = R"json({
  "schemaVersion": 16,
  "shortcuts": {
    "functionBar": [
      { "vk": "F3", "ctrl": "true", "commandId": "cmd/pane/view" }
    ],
    "folderView": []
  }
})json";

    state.Require(SelfTest::WriteTextFile(settingsPath, kMalformedSettings), L"Failed to write malformed shortcut settings file.");

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Malformed shortcut settings should recover only that section in TryLoadSettingsNoRecovery.");
    state.Require(! loaded.shortcuts.has_value(), L"Malformed shortcut recovery should restore the section default.");
    state.Require(! loaded.persistence.opaqueTopLevelMembers.empty() && loaded.persistence.opaqueTopLevelMembers[0].first == "shortcuts",
                  L"Malformed shortcut JSON should remain available for repair.");
    state.Require(SelfTest::PathExists(settingsPath), L"Malformed no-recovery load should keep the original settings file in place.");
    state.Require(FindSettingsBackupArtifact(kTestAppId).empty(), L"Malformed no-recovery load should not create a .bad backup file.");
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsHotReloadSelfSaveSuppression(HWND mainWindow, CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestHotReloadSelfSave";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&]
    {
        SettingsHotReload::DebugSetSettingsSavePostWriteDelayForSelfTest(0u);
        SettingsHotReload::DebugSetSettingsReloadPostStampDelayForSelfTest(0u);
        SettingsHotReload::Stop();
        RestoreMainSettingsHotReload(mainWindow, state);
        CleanupSettingsArtifacts(kTestAppId);
    });

    Common::Settings::Settings baseline{};
    baseline.theme.currentThemeId = L"builtin/light";
    const HRESULT seedHr          = Common::Settings::SaveSettings(kTestAppId, baseline);
    state.Require(SUCCEEDED(seedHr), L"Failed to seed hot-reload self-save test settings.");
    if (FAILED(seedHr))
    {
        return false;
    }

    SettingsHotReloadTestWindowState windowState{};
    HWND hwnd = CreateSettingsHotReloadTestWindow(windowState);
    state.Require(hwnd != nullptr && IsWindow(hwnd) != FALSE, L"Failed to create hot-reload self-test window.");
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }
    const auto destroyWindow = wil::scope_exit([&]
    {
        if (hwnd && IsWindow(hwnd))
        {
            DestroyWindow(hwnd);
        }
    });

    const HRESULT startHr = SettingsHotReload::Start(hwnd, kTestAppId);
    state.Require(SUCCEEDED(startHr), L"Failed to start settings hot-reload watcher for self-save suppression test.");
    if (FAILED(startHr))
    {
        return false;
    }

    Common::Settings::Settings selfSaved = baseline;
    selfSaved.theme.currentThemeId       = L"builtin/dark";

    const uint32_t beforeSelfSave = windowState.changeCount.load(std::memory_order_acquire);
    const HRESULT selfSaveHr      = SettingsHotReload::SaveSettingsAndSchema(kTestAppId, selfSaved);
    state.Require(SUCCEEDED(selfSaveHr), L"Failed to save settings through SettingsHotReload::SaveSettingsAndSchema.");
    state.Require(WaitForAtomicAtLeast(windowState.changeCount, beforeSelfSave + 1u, SelfTest::Scale(std::chrono::milliseconds{3000})),
                  L"Watcher did not observe the self-save settings write.");

    const SettingsHotReload::ChangedSettingsLoadResult suppressed = SettingsHotReload::TryLoadChangedSettings();
    state.Require(suppressed.status == SettingsHotReload::ChangedSettingsStatus::NoChange,
                  L"Self-save should be suppressed by the applied-stamp de-duplication path.");
    state.Require(suppressed.stamp.has_value(), L"Suppressed self-save result should still return the observed stamp.");

    Common::Settings::Settings racedSelfSave = selfSaved;
    racedSelfSave.theme.currentThemeId       = L"builtin/highContrast";
    SettingsHotReload::DebugSetSettingsSavePostWriteDelayForSelfTest(1500u);
    state.Require(SUCCEEDED(SettingsHotReload::QueueSettingsSave(kTestAppId, racedSelfSave, L"", L"self-save-race")),
                  L"Failed to queue the asynchronous self-save race fixture.");

    bool racedWriteVisible        = false;
    const auto racedWriteDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(std::chrono::milliseconds{3000});
    while (std::chrono::steady_clock::now() < racedWriteDeadline)
    {
        Common::Settings::Settings disk{};
        if (Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, disk) == S_OK && disk.theme.currentThemeId == racedSelfSave.theme.currentThemeId)
        {
            racedWriteVisible = true;
            break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds{5});
    }
    state.Require(racedWriteVisible, L"Asynchronous self-save did not reach disk during the forced write-before-stamp race window.");

    const SettingsHotReload::ChangedSettingsLoadResult inFlightSuppressed = SettingsHotReload::TryLoadChangedSettings();
    state.Require(inFlightSuppressed.status == SettingsHotReload::ChangedSettingsStatus::NoChange,
                  L"The exact stamp of an in-flight self-save should suppress only that atomic replacement.");

    Common::Settings::Settings externalDuringSelfSave{};
    state.Require(Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, externalDuringSelfSave) == S_OK,
                  L"Failed to load the current revision for the external replacement race.");
    externalDuringSelfSave.theme.currentThemeId = L"builtin/rainbow";
    const uint32_t beforeExternalRaceSave       = windowState.changeCount.load(std::memory_order_acquire);
    const HRESULT externalRaceSaveHr            = Common::Settings::SaveSettings(kTestAppId, externalDuringSelfSave);
    state.Require(SUCCEEDED(externalRaceSaveHr), L"Failed to replace settings externally during the forced post-write window.");
    state.Require(WaitForAtomicAtLeast(windowState.changeCount, beforeExternalRaceSave + 1u, SelfTest::Scale(std::chrono::milliseconds{3000})),
                  L"Watcher did not observe the external replacement during the self-save post-write window.");

    const SettingsHotReload::ChangedSettingsLoadResult externalRaceLoaded = SettingsHotReload::TryLoadChangedSettings();
    state.Require(externalRaceLoaded.status == SettingsHotReload::ChangedSettingsStatus::Loaded,
                  L"An external replacement after the app's exact atomic write must not be mislabeled as that self-write.");
    state.Require(externalRaceLoaded.settings.theme.currentThemeId == L"builtin/rainbow",
                  L"Hot reload did not preserve the external replacement made during the self-save post-write window.");
    if (externalRaceLoaded.stamp.has_value())
    {
        SettingsHotReload::MarkAppliedStamp(externalRaceLoaded.stamp.value());
    }

    SettingsHotReload::DebugSetSettingsSavePostWriteDelayForSelfTest(0u);
    state.Require(SettingsHotReload::FlushQueuedSettingsSaves(static_cast<DWORD>(SelfTest::ScaleTimeout(5000u))),
                  L"Asynchronous self-save race fixture did not finish after releasing the post-write delay.");

    const SettingsHotReload::ChangedSettingsLoadResult deferredSuppressed = SettingsHotReload::TryLoadChangedSettings();
    state.Require(deferredSuppressed.status == SettingsHotReload::ChangedSettingsStatus::NoChange,
                  L"Schema-directory notifications should resolve against the already-applied external settings stamp.");

    Common::Settings::Settings externalBeforeFailedSave = externalDuringSelfSave;
    externalBeforeFailedSave.theme.currentThemeId       = L"builtin/light";
    const uint32_t beforeEpochRaceSave                  = windowState.changeCount.load(std::memory_order_acquire);
    state.Require(SUCCEEDED(Common::Settings::SaveSettings(kTestAppId, externalBeforeFailedSave)),
                  L"Failed to seed the external settings replacement for epoch-retry coverage.");
    state.Require(WaitForAtomicAtLeast(windowState.changeCount, beforeEpochRaceSave + 1u, SelfTest::Scale(std::chrono::milliseconds{3000})),
                  L"Watcher did not observe the external replacement for epoch-retry coverage.");

    SettingsHotReload::ChangedSettingsLoadResult epochRaceLoaded{};
    SettingsHotReload::DebugSetSettingsReloadPostStampDelayForSelfTest(500u);
    std::jthread epochRaceLoader([&]() noexcept { epochRaceLoaded = SettingsHotReload::TryLoadChangedSettings(); });
    const auto reloadDelayDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(std::chrono::milliseconds{3000});
    while (std::chrono::steady_clock::now() < reloadDelayDeadline && ! SettingsHotReload::DebugIsSettingsReloadPostStampDelayActiveForSelfTest())
    {
        std::this_thread::sleep_for(std::chrono::milliseconds{5});
    }
    const bool reloadDelayEntered = SettingsHotReload::DebugIsSettingsReloadPostStampDelayActiveForSelfTest();
    state.Require(reloadDelayEntered, L"Changed-settings load did not enter the deterministic post-stamp epoch race window.");

    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);
    wil::unique_hfile blockedTarget(
        CreateFileW(settingsPath.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr));
    state.Require(static_cast<bool>(blockedTarget), L"Failed to deny replacement of the settings target for failed-save epoch coverage.");
    if (reloadDelayEntered && blockedTarget)
    {
        Common::Settings::Settings failedInternalSave = externalBeforeFailedSave;
        failedInternalSave.theme.currentThemeId       = L"builtin/dark";
        const HRESULT failedSaveHr                    = SettingsHotReload::SaveSettingsAndSchema(kTestAppId, failedInternalSave);
        state.Require(FAILED(failedSaveHr), L"The replacement-denied target fixture should force the internal settings save to fail.");
    }
    blockedTarget.reset();
    SettingsHotReload::DebugSetSettingsReloadPostStampDelayForSelfTest(0u);
    epochRaceLoader.join();

    state.Require(epochRaceLoaded.status == SettingsHotReload::ChangedSettingsStatus::Loaded,
                  L"An internal save epoch that begins and fails between reload checks must trigger a retry, not swallow the external notification.");
    state.Require(epochRaceLoaded.settings.theme.currentThemeId == L"builtin/light",
                  L"Epoch retry did not load the external settings that survived the failed internal save.");

    return state.failure.empty();
}

constexpr wchar_t kSettingsSaveTeardownChildEnv[]     = L"REDSALAMANDER_SETTINGS_SAVE_TEARDOWN_CHILD";
constexpr wchar_t kSettingsSaveTeardownChildRootEnv[] = L"REDSALAMANDER_SELFTEST_ROOT";
constexpr wchar_t kSettingsSaveTeardownTestRootEnv[]  = L"REDSALAMANDER_TEST_ROOT";
constexpr wchar_t kSettingsSaveTeardownTestRunIdEnv[] = L"REDSALAMANDER_TEST_RUN_ID";

enum class SettingsSaveChildMode : uint8_t
{
    None,
    FinalSaveOrdering,
    BoundedTeardown,
    SessionEnd,
};

[[nodiscard]] SettingsSaveChildMode GetSettingsSaveChildMode() noexcept
{
    std::array<wchar_t, 32> value{};
    const DWORD length = GetEnvironmentVariableW(kSettingsSaveTeardownChildEnv, value.data(), static_cast<DWORD>(value.size()));
    if (length == 8u && std::wstring_view(value.data(), length) == L"ordering")
    {
        return SettingsSaveChildMode::FinalSaveOrdering;
    }
    if (length == 8u && std::wstring_view(value.data(), length) == L"teardown")
    {
        return SettingsSaveChildMode::BoundedTeardown;
    }
    if (length == 10u && std::wstring_view(value.data(), length) == L"sessionend")
    {
        return SettingsSaveChildMode::SessionEnd;
    }
    return SettingsSaveChildMode::None;
}

[[nodiscard]] bool RunSettingsFinalSaveOrderingChild(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestSettingsFinalSaveOrderingChild";
    static_cast<void>(SettingsHotReload::FlushQueuedSettingsSaves(INFINITE));
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&]() noexcept { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings firstFinal{};
    firstFinal.theme.currentThemeId                           = L"builtin/highContrast";
    const SettingsHotReload::SettingsSaveDebugSnapshot before = SettingsHotReload::DebugGetSettingsSaveSnapshotForSelfTest();

    SettingsHotReload::BeginProcessShutdown();

    HRESULT concurrentNormalHr = E_PENDING;
    std::jthread concurrentNormal([&]() noexcept
    { concurrentNormalHr = SettingsHotReload::QueueSettingsSave(kTestAppId, firstFinal, L"", L"after-shutdown-fence"); });
    concurrentNormal.join();
    state.Require(concurrentNormalHr == HRESULT_FROM_WIN32(ERROR_SHUTDOWN_IN_PROGRESS),
                  L"A normal submitter must not cross the serialized process-shutdown fence.");

    const HRESULT firstFinalHr = SettingsHotReload::SaveSettingsAndSchemaForProcessShutdown(kTestAppId, firstFinal, 5000u);
    state.Require(SUCCEEDED(firstFinalHr), L"BeginProcessShutdown followed by the final settings save should succeed.");

    Common::Settings::Settings duplicateFinal = firstFinal;
    duplicateFinal.theme.currentThemeId       = L"builtin/rainbow";
    const HRESULT duplicateFinalHr            = SettingsHotReload::SaveSettingsAndSchemaForProcessShutdown(kTestAppId, duplicateFinal, 5000u);
    state.Require(SUCCEEDED(duplicateFinalHr), L"Duplicate process-final settings persistence should be idempotent.");

    const SettingsHotReload::SettingsSaveDebugSnapshot after = SettingsHotReload::DebugGetSettingsSaveSnapshotForSelfTest();
    state.Require(after.queuedGeneration == before.queuedGeneration + 1u, L"Process finalization should admit exactly one settings snapshot.");
    state.Require(SettingsHotReload::SaveSettingsAndSchema(kTestAppId, duplicateFinal) == HRESULT_FROM_WIN32(ERROR_SHUTDOWN_IN_PROGRESS),
                  L"Normal synchronous persistence should remain rejected after process finalization.");

    Common::Settings::Settings loaded{};
    state.Require(Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded) == S_OK, L"The process-final settings snapshot should be readable.");
    state.Require(loaded.theme.currentThemeId == firstFinal.theme.currentThemeId, L"Duplicate finalization must preserve the first admitted final snapshot.");
    return state.failure.empty();
}

[[nodiscard]] bool RunSettingsSaveTeardownChild(CaseState& state) noexcept
{
    using namespace std::chrono_literals;
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestSettingsSaveTeardownChild";

    static_cast<void>(SettingsHotReload::FlushQueuedSettingsSaves(INFINITE));
    CleanupSettingsArtifacts(kTestAppId);

    Common::Settings::Settings settings{};
    settings.theme.currentThemeId = L"builtin/dark";
    // Keep the injected storage stall far beyond any supported self-test timeout multiplier so the
    // old static-destructor join cannot accidentally finish inside the parent's deadline.
    SettingsHotReload::DebugSetSettingsSaveDelayForSelfTest(300'000u);
    state.Require(SUCCEEDED(SettingsHotReload::QueueSettingsSave(kTestAppId, settings, L"", L"bounded-process-teardown-child")),
                  L"Failed to queue the deliberately stalled child-process settings save.");

    const auto startedDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(3000ms);
    while (std::chrono::steady_clock::now() < startedDeadline && ! SettingsHotReload::DebugGetSettingsSaveSnapshotForSelfTest().saveInProgress)
    {
        std::this_thread::sleep_for(5ms);
    }
    state.Require(SettingsHotReload::DebugGetSettingsSaveSnapshotForSelfTest().saveInProgress,
                  L"Child-process settings save did not enter the deliberately stalled storage phase.");

    Common::Settings::Settings finalSettings = settings;
    finalSettings.theme.currentThemeId       = L"builtin/highContrast";
    const auto finalSaveStarted              = std::chrono::steady_clock::now();
    const HRESULT finalSaveHr                = SettingsHotReload::SaveSettingsAndSchemaForProcessShutdown(kTestAppId, finalSettings, 25u);
    const auto finalSaveElapsed              = std::chrono::steady_clock::now() - finalSaveStarted;
    state.Require(finalSaveHr == HRESULT_FROM_WIN32(ERROR_TIMEOUT),
                  L"The production final-save path should return ERROR_TIMEOUT behind a stalled earlier request.");
    state.Require(finalSaveElapsed < SelfTest::Scale(250ms), L"The production final-save path exceeded its caller-supplied shutdown deadline.");

    // Do not clear the delay or flush here. Returning with a live save is the regression setup:
    // process teardown must leave both requests worker-owned instead of joining this worker.
    return state.failure.empty();
}

[[nodiscard]] bool RunSettingsSessionEndChild(const HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;
    constexpr std::wstring_view kTestAppId     = L"RedSalamander";
    constexpr std::string_view kSchemaSentinel = "session-end-schema-sentinel";

    state.Require(mainWindow != nullptr && IsWindow(mainWindow) != FALSE, L"The real WM_ENDSESSION regression requires the child main window.");
    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        return false;
    }

    static_cast<void>(SettingsHotReload::FlushQueuedSettingsSaves(INFINITE));
    CleanupSettingsArtifacts(kTestAppId);

    const std::filesystem::path schemaPath = Common::Settings::GetSettingsSchemaPath(kTestAppId);
    state.Require(! schemaPath.empty(), L"Session-end regression schema path is unavailable.");
    state.Require(SelfTest::WriteTextFile(schemaPath, kSchemaSentinel), L"Failed to seed the session-end schema sentinel.");
    if (! state.failure.empty())
    {
        return false;
    }

    Common::Settings::Settings olderInFlight{};
    olderInFlight.theme.currentThemeId = L"builtin/dark";
    const DWORD delayMs                = static_cast<DWORD>(SelfTest::Scale(500ms).count());
    SettingsHotReload::DebugSetSettingsSaveDelayForSelfTest(delayMs);
    state.Require(SUCCEEDED(SettingsHotReload::QueueSettingsSave(kTestAppId, olderInFlight, L"", L"session-end-older-in-flight")),
                  L"Failed to queue the deliberately stalled older settings snapshot.");

    const auto startDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(3000ms);
    while (std::chrono::steady_clock::now() < startDeadline && ! SettingsHotReload::DebugGetSettingsSaveSnapshotForSelfTest().saveInProgress)
    {
        std::this_thread::sleep_for(5ms);
    }
    state.Require(SettingsHotReload::DebugGetSettingsSaveSnapshotForSelfTest().saveInProgress,
                  L"Older settings snapshot did not enter the deterministic storage stall.");
    if (! state.failure.empty())
    {
        return false;
    }

    SettingsHotReload::DebugSetSettingsSaveDelayForSelfTest(0u);
    Common::Settings::Settings olderQueued = olderInFlight;
    olderQueued.theme.currentThemeId       = L"builtin/light";
    state.Require(SUCCEEDED(SettingsHotReload::QueueSettingsSave(kTestAppId, olderQueued, L"", L"session-end-older-queued")),
                  L"Failed to queue the older snapshot behind the stalled save.");

    // This child deliberately leaves the writer seam unset: WM_ENDSESSION must use the real
    // coordinator path because its shutdown fence is intentionally process-lifetime.
    DebugResetSessionEndSettingsSaveForSelfTest();
    g_settings.theme.currentThemeId = L"builtin/highContrast";
    SendMessageW(mainWindow, WM_ENDSESSION, TRUE, ENDSESSION_CLOSEAPP);

    const SessionEndSettingsDebugSnapshot sessionEnd = DebugGetSessionEndSettingsSnapshotForSelfTest();
    const uint64_t maxDurationUs = static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::microseconds>(SelfTest::Scale(5000ms)).count());
    state.Require(sessionEnd.writerCallCount == 1u, L"Real WM_ENDSESSION should submit exactly one final settings snapshot.");
    state.Require(sessionEnd.normalTeardownCallCount == 0u, L"WM_ENDSESSION must not enter normal teardown.");
    state.Require(SUCCEEDED(sessionEnd.lastResult), L"The bounded session-end coordinator save should complete successfully.");
    state.Require(sessionEnd.durationUs < maxDurationUs, L"The session-end coordinator save exceeded its documented five-second deadline.");

    Common::Settings::Settings persisted{};
    state.Require(Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, persisted) == S_OK,
                  L"Failed to read the real session-end settings snapshot from disk.");
    state.Require(persisted.theme.currentThemeId == L"builtin/highContrast",
                  L"The session-end snapshot must win over both older serialized settings snapshots.");
    state.Require(ReadAuditTextFile(schemaPath) == kSchemaSentinel, L"The settings-only session-end request must leave the schema sidecar unchanged.");

    Common::Settings::Settings laterSubmission = persisted;
    laterSubmission.theme.currentThemeId       = L"builtin/rainbow";
    state.Require(SettingsHotReload::QueueSettingsSave(kTestAppId, laterSubmission, L"", L"after-session-end") ==
                      HRESULT_FROM_WIN32(ERROR_SHUTDOWN_IN_PROGRESS),
                  L"The session-end final-save fence must reject later asynchronous submissions.");
    state.Require(SettingsHotReload::SaveSettingsAndSchema(kTestAppId, laterSubmission) == HRESULT_FROM_WIN32(ERROR_SHUTDOWN_IN_PROGRESS),
                  L"The session-end final-save fence must reject later synchronous submissions.");

    const std::wstring artifactText          = std::format(L"{{\n"
                                                           L"  \"scenario\": \"app/windows-session-end-settings-save-real\",\n"
                                                           L"  \"App.Shutdown.SessionEndSettingsSave_us\": {},\n"
                                                           L"  \"writer_call_count\": {},\n"
                                                           L"  \"result_hr\": {}\n"
                                                           L"}}\n",
                                                           sessionEnd.durationUs,
                                                           sessionEnd.writerCallCount,
                                                           static_cast<uint32_t>(sessionEnd.lastResult));
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"session_end_settings_real_metrics.json");
    state.Require(! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, artifactText),
                  L"Failed to record the real session-end coordinator metric artifact.");
    return state.failure.empty();
}

[[nodiscard]] bool RequireSettingsSaveChild(CaseState& state, std::wstring_view childMode) noexcept
{
    std::array<wchar_t, 32768> modulePath{};
    const DWORD modulePathLength = GetModuleFileNameW(nullptr, modulePath.data(), static_cast<DWORD>(modulePath.size()));
    state.Require(modulePathLength > 0u && modulePathLength < modulePath.size(),
                  L"Could not resolve the current executable for settings-save teardown validation.");
    if (modulePathLength == 0u || modulePathLength >= modulePath.size())
    {
        return false;
    }

    const DWORD previousLength = GetEnvironmentVariableW(kSettingsSaveTeardownChildEnv, nullptr, 0u);
    std::wstring previousValue;
    if (previousLength > 0u)
    {
        previousValue.resize(previousLength);
        const DWORD copied = GetEnvironmentVariableW(kSettingsSaveTeardownChildEnv, previousValue.data(), previousLength);
        if (copied == 0u || copied >= previousLength)
        {
            previousValue.clear();
        }
        else
        {
            previousValue.resize(copied);
        }
    }
    const bool hadPreviousValue   = ! previousValue.empty();
    const auto restoreEnvironment = wil::scope_exit([&]() noexcept
    { static_cast<void>(SetEnvironmentVariableW(kSettingsSaveTeardownChildEnv, hadPreviousValue ? previousValue.c_str() : nullptr)); });
    const std::wstring childModeText(childMode);
    state.Require(SetEnvironmentVariableW(kSettingsSaveTeardownChildEnv, childModeText.c_str()) != FALSE,
                  L"Failed to configure the settings-save child process.");
    if (! state.failure.empty())
    {
        return false;
    }

    const DWORD previousTestRootLength = GetEnvironmentVariableW(kSettingsSaveTeardownTestRootEnv, nullptr, 0u);
    std::wstring previousTestRootValue;
    if (previousTestRootLength > 0u)
    {
        previousTestRootValue.resize(previousTestRootLength);
        const DWORD copied = GetEnvironmentVariableW(kSettingsSaveTeardownTestRootEnv, previousTestRootValue.data(), previousTestRootLength);
        if (copied == 0u || copied >= previousTestRootLength)
        {
            previousTestRootValue.clear();
        }
        else
        {
            previousTestRootValue.resize(copied);
        }
    }
    const bool hadPreviousTestRootValue = ! previousTestRootValue.empty();

    const std::filesystem::path childSelfTestRoot = hadPreviousTestRootValue ? std::filesystem::path(previousTestRootValue) : std::filesystem::path{};
    state.Require(! childSelfTestRoot.empty(), L"Could not resolve the exact test root for the settings-save child process.");
    if (childSelfTestRoot.empty())
    {
        return false;
    }
    const std::wstring childTestRunId        = std::format(L"ss-{}-{}", GetCurrentProcessId(), GetTickCount64());
    const std::filesystem::path childRunRoot = childSelfTestRoot / L"runs" / childTestRunId;
    state.Require(SelfTest::EnsureDirectory(childRunRoot), L"Could not create the isolated settings-save teardown child run root.");
    if (! state.failure.empty())
    {
        return false;
    }
    const auto cleanupChildRoot = wil::scope_exit([&]() noexcept { static_cast<void>(SelfTest::RemoveAll(childRunRoot)); });

    const DWORD previousRootLength = GetEnvironmentVariableW(kSettingsSaveTeardownChildRootEnv, nullptr, 0u);
    std::wstring previousRootValue;
    if (previousRootLength > 0u)
    {
        previousRootValue.resize(previousRootLength);
        const DWORD copied = GetEnvironmentVariableW(kSettingsSaveTeardownChildRootEnv, previousRootValue.data(), previousRootLength);
        if (copied == 0u || copied >= previousRootLength)
        {
            previousRootValue.clear();
        }
        else
        {
            previousRootValue.resize(copied);
        }
    }
    const bool hadPreviousRootValue        = ! previousRootValue.empty();
    const auto restoreChildRootEnvironment = wil::scope_exit([&]() noexcept
    { static_cast<void>(SetEnvironmentVariableW(kSettingsSaveTeardownChildRootEnv, hadPreviousRootValue ? previousRootValue.c_str() : nullptr)); });
    state.Require(SetEnvironmentVariableW(kSettingsSaveTeardownChildRootEnv, childSelfTestRoot.c_str()) != FALSE,
                  L"Failed to isolate the settings-save teardown child self-test root.");
    if (! state.failure.empty())
    {
        return false;
    }

    const auto restoreTestRootEnvironment = wil::scope_exit([&]() noexcept
    { static_cast<void>(SetEnvironmentVariableW(kSettingsSaveTeardownTestRootEnv, hadPreviousTestRootValue ? previousTestRootValue.c_str() : nullptr)); });
    state.Require(SetEnvironmentVariableW(kSettingsSaveTeardownTestRootEnv, childSelfTestRoot.c_str()) != FALSE,
                  L"Failed to isolate the settings-save teardown child unified test root.");

    const DWORD previousTestRunIdLength = GetEnvironmentVariableW(kSettingsSaveTeardownTestRunIdEnv, nullptr, 0u);
    std::wstring previousTestRunIdValue;
    if (previousTestRunIdLength > 0u)
    {
        previousTestRunIdValue.resize(previousTestRunIdLength);
        const DWORD copied = GetEnvironmentVariableW(kSettingsSaveTeardownTestRunIdEnv, previousTestRunIdValue.data(), previousTestRunIdLength);
        if (copied == 0u || copied >= previousTestRunIdLength)
        {
            previousTestRunIdValue.clear();
        }
        else
        {
            previousTestRunIdValue.resize(copied);
        }
    }
    const bool hadPreviousTestRunIdValue   = ! previousTestRunIdValue.empty();
    const auto restoreTestRunIdEnvironment = wil::scope_exit([&]() noexcept
    { static_cast<void>(SetEnvironmentVariableW(kSettingsSaveTeardownTestRunIdEnv, hadPreviousTestRunIdValue ? previousTestRunIdValue.c_str() : nullptr)); });
    state.Require(SetEnvironmentVariableW(kSettingsSaveTeardownTestRunIdEnv, childTestRunId.c_str()) != FALSE,
                  L"Failed to isolate the settings-save teardown child unified test run.");
    if (! state.failure.empty())
    {
        return false;
    }
    const std::filesystem::path childSelfTestArtifactRoot = childSelfTestRoot / L"runs" / childTestRunId / L"artifacts" / L"selftest";

    const std::wstring executable(modulePath.data(), modulePathLength);
    std::wstring commandLine = std::format(
        L"\"{}\" --commands-selftest --selftest-timeout-multiplier=3 --selftest-case=settings_save_queue_serializes_coalesces_and_flushes", executable);

    STARTUPINFOW startupInfo{};
    startupInfo.cb          = sizeof(startupInfo);
    startupInfo.dwFlags     = STARTF_USESHOWWINDOW;
    startupInfo.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION processInfo{};
    const BOOL created = CreateProcessW(nullptr, commandLine.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &startupInfo, &processInfo);
    state.Require(created != FALSE, std::format(L"Failed to launch the settings-save teardown child process. error={}", GetLastError()));
    if (created == FALSE)
    {
        return false;
    }

    wil::unique_handle process(processInfo.hProcess);
    wil::unique_handle thread(processInfo.hThread);
    const auto terminateChild = wil::scope_exit([&]() noexcept
    {
        if (process && WaitForSingleObject(process.get(), 0u) == WAIT_TIMEOUT)
        {
            static_cast<void>(TerminateProcess(process.get(), ERROR_TIMEOUT));
            static_cast<void>(WaitForSingleObject(process.get(), 2000u));
        }
    });

    const DWORD waitResult = WaitForSingleObject(process.get(), static_cast<DWORD>(SelfTest::ScaleTimeout(12'000u)));
    state.Require(waitResult == WAIT_OBJECT_0,
                  waitResult == WAIT_TIMEOUT ? L"Settings-save child process exceeded its bounded deadline."
                                             : std::format(L"Waiting for the settings-save teardown child process failed. error={}", GetLastError()));
    if (waitResult != WAIT_OBJECT_0)
    {
        return false;
    }

    DWORD exitCode = ERROR_GEN_FAILURE;
    state.Require(GetExitCodeProcess(process.get(), &exitCode) != FALSE,
                  std::format(L"Could not read the settings-save teardown child exit code. error={}", GetLastError()));
    state.Require(exitCode == 0u, std::format(L"Settings-save teardown child process exited with code {}.", exitCode));
    if (childMode == L"sessionend" && exitCode == 0u)
    {
        const std::filesystem::path sourceMetricSummary      = childSelfTestArtifactRoot / L"last_run" / L"perf" / L"session_end_settings_real_metrics.json";
        const std::filesystem::path destinationMetricSummary = SelfTest::GetPerfArtifactPath(L"session_end_settings_real_metrics.json");
        std::error_code copyError;
        const bool copiedSummary =
            ! destinationMetricSummary.empty() &&
            std::filesystem::copy_file(sourceMetricSummary, destinationMetricSummary, std::filesystem::copy_options::overwrite_existing, copyError);
        state.Require(copiedSummary && ! copyError,
                      std::format(L"Failed to preserve the real session-end metric artifact from the child process. error={}", copyError.value()));

        const std::filesystem::path sourceMetricRows = childSelfTestArtifactRoot / L"last_run" / L"perf" / L"perf_metrics.jsonl";
        const std::string childMetricRows            = ReadAuditTextFile(sourceMetricRows);
        state.Require(childMetricRows.find("\"metric\":\"App.Shutdown.SessionEndSettingsSave\"") != std::string::npos,
                      L"The real session-end child process did not record App.Shutdown.SessionEndSettingsSave.");
        copyError.clear();
        const std::filesystem::path destinationMetricRows = SelfTest::GetPerfArtifactPath(L"session_end_settings_real_perf_metrics.jsonl");
        const bool copiedRows =
            ! destinationMetricRows.empty() &&
            std::filesystem::copy_file(sourceMetricRows, destinationMetricRows, std::filesystem::copy_options::overwrite_existing, copyError);
        state.Require(copiedRows && ! copyError,
                      std::format(L"Failed to preserve the real session-end metric rows from the child process. error={}", copyError.value()));
    }
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsSaveQueueSerializesCoalescesAndFlushes(const HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;
    switch (GetSettingsSaveChildMode())
    {
        case SettingsSaveChildMode::FinalSaveOrdering: return RunSettingsFinalSaveOrderingChild(state);
        case SettingsSaveChildMode::BoundedTeardown: return RunSettingsSaveTeardownChild(state);
        case SettingsSaveChildMode::SessionEnd: return RunSettingsSessionEndChild(mainWindow, state);
        case SettingsSaveChildMode::None: break;
    }

    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestSerializedSettingsSave";
    static_cast<void>(SettingsHotReload::FlushQueuedSettingsSaves(INFINITE));
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&]
    {
        SettingsHotReload::DebugSetSettingsSaveDelayForSelfTest(0u);
        static_cast<void>(SettingsHotReload::FlushQueuedSettingsSaves(INFINITE));
        CleanupSettingsArtifacts(kTestAppId);
    });

    const std::filesystem::path schemaPath = Common::Settings::GetSettingsSchemaPath(kTestAppId);
    state.Require(! schemaPath.empty(), L"Serialized settings-save test schema path unavailable.");
    state.Require(SelfTest::WriteTextFile(schemaPath, "schema-sentinel"), L"Failed to seed the serialized settings-save schema sentinel.");

    Common::Settings::Settings first{};
    first.theme.currentThemeId        = L"builtin/light";
    Common::Settings::Settings second = first;
    second.theme.currentThemeId       = L"builtin/dark";

    const DWORD uiThreadId                                    = GetCurrentThreadId();
    const SettingsHotReload::SettingsSaveDebugSnapshot before = SettingsHotReload::DebugGetSettingsSaveSnapshotForSelfTest();
    const auto enqueueStart                                   = std::chrono::steady_clock::now();
    const HRESULT firstQueueHr                                = SettingsHotReload::QueueSettingsSave(kTestAppId, first, L"", L"serialized-save-first");
    const HRESULT secondQueueHr                               = SettingsHotReload::QueueSettingsSave(kTestAppId, second, L"", L"serialized-save-second");
    const auto enqueueElapsed                                 = std::chrono::steady_clock::now() - enqueueStart;
    state.Require(SUCCEEDED(firstQueueHr) && SUCCEEDED(secondQueueHr), L"Failed to queue coalesced asynchronous settings saves.");
    state.Require(enqueueElapsed < SelfTest::Scale(250ms), L"Asynchronous settings enqueue should remain bounded and avoid caller-thread disk I/O.");

    const SettingsHotReload::SettingsSaveDebugSnapshot queued = SettingsHotReload::DebugGetSettingsSaveSnapshotForSelfTest();
    state.Require(queued.queuedGeneration >= before.queuedGeneration + 2u, L"Each asynchronous settings request should receive a monotonic generation.");
    state.Require(queued.coalescedCount > before.coalescedCount, L"Back-to-back settings snapshots for one app should coalesce.");
    state.Require(queued.lastQueueThreadId == uiThreadId, L"The immutable settings snapshots should be captured from the calling UI thread.");
    state.Require(SettingsHotReload::FlushQueuedSettingsSaves(static_cast<DWORD>(SelfTest::Scale(5000ms).count())),
                  L"Coalesced asynchronous settings saves did not flush within the bounded deadline.");

    Common::Settings::Settings loaded{};
    state.Require(SUCCEEDED(Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded)), L"Failed to load the coalesced asynchronous settings result.");
    state.Require(loaded.theme.currentThemeId == second.theme.currentThemeId,
                  L"Coalesced asynchronous settings persistence should keep the newest immutable snapshot.");
    state.Require(ReadAuditTextFile(schemaPath) == "schema-sentinel", L"Value-only asynchronous settings saves must not regenerate the aggregated schema.");

    Common::Settings::Settings queuedBeforeSync = second;
    queuedBeforeSync.theme.currentThemeId       = L"builtin/light";
    Common::Settings::Settings synchronousFinal = second;
    synchronousFinal.theme.currentThemeId       = L"builtin/rainbow";
    state.Require(SUCCEEDED(SettingsHotReload::QueueSettingsSave(kTestAppId, queuedBeforeSync, L"", L"serialized-before-sync")),
                  L"Failed to queue the pre-synchronous settings snapshot.");
    state.Require(SUCCEEDED(SettingsHotReload::SaveSettingsAndSchema(kTestAppId, synchronousFinal)),
                  L"Failed to perform the serialized synchronous settings save.");
    loaded = {};
    state.Require(SUCCEEDED(Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded)), L"Failed to load the serialized synchronous settings result.");
    state.Require(loaded.theme.currentThemeId == synchronousFinal.theme.currentThemeId,
                  L"A queued older snapshot must not overwrite a later synchronous settings save.");

    Common::Settings::Settings asynchronousAfterSync = synchronousFinal;
    asynchronousAfterSync.theme.currentThemeId       = L"builtin/light";
    state.Require(SUCCEEDED(SettingsHotReload::QueueSettingsSave(kTestAppId, asynchronousAfterSync, L"", L"serialized-after-sync")),
                  L"Failed to queue an asynchronous snapshot based on the last synchronous commit.");
    state.Require(SettingsHotReload::FlushQueuedSettingsSaves(static_cast<DWORD>(SelfTest::Scale(5000ms).count())),
                  L"The post-synchronous asynchronous settings snapshot did not flush within the bounded deadline.");
    synchronousFinal.theme.currentThemeId = L"builtin/rainbow";
    state.Require(SUCCEEDED(SettingsHotReload::SaveSettingsAndSchema(kTestAppId, synchronousFinal)),
                  L"A caller stamp returned by a synchronous save must remain valid after a serialized asynchronous save.");
    loaded = {};
    state.Require(SUCCEEDED(Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded)),
                  L"Failed to load the sync-async-sync serialized settings result.");
    state.Require(loaded.theme.currentThemeId == synchronousFinal.theme.currentThemeId,
                  L"The final synchronous snapshot must win after a serialized asynchronous save.");

    Common::Settings::Settings retainedOriginalSource = second;
    retainedOriginalSource.theme.currentThemeId       = L"builtin/highContrast";
    state.Require(SUCCEEDED(SettingsHotReload::SaveSettingsAndSchema(kTestAppId, retainedOriginalSource)),
                  L"An independently retained snapshot from the validated internal source lineage must remain serializable.");
    loaded = {};
    state.Require(SUCCEEDED(Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded)),
                  L"Failed to load the retained-source serialized settings result.");
    state.Require(loaded.theme.currentThemeId == retainedOriginalSource.theme.currentThemeId,
                  L"The retained-source synchronous snapshot must win after serialization.");

    Common::Settings::Settings shutdownFinal = retainedOriginalSource;
    shutdownFinal.theme.currentThemeId       = L"builtin/highContrast";
    state.Require(SUCCEEDED(SettingsHotReload::QueueSettingsSave(kTestAppId, shutdownFinal, L"", L"serialized-shutdown-flush")),
                  L"Failed to queue the shutdown-flush settings snapshot.");
    state.Require(SettingsHotReload::FlushQueuedSettingsSaves(static_cast<DWORD>(SelfTest::Scale(5000ms).count())),
                  L"Shutdown-style settings flush did not finish within the bounded deadline.");
    loaded = {};
    state.Require(SUCCEEDED(Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded)), L"Failed to load the shutdown-flushed settings result.");
    state.Require(loaded.theme.currentThemeId == shutdownFinal.theme.currentThemeId, L"Shutdown flush should persist the latest queued generation.");

    Common::Settings::Settings delayed = shutdownFinal;
    delayed.theme.currentThemeId       = L"builtin/light";
    const DWORD injectedDelayMs        = static_cast<DWORD>(SelfTest::Scale(250ms).count());
    SettingsHotReload::DebugSetSettingsSaveDelayForSelfTest(injectedDelayMs);
    state.Require(SUCCEEDED(SettingsHotReload::QueueSettingsSave(kTestAppId, delayed, L"", L"serialized-bounded-timeout")),
                  L"Failed to queue the delayed settings snapshot for bounded-flush validation.");
    const auto saveStartDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(3000ms);
    bool delayedSaveStarted      = false;
    while (std::chrono::steady_clock::now() < saveStartDeadline)
    {
        delayedSaveStarted = SettingsHotReload::DebugGetSettingsSaveSnapshotForSelfTest().saveInProgress;
        if (delayedSaveStarted)
        {
            break;
        }
        std::this_thread::sleep_for(5ms);
    }
    state.Require(delayedSaveStarted, L"Delayed settings save did not start for bounded-flush validation.");
    const auto boundedFlushStart   = std::chrono::steady_clock::now();
    const bool unexpectedlyFlushed = SettingsHotReload::FlushQueuedSettingsSaves(1u);
    const auto boundedFlushElapsed = std::chrono::steady_clock::now() - boundedFlushStart;
    state.Require(! unexpectedlyFlushed, L"A one-millisecond settings shutdown deadline should time out while storage is deliberately stalled.");
    state.Require(boundedFlushElapsed < SelfTest::Scale(250ms), L"Timed settings flush exceeded its caller-supplied bounded deadline.");
    SettingsHotReload::DebugSetSettingsSaveDelayForSelfTest(0u);
    state.Require(SettingsHotReload::FlushQueuedSettingsSaves(static_cast<DWORD>(SelfTest::Scale(5000ms).count())),
                  L"Delayed settings snapshot did not remain safely owned and finish after the bounded flush timed out.");

    const SettingsHotReload::SettingsSaveDebugSnapshot completed = SettingsHotReload::DebugGetSettingsSaveSnapshotForSelfTest();
    state.Require(completed.completedGeneration >= completed.queuedGeneration, L"Settings-save flush should complete the latest queued generation.");
    state.Require(completed.lastSaveThreadId != 0 && completed.lastSaveThreadId != uiThreadId,
                  L"Asynchronous and serialized settings persistence should execute off the UI thread.");
    state.Require(RequireSettingsSaveChild(state, L"ordering"), L"Settings-save process finalization ordering was not deterministic.");
    state.Require(RequireSettingsSaveChild(state, L"teardown"), L"Settings-save process teardown was not bounded while storage remained stalled.");
    state.Require(RequireSettingsSaveChild(state, L"sessionend"), L"Real WM_ENDSESSION did not fence and serialize the final settings snapshot.");
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsHotReloadInvalidExternalFile(HWND mainWindow, CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestHotReloadInvalid";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&]
    {
        SettingsHotReload::Stop();
        RestoreMainSettingsHotReload(mainWindow, state);
        CleanupSettingsArtifacts(kTestAppId);
    });

    Common::Settings::Settings baseline{};
    baseline.theme.currentThemeId = L"builtin/system";
    const HRESULT seedHr          = Common::Settings::SaveSettings(kTestAppId, baseline);
    state.Require(SUCCEEDED(seedHr), L"Failed to seed invalid external-file hot-reload test settings.");
    if (FAILED(seedHr))
    {
        return false;
    }

    SettingsHotReloadTestWindowState windowState{};
    HWND hwnd = CreateSettingsHotReloadTestWindow(windowState);
    state.Require(hwnd != nullptr && IsWindow(hwnd) != FALSE, L"Failed to create hot-reload invalid-file self-test window.");
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }
    const auto destroyWindow = wil::scope_exit([&]
    {
        if (hwnd && IsWindow(hwnd))
        {
            DestroyWindow(hwnd);
        }
    });

    const HRESULT startHr = SettingsHotReload::Start(hwnd, kTestAppId);
    state.Require(SUCCEEDED(startHr), L"Failed to start settings hot-reload watcher for invalid-file test.");
    if (FAILED(startHr))
    {
        return false;
    }

    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);
    state.Require(! settingsPath.empty(), L"Invalid-file hot-reload test settings path unavailable.");

    std::this_thread::sleep_for(SelfTest::Scale(std::chrono::milliseconds{50}));
    const uint32_t beforeInvalidWrite = windowState.changeCount.load(std::memory_order_acquire);
    state.Require(SelfTest::WriteTextFile(settingsPath, R"({"schemaVersion":9999})"), L"Failed to write unsupported-schema settings file.");
    state.Require(WaitForAtomicAtLeast(windowState.changeCount, beforeInvalidWrite + 1u, SelfTest::Scale(std::chrono::milliseconds{3000})),
                  L"Watcher did not observe the invalid external settings write.");

    SettingsHotReload::ChangedSettingsLoadResult invalid{};
    const auto invalidDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(std::chrono::milliseconds{3000});
    for (;;)
    {
        invalid = SettingsHotReload::TryLoadChangedSettings();
        if (invalid.status == SettingsHotReload::ChangedSettingsStatus::Invalid || std::chrono::steady_clock::now() >= invalidDeadline)
        {
            break;
        }

        std::this_thread::sleep_for(SelfTest::Scale(std::chrono::milliseconds{25}));
    }
    state.Require(invalid.status != SettingsHotReload::ChangedSettingsStatus::Loaded,
                  L"Unsupported schema version should not be applied through external settings hot-reload.");
    state.Require(invalid.status == SettingsHotReload::ChangedSettingsStatus::Invalid || invalid.status == SettingsHotReload::ChangedSettingsStatus::NoChange ||
                      invalid.status == SettingsHotReload::ChangedSettingsStatus::Missing || invalid.status == SettingsHotReload::ChangedSettingsStatus::Error,
                  L"Unsupported schema version produced an unexpected external settings hot-reload status.");
    state.Require(invalid.status == SettingsHotReload::ChangedSettingsStatus::NoChange || FAILED(invalid.hr),
                  L"Invalid external settings load should either stay suppressed as no-change or return a failure HRESULT.");
    if (invalid.stamp.has_value())
    {
        SettingsHotReload::MarkRejectedStamp(invalid.stamp.value());
        const SettingsHotReload::ChangedSettingsLoadResult deduped = SettingsHotReload::TryLoadChangedSettings();
        state.Require(deduped.status == SettingsHotReload::ChangedSettingsStatus::NoChange,
                      L"Rejected invalid settings stamp should be de-duplicated on subsequent checks.");
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsHotReloadTransientArmFailureIsAsync(HWND mainWindow, CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestHotReloadTransientArmFailure";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&]
    {
        SettingsHotReload::DebugSetChangeNotificationOpenFailuresForSelfTest(0u, ERROR_SUCCESS);
        SettingsHotReload::Stop();
        RestoreMainSettingsHotReload(mainWindow, state);
        CleanupSettingsArtifacts(kTestAppId);
    });

    Common::Settings::Settings baseline{};
    baseline.theme.currentThemeId = L"builtin/light";
    const HRESULT seedHr          = Common::Settings::SaveSettings(kTestAppId, baseline);
    state.Require(SUCCEEDED(seedHr), L"Failed to seed transient-arm-failure hot-reload test settings.");
    if (FAILED(seedHr))
    {
        return false;
    }

    SettingsHotReloadTestWindowState windowState{};
    HWND hwnd = CreateSettingsHotReloadTestWindow(windowState);
    state.Require(hwnd != nullptr && IsWindow(hwnd) != FALSE, L"Failed to create hot-reload transient-arm-failure self-test window.");
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }
    const auto destroyWindow = wil::scope_exit([&]
    {
        if (hwnd && IsWindow(hwnd))
        {
            DestroyWindow(hwnd);
        }
    });

    SettingsHotReload::DebugSetChangeNotificationOpenFailuresForSelfTest(1u, ERROR_PATH_NOT_FOUND);
    const auto startBegin = std::chrono::steady_clock::now();
    const HRESULT startHr = SettingsHotReload::Start(hwnd, kTestAppId);
    const auto elapsed    = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - startBegin);

    state.Require(elapsed < std::chrono::milliseconds{200}, L"SettingsHotReload::Start blocked on a transient watcher-arm failure.");
    state.Require(startHr != HRESULT_FROM_WIN32(WAIT_TIMEOUT), L"SettingsHotReload::Start should not return WAIT_TIMEOUT for transient watcher-arm failure.");
    state.Require(SUCCEEDED(startHr), L"SettingsHotReload::Start should keep the watcher alive after a transient watcher-arm failure.");
    if (FAILED(startHr))
    {
        return false;
    }

    // The injected first-arm failure leaves a deterministic window in which no directory
    // notification exists. The post-arm stamp comparison must recover this write.
    Common::Settings::Settings external = baseline;
    external.theme.currentThemeId       = L"builtin/dark";
    const uint32_t beforeExternalSave   = windowState.changeCount.load(std::memory_order_acquire);
    const HRESULT externalSaveHr        = Common::Settings::SaveSettings(kTestAppId, external);
    state.Require(SUCCEEDED(externalSaveHr), L"Failed to save external settings change after transient watcher-arm failure.");
    state.Require(WaitForAtomicAtLeast(windowState.changeCount, beforeExternalSave + 1u, SelfTest::Scale(std::chrono::milliseconds{4000})),
                  L"Watcher did not self-arm and observe the external settings write after a transient arm failure.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsHotReloadRejectsStaleSessionNotification(HWND mainWindow, CaseState& state) noexcept
{
    constexpr std::wstring_view kFirstAppId  = L"RedSalamanderSelfTestHotReloadStaleSessionA";
    constexpr std::wstring_view kSecondAppId = L"RedSalamanderSelfTestHotReloadStaleSessionB";
    CleanupSettingsArtifacts(kFirstAppId);
    CleanupSettingsArtifacts(kSecondAppId);
    const auto cleanup = wil::scope_exit([&]
    {
        SettingsHotReload::Stop();
        CleanupSettingsArtifacts(kFirstAppId);
        CleanupSettingsArtifacts(kSecondAppId);
        RestoreMainSettingsHotReload(mainWindow, state);
    });

    SettingsHotReloadTestWindowState windowState{};
    HWND hwnd = CreateSettingsHotReloadTestWindow(windowState);
    state.Require(hwnd != nullptr && IsWindow(hwnd) != FALSE, L"Failed to create the stale-session hot-reload test window.");
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }
    const auto destroyWindow = wil::scope_exit([&]
    {
        if (hwnd && IsWindow(hwnd))
        {
            DestroyWindow(hwnd);
        }
    });

    Common::Settings::Settings first{};
    first.theme.currentThemeId = L"builtin/light";
    state.Require(SUCCEEDED(Common::Settings::SaveSettings(kFirstAppId, first)), L"Failed to seed the first stale-session settings file.");
    state.Require(SUCCEEDED(SettingsHotReload::Start(hwnd, kFirstAppId)), L"Failed to start the first stale-session settings watcher.");
    if (! state.failure.empty())
    {
        return false;
    }

    const uint32_t beforeFirstSave = windowState.changeCount.load(std::memory_order_acquire);
    first.theme.currentThemeId     = L"builtin/dark";
    state.Require(SUCCEEDED(Common::Settings::SaveSettings(kFirstAppId, first)), L"Failed to change the first stale-session settings file.");
    state.Require(WaitForAtomicAtLeast(windowState.changeCount, beforeFirstSave + 1u, SelfTest::Scale(std::chrono::milliseconds{4000})),
                  L"The first stale-session watcher did not post a settings notification.");
    const uint64_t staleSessionGeneration = windowState.lastSessionGeneration.load(std::memory_order_acquire);
    state.Require(staleSessionGeneration != 0u, L"The first settings notification did not carry its watcher session generation.");

    Common::Settings::Settings second{};
    second.theme.currentThemeId = L"builtin/light";
    state.Require(SUCCEEDED(Common::Settings::SaveSettings(kSecondAppId, second)), L"Failed to seed the second stale-session settings file.");
    state.Require(SUCCEEDED(SettingsHotReload::Start(hwnd, kSecondAppId)), L"Failed to start the second stale-session settings watcher.");
    if (! state.failure.empty())
    {
        return false;
    }

    second.theme.currentThemeId = L"builtin/rainbow";
    state.Require(SUCCEEDED(Common::Settings::SaveSettings(kSecondAppId, second)), L"Failed to change the second stale-session settings file.");

    const SettingsHotReload::SettingsFileChangedPayload staleNotification{.tickCount = GetTickCount64(), .sessionGeneration = staleSessionGeneration};
    const SettingsHotReload::ChangedSettingsLoadResult staleResult = SettingsHotReload::TryLoadChangedSettingsForNotification(staleNotification);
    state.Require(staleResult.status == SettingsHotReload::ChangedSettingsStatus::NoChange,
                  L"A stale watcher notification must not load settings from the replacement watcher session.");

    const SettingsHotReload::ChangedSettingsLoadResult currentResult = SettingsHotReload::TryLoadChangedSettings();
    state.Require(currentResult.status == SettingsHotReload::ChangedSettingsStatus::Loaded,
                  L"Rejecting a stale watcher notification must leave the current session change available.");
    state.Require(currentResult.settings.theme.currentThemeId == second.theme.currentThemeId,
                  L"The current watcher session did not load its own external settings change after stale-notification rejection.");
    return state.failure.empty();
}

[[nodiscard]] bool IsOwnedBy(HWND window, HWND expectedOwner) noexcept
{
    if (! window || ! IsWindow(window) || ! expectedOwner || ! IsWindow(expectedOwner))
    {
        return false;
    }

    const HWND owner = GetWindow(window, GW_OWNER);
    return owner == expectedOwner;
}

template <typename GetWindowFunc> [[nodiscard]] HWND WaitForWindow(GetWindowFunc&& getWindow, std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();

        const HWND hwnd = getWindow();
        if (hwnd && IsWindow(hwnd) != FALSE)
        {
            return hwnd;
        }
        std::this_thread::sleep_for(10ms);
    }

    return nullptr;
}

[[nodiscard]] bool WaitForWindowClosed(HWND hwnd, std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    if (! hwnd)
    {
        return true;
    }

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();

        if (IsWindow(hwnd) == FALSE)
        {
            return true;
        }
        std::this_thread::sleep_for(10ms);
    }

    return IsWindow(hwnd) == FALSE;
}

[[nodiscard]] bool IsActuallyVisibleChildWindow(HWND hwnd) noexcept
{
    if (! hwnd || IsWindowVisible(hwnd) == FALSE)
    {
        return false;
    }

    // DxUi text bridges stay WS_VISIBLE for IME routing, but an empty region keeps them off-screen.
    wil::unique_hrgn region(CreateRectRgn(0, 0, 0, 0));
    if (region)
    {
        const int rgnType = GetWindowRgn(hwnd, region.get());
        if (rgnType == NULLREGION)
        {
            return false;
        }
    }

    return true;
}

[[nodiscard]] size_t CountVisibleChildWindows(HWND hwnd) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return 0u;
    }

    struct VisibleChildCounter
    {
        size_t count = 0u;
    } counter{};

    static_cast<void>(EnumChildWindows(hwnd,
                                       [](HWND child, LPARAM lParam) noexcept -> BOOL
    {
        auto& counterRef = *reinterpret_cast<VisibleChildCounter*>(lParam);
        if (IsActuallyVisibleChildWindow(child))
        {
            ++counterRef.count;
        }
        return TRUE;
    },
                                       reinterpret_cast<LPARAM>(&counter)));

    return counter.count;
}

[[nodiscard]] HWND FindDescendantWindowByClass(HWND hwnd, std::wstring_view className) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE || className.empty())
    {
        return nullptr;
    }

    struct FindByClassContext
    {
        std::wstring_view targetClass;
        HWND found = nullptr;
    } context{className, nullptr};

    static_cast<void>(EnumChildWindows(hwnd,
                                       [](HWND child, LPARAM lParam) noexcept -> BOOL
    {
        auto& contextRef = *reinterpret_cast<FindByClassContext*>(lParam);

        std::array<wchar_t, 128> childClass{};
        const int length = GetClassNameW(child, childClass.data(), static_cast<int>(childClass.size()));
        if (length > 0 && std::wstring_view(childClass.data(), static_cast<size_t>(length)) == contextRef.targetClass)
        {
            contextRef.found = child;
            return FALSE;
        }
        return TRUE;
    },
                                       reinterpret_cast<LPARAM>(&context)));

    return context.found;
}

[[nodiscard]] bool WindowHasClass(HWND hwnd, std::wstring_view className) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE || className.empty())
    {
        return false;
    }

    std::array<wchar_t, 128> actualClass{};
    const int length = GetClassNameW(hwnd, actualClass.data(), static_cast<int>(actualClass.size()));
    return length > 0 && std::wstring_view(actualClass.data(), static_cast<size_t>(length)) == className;
}

[[nodiscard]] LPARAM MapClientPointLParam(HWND fromWindow, HWND targetWindow, LPARAM pointLParam) noexcept
{
    POINT point{
        GET_X_LPARAM(pointLParam),
        GET_Y_LPARAM(pointLParam),
    };
    if (fromWindow && targetWindow && fromWindow != targetWindow)
    {
        MapWindowPoints(fromWindow, targetWindow, &point, 1);
    }
    return MAKELPARAM(point.x, point.y);
}

[[nodiscard]] LPARAM DipPointToClientLParam(HWND hwnd, float xDip, float yDip) noexcept
{
    const UINT dpi    = hwnd && IsWindow(hwnd) != FALSE ? GetDpiForWindow(hwnd) : USER_DEFAULT_SCREEN_DPI;
    const float scale = static_cast<float>(dpi) / 96.0f;
    const LONG x      = static_cast<LONG>(std::lround(xDip * scale));
    const LONG y      = static_cast<LONG>(std::lround(yDip * scale));
    return MAKELPARAM(x, y);
}

[[maybe_unused]] [[nodiscard]] LPARAM DipPointToWindowLParam(HWND hwnd, float xDip, float yDip) noexcept
{
    return DipPointToClientLParam(hwnd, xDip, yDip);
}

[[nodiscard]] HWND ResolveMouseInputWindowForHostPoint(HWND hwnd, LPARAM hostPoint) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return nullptr;
    }

    POINT point{
        GET_X_LPARAM(hostPoint),
        GET_Y_LPARAM(hostPoint),
    };
    if (const HWND child = ChildWindowFromPointEx(hwnd, point, CWP_SKIPDISABLED | CWP_SKIPINVISIBLE | CWP_SKIPTRANSPARENT);
        child && child != hwnd && IsWindow(child) != FALSE)
    {
        return child;
    }

    return hwnd;
}

void SendMouseDragToResolvedPointWindow(HWND hwnd, LPARAM hostStartPoint, LPARAM hostTargetPoint) noexcept
{
    const HWND targetWindow  = ResolveMouseInputWindowForHostPoint(hwnd, hostStartPoint);
    const LPARAM startPoint  = MapClientPointLParam(hwnd, targetWindow, hostStartPoint);
    const LPARAM targetPoint = MapClientPointLParam(hwnd, targetWindow, hostTargetPoint);
    SendMessageW(targetWindow, WM_MOUSEMOVE, 0, startPoint);
    SendMessageW(targetWindow, WM_LBUTTONDOWN, MK_LBUTTON, startPoint);
    SendMessageW(targetWindow, WM_MOUSEMOVE, MK_LBUTTON, targetPoint);
    SendMessageW(targetWindow, WM_LBUTTONUP, 0, targetPoint);
    PumpPendingMessages();
}

void SendMouseClickToResolvedPointWindow(HWND hwnd, LPARAM hostPoint) noexcept
{
    const HWND targetWindow = ResolveMouseInputWindowForHostPoint(hwnd, hostPoint);
    const LPARAM point      = MapClientPointLParam(hwnd, targetWindow, hostPoint);
    SendMessageW(targetWindow, WM_MOUSEMOVE, 0, point);
    SendMessageW(targetWindow, WM_LBUTTONDOWN, MK_LBUTTON, point);
    SendMessageW(targetWindow, WM_LBUTTONUP, 0, point);
    PumpPendingMessages();
}

void SendMouseClickToDirectWindow(HWND hwnd, LPARAM point) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return;
    }

    SendMessageW(hwnd, WM_MOUSEMOVE, 0, point);
    SendMessageW(hwnd, WM_LBUTTONDOWN, MK_LBUTTON, point);
    SendMessageW(hwnd, WM_LBUTTONUP, 0, point);
    PumpPendingMessages();
}

void SendMouseDoubleClickToResolvedPointWindow(HWND hwnd, LPARAM hostPoint) noexcept
{
    const HWND targetWindow = ResolveMouseInputWindowForHostPoint(hwnd, hostPoint);
    const LPARAM point      = MapClientPointLParam(hwnd, targetWindow, hostPoint);
    SendMessageW(targetWindow, WM_MOUSEMOVE, 0, point);
    SendMessageW(targetWindow, WM_LBUTTONDOWN, MK_LBUTTON, point);
    SendMessageW(targetWindow, WM_LBUTTONUP, 0, point);
    SendMessageW(targetWindow, WM_LBUTTONDBLCLK, MK_LBUTTON, point);
    SendMessageW(targetWindow, WM_LBUTTONUP, 0, point);
    PumpPendingMessages();
}

void SendMouseDragToDirectWindow(HWND hwnd, LPARAM startPoint, LPARAM targetPoint) noexcept
{
    SendMessageW(hwnd, WM_MOUSEMOVE, 0, startPoint);
    SendMessageW(hwnd, WM_LBUTTONDOWN, MK_LBUTTON, startPoint);
    SendMessageW(hwnd, WM_MOUSEMOVE, MK_LBUTTON, targetPoint);
    SendMessageW(hwnd, WM_LBUTTONUP, 0, targetPoint);
    PumpPendingMessages();
}

[[nodiscard]] std::optional<float> ResolveFindFirstVisibleHeaderResizeStartXDip(const FindFilesDebugSnapshot& snapshot) noexcept
{
    const float yDip = (snapshot.firstResultHeaderRect.top + snapshot.firstResultHeaderRect.bottom) * 0.5f;
    if (snapshot.firstResultHeaderRect.right <= snapshot.firstResultHeaderRect.left)
    {
        return std::nullopt;
    }

    for (float offsetDip = 2.0f; offsetDip <= 4.0f; offsetDip += 0.25f)
    {
        const float xDip = snapshot.firstResultHeaderRect.right - offsetDip;
        FindFilesDebugGridHit hit{};
        if (DebugHitTestFindFilesWindowResultsGrid(xDip, yDip, hit) && hit.isHeaderResize)
        {
            return xDip;
        }
    }

    for (float offsetDip = 0.5f; offsetDip <= 8.0f; offsetDip += 0.25f)
    {
        const float xDip = snapshot.firstResultHeaderRect.right - offsetDip;
        FindFilesDebugGridHit hit{};
        if (DebugHitTestFindFilesWindowResultsGrid(xDip, yDip, hit) && hit.isHeaderResize)
        {
            return xDip;
        }
    }

    return std::nullopt;
}

[[nodiscard]] bool SendFindFirstVisibleHeaderResizeDrag(HWND findWindow, const FindFilesDebugSnapshot& snapshot, float deltaDip) noexcept
{
    if (! findWindow || IsWindow(findWindow) == FALSE || ! std::isfinite(deltaDip) || deltaDip == 0.0f)
    {
        return false;
    }

    const std::optional<float> startXDip = ResolveFindFirstVisibleHeaderResizeStartXDip(snapshot);
    if (! startXDip.has_value())
    {
        return false;
    }

    const float yDip          = (snapshot.firstResultHeaderRect.top + snapshot.firstResultHeaderRect.bottom) * 0.5f;
    const LPARAM resizeStart  = DipPointToClientLParam(findWindow, startXDip.value(), yDip);
    const LPARAM resizeTarget = DipPointToClientLParam(findWindow, startXDip.value() + deltaDip, yDip);
    const HWND targetWindow   = ResolveMouseInputWindowForHostPoint(findWindow, resizeStart);
    if (! targetWindow || IsWindow(targetWindow) == FALSE)
    {
        return false;
    }

    SendMouseDragToResolvedPointWindow(findWindow, resizeStart, resizeTarget);
    return true;
}

[[nodiscard]] bool SendFindFirstVisibleHeaderResizeDragToHost(HWND findWindow, const FindFilesDebugSnapshot& snapshot, float deltaDip) noexcept
{
    if (! findWindow || IsWindow(findWindow) == FALSE || ! std::isfinite(deltaDip) || deltaDip == 0.0f)
    {
        return false;
    }

    const std::optional<float> startXDip = ResolveFindFirstVisibleHeaderResizeStartXDip(snapshot);
    if (! startXDip.has_value())
    {
        return false;
    }

    const float yDip          = (snapshot.firstResultHeaderRect.top + snapshot.firstResultHeaderRect.bottom) * 0.5f;
    const LPARAM resizeStart  = DipPointToClientLParam(findWindow, startXDip.value(), yDip);
    const LPARAM resizeTarget = DipPointToClientLParam(findWindow, startXDip.value() + deltaDip, yDip);
    SendMouseDragToDirectWindow(findWindow, resizeStart, resizeTarget);
    return true;
}

[[maybe_unused]] [[nodiscard]] bool SendFindSecondVisibleHeaderAheadOfFirst(HWND findWindow, const FindFilesDebugSnapshot& snapshot) noexcept
{
    if (! findWindow || IsWindow(findWindow) == FALSE)
    {
        return false;
    }

    if (snapshot.firstResultHeaderRect.right <= snapshot.firstResultHeaderRect.left ||
        snapshot.secondResultHeaderRect.right <= snapshot.secondResultHeaderRect.left)
    {
        return false;
    }

    const float startXDip      = (snapshot.secondResultHeaderRect.left + snapshot.secondResultHeaderRect.right) * 0.5f;
    const float yDip           = (snapshot.secondResultHeaderRect.top + snapshot.secondResultHeaderRect.bottom) * 0.5f;
    const float targetXDip     = snapshot.firstResultHeaderRect.left + 12.0f;
    const LPARAM reorderStart  = DipPointToClientLParam(findWindow, startXDip, yDip);
    const LPARAM reorderTarget = DipPointToClientLParam(findWindow, targetXDip, yDip);
    SendMouseDragToResolvedPointWindow(findWindow, reorderStart, reorderTarget);
    return true;
}

[[nodiscard]] std::optional<float> ResolveIssuesPaneTaskHeaderResizeStartXDip(HWND pane, const FileOperationsIssuesPane::SelfTestSnapshot& snapshot) noexcept
{
    if (! pane || IsWindow(pane) == FALSE || snapshot.taskHeaderRect.right <= snapshot.taskHeaderRect.left)
    {
        return std::nullopt;
    }

    const float yDip = (snapshot.taskHeaderRect.top + snapshot.taskHeaderRect.bottom) * 0.5f;
    for (float offsetDip = 2.0f; offsetDip <= 4.0f; offsetDip += 0.25f)
    {
        const float xDip = snapshot.taskHeaderRect.right - offsetDip;
        FileOperationsIssuesPane::SelfTestGridHit hit{};
        if (FileOperationsIssuesPane::SelfTestHitTestGridPoint(pane, xDip, yDip, hit) && hit.isHeaderResize && hit.columnIndex == 1u)
        {
            return xDip;
        }
    }

    for (float offsetDip = 0.5f; offsetDip <= 8.0f; offsetDip += 0.25f)
    {
        const float xDip = snapshot.taskHeaderRect.right - offsetDip;
        FileOperationsIssuesPane::SelfTestGridHit hit{};
        if (FileOperationsIssuesPane::SelfTestHitTestGridPoint(pane, xDip, yDip, hit) && hit.isHeaderResize && hit.columnIndex == 1u)
        {
            return xDip;
        }
    }

    return std::nullopt;
}

[[nodiscard]] bool SendIssuesPaneTaskHeaderResizeDrag(HWND pane, const FileOperationsIssuesPane::SelfTestSnapshot& snapshot, float deltaDip) noexcept
{
    if (! pane || IsWindow(pane) == FALSE || ! std::isfinite(deltaDip) || deltaDip == 0.0f)
    {
        return false;
    }

    const std::optional<float> startXDip = ResolveIssuesPaneTaskHeaderResizeStartXDip(pane, snapshot);
    if (! startXDip.has_value())
    {
        return false;
    }

    const float yDip          = (snapshot.taskHeaderRect.top + snapshot.taskHeaderRect.bottom) * 0.5f;
    const LPARAM resizeStart  = DipPointToClientLParam(pane, startXDip.value(), yDip);
    const LPARAM resizeTarget = DipPointToClientLParam(pane, startXDip.value() + deltaDip, yDip);
    SendMouseDragToResolvedPointWindow(pane, resizeStart, resizeTarget);
    return true;
}

[[nodiscard]] HWND FindVisibleDescendantWindowByClass(HWND hwnd, std::wstring_view expectedClassName) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE || expectedClassName.empty())
    {
        return nullptr;
    }

    struct WindowClassSearchContext
    {
        std::wstring_view expectedClassName;
        HWND found = nullptr;
    } context{expectedClassName, nullptr};

    static_cast<void>(EnumChildWindows(hwnd,
                                       [](HWND child, LPARAM lParam) noexcept -> BOOL
    {
        auto& contextRef = *reinterpret_cast<WindowClassSearchContext*>(lParam);
        if (! IsActuallyVisibleChildWindow(child))
        {
            return TRUE;
        }

        std::array<wchar_t, 128> className{};
        const int classLen = GetClassNameW(child, className.data(), static_cast<int>(className.size()));
        if (classLen <= 0)
        {
            return TRUE;
        }

        const std::wstring_view actualClassName(className.data(), static_cast<size_t>(classLen));
        const bool matchesExpected =
            actualClassName == contextRef.expectedClassName || (contextRef.expectedClassName == L"Edit" && actualClassName == L"RICHEDIT50W");
        if (! matchesExpected)
        {
            return TRUE;
        }

        contextRef.found = child;
        return FALSE;
    },
                                       reinterpret_cast<LPARAM>(&context)));

    if (context.found)
    {
        return context.found;
    }

    struct OwnedWindowClassSearchContext
    {
        std::wstring_view expectedClassName;
        HWND ownerRoot = nullptr;
        HWND found     = nullptr;
    } ownedContext{expectedClassName, GetAncestor(hwnd, GA_ROOT), nullptr};

    const DWORD ownerThreadId = GetWindowThreadProcessId(hwnd, nullptr);
    if (ownerThreadId != 0u)
    {
        static_cast<void>(EnumThreadWindows(ownerThreadId,
                                            [](HWND candidate, LPARAM lParam) noexcept -> BOOL
        {
            auto& contextRef = *reinterpret_cast<OwnedWindowClassSearchContext*>(lParam);
            if (! IsActuallyVisibleChildWindow(candidate))
            {
                return TRUE;
            }

            const HWND owner = GetWindow(candidate, GW_OWNER);
            if (! owner || GetAncestor(owner, GA_ROOT) != contextRef.ownerRoot)
            {
                return TRUE;
            }

            std::array<wchar_t, 128> className{};
            const int classLen = GetClassNameW(candidate, className.data(), static_cast<int>(className.size()));
            if (classLen <= 0)
            {
                return TRUE;
            }

            const std::wstring_view actualClassName(className.data(), static_cast<size_t>(classLen));
            const bool matchesExpected =
                actualClassName == contextRef.expectedClassName || (contextRef.expectedClassName == L"Edit" && actualClassName == L"RICHEDIT50W");
            if (! matchesExpected)
            {
                return TRUE;
            }

            contextRef.found = candidate;
            return FALSE;
        },
                                            reinterpret_cast<LPARAM>(&ownedContext)));
    }

    if (ownedContext.found)
    {
        return ownedContext.found;
    }

    return context.found;
}

[[nodiscard]] bool WindowExposesUiaProvider(HWND hwnd) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    DWORD_PTR result         = 0u;
    const LRESULT sendResult = SendMessageTimeoutW(hwnd, WM_GETOBJECT, 0, static_cast<LPARAM>(UiaRootObjectId), SMTO_ABORTIFHUNG | SMTO_BLOCK, 1000u, &result);
    return sendResult != 0 && result != 0u;
}

[[nodiscard]] bool WaitForWindowExposesUiaProvider(HWND hwnd, std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        if (WindowExposesUiaProvider(hwnd))
        {
            return true;
        }

        std::this_thread::sleep_for(20ms);
    }

    return WindowExposesUiaProvider(hwnd);
}

[[nodiscard]] size_t CountVisibleDescendantWindowsExposingUiaProviders(HWND hwnd) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return 0u;
    }

    struct UiaProviderCounter
    {
        size_t count = 0u;
    } counter{};

    static_cast<void>(EnumChildWindows(hwnd,
                                       [](HWND child, LPARAM lParam) noexcept -> BOOL
    {
        auto& counterRef = *reinterpret_cast<UiaProviderCounter*>(lParam);
        if (IsActuallyVisibleChildWindow(child) && WindowExposesUiaProvider(child))
        {
            ++counterRef.count;
        }
        return TRUE;
    },
                                       reinterpret_cast<LPARAM>(&counter)));

    return counter.count;
}

[[nodiscard]] std::vector<HWND> CollectVisibleDescendantWindowsExposingUiaProviders(HWND hwnd) noexcept
{
    std::vector<HWND> windows;
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return windows;
    }

    static_cast<void>(EnumChildWindows(hwnd,
                                       [](HWND child, LPARAM lParam) noexcept -> BOOL
    {
        auto& windowsRef = *reinterpret_cast<std::vector<HWND>*>(lParam);
        if (IsActuallyVisibleChildWindow(child) && WindowExposesUiaProvider(child))
        {
            windowsRef.push_back(child);
        }
        return TRUE;
    },
                                       reinterpret_cast<LPARAM>(&windows)));

    return windows;
}

struct UiaDescendantPatternStats
{
    size_t visibleElementCount     = 0u;
    size_t invokePatternCount      = 0u;
    size_t valuePatternCount       = 0u;
    size_t textPatternCount        = 0u;
    size_t togglePatternCount      = 0u;
    size_t rangeValuePatternCount  = 0u;
    size_t textControlCount        = 0u;
    size_t buttonControlCount      = 0u;
    size_t editControlCount        = 0u;
    size_t comboBoxControlCount    = 0u;
    size_t checkBoxControlCount    = 0u;
    size_t radioButtonControlCount = 0u;
    size_t namedButtonControlCount = 0u;
};

[[nodiscard]] std::vector<wil::com_ptr<IUIAutomationElement>> FindMatchingVisibleDescendantElements(HWND hwnd,
                                                                                                    const CONTROLTYPEID expectedControlType) noexcept;

[[nodiscard]] std::optional<UiaDescendantPatternStats> CollectVisibleUiaDescendantPatternStats(HWND hwnd) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return std::nullopt;
    }

    UiaDescendantPatternStats stats{};
    for (const auto& element : FindMatchingVisibleDescendantElements(hwnd, 0))
    {
        if (! element)
        {
            continue;
        }

        ++stats.visibleElementCount;

        CONTROLTYPEID controlType = 0;
        if (SUCCEEDED(element->get_CurrentControlType(&controlType)))
        {
            switch (controlType)
            {
                case UIA_TextControlTypeId: ++stats.textControlCount; break;
                case UIA_EditControlTypeId: ++stats.editControlCount; break;
                case UIA_ButtonControlTypeId:
                {
                    ++stats.buttonControlCount;
                    wil::unique_bstr name;
                    if (SUCCEEDED(element->get_CurrentName(&name)) && name.get() && name.get()[0] != L'\0')
                    {
                        ++stats.namedButtonControlCount;
                    }
                    break;
                }
                case UIA_ComboBoxControlTypeId: ++stats.comboBoxControlCount; break;
                case UIA_CheckBoxControlTypeId: ++stats.checkBoxControlCount; break;
                case UIA_RadioButtonControlTypeId: ++stats.radioButtonControlCount; break;
            }
        }

        wil::com_ptr<IUIAutomationInvokePattern> invokePattern;
        if (SUCCEEDED(element->GetCurrentPatternAs(UIA_InvokePatternId, __uuidof(IUIAutomationInvokePattern), invokePattern.put_void())) && invokePattern)
        {
            ++stats.invokePatternCount;
        }

        wil::com_ptr<IUIAutomationValuePattern> valuePattern;
        if (SUCCEEDED(element->GetCurrentPatternAs(UIA_ValuePatternId, __uuidof(IUIAutomationValuePattern), valuePattern.put_void())) && valuePattern)
        {
            ++stats.valuePatternCount;
        }

        wil::com_ptr<IUIAutomationTextPattern> textPattern;
        if (SUCCEEDED(element->GetCurrentPatternAs(UIA_TextPatternId, __uuidof(IUIAutomationTextPattern), textPattern.put_void())) && textPattern)
        {
            ++stats.textPatternCount;
        }

        wil::com_ptr<IUIAutomationTogglePattern> togglePattern;
        if (SUCCEEDED(element->GetCurrentPatternAs(UIA_TogglePatternId, __uuidof(IUIAutomationTogglePattern), togglePattern.put_void())) && togglePattern)
        {
            ++stats.togglePatternCount;
        }

        wil::com_ptr<IRangeValueProvider> rangeValueProvider;
        if (SUCCEEDED(element->GetCurrentPatternAs(UIA_RangeValuePatternId, __uuidof(IRangeValueProvider), rangeValueProvider.put_void())) &&
            rangeValueProvider)
        {
            ++stats.rangeValuePatternCount;
        }
    }

    return stats;
}

struct UiaSelectionPatternState
{
    CONTROLTYPEID rootControlType     = 0;
    bool hasSelectionPattern          = false;
    size_t selectionCount             = 0u;
    CONTROLTYPEID selectedControlType = 0;
    std::wstring selectedName;
    bool selectedHasSelectionItemPattern = false;
};

struct UiaValuePatternState
{
    CONTROLTYPEID controlType = 0;
    std::wstring name;
    std::wstring value;
    bool isReadOnly = false;
};

struct UiaControlValueState
{
    CONTROLTYPEID controlType = 0;
    std::wstring name;
    std::wstring value;
    bool isReadOnly       = false;
    bool hasValuePattern  = false;
    bool hasValueProperty = false;
};
enum class UiaReadableTextPatternSource
{
    ValuePattern,
    TextPattern,
};

struct UiaReadableTextState
{
    CONTROLTYPEID controlType = 0;
    std::wstring name;
    std::wstring value;
    bool isReadOnly                            = false;
    bool readOnlyKnown                         = false;
    UiaReadableTextPatternSource patternSource = UiaReadableTextPatternSource::ValuePattern;
};

[[nodiscard]] std::wstring NormalizeComparisonNewlines(std::wstring_view text)
{
    std::wstring normalized;
    normalized.reserve(text.size());
    for (size_t index = 0; index < text.size(); ++index)
    {
        if (text[index] == L'\r')
        {
            continue;
        }

        normalized.push_back(text[index]);
    }

    return normalized;
}
struct UiaNamedElementState
{
    CONTROLTYPEID controlType = 0;
    std::wstring name;
};

struct UiaTogglePatternState
{
    CONTROLTYPEID controlType = 0;
    std::wstring name;
    ToggleState toggleState = ToggleState_Off;
};

[[nodiscard]] std::optional<UiaSelectionPatternState> CollectUiaSelectionPatternState(HWND hwnd) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return std::nullopt;
    }

    const HRESULT coinitHr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    if (FAILED(coinitHr) && coinitHr != RPC_E_CHANGED_MODE)
    {
        return std::nullopt;
    }

    const bool shouldUninitialize = SUCCEEDED(coinitHr);
    const auto coUninitialize     = wil::scope_exit([shouldUninitialize]() noexcept
    {
        if (shouldUninitialize)
        {
            CoUninitialize();
        }
    });

    wil::com_ptr<IUIAutomation> automation;
    HRESULT hr = CoCreateInstance(CLSID_CUIAutomation, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(automation.addressof()));
    if (FAILED(hr) || ! automation)
    {
        return std::nullopt;
    }

    wil::com_ptr<IUIAutomationElement> root;
    hr = automation->ElementFromHandle(hwnd, root.addressof());
    if (FAILED(hr) || ! root)
    {
        return std::nullopt;
    }

    UiaSelectionPatternState state{};
    static_cast<void>(root->get_CurrentControlType(&state.rootControlType));

    wil::com_ptr<IUIAutomationSelectionPattern> selectionPattern;
    if (SUCCEEDED(root->GetCurrentPatternAs(UIA_SelectionPatternId, __uuidof(IUIAutomationSelectionPattern), selectionPattern.put_void())) && selectionPattern)
    {
        state.hasSelectionPattern = true;

        wil::com_ptr<IUIAutomationElementArray> selection;
        if (SUCCEEDED(selectionPattern->GetCurrentSelection(selection.addressof())) && selection)
        {
            int length = 0;
            if (SUCCEEDED(selection->get_Length(&length)) && length >= 0)
            {
                state.selectionCount = static_cast<size_t>(length);
                if (length > 0)
                {
                    wil::com_ptr<IUIAutomationElement> selected;
                    if (SUCCEEDED(selection->GetElement(0, selected.addressof())) && selected)
                    {
                        static_cast<void>(selected->get_CurrentControlType(&state.selectedControlType));

                        wil::unique_bstr name;
                        if (SUCCEEDED(selected->get_CurrentName(&name)))
                        {
                            state.selectedName.assign(name.get() ? name.get() : L"");
                        }

                        wil::com_ptr<IUIAutomationSelectionItemPattern> selectionItemProvider;
                        if (SUCCEEDED(selected->GetCurrentPatternAs(
                                UIA_SelectionItemPatternId, __uuidof(IUIAutomationSelectionItemPattern), selectionItemProvider.put_void())) &&
                            selectionItemProvider)
                        {
                            state.selectedHasSelectionItemPattern = true;
                        }
                    }
                }
            }
        }
    }

    return state;
}

struct UiaThreadContext final
{
    wil::com_ptr<IUIAutomation> automation;
    wil::com_ptr<IUIAutomation2> timeoutAutomation;
    bool shouldUninitialize = false;

    UiaThreadContext() noexcept
    {
        EnsureInitialized();
    }

    ~UiaThreadContext() noexcept
    {
        Release();
    }

    void EnsureInitialized() noexcept
    {
        if (automation)
        {
            return;
        }

        const HRESULT coinitHr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
        if (FAILED(coinitHr) && coinitHr != RPC_E_CHANGED_MODE)
        {
            return;
        }

        const bool shouldUninitializeAttempt = SUCCEEDED(coinitHr);
        wil::com_ptr<IUIAutomation2> createdTimeoutAutomation;
        const HRESULT createHr = CoCreateInstance(CLSID_CUIAutomation8, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(createdTimeoutAutomation.addressof()));
        if (FAILED(createHr) || ! createdTimeoutAutomation)
        {
            if (shouldUninitializeAttempt)
            {
                CoUninitialize();
            }
            return;
        }

        wil::com_ptr<IUIAutomation> createdAutomation;
        createdAutomation = createdTimeoutAutomation.get();
        if (! createdAutomation)
        {
            if (shouldUninitializeAttempt)
            {
                CoUninitialize();
            }
            return;
        }

        automation         = std::move(createdAutomation);
        timeoutAutomation  = std::move(createdTimeoutAutomation);
        shouldUninitialize = shouldUninitializeAttempt;
    }

    [[nodiscard]] bool ConfigureTimeouts(const DWORD timeoutMs) noexcept
    {
        EnsureInitialized();
        if (! timeoutAutomation)
        {
            return false;
        }

        const HRESULT connectionHr  = timeoutAutomation->put_ConnectionTimeout(timeoutMs);
        const HRESULT transactionHr = timeoutAutomation->put_TransactionTimeout(timeoutMs);
        return SUCCEEDED(connectionHr) && SUCCEEDED(transactionHr);
    }

    void Release() noexcept
    {
        automation.reset();
        timeoutAutomation.reset();
        if (shouldUninitialize)
        {
            CoUninitialize();
            shouldUninitialize = false;
        }
    }
};

[[nodiscard]] UiaThreadContext& GetThreadUiAutomationContext() noexcept
{
    thread_local UiaThreadContext context{};
    return context;
}

[[nodiscard]] IUIAutomation* GetThreadUiAutomation() noexcept
{
    UiaThreadContext& context = GetThreadUiAutomationContext();
    context.EnsureInitialized();
    return context.automation.get();
}

void ReleaseThreadUiAutomationForSelfTest() noexcept
{
    GetThreadUiAutomationContext().Release();
}

struct UiaOperationLifetime final
{
    UiaOperationLifetime()                                       = default;
    UiaOperationLifetime(const UiaOperationLifetime&)            = delete;
    UiaOperationLifetime& operator=(const UiaOperationLifetime&) = delete;
    UiaOperationLifetime(UiaOperationLifetime&&)                 = delete;
    UiaOperationLifetime& operator=(UiaOperationLifetime&&)      = delete;

    std::atomic<bool> done          = false;
    std::atomic<DWORD> workerThread = 0u;
};

struct UiaDeadlineBudget final
{
    std::chrono::milliseconds total{};
    std::chrono::milliseconds operation{};
    DWORD clientTimeoutMs = 1u;
};

[[nodiscard]] UiaDeadlineBudget MakeUiaDeadlineBudget(const uint32_t timeoutBudgetMs) noexcept
{
    const std::chrono::milliseconds total = SelfTest::Scale(std::chrono::milliseconds{timeoutBudgetMs});
    const uint64_t totalMs                = std::max<uint64_t>(1u, static_cast<uint64_t>(total.count()));
    const uint64_t cancellationReserveMs =
        (totalMs > 1u) ? std::min<uint64_t>(totalMs - 1u, std::min<uint64_t>(500u, std::max<uint64_t>(1u, totalMs / 4u))) : 0u;
    const uint64_t operationMs = totalMs - cancellationReserveMs;
    const uint64_t clientMarginMs =
        (operationMs > 1u) ? std::min<uint64_t>(operationMs - 1u, std::min<uint64_t>(250u, std::max<uint64_t>(1u, operationMs / 4u))) : 0u;
    const uint64_t clientTimeoutMs = operationMs - clientMarginMs;

    UiaDeadlineBudget budget{};
    budget.total           = std::chrono::milliseconds{static_cast<std::chrono::milliseconds::rep>(totalMs)};
    budget.operation       = std::chrono::milliseconds{static_cast<std::chrono::milliseconds::rep>(operationMs)};
    budget.clientTimeoutMs = static_cast<DWORD>(std::min<uint64_t>(clientTimeoutMs, std::numeric_limits<DWORD>::max()));
    return budget;
}

template <typename SharedState, typename Action>
void ExecuteBoundedUiaWorker(const std::shared_ptr<SharedState>& sharedState,
                             const std::stop_token stopToken,
                             const uint32_t timeoutBudgetMs,
                             Action&& action) noexcept
{
    const DWORD workerThreadId = GetCurrentThreadId();
    sharedState->lifetime.workerThread.store(workerThreadId, std::memory_order_release);
    const auto finish = wil::scope_exit([&]() noexcept
    {
        sharedState->lifetime.workerThread.store(0u, std::memory_order_release);
        sharedState->lifetime.done.store(true, std::memory_order_release);
    });

    const HRESULT cancellationHr   = CoEnableCallCancellation(nullptr);
    const auto disableCancellation = wil::scope_exit([cancellationHr]() noexcept
    {
        if (SUCCEEDED(cancellationHr))
        {
            static_cast<void>(CoDisableCallCancellation(nullptr));
        }
    });

    const UiaDeadlineBudget deadlineBudget = MakeUiaDeadlineBudget(timeoutBudgetMs);
    if (! GetThreadUiAutomationContext().ConfigureTimeouts(deadlineBudget.clientTimeoutMs))
    {
        SelfTest::AppendSelfTestTrace(L"UIA helper: failed to create a bounded IUIAutomation2 client; skipping the provider call.");
        return;
    }

    if (stopToken.stop_requested())
    {
        return;
    }

    if constexpr (std::is_invocable_v<Action&, std::stop_token>)
    {
        std::invoke(action, stopToken);
    }
    else
    {
        std::invoke(action);
    }
}

[[nodiscard]] bool WaitForBoundedUiaWorker(
    std::jthread& worker, UiaOperationLifetime& lifetime, const uint32_t timeoutBudgetMs, std::wstring_view timeoutOperation, std::wstring_view label) noexcept
{
    using namespace std::chrono_literals;

    const UiaDeadlineBudget deadlineBudget = MakeUiaDeadlineBudget(timeoutBudgetMs);
    const auto started                     = std::chrono::steady_clock::now();
    const auto operationDeadline           = started + deadlineBudget.operation;
    const auto overallDeadline             = started + deadlineBudget.total;
    while (! lifetime.done.load(std::memory_order_acquire) && std::chrono::steady_clock::now() < operationDeadline)
    {
        PumpPendingMessages();
        std::this_thread::sleep_for(10ms);
    }

    const bool timedOut = ! lifetime.done.load(std::memory_order_acquire);
    if (timedOut)
    {
        SelfTest::AppendSelfTestTrace(std::format(L"UIA helper: {} timed out during '{}'.", timeoutOperation, label));
        worker.request_stop();

        if (const DWORD workerThreadId = lifetime.workerThread.load(std::memory_order_acquire); workerThreadId != 0u)
        {
            static_cast<void>(CoCancelCall(workerThreadId, 0u));
        }

        while (! lifetime.done.load(std::memory_order_acquire) && std::chrono::steady_clock::now() < overallDeadline)
        {
            PumpPendingMessages();
            std::this_thread::sleep_for(5ms);
        }
    }

    if (! lifetime.done.load(std::memory_order_acquire))
    {
        // The IUIAutomation2 transaction timeout expires before operationDeadline, and CoCancelCall receives the remaining reserved
        // portion of the declared total budget. Consequently a blocked provider returns through the timed-out assertion path above.
        // Reaching this branch means the OS violated both COM deadline mechanisms; fail fast instead of joining without a bound or
        // detaching a worker that can retain HWNDs and run into the next case.
        SelfTest::AppendSelfTestTrace(std::format(L"UIA helper: {} violated its client timeout and ignored COM cancellation during '{}'; "
                                                  L"terminating the self-test process.",
                                                  timeoutOperation,
                                                  label));
        std::terminate();
    }

    worker.join();
    return ! timedOut;
}

[[nodiscard]] bool TryGetUiAutomationRootElement(HWND hwnd, wil::com_ptr<IUIAutomationElement>& root) noexcept
{
    root.reset();
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    IUIAutomation* automation = GetThreadUiAutomation();
    return automation && SUCCEEDED(automation->ElementFromHandle(hwnd, root.addressof())) && root;
}

[[nodiscard]] wil::com_ptr<IUIAutomationCondition> CreateVisibleDescendantCondition(IUIAutomation& automation,
                                                                                    CONTROLTYPEID expectedControlType,
                                                                                    std::wstring_view expectedName) noexcept
{
    wil::com_ptr<IUIAutomationCondition> visibleCondition;
    VARIANT visibleValue{};
    visibleValue.vt      = VT_BOOL;
    visibleValue.boolVal = VARIANT_FALSE;
    if (FAILED(automation.CreatePropertyCondition(UIA_IsOffscreenPropertyId, visibleValue, visibleCondition.addressof())) || ! visibleCondition)
    {
        return {};
    }

    auto appendCondition = [&automation](wil::com_ptr<IUIAutomationCondition>& aggregate, wil::com_ptr<IUIAutomationCondition>&& next) noexcept
    {
        if (! next)
        {
            return false;
        }

        wil::com_ptr<IUIAutomationCondition> combined;
        return SUCCEEDED(automation.CreateAndCondition(aggregate.get(), next.get(), combined.addressof())) && combined &&
               ((aggregate = std::move(combined)), true);
    };

    if (expectedControlType != 0)
    {
        wil::com_ptr<IUIAutomationCondition> controlTypeCondition;
        VARIANT controlTypeValue{};
        controlTypeValue.vt   = VT_I4;
        controlTypeValue.lVal = expectedControlType;
        if (FAILED(automation.CreatePropertyCondition(UIA_ControlTypePropertyId, controlTypeValue, controlTypeCondition.addressof())) ||
            ! controlTypeCondition || ! appendCondition(visibleCondition, std::move(controlTypeCondition)))
        {
            return {};
        }
    }

    if (! expectedName.empty())
    {
        wil::com_ptr<IUIAutomationCondition> nameCondition;
        VARIANT nameValue{};
        nameValue.vt        = VT_BSTR;
        nameValue.bstrVal   = SysAllocStringLen(expectedName.data(), static_cast<UINT>(expectedName.size()));
        const auto freeName = wil::scope_exit([&nameValue]() noexcept { SysFreeString(nameValue.bstrVal); });
        if (! nameValue.bstrVal || FAILED(automation.CreatePropertyCondition(UIA_NamePropertyId, nameValue, nameCondition.addressof())) || ! nameCondition ||
            ! appendCondition(visibleCondition, std::move(nameCondition)))
        {
            return {};
        }
    }

    return visibleCondition;
}

[[nodiscard]] bool TryReadRawProviderLongProperty(IRawElementProviderSimple& provider, PROPERTYID propertyId, LONG& outValue) noexcept
{
    outValue = 0;

    VARIANT value{};
    VariantInit(&value);
    const auto clearValue = wil::scope_exit([&value]() noexcept { VariantClear(&value); });

    if (FAILED(provider.GetPropertyValue(propertyId, &value)) || value.vt != VT_I4)
    {
        return false;
    }

    outValue = value.lVal;
    return true;
}

[[nodiscard]] bool TryReadRawProviderBoolProperty(IRawElementProviderSimple& provider, PROPERTYID propertyId, bool& outValue) noexcept
{
    outValue = false;

    VARIANT value{};
    VariantInit(&value);
    const auto clearValue = wil::scope_exit([&value]() noexcept { VariantClear(&value); });

    if (FAILED(provider.GetPropertyValue(propertyId, &value)) || value.vt != VT_BOOL)
    {
        return false;
    }

    outValue = value.boolVal != VARIANT_FALSE;
    return true;
}

[[nodiscard]] bool TryReadRawProviderStringProperty(IRawElementProviderSimple& provider, PROPERTYID propertyId, std::wstring& outValue) noexcept
{
    outValue.clear();

    VARIANT value{};
    VariantInit(&value);
    const auto clearValue = wil::scope_exit([&value]() noexcept { VariantClear(&value); });

    if (FAILED(provider.GetPropertyValue(propertyId, &value)) || value.vt != VT_BSTR)
    {
        return false;
    }

    outValue.assign(value.bstrVal ? value.bstrVal : L"");
    return true;
}

[[nodiscard]] bool RawProviderMatchesVisibleDescendant(IRawElementProviderSimple& provider,
                                                       CONTROLTYPEID expectedControlType,
                                                       std::wstring_view expectedName,
                                                       std::wstring_view expectedAutomationId) noexcept
{
    bool isOffscreen = true;
    if (! TryReadRawProviderBoolProperty(provider, UIA_IsOffscreenPropertyId, isOffscreen) || isOffscreen)
    {
        return false;
    }

    if (expectedControlType != 0)
    {
        LONG controlType = 0;
        if (! TryReadRawProviderLongProperty(provider, UIA_ControlTypePropertyId, controlType) || controlType != static_cast<LONG>(expectedControlType))
        {
            return false;
        }
    }

    if (! expectedName.empty())
    {
        std::wstring name;
        if (! TryReadRawProviderStringProperty(provider, UIA_NamePropertyId, name) || name != expectedName)
        {
            return false;
        }
    }

    if (! expectedAutomationId.empty())
    {
        std::wstring actualId;
        if (! TryReadRawProviderStringProperty(provider, UIA_AutomationIdPropertyId, actualId) || actualId != expectedAutomationId)
            return false;
    }
    return true;
}

enum class WindowHostRawProviderTreeVisitStatus : uint8_t
{
    MissingRoot,
    Complete,
    Stopped,
    Error,
};

// Walk one window-host provider, including offscreen fragments. The visible
// finder keeps its historical best-effort traversal; absence proofs require
// failClosed and Complete, since errors and a missing root are not empty trees.
template <typename Visitor>
[[nodiscard]] WindowHostRawProviderTreeVisitStatus VisitWindowHostRawProviderTree(HWND providerHwnd, bool failClosed, Visitor&& visitor) noexcept
{
    if (! providerHwnd || IsWindow(providerHwnd) == FALSE)
        return WindowHostRawProviderTreeVisitStatus::MissingRoot;

    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> rootProvider;
    rootProvider.attach(DxUi::CreateWindowHostAccessibilityProvider(providerHwnd));
    if (! rootProvider)
        return WindowHostRawProviderTreeVisitStatus::MissingRoot;

    wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
    if (FAILED(rootProvider.query_to(rootFragment.put())) || ! rootFragment)
        return WindowHostRawProviderTreeVisitStatus::Error;

    constexpr size_t kVisitBudget = 4096u;
    std::vector<wil::com_ptr_nothrow<IRawElementProviderFragment>> pending;
    pending.push_back(std::move(rootFragment));
    size_t visitedCount = 0u;
    while (! pending.empty())
    {
        if (visitedCount >= kVisitBudget)
            return WindowHostRawProviderTreeVisitStatus::Error;

        wil::com_ptr_nothrow<IRawElementProviderFragment> current = std::move(pending.back());
        pending.pop_back();
        ++visitedCount;
        if (! current)
        {
            if (failClosed)
                return WindowHostRawProviderTreeVisitStatus::Error;
            continue;
        }

        wil::com_ptr_nothrow<IRawElementProviderSimple> simple;
        if (FAILED(current.query_to(simple.put())) || ! simple)
        {
            if (failClosed)
                return WindowHostRawProviderTreeVisitStatus::Error;
        }
        else if (! visitor(*simple))
            return WindowHostRawProviderTreeVisitStatus::Stopped;

        wil::com_ptr_nothrow<IRawElementProviderFragment> child;
        if (FAILED(current->Navigate(NavigateDirection_FirstChild, child.put())))
        {
            if (failClosed)
                return WindowHostRawProviderTreeVisitStatus::Error;
            continue;
        }
        while (child)
        {
            if (failClosed && visitedCount + pending.size() >= kVisitBudget)
                return WindowHostRawProviderTreeVisitStatus::Error;
            wil::com_ptr_nothrow<IRawElementProviderFragment> nextSibling;
            const HRESULT siblingHr = child->Navigate(NavigateDirection_NextSibling, nextSibling.put());
            if (FAILED(siblingHr) && failClosed)
                return WindowHostRawProviderTreeVisitStatus::Error;
            pending.push_back(std::move(child));
            child = std::move(nextSibling);
        }
    }
    return WindowHostRawProviderTreeVisitStatus::Complete;
}

[[nodiscard]] bool FindMatchingWindowHostRawProvider(HWND hwnd,
                                                     CONTROLTYPEID expectedControlType,
                                                     std::wstring_view expectedName,
                                                     IRawElementProviderSimple** outProvider,
                                                     std::wstring_view expectedAutomationId = {}) noexcept
{
    if (! outProvider)
    {
        return false;
    }
    *outProvider = nullptr;

    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    const auto tryProviderWindow = [&](HWND providerHwnd) noexcept
    {
        wil::com_ptr_nothrow<IRawElementProviderSimple> match;
        const auto status = VisitWindowHostRawProviderTree(providerHwnd,
                                                           false,
                                                           [&](IRawElementProviderSimple& simple) noexcept
        {
            if (RawProviderMatchesVisibleDescendant(simple, expectedControlType, expectedName, expectedAutomationId))
            {
                match = &simple;
                return false;
            }
            return true;
        });
        if (status != WindowHostRawProviderTreeVisitStatus::Stopped || ! match)
            return false;
        *outProvider = match.detach();
        return true;
    };

    if (tryProviderWindow(hwnd))
    {
        return true;
    }

    std::vector<HWND> childWindows;

    static_cast<void>(EnumChildWindows(hwnd,
                                       [](HWND child, LPARAM lParam) noexcept -> BOOL
    {
        auto& childWindowsRef = *reinterpret_cast<std::vector<HWND>*>(lParam);
        childWindowsRef.push_back(child);
        return TRUE;
    },
                                       reinterpret_cast<LPARAM>(&childWindows)));
    for (const HWND child : childWindows)
    {
        if (tryProviderWindow(child))
        {
            return true;
        }
    }

    return false;
}

[[nodiscard]] std::optional<UiaValuePatternState> CollectWindowHostRawProviderValuePatternStateByName(HWND hwnd,
                                                                                                      const CONTROLTYPEID expectedControlType,
                                                                                                      std::wstring_view expectedName) noexcept
{
    wil::com_ptr_nothrow<IRawElementProviderSimple> provider;
    if (! FindMatchingWindowHostRawProvider(hwnd, expectedControlType, expectedName, provider.put()) || ! provider)
    {
        return std::nullopt;
    }

    wil::com_ptr_nothrow<IUnknown> patternUnknown;
    if (FAILED(provider->GetPatternProvider(UIA_ValuePatternId, patternUnknown.put())) || ! patternUnknown)
    {
        return std::nullopt;
    }

    wil::com_ptr_nothrow<IValueProvider> valueProvider;
    if (FAILED(patternUnknown.query_to(valueProvider.put())) || ! valueProvider)
    {
        return std::nullopt;
    }

    UiaValuePatternState state{};
    LONG controlType = 0;
    if (TryReadRawProviderLongProperty(*provider.get(), UIA_ControlTypePropertyId, controlType))
    {
        state.controlType = static_cast<CONTROLTYPEID>(controlType);
    }
    state.name.assign(expectedName);
    if (state.name.empty())
    {
        static_cast<void>(TryReadRawProviderStringProperty(*provider.get(), UIA_NamePropertyId, state.name));
    }

    wil::unique_bstr value;
    if (SUCCEEDED(valueProvider->get_Value(&value)))
    {
        state.value.assign(value.get() ? value.get() : L"");
    }

    BOOL readOnly = FALSE;
    if (SUCCEEDED(valueProvider->get_IsReadOnly(&readOnly)))
    {
        state.isReadOnly = readOnly != FALSE;
    }

    return state;
}

[[nodiscard]] std::vector<UiaControlValueState> CollectWindowHostRawProviderValuePatternStates(HWND hwnd, const CONTROLTYPEID expectedControlType) noexcept
{
    std::vector<UiaControlValueState> result;
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return result;
    }

    std::vector<HWND> providerWindows;
    providerWindows.push_back(hwnd);
    static_cast<void>(EnumChildWindows(hwnd,
                                       [](HWND child, LPARAM lParam) noexcept -> BOOL
    {
        auto& providerWindowsRef = *reinterpret_cast<std::vector<HWND>*>(lParam);
        providerWindowsRef.push_back(child);
        return TRUE;
    },
                                       reinterpret_cast<LPARAM>(&providerWindows)));

    for (const HWND providerHwnd : providerWindows)
    {
        if (! providerHwnd || IsWindow(providerHwnd) == FALSE)
        {
            continue;
        }

        wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> rootProvider;
        rootProvider.attach(DxUi::CreateWindowHostAccessibilityProvider(providerHwnd));
        if (! rootProvider)
        {
            continue;
        }

        wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
        if (FAILED(rootProvider.query_to(rootFragment.put())) || ! rootFragment)
        {
            continue;
        }

        std::vector<wil::com_ptr_nothrow<IRawElementProviderFragment>> pending;
        pending.push_back(std::move(rootFragment));

        size_t visitedCount = 0u;
        while (! pending.empty() && visitedCount < 4096u)
        {
            wil::com_ptr_nothrow<IRawElementProviderFragment> current = std::move(pending.back());
            pending.pop_back();
            ++visitedCount;

            if (! current)
            {
                continue;
            }

            wil::com_ptr_nothrow<IRawElementProviderSimple> simple;
            if (SUCCEEDED(current.query_to(simple.put())) && simple)
            {
                LONG controlType = 0;
                if (TryReadRawProviderLongProperty(*simple.get(), UIA_ControlTypePropertyId, controlType) &&
                    (expectedControlType == 0 || controlType == static_cast<LONG>(expectedControlType)))
                {
                    UiaControlValueState state{};
                    state.controlType = static_cast<CONTROLTYPEID>(controlType);
                    static_cast<void>(TryReadRawProviderStringProperty(*simple.get(), UIA_NamePropertyId, state.name));

                    wil::com_ptr_nothrow<IUnknown> patternUnknown;
                    if (SUCCEEDED(simple->GetPatternProvider(UIA_ValuePatternId, patternUnknown.put())) && patternUnknown)
                    {
                        wil::com_ptr_nothrow<IValueProvider> valueProvider;
                        if (SUCCEEDED(patternUnknown.query_to(valueProvider.put())) && valueProvider)
                        {
                            state.hasValuePattern = true;

                            wil::unique_bstr value;
                            if (SUCCEEDED(valueProvider->get_Value(&value)))
                            {
                                state.value.assign(value.get() ? value.get() : L"");
                                state.hasValueProperty = true;
                            }

                            BOOL readOnly = FALSE;
                            if (SUCCEEDED(valueProvider->get_IsReadOnly(&readOnly)))
                            {
                                state.isReadOnly = readOnly != FALSE;
                            }
                        }
                    }

                    result.push_back(std::move(state));
                }
            }

            wil::com_ptr_nothrow<IRawElementProviderFragment> child;
            if (FAILED(current->Navigate(NavigateDirection_FirstChild, child.put())) || ! child)
            {
                continue;
            }

            while (child)
            {
                wil::com_ptr_nothrow<IRawElementProviderFragment> nextSibling;
                static_cast<void>(child->Navigate(NavigateDirection_NextSibling, nextSibling.put()));
                pending.push_back(std::move(child));
                child = std::move(nextSibling);
            }
        }
    }

    return result;
}

[[nodiscard]] bool SetWindowHostRawProviderValueByName(HWND hwnd,
                                                       const CONTROLTYPEID expectedControlType,
                                                       std::wstring_view expectedName,
                                                       std::wstring_view value) noexcept
{
    wil::com_ptr_nothrow<IRawElementProviderSimple> provider;
    if (! FindMatchingWindowHostRawProvider(hwnd, expectedControlType, expectedName, provider.put()) || ! provider)
    {
        return false;
    }

    wil::com_ptr_nothrow<IUnknown> patternUnknown;
    if (FAILED(provider->GetPatternProvider(UIA_ValuePatternId, patternUnknown.put())) || ! patternUnknown)
    {
        return false;
    }

    wil::com_ptr_nothrow<IValueProvider> valueProvider;
    if (FAILED(patternUnknown.query_to(valueProvider.put())) || ! valueProvider)
    {
        return false;
    }

    BOOL readOnly = FALSE;
    if (SUCCEEDED(valueProvider->get_IsReadOnly(&readOnly)) && readOnly != FALSE)
    {
        return false;
    }

    const std::wstring newValueText{value};
    const wil::unique_bstr newValue(SysAllocString(newValueText.c_str()));
    if (! newValue && ! newValueText.empty())
    {
        return false;
    }

    const HRESULT actionHr = valueProvider->SetValue(newValue.get());
    if (FAILED(actionHr))
    {
        SelfTest::AppendSelfTestTrace(std::format(L"UIA helper: raw ValuePattern.SetValue failed with HRESULT 0x{:08X}.", static_cast<uint32_t>(actionHr)));
    }
    return SUCCEEDED(actionHr);
}

[[nodiscard]] bool InvokeWindowHostRawProviderDescendantByName(HWND hwnd, CONTROLTYPEID expectedControlType, std::wstring_view expectedName) noexcept
{
    wil::com_ptr_nothrow<IRawElementProviderSimple> provider;
    if (! FindMatchingWindowHostRawProvider(hwnd, expectedControlType, expectedName, provider.put()) || ! provider)
    {
        return false;
    }

    wil::com_ptr_nothrow<IUnknown> patternUnknown;
    if (FAILED(provider->GetPatternProvider(UIA_InvokePatternId, patternUnknown.put())) || ! patternUnknown)
    {
        return false;
    }

    wil::com_ptr_nothrow<IInvokeProvider> invokeProvider;
    if (FAILED(patternUnknown.query_to(invokeProvider.put())) || ! invokeProvider)
    {
        return false;
    }

    const HRESULT actionHr = invokeProvider->Invoke();
    if (FAILED(actionHr))
    {
        SelfTest::AppendSelfTestTrace(std::format(L"UIA helper: raw InvokePattern.Invoke failed with HRESULT 0x{:08X}.", static_cast<uint32_t>(actionHr)));
    }
    return SUCCEEDED(actionHr);
}

[[nodiscard]] std::optional<UiaNamedElementState> CollectWindowHostRawProviderNamedElementState(HWND hwnd,
                                                                                                const CONTROLTYPEID expectedControlType,
                                                                                                std::wstring_view expectedName) noexcept
{
    wil::com_ptr_nothrow<IRawElementProviderSimple> provider;
    if (! FindMatchingWindowHostRawProvider(hwnd, expectedControlType, expectedName, provider.put()) || ! provider)
    {
        return std::nullopt;
    }

    UiaNamedElementState state{};
    LONG controlType = 0;
    if (TryReadRawProviderLongProperty(*provider.get(), UIA_ControlTypePropertyId, controlType))
    {
        state.controlType = static_cast<CONTROLTYPEID>(controlType);
    }
    state.name.assign(expectedName);
    if (state.name.empty())
    {
        static_cast<void>(TryReadRawProviderStringProperty(*provider.get(), UIA_NamePropertyId, state.name));
    }

    return state;
}

[[nodiscard]] bool FindMatchingVisibleDescendantElement(HWND hwnd,
                                                        const CONTROLTYPEID expectedControlType,
                                                        std::wstring_view expectedName,
                                                        IUIAutomationElement** outElement) noexcept
{
    if (outElement == nullptr)
    {
        return false;
    }
    *outElement = nullptr;

    if (! expectedName.empty())
    {
        SelfTest::AppendSelfTestTrace(std::format(
            L"UIA helper: find descendant begin hwnd=0x{:X} type={} name='{}'", reinterpret_cast<UINT_PTR>(hwnd), expectedControlType, expectedName));
    }

    if (! expectedName.empty())
    {
        SelfTest::AppendSelfTestTrace(L"UIA helper: condition created");
    }

    for (const auto& element : FindMatchingVisibleDescendantElements(hwnd, expectedControlType))
    {
        if (! element)
        {
            continue;
        }
        if (! expectedName.empty())
        {
            wil::unique_bstr currentName;
            if (FAILED(element->get_CurrentName(&currentName)) ||
                (currentName.get() ? std::wstring_view(currentName.get()) : std::wstring_view{}) != expectedName)
            {
                continue;
            }
        }
        wil::com_ptr<IUIAutomationElement> match = element;
        *outElement                              = match.detach();
        if (! expectedName.empty())
        {
            SelfTest::AppendSelfTestTrace(L"UIA helper: FindFirst matched element");
        }
        return true;
    }

    if (! expectedName.empty())
    {
        SelfTest::AppendSelfTestTrace(L"UIA helper: FindFirst returned no matching element");
    }

    return false;
}

[[nodiscard]] std::vector<wil::com_ptr<IUIAutomationElement>> FindMatchingVisibleDescendantElements(HWND hwnd, const CONTROLTYPEID expectedControlType) noexcept
{
    std::vector<wil::com_ptr<IUIAutomationElement>> elements;

    IUIAutomation* automation = GetThreadUiAutomation();
    if (! automation)
    {
        return elements;
    }

    const auto appendUnique = [&](wil::com_ptr<IUIAutomationElement> element) noexcept
    {
        if (! element)
        {
            return;
        }
        if (expectedControlType != 0)
        {
            CONTROLTYPEID controlType = 0;
            if (FAILED(element->get_CurrentControlType(&controlType)) || controlType != expectedControlType)
            {
                return;
            }
        }
        for (const auto& existing : elements)
        {
            if (! existing)
            {
                continue;
            }

            BOOL same = FALSE;
            if (SUCCEEDED(automation->CompareElements(existing.get(), element.get(), &same)) && same != FALSE)
            {
                return;
            }
        }
        elements.push_back(std::move(element));
    };

    const auto appendFromRoot = [&](HWND rootHwnd, const TreeScope scope) noexcept
    {
        wil::com_ptr<IUIAutomationElement> root;
        if (FAILED(automation->ElementFromHandle(rootHwnd, root.addressof())) || ! root)
        {
            return;
        }

        wil::com_ptr<IUIAutomationCondition> condition = CreateVisibleDescendantCondition(*automation, 0, {});
        if (! condition)
        {
            return;
        }

        wil::com_ptr<IUIAutomationElementArray> matches;
        if (FAILED(root->FindAll(scope, condition.get(), matches.addressof())) || ! matches)
        {
            return;
        }

        int length = 0;
        if (FAILED(matches->get_Length(&length)) || length <= 0)
        {
            return;
        }

        for (int i = 0; i < length; ++i)
        {
            wil::com_ptr<IUIAutomationElement> element;
            if (SUCCEEDED(matches->GetElement(i, element.addressof())) && element)
            {
                appendUnique(std::move(element));
            }
        }
    };

    appendFromRoot(hwnd, expectedControlType == 0 ? TreeScope_Descendants : static_cast<TreeScope>(TreeScope_Element | TreeScope_Descendants));

    for (const HWND providerWindow : CollectVisibleDescendantWindowsExposingUiaProviders(hwnd))
    {
        appendFromRoot(providerWindow, static_cast<TreeScope>(TreeScope_Element | TreeScope_Subtree));
    }

    return elements;
}

[[nodiscard]] std::optional<UiaSelectionPatternState> CollectVisibleDescendantSelectionPatternState(HWND hwnd, const CONTROLTYPEID expectedControlType) noexcept
{
    wil::com_ptr<IUIAutomationElement> element;
    if (! FindMatchingVisibleDescendantElement(hwnd, expectedControlType, {}, element.put()) || ! element)
    {
        return std::nullopt;
    }

    UiaSelectionPatternState state{};
    static_cast<void>(element->get_CurrentControlType(&state.rootControlType));

    wil::com_ptr<IUIAutomationSelectionPattern> selectionPattern;
    if (SUCCEEDED(element->GetCurrentPatternAs(UIA_SelectionPatternId, __uuidof(IUIAutomationSelectionPattern), selectionPattern.put_void())) &&
        selectionPattern)
    {
        state.hasSelectionPattern = true;

        wil::com_ptr<IUIAutomationElementArray> selection;
        if (SUCCEEDED(selectionPattern->GetCurrentSelection(selection.addressof())) && selection)
        {
            int selectionLength = 0;
            if (SUCCEEDED(selection->get_Length(&selectionLength)) && selectionLength >= 0)
            {
                state.selectionCount = static_cast<size_t>(selectionLength);
                if (selectionLength > 0)
                {
                    wil::com_ptr<IUIAutomationElement> selected;
                    if (SUCCEEDED(selection->GetElement(0, selected.addressof())) && selected)
                    {
                        static_cast<void>(selected->get_CurrentControlType(&state.selectedControlType));

                        wil::unique_bstr name;
                        if (SUCCEEDED(selected->get_CurrentName(&name)))
                        {
                            state.selectedName.assign(name.get() ? name.get() : L"");
                        }

                        wil::com_ptr<IUIAutomationSelectionItemPattern> selectionItemProvider;
                        if (SUCCEEDED(selected->GetCurrentPatternAs(
                                UIA_SelectionItemPatternId, __uuidof(IUIAutomationSelectionItemPattern), selectionItemProvider.put_void())) &&
                            selectionItemProvider)
                        {
                            state.selectedHasSelectionItemPattern = true;
                        }
                    }
                }
            }
        }
    }

    return state;
}

[[nodiscard]] std::optional<UiaSelectionPatternState> CollectVisibleDescendantSelectionPatternStateWithMessagePump(HWND hwnd,
                                                                                                                   const CONTROLTYPEID expectedControlType,
                                                                                                                   std::wstring_view label) noexcept
{
    using namespace std::chrono_literals;

    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return std::nullopt;
    }

    struct SharedState
    {
        SharedState()                              = default;
        SharedState(const SharedState&)            = delete;
        SharedState& operator=(const SharedState&) = delete;
        SharedState(SharedState&&)                 = delete;
        SharedState& operator=(SharedState&&)      = delete;

        std::optional<UiaSelectionPatternState> result;
        UiaOperationLifetime lifetime;
    };

    auto sharedState = std::make_shared<SharedState>();
    std::jthread worker([sharedState, hwnd, expectedControlType](const std::stop_token stopToken) noexcept
    {
        ExecuteBoundedUiaWorker(
            sharedState, stopToken, 3000u, [&]() noexcept { sharedState->result = CollectVisibleDescendantSelectionPatternState(hwnd, expectedControlType); });
    });

    return WaitForBoundedUiaWorker(worker, sharedState->lifetime, 3000u, L"SelectionPattern read", label) ? sharedState->result : std::nullopt;
}

template <typename Predicate> [[nodiscard]] bool WaitForVisibleGridSelectionState(HWND hwnd, Predicate&& predicate, UiaSelectionPatternState& outState) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(3000ms);
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        const auto selectionState = CollectVisibleDescendantSelectionPatternState(hwnd, UIA_DataGridControlTypeId);
        if (selectionState.has_value())
        {
            outState = selectionState.value();
            if (predicate(selectionState.value()))
            {
                return true;
            }
        }

        std::this_thread::sleep_for(20ms);
    }

    const auto selectionState = CollectVisibleDescendantSelectionPatternState(hwnd, UIA_DataGridControlTypeId);
    if (selectionState.has_value())
    {
        outState = selectionState.value();
        if (predicate(selectionState.value()))
        {
            return true;
        }
    }

    return false;
}

template <typename SelectRowFn>
[[nodiscard]] bool VerifyPreferencesGridSelectionPattern(
    HWND prefs, CaseState& state, std::wstring_view pageName, const size_t rowCount, SelectRowFn&& selectRow) noexcept
{
    state.Require(rowCount > 0u, std::format(L"Preferences {} page should expose at least one visible DX grid row.", pageName));
    if (rowCount == 0u || ! state.failure.empty())
    {
        return false;
    }

    const auto hasExpectedSelection = [](const UiaSelectionPatternState& value) noexcept
    {
        return value.rootControlType == UIA_DataGridControlTypeId && value.hasSelectionPattern && value.selectionCount == 1u &&
               value.selectedControlType == UIA_DataItemControlTypeId && value.selectedHasSelectionItemPattern && ! value.selectedName.empty();
    };

    UiaSelectionPatternState selectionState{};
    state.Require(selectRow(0u), std::format(L"Failed to select the first Preferences {} DX grid row.", pageName));
    if (! state.failure.empty())
    {
        return false;
    }

    state.Require(WaitForVisibleGridSelectionState(prefs, hasExpectedSelection, selectionState),
                  std::format(L"Preferences {} DX grid did not expose live UI Automation SelectionPattern after selecting the first row.", pageName));
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring firstSelectedName = selectionState.selectedName;
    state.Require(! firstSelectedName.empty(), std::format(L"Preferences {} DX grid should expose a non-empty selected-row accessible name.", pageName));
    if (rowCount > 1u)
    {
        state.Require(selectRow(1u), std::format(L"Failed to select the second Preferences {} DX grid row.", pageName));
        if (! state.failure.empty())
        {
            return false;
        }

        state.Require(WaitForVisibleGridSelectionState(prefs,
                                                       [&](const UiaSelectionPatternState& value) noexcept
        { return hasExpectedSelection(value) && value.selectedName != firstSelectedName; },
                                                       selectionState),
                      std::format(L"Preferences {} DX grid did not update the selected-row accessible name after moving selection.", pageName));
    }

    return state.failure.empty();
}

[[nodiscard]] std::vector<UiaSelectionPatternState> CollectVisibleDescendantSelectionPatternStates(HWND hwnd, const CONTROLTYPEID expectedControlType) noexcept
{
    std::vector<UiaSelectionPatternState> states;
    for (const auto& element : FindMatchingVisibleDescendantElements(hwnd, expectedControlType))
    {
        UiaSelectionPatternState state{};
        static_cast<void>(element->get_CurrentControlType(&state.rootControlType));

        wil::com_ptr<IUIAutomationSelectionPattern> selectionPattern;
        if (SUCCEEDED(element->GetCurrentPatternAs(UIA_SelectionPatternId, __uuidof(IUIAutomationSelectionPattern), selectionPattern.put_void())) &&
            selectionPattern)
        {
            state.hasSelectionPattern = true;

            wil::com_ptr<IUIAutomationElementArray> selection;
            if (SUCCEEDED(selectionPattern->GetCurrentSelection(selection.addressof())) && selection)
            {
                int selectionLength = 0;
                if (SUCCEEDED(selection->get_Length(&selectionLength)) && selectionLength >= 0)
                {
                    state.selectionCount = static_cast<size_t>(selectionLength);
                    if (selectionLength > 0)
                    {
                        wil::com_ptr<IUIAutomationElement> selected;
                        if (SUCCEEDED(selection->GetElement(0, selected.addressof())) && selected)
                        {
                            static_cast<void>(selected->get_CurrentControlType(&state.selectedControlType));

                            wil::unique_bstr name;
                            if (SUCCEEDED(selected->get_CurrentName(&name)))
                            {
                                state.selectedName.assign(name.get() ? name.get() : L"");
                            }

                            wil::com_ptr<IUIAutomationSelectionItemPattern> selectionItemProvider;
                            if (SUCCEEDED(selected->GetCurrentPatternAs(
                                    UIA_SelectionItemPatternId, __uuidof(IUIAutomationSelectionItemPattern), selectionItemProvider.put_void())) &&
                                selectionItemProvider)
                            {
                                state.selectedHasSelectionItemPattern = true;
                            }
                        }
                    }
                }
            }
        }

        states.push_back(std::move(state));
    }

    return states;
}

template <typename Predicate>
[[nodiscard]] bool WaitForAnyVisibleGridSelectionState(HWND hwnd, Predicate&& predicate, UiaSelectionPatternState& outState) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(3000ms);
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        for (const auto& selectionState : CollectVisibleDescendantSelectionPatternStates(hwnd, UIA_DataGridControlTypeId))
        {
            if (predicate(selectionState))
            {
                outState = selectionState;
                return true;
            }
        }

        std::this_thread::sleep_for(20ms);
    }

    for (const auto& selectionState : CollectVisibleDescendantSelectionPatternStates(hwnd, UIA_DataGridControlTypeId))
    {
        if (predicate(selectionState))
        {
            outState = selectionState;
            return true;
        }
    }

    return false;
}

[[nodiscard]] std::optional<UiaValuePatternState> CollectVisibleDescendantValuePatternState(HWND hwnd, const CONTROLTYPEID expectedControlType) noexcept
{
    for (const auto& element : FindMatchingVisibleDescendantElements(hwnd, expectedControlType))
    {
        if (! element)
        {
            continue;
        }

        wil::com_ptr<IUIAutomationValuePattern> valuePattern;
        if (FAILED(element->GetCurrentPatternAs(UIA_ValuePatternId, __uuidof(IUIAutomationValuePattern), valuePattern.put_void())) || ! valuePattern)
        {
            continue;
        }

        UiaValuePatternState state{};
        static_cast<void>(element->get_CurrentControlType(&state.controlType));

        wil::unique_bstr name;
        if (SUCCEEDED(element->get_CurrentName(&name)))
        {
            state.name.assign(name.get() ? name.get() : L"");
        }

        wil::unique_bstr value;
        if (SUCCEEDED(valuePattern->get_CurrentValue(&value)))
        {
            state.value.assign(value.get() ? value.get() : L"");
        }

        BOOL readOnly = FALSE;
        if (SUCCEEDED(valuePattern->get_CurrentIsReadOnly(&readOnly)))
        {
            state.isReadOnly = readOnly != FALSE;
        }

        return state;
    }

    return std::nullopt;
}

[[nodiscard]] std::optional<UiaValuePatternState> CollectWindowRootOrDescendantValuePatternState(HWND hwnd, const CONTROLTYPEID expectedControlType) noexcept
{
    IUIAutomation* automation = GetThreadUiAutomation();
    if (! automation)
    {
        return std::nullopt;
    }

    wil::com_ptr<IUIAutomationElement> root;
    if (SUCCEEDED(automation->ElementFromHandle(hwnd, root.addressof())) && root)
    {
        UiaValuePatternState state{};
        if (SUCCEEDED(root->get_CurrentControlType(&state.controlType)) && (expectedControlType == 0 || state.controlType == expectedControlType))
        {
            wil::com_ptr<IUIAutomationValuePattern> valuePattern;
            if (SUCCEEDED(root->GetCurrentPatternAs(UIA_ValuePatternId, __uuidof(IUIAutomationValuePattern), valuePattern.put_void())) && valuePattern)
            {
                wil::unique_bstr name;
                if (SUCCEEDED(root->get_CurrentName(&name)))
                {
                    state.name.assign(name.get() ? name.get() : L"");
                }

                wil::unique_bstr value;
                if (SUCCEEDED(valuePattern->get_CurrentValue(&value)))
                {
                    state.value.assign(value.get() ? value.get() : L"");
                }

                BOOL readOnly = FALSE;
                if (SUCCEEDED(valuePattern->get_CurrentIsReadOnly(&readOnly)))
                {
                    state.isReadOnly = readOnly != FALSE;
                }

                return state;
            }
        }
    }

    return CollectVisibleDescendantValuePatternState(hwnd, expectedControlType);
}

[[nodiscard]] bool FocusedElementBelongsToWindow(IUIAutomationElement& element, HWND hwnd) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    UIA_HWND nativeHwnd = nullptr;
    if (FAILED(element.get_CurrentNativeWindowHandle(&nativeHwnd)) || ! nativeHwnd)
    {
        return false;
    }

    const HWND nativeWindow = static_cast<HWND>(nativeHwnd);
    return nativeWindow == hwnd || IsChild(hwnd, nativeWindow) != FALSE;
}

[[maybe_unused]] [[nodiscard]] std::optional<UiaValuePatternState> CollectFocusedValuePatternState(HWND hwnd, const CONTROLTYPEID expectedControlType) noexcept
{
    IUIAutomation* automation = GetThreadUiAutomation();
    if (! automation)
    {
        return std::nullopt;
    }

    wil::com_ptr<IUIAutomationElement> element;
    if (FAILED(automation->GetFocusedElement(element.addressof())) || ! element || ! FocusedElementBelongsToWindow(*element, hwnd))
    {
        return std::nullopt;
    }

    UiaValuePatternState state{};
    if (FAILED(element->get_CurrentControlType(&state.controlType)) || (expectedControlType != 0 && state.controlType != expectedControlType))
    {
        return std::nullopt;
    }

    wil::com_ptr<IUIAutomationValuePattern> valuePattern;
    if (FAILED(element->GetCurrentPatternAs(UIA_ValuePatternId, __uuidof(IUIAutomationValuePattern), valuePattern.put_void())) || ! valuePattern)
    {
        return std::nullopt;
    }

    wil::unique_bstr name;
    if (SUCCEEDED(element->get_CurrentName(&name)))
    {
        state.name.assign(name.get() ? name.get() : L"");
    }

    wil::unique_bstr value;
    if (SUCCEEDED(valuePattern->get_CurrentValue(&value)))
    {
        state.value.assign(value.get() ? value.get() : L"");
    }

    BOOL readOnly = FALSE;
    if (SUCCEEDED(valuePattern->get_CurrentIsReadOnly(&readOnly)))
    {
        state.isReadOnly = readOnly != FALSE;
    }

    return state;
}

[[nodiscard]] UiaControlValueState CollectControlValueState(IUIAutomationElement* element,
                                                            const CONTROLTYPEID fallbackControlType = 0,
                                                            std::wstring_view fallbackName          = {}) noexcept
{
    UiaControlValueState state{};
    state.controlType = fallbackControlType;
    state.name.assign(fallbackName);

    if (! element)
    {
        return state;
    }

    static_cast<void>(element->get_CurrentControlType(&state.controlType));
    if (state.name.empty())
    {
        wil::unique_bstr name;
        if (SUCCEEDED(element->get_CurrentName(&name)))
        {
            state.name.assign(name.get() ? name.get() : L"");
        }
    }

    wil::com_ptr<IUIAutomationValuePattern> valuePattern;
    if (SUCCEEDED(element->GetCurrentPatternAs(UIA_ValuePatternId, __uuidof(IUIAutomationValuePattern), valuePattern.put_void())) && valuePattern)
    {
        state.hasValuePattern = true;

        wil::unique_bstr value;
        if (SUCCEEDED(valuePattern->get_CurrentValue(&value)))
        {
            state.value.assign(value.get() ? value.get() : L"");
        }

        BOOL readOnly = FALSE;
        if (SUCCEEDED(valuePattern->get_CurrentIsReadOnly(&readOnly)))
        {
            state.isReadOnly = readOnly != FALSE;
        }
    }

    VARIANT valueVariant{};
    VariantInit(&valueVariant);
    const HRESULT valueHr = element->GetCurrentPropertyValue(UIA_ValueValuePropertyId, &valueVariant);
    if (SUCCEEDED(valueHr))
    {
        state.hasValueProperty = true;
        if ((! state.hasValuePattern || state.value.empty()) && valueVariant.vt == VT_BSTR)
        {
            state.value.assign(valueVariant.bstrVal ? valueVariant.bstrVal : L"");
        }
    }
    VariantClear(&valueVariant);

    VARIANT readOnlyVariant{};
    VariantInit(&readOnlyVariant);
    const HRESULT readOnlyHr = element->GetCurrentPropertyValue(UIA_ValueIsReadOnlyPropertyId, &readOnlyVariant);
    if (SUCCEEDED(readOnlyHr))
    {
        state.hasValueProperty = true;
        if (! state.hasValuePattern && readOnlyVariant.vt == VT_BOOL)
        {
            state.isReadOnly = readOnlyVariant.boolVal != VARIANT_FALSE;
        }
    }
    VariantClear(&readOnlyVariant);

    return state;
}

[[nodiscard]] std::optional<UiaControlValueState> CollectVisibleDescendantControlValueState(HWND hwnd, const CONTROLTYPEID expectedControlType) noexcept
{
    wil::com_ptr<IUIAutomationElement> element;
    if (! FindMatchingVisibleDescendantElement(hwnd, expectedControlType, {}, element.put()) || ! element)
    {
        return std::nullopt;
    }

    return CollectControlValueState(element.get());
}

[[nodiscard]] std::optional<UiaReadableTextState> CollectVisibleDescendantReadableTextState(HWND hwnd, const CONTROLTYPEID expectedControlType) noexcept
{
    for (const auto& element : FindMatchingVisibleDescendantElements(hwnd, expectedControlType))
    {
        if (! element)
        {
            continue;
        }

        UiaReadableTextState state{};
        static_cast<void>(element->get_CurrentControlType(&state.controlType));

        wil::unique_bstr name;
        if (SUCCEEDED(element->get_CurrentName(&name)))
        {
            state.name.assign(name.get() ? name.get() : L"");
        }

        wil::com_ptr<IUIAutomationValuePattern> valuePattern;
        if (SUCCEEDED(element->GetCurrentPatternAs(UIA_ValuePatternId, __uuidof(IUIAutomationValuePattern), valuePattern.put_void())) && valuePattern)
        {
            wil::unique_bstr value;
            if (SUCCEEDED(valuePattern->get_CurrentValue(&value)))
            {
                state.value.assign(value.get() ? value.get() : L"");
            }

            BOOL isReadOnly = FALSE;
            if (SUCCEEDED(valuePattern->get_CurrentIsReadOnly(&isReadOnly)))
            {
                state.readOnlyKnown = true;
                state.isReadOnly    = isReadOnly != FALSE;
            }

            state.patternSource = UiaReadableTextPatternSource::ValuePattern;
            return state;
        }

        wil::com_ptr<IUIAutomationTextPattern> textPattern;
        if (FAILED(element->GetCurrentPatternAs(UIA_TextPatternId, __uuidof(IUIAutomationTextPattern), textPattern.put_void())) || ! textPattern)
        {
            continue;
        }

        wil::com_ptr<IUIAutomationTextRange> documentRange;
        if (FAILED(textPattern->get_DocumentRange(documentRange.addressof())) || ! documentRange)
        {
            continue;
        }

        wil::unique_bstr text;
        if (FAILED(documentRange->GetText(-1, &text)))
        {
            continue;
        }

        state.value.assign(text.get() ? text.get() : L"");
        state.patternSource = UiaReadableTextPatternSource::TextPattern;
        return state;
    }

    return std::nullopt;
}

[[nodiscard]] std::optional<UiaNamedElementState> CollectVisibleDescendantNamedElementState(HWND hwnd, const CONTROLTYPEID expectedControlType) noexcept
{
    wil::com_ptr<IUIAutomationElement> element;
    if (! FindMatchingVisibleDescendantElement(hwnd, expectedControlType, {}, element.put()) || ! element)
    {
        return CollectWindowHostRawProviderNamedElementState(hwnd, expectedControlType, {});
    }

    UiaNamedElementState state{};
    static_cast<void>(element->get_CurrentControlType(&state.controlType));

    wil::unique_bstr name;
    if (SUCCEEDED(element->get_CurrentName(&name)))
    {
        state.name.assign(name.get() ? name.get() : L"");
    }

    return state;
}

[[nodiscard]] std::optional<UiaNamedElementState> CollectVisibleDescendantNamedElementStateWithMessagePump(HWND hwnd,
                                                                                                           const CONTROLTYPEID expectedControlType,
                                                                                                           std::wstring_view label) noexcept
{
    using namespace std::chrono_literals;

    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return std::nullopt;
    }

    struct SharedState
    {
        SharedState()                              = default;
        SharedState(const SharedState&)            = delete;
        SharedState& operator=(const SharedState&) = delete;
        SharedState(SharedState&&)                 = delete;
        SharedState& operator=(SharedState&&)      = delete;

        std::optional<UiaNamedElementState> result;
        UiaOperationLifetime lifetime;
    };

    auto sharedState = std::make_shared<SharedState>();
    std::jthread worker([sharedState, hwnd, expectedControlType](const std::stop_token stopToken) noexcept
    {
        ExecuteBoundedUiaWorker(sharedState,
                                stopToken,
                                3000u,
                                [&]() noexcept
        {
            using namespace std::chrono_literals;

            const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(2750ms);
            while (! stopToken.stop_requested() && std::chrono::steady_clock::now() < deadline)
            {
                sharedState->result = CollectVisibleDescendantNamedElementState(hwnd, expectedControlType);
                if (sharedState->result.has_value())
                {
                    break;
                }

                std::this_thread::sleep_for(25ms);
            }
        });
    });

    return WaitForBoundedUiaWorker(worker, sharedState->lifetime, 3000u, L"named element read", label) ? sharedState->result : std::nullopt;
}

[[nodiscard]] bool FindVisibleToggleDescendantElement(HWND hwnd, std::wstring_view expectedName, IUIAutomationElement** outElement) noexcept
{
    if (! outElement)
    {
        return false;
    }

    *outElement               = nullptr;
    IUIAutomation* automation = GetThreadUiAutomation();
    if (! automation)
    {
        return false;
    }

    constexpr CONTROLTYPEID toggleControlTypes[] = {
        UIA_CheckBoxControlTypeId,
        UIA_ButtonControlTypeId,
        UIA_RadioButtonControlTypeId,
    };

    const auto matchesExpectedName = [&](IUIAutomationElement& element) noexcept
    {
        if (expectedName.empty())
        {
            return true;
        }

        wil::unique_bstr name;
        if (FAILED(element.get_CurrentName(&name)))
        {
            return false;
        }

        const std::wstring_view elementName = name.get() ? std::wstring_view{name.get()} : std::wstring_view{};
        return elementName == expectedName;
    };

    for (const CONTROLTYPEID controlType : toggleControlTypes)
    {
        for (auto& element : FindMatchingVisibleDescendantElements(hwnd, controlType))
        {
            if (! element || ! matchesExpectedName(*element))
            {
                continue;
            }

            wil::com_ptr<IUIAutomationTogglePattern> togglePattern;
            if (FAILED(element->GetCurrentPatternAs(UIA_TogglePatternId, __uuidof(IUIAutomationTogglePattern), togglePattern.put_void())) || ! togglePattern)
            {
                continue;
            }

            *outElement = element.detach();
            return true;
        }
    }

    return false;
}

[[nodiscard]] std::optional<UiaTogglePatternState> CollectVisibleDescendantTogglePatternState(HWND hwnd) noexcept
{
    wil::com_ptr<IUIAutomationElement> element;
    if (! FindVisibleToggleDescendantElement(hwnd, {}, element.put()) || ! element)
    {
        return std::nullopt;
    }

    wil::com_ptr<IUIAutomationTogglePattern> togglePattern;
    if (FAILED(element->GetCurrentPatternAs(UIA_TogglePatternId, __uuidof(IUIAutomationTogglePattern), togglePattern.put_void())) || ! togglePattern)
    {
        return std::nullopt;
    }

    UiaTogglePatternState state{};
    static_cast<void>(element->get_CurrentControlType(&state.controlType));

    wil::unique_bstr name;
    if (SUCCEEDED(element->get_CurrentName(&name)))
    {
        state.name.assign(name.get() ? name.get() : L"");
    }

    static_cast<void>(togglePattern->get_CurrentToggleState(&state.toggleState));
    return state;
}

[[nodiscard]] std::optional<UiaTogglePatternState> CollectWindowRootOrDescendantTogglePatternState(HWND hwnd) noexcept
{
    IUIAutomation* automation = GetThreadUiAutomation();
    if (! automation)
    {
        return std::nullopt;
    }

    wil::com_ptr<IUIAutomationElement> root;
    if (SUCCEEDED(automation->ElementFromHandle(hwnd, root.addressof())) && root)
    {
        wil::com_ptr<IUIAutomationTogglePattern> togglePattern;
        if (SUCCEEDED(root->GetCurrentPatternAs(UIA_TogglePatternId, __uuidof(IUIAutomationTogglePattern), togglePattern.put_void())) && togglePattern)
        {
            UiaTogglePatternState state{};
            static_cast<void>(root->get_CurrentControlType(&state.controlType));

            wil::unique_bstr name;
            if (SUCCEEDED(root->get_CurrentName(&name)))
            {
                state.name.assign(name.get() ? name.get() : L"");
            }

            static_cast<void>(togglePattern->get_CurrentToggleState(&state.toggleState));
            return state;
        }
    }

    return CollectVisibleDescendantTogglePatternState(hwnd);
}

[[nodiscard]] std::optional<UiaControlValueState> CollectVisibleDescendantControlValueStateByName(HWND hwnd,
                                                                                                  const CONTROLTYPEID expectedControlType,
                                                                                                  std::wstring_view expectedName) noexcept
{
    wil::com_ptr<IUIAutomationElement> element;
    if (! FindMatchingVisibleDescendantElement(hwnd, expectedControlType, expectedName, element.put()) || ! element)
    {
        return std::nullopt;
    }

    return CollectControlValueState(element.get(), expectedControlType, expectedName);
}

[[nodiscard]] std::vector<UiaControlValueState> CollectVisibleDescendantControlValueStates(HWND hwnd, const CONTROLTYPEID expectedControlType) noexcept
{
    std::vector<UiaControlValueState> states;
    for (const auto& element : FindMatchingVisibleDescendantElements(hwnd, expectedControlType))
    {
        if (! element)
        {
            continue;
        }

        states.push_back(CollectControlValueState(element.get()));
    }

    return states;
}

[[nodiscard]] std::optional<UiaValuePatternState> CollectVisibleDescendantValuePatternStateByName(HWND hwnd,
                                                                                                  const CONTROLTYPEID expectedControlType,
                                                                                                  std::wstring_view expectedName) noexcept
{
    wil::com_ptr<IUIAutomationElement> element;
    if (! FindMatchingVisibleDescendantElement(hwnd, expectedControlType, expectedName, element.put()) || ! element)
    {
        return CollectWindowHostRawProviderValuePatternStateByName(hwnd, expectedControlType, expectedName);
    }

    wil::com_ptr<IUIAutomationValuePattern> valuePattern;
    if (FAILED(element->GetCurrentPatternAs(UIA_ValuePatternId, __uuidof(IUIAutomationValuePattern), valuePattern.put_void())) || ! valuePattern)
    {
        return std::nullopt;
    }

    UiaValuePatternState state{};
    state.controlType = expectedControlType;
    state.name.assign(expectedName);

    wil::unique_bstr value;
    if (SUCCEEDED(valuePattern->get_CurrentValue(&value)))
    {
        state.value.assign(value.get() ? value.get() : L"");
    }

    BOOL readOnly = FALSE;
    if (SUCCEEDED(valuePattern->get_CurrentIsReadOnly(&readOnly)))
    {
        state.isReadOnly = readOnly != FALSE;
    }

    return state;
}

[[nodiscard]] std::optional<UiaTogglePatternState> CollectVisibleDescendantTogglePatternStateByName(HWND hwnd, std::wstring_view expectedName) noexcept
{
    wil::com_ptr<IUIAutomationElement> element;
    if (! FindVisibleToggleDescendantElement(hwnd, expectedName, element.put()) || ! element)
    {
        return std::nullopt;
    }

    wil::com_ptr<IUIAutomationTogglePattern> togglePattern;
    if (FAILED(element->GetCurrentPatternAs(UIA_TogglePatternId, __uuidof(IUIAutomationTogglePattern), togglePattern.put_void())) || ! togglePattern)
    {
        return std::nullopt;
    }

    UiaTogglePatternState state{};
    static_cast<void>(element->get_CurrentControlType(&state.controlType));
    state.name.assign(expectedName);
    static_cast<void>(togglePattern->get_CurrentToggleState(&state.toggleState));
    return state;
}

[[nodiscard]] bool SetVisibleDescendantValueByName(HWND hwnd,
                                                   const CONTROLTYPEID expectedControlType,
                                                   std::wstring_view expectedName,
                                                   std::wstring_view value) noexcept
{
    wil::com_ptr<IUIAutomationElement> element;
    if (! FindMatchingVisibleDescendantElement(hwnd, expectedControlType, expectedName, element.put()) || ! element)
    {
        return false;
    }

    wil::com_ptr<IUIAutomationValuePattern> valuePattern;
    if (FAILED(element->GetCurrentPatternAs(UIA_ValuePatternId, __uuidof(IUIAutomationValuePattern), valuePattern.put_void())) || ! valuePattern)
    {
        return false;
    }

    BOOL readOnly = FALSE;
    if (SUCCEEDED(valuePattern->get_CurrentIsReadOnly(&readOnly)) && readOnly != FALSE)
    {
        return false;
    }

    const std::wstring newValueText{value};
    const wil::unique_bstr newValue(SysAllocString(newValueText.c_str()));
    if (! newValue && ! newValueText.empty())
    {
        return false;
    }

    const HRESULT actionHr = valuePattern->SetValue(newValue.get());
    if (FAILED(actionHr))
    {
        SelfTest::AppendSelfTestTrace(std::format(L"UIA helper: ValuePattern.SetValue failed with HRESULT 0x{:08X}.", static_cast<uint32_t>(actionHr)));
    }
    return SUCCEEDED(actionHr);
}

template <typename Action>
[[nodiscard]] bool RunUiaActionWithMessagePump(std::wstring_view timeoutOperation,
                                               std::wstring_view label,
                                               const uint32_t timeoutBudgetMs,
                                               Action&& action) noexcept
{
    struct SharedState
    {
        SharedState()                              = default;
        SharedState(const SharedState&)            = delete;
        SharedState& operator=(const SharedState&) = delete;
        SharedState(SharedState&&)                 = delete;
        SharedState& operator=(SharedState&&)      = delete;

        bool result = false;
        UiaOperationLifetime lifetime;
    };

    auto sharedState = std::make_shared<SharedState>();
    std::jthread worker([sharedState, timeoutBudgetMs, action = std::forward<Action>(action)](const std::stop_token stopToken) mutable noexcept
    {
        ExecuteBoundedUiaWorker(sharedState,
                                stopToken,
                                timeoutBudgetMs,
                                [&]() noexcept
        {
            if constexpr (std::is_invocable_r_v<bool, Action&, std::stop_token>)
            {
                sharedState->result = std::invoke(action, stopToken);
            }
            else
            {
                sharedState->result = std::invoke(action);
            }
        });
    });

    return WaitForBoundedUiaWorker(worker, sharedState->lifetime, timeoutBudgetMs, timeoutOperation, label) && sharedState->result;
}

template <typename Action> [[nodiscard]] bool RunUiaActionWithMessagePump(std::wstring_view timeoutOperation, std::wstring_view label, Action&& action) noexcept
{
    constexpr uint32_t kUiaActionDispatchTimeoutBudgetMs = 7000u;
    return RunUiaActionWithMessagePump(timeoutOperation, label, kUiaActionDispatchTimeoutBudgetMs, std::forward<Action>(action));
}

[[nodiscard]] bool TestUiaActionDeadlineCancelsBlockedOperation(CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    struct BlockingProbe final
    {
        BlockingProbe()                                = default;
        BlockingProbe(const BlockingProbe&)            = delete;
        BlockingProbe& operator=(const BlockingProbe&) = delete;
        BlockingProbe(BlockingProbe&&)                 = delete;
        BlockingProbe& operator=(BlockingProbe&&)      = delete;

        std::atomic<bool> entered              = false;
        std::atomic<bool> cancellationObserved = false;
        std::atomic<bool> exited               = false;
    };

    constexpr uint32_t kBlockedOperationBudgetMs = 4000u;
    const UiaDeadlineBudget deadlineBudget       = MakeUiaDeadlineBudget(kBlockedOperationBudgetMs);
    const auto cancellationReserve               = deadlineBudget.total - deadlineBudget.operation;
    const auto cancellationDelay                 = cancellationReserve / 2;
    auto probe                                   = std::make_shared<BlockingProbe>();
    const auto started                           = std::chrono::steady_clock::now();
    const bool result                            = RunUiaActionWithMessagePump(L"blocking-provider lifetime proof",
                                                                               L"deterministic blocked UIA operation",
                                                                               kBlockedOperationBudgetMs,
                                                                               [probe, cancellationDelay](const std::stop_token stopToken) noexcept
    {
        probe->entered.store(true, std::memory_order_release);
        // A fixed sleep can finish before a heavily scheduled harness observes the operation deadline. Keep the synthetic
        // provider blocked until the deadline path requests cancellation, then occupy part of the reserved cancellation budget
        // so WaitForBoundedUiaWorker must join the retiring operation before reporting the timeout.
        while (! stopToken.stop_requested())
        {
            std::this_thread::sleep_for(1ms);
        }
        probe->cancellationObserved.store(true, std::memory_order_release);
        std::this_thread::sleep_for(cancellationDelay);
        probe->exited.store(true, std::memory_order_release);
        return true;
    });
    const auto elapsed                           = std::chrono::steady_clock::now() - started;

    state.Require(probe->entered.load(std::memory_order_acquire), L"Bounded UIA dispatch should start the deterministic blocked operation.");
    state.Require(! result, L"Bounded UIA dispatch should report the blocked operation as timed out.");
    state.Require(probe->cancellationObserved.load(std::memory_order_acquire),
                  L"Bounded UIA dispatch should request cancellation after the operation deadline.");
    state.Require(probe->exited.load(std::memory_order_acquire),
                  L"Bounded UIA dispatch should join the cancelled operation before returning the failed result.");
    state.Require(elapsed < deadlineBudget.total,
                  std::format(L"Bounded UIA dispatch should return the failed result within its declared {} ms budget; elapsed={} ms.",
                              deadlineBudget.total.count(),
                              std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count()));
    return state.failure.empty();
}

[[nodiscard]] bool SetWindowHostRawProviderValueByNameWithMessagePump(
    HWND hwnd, const CONTROLTYPEID expectedControlType, std::wstring_view expectedName, std::wstring_view value, std::wstring_view label) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    const std::wstring nameCopy  = std::wstring(expectedName);
    const std::wstring valueCopy = std::wstring(value);
    if (GetWindowThreadProcessId(hwnd, nullptr) == GetCurrentThreadId())
    {
        return SetWindowHostRawProviderValueByName(hwnd, expectedControlType, nameCopy, valueCopy);
    }

    return RunUiaActionWithMessagePump(L"raw ValuePattern SetValue", label, [hwnd, expectedControlType, nameCopy, valueCopy]() noexcept {
        return SetWindowHostRawProviderValueByName(hwnd, expectedControlType, nameCopy, valueCopy);
    });
}

[[nodiscard]] bool SetVisibleDescendantValueByNameWithMessagePump(
    HWND hwnd, const CONTROLTYPEID expectedControlType, std::wstring_view expectedName, std::wstring_view value, std::wstring_view label) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    const std::wstring nameCopy  = std::wstring(expectedName);
    const std::wstring valueCopy = std::wstring(value);
    return RunUiaActionWithMessagePump(L"ValuePattern SetValue", label, [hwnd, expectedControlType, nameCopy, valueCopy]() noexcept {
        return SetVisibleDescendantValueByName(hwnd, expectedControlType, nameCopy, valueCopy);
    });
}

[[nodiscard]] std::optional<UiaValuePatternState> CollectVisibleDescendantValuePatternStateWithMessagePump(HWND hwnd,
                                                                                                           const CONTROLTYPEID expectedControlType,
                                                                                                           std::wstring_view label) noexcept
{
    using namespace std::chrono_literals;

    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return std::nullopt;
    }

    struct SharedState
    {
        SharedState()                              = default;
        SharedState(const SharedState&)            = delete;
        SharedState& operator=(const SharedState&) = delete;
        SharedState(SharedState&&)                 = delete;
        SharedState& operator=(SharedState&&)      = delete;

        std::optional<UiaValuePatternState> result;
        UiaOperationLifetime lifetime;
    };

    auto sharedState = std::make_shared<SharedState>();
    std::jthread worker([sharedState, hwnd, expectedControlType](const std::stop_token stopToken) noexcept
    {
        ExecuteBoundedUiaWorker(
            sharedState, stopToken, 3000u, [&]() noexcept { sharedState->result = CollectVisibleDescendantValuePatternState(hwnd, expectedControlType); });
    });

    return WaitForBoundedUiaWorker(worker, sharedState->lifetime, 3000u, L"ValuePattern read", label) ? sharedState->result : std::nullopt;
}

[[nodiscard]] std::optional<UiaValuePatternState> CollectVisibleDescendantValuePatternStateByNameWithMessagePump(HWND hwnd,
                                                                                                                 const CONTROLTYPEID expectedControlType,
                                                                                                                 std::wstring_view expectedName,
                                                                                                                 std::wstring_view label) noexcept
{
    using namespace std::chrono_literals;

    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return std::nullopt;
    }

    struct SharedState
    {
        SharedState()                              = default;
        SharedState(const SharedState&)            = delete;
        SharedState& operator=(const SharedState&) = delete;
        SharedState(SharedState&&)                 = delete;
        SharedState& operator=(SharedState&&)      = delete;

        std::optional<UiaValuePatternState> result;
        UiaOperationLifetime lifetime;
    };

    auto sharedState            = std::make_shared<SharedState>();
    const std::wstring nameCopy = std::wstring(expectedName);
    std::jthread worker([sharedState, hwnd, expectedControlType, nameCopy](const std::stop_token stopToken) noexcept
    {
        ExecuteBoundedUiaWorker(sharedState, stopToken, 3000u, [&]() noexcept {
            sharedState->result = CollectVisibleDescendantValuePatternStateByName(hwnd, expectedControlType, nameCopy);
        });
    });

    return WaitForBoundedUiaWorker(worker, sharedState->lifetime, 3000u, L"ValuePattern named read", label) ? sharedState->result : std::nullopt;
}

[[nodiscard]] std::optional<UiaTogglePatternState> CollectVisibleDescendantTogglePatternStateWithMessagePump(HWND hwnd, std::wstring_view label) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return std::nullopt;
    }

    struct SharedState
    {
        SharedState()                              = default;
        SharedState(const SharedState&)            = delete;
        SharedState& operator=(const SharedState&) = delete;
        SharedState(SharedState&&)                 = delete;
        SharedState& operator=(SharedState&&)      = delete;

        std::optional<UiaTogglePatternState> result;
        UiaOperationLifetime lifetime;
    };

    auto sharedState = std::make_shared<SharedState>();
    std::jthread worker([sharedState, hwnd](const std::stop_token stopToken) noexcept
    { ExecuteBoundedUiaWorker(sharedState, stopToken, 3000u, [&]() noexcept { sharedState->result = CollectVisibleDescendantTogglePatternState(hwnd); }); });

    return WaitForBoundedUiaWorker(worker, sharedState->lifetime, 3000u, L"TogglePattern read", label) ? sharedState->result : std::nullopt;
}

[[nodiscard]] std::optional<UiaTogglePatternState> CollectVisibleDescendantTogglePatternStateByNameWithMessagePump(HWND hwnd,
                                                                                                                   std::wstring_view expectedName,
                                                                                                                   std::wstring_view label) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return std::nullopt;
    }

    struct SharedState
    {
        SharedState()                              = default;
        SharedState(const SharedState&)            = delete;
        SharedState& operator=(const SharedState&) = delete;
        SharedState(SharedState&&)                 = delete;
        SharedState& operator=(SharedState&&)      = delete;

        std::optional<UiaTogglePatternState> result;
        UiaOperationLifetime lifetime;
    };

    auto sharedState            = std::make_shared<SharedState>();
    const std::wstring nameCopy = std::wstring(expectedName);
    std::jthread worker([sharedState, hwnd, nameCopy](const std::stop_token stopToken) noexcept
    {
        ExecuteBoundedUiaWorker(
            sharedState, stopToken, 3000u, [&]() noexcept { sharedState->result = CollectVisibleDescendantTogglePatternStateByName(hwnd, nameCopy); });
    });

    return WaitForBoundedUiaWorker(worker, sharedState->lifetime, 3000u, L"TogglePattern named read", label) ? sharedState->result : std::nullopt;
}

template <typename Predicate>
[[nodiscard]] bool WaitForVisibleDescendantValuePatternState(
    HWND hwnd, const CONTROLTYPEID expectedControlType, Predicate&& predicate, std::optional<UiaValuePatternState>& outState, std::wstring_view label) noexcept
{
    using namespace std::chrono_literals;

    outState.reset();
    const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(3000ms);
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        const auto valueState = CollectVisibleDescendantValuePatternStateWithMessagePump(hwnd, expectedControlType, label);
        if (valueState.has_value())
        {
            outState = valueState;
            if (predicate(valueState.value()))
            {
                return true;
            }
        }
        std::this_thread::sleep_for(20ms);
    }

    const auto valueState = CollectVisibleDescendantValuePatternStateWithMessagePump(hwnd, expectedControlType, label);
    if (valueState.has_value())
    {
        outState = valueState;
        return predicate(valueState.value());
    }

    return false;
}

[[nodiscard]] bool SetElementValue(IUIAutomationElement& element, std::wstring_view value) noexcept;

[[maybe_unused]] [[nodiscard]] bool SetFocusedValue(HWND hwnd, const CONTROLTYPEID expectedControlType, std::wstring_view value) noexcept
{
    IUIAutomation* automation = GetThreadUiAutomation();
    if (! automation)
    {
        return false;
    }

    wil::com_ptr<IUIAutomationElement> element;
    if (FAILED(automation->GetFocusedElement(element.addressof())) || ! element || ! FocusedElementBelongsToWindow(*element, hwnd))
    {
        return false;
    }

    CONTROLTYPEID controlType = 0;
    if (FAILED(element->get_CurrentControlType(&controlType)) || (expectedControlType != 0 && controlType != expectedControlType))
    {
        return false;
    }

    return SetElementValue(*element, value);
}

[[nodiscard]] bool SetElementValue(IUIAutomationElement& element, std::wstring_view value) noexcept
{
    wil::com_ptr<IUIAutomationValuePattern> valuePattern;
    if (FAILED(element.GetCurrentPatternAs(UIA_ValuePatternId, __uuidof(IUIAutomationValuePattern), valuePattern.put_void())) || ! valuePattern)
    {
        return false;
    }

    BOOL readOnly = FALSE;
    if (SUCCEEDED(valuePattern->get_CurrentIsReadOnly(&readOnly)) && readOnly != FALSE)
    {
        return false;
    }

    const std::wstring newValueText{value};
    const wil::unique_bstr newValue(SysAllocString(newValueText.c_str()));
    if (! newValue && ! newValueText.empty())
    {
        return false;
    }

    const HRESULT actionHr = valuePattern->SetValue(newValue.get());
    if (FAILED(actionHr))
    {
        SelfTest::AppendSelfTestTrace(std::format(L"UIA helper: ValuePattern.SetValue failed with HRESULT 0x{:08X}.", static_cast<uint32_t>(actionHr)));
    }
    return SUCCEEDED(actionHr);
}

[[nodiscard]] bool SetVisibleDescendantValue(HWND hwnd,
                                             const CONTROLTYPEID expectedControlType,
                                             std::wstring_view expectedName,
                                             std::wstring_view value) noexcept;

[[nodiscard]] bool SetWindowRootOrDescendantValue(HWND hwnd,
                                                  const CONTROLTYPEID expectedControlType,
                                                  std::wstring_view expectedName,
                                                  std::wstring_view value) noexcept
{
    IUIAutomation* automation = GetThreadUiAutomation();
    if (! automation)
    {
        return false;
    }

    wil::com_ptr<IUIAutomationElement> root;
    if (expectedName.empty() && SUCCEEDED(automation->ElementFromHandle(hwnd, root.addressof())) && root)
    {
        CONTROLTYPEID controlType = 0;
        if (SUCCEEDED(root->get_CurrentControlType(&controlType)) && (expectedControlType == 0 || controlType == expectedControlType))
        {
            if (SetElementValue(*root, value))
            {
                return true;
            }
        }
    }

    return SetVisibleDescendantValue(hwnd, expectedControlType, expectedName, value);
}

[[nodiscard]] bool SetWindowRootOrDescendantValue(HWND hwnd, const CONTROLTYPEID expectedControlType, std::wstring_view value) noexcept
{
    return SetWindowRootOrDescendantValue(hwnd, expectedControlType, {}, value);
}

[[nodiscard]] bool SetVisibleDescendantValue(HWND hwnd,
                                             const CONTROLTYPEID expectedControlType,
                                             std::wstring_view expectedName,
                                             std::wstring_view value) noexcept
{
    wil::com_ptr<IUIAutomationElement> element;
    if (! FindMatchingVisibleDescendantElement(hwnd, expectedControlType, expectedName, element.put()) || ! element)
    {
        return SetWindowHostRawProviderValueByName(hwnd, expectedControlType, expectedName, value);
    }

    return SetElementValue(*element, value);
}

[[nodiscard]] bool SetVisibleDescendantValueWithMessagePump(
    HWND hwnd, const CONTROLTYPEID expectedControlType, std::wstring_view expectedName, std::wstring_view value, std::wstring_view label) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    const std::wstring nameCopy  = std::wstring(expectedName);
    const std::wstring valueCopy = std::wstring(value);
    return RunUiaActionWithMessagePump(L"ValuePattern SetValue", label, [hwnd, expectedControlType, nameCopy, valueCopy]() noexcept {
        return SetVisibleDescendantValue(hwnd, expectedControlType, nameCopy, valueCopy);
    });
}

[[nodiscard]] bool SetVisibleDescendantValueWithMessagePump(HWND hwnd,
                                                            const CONTROLTYPEID expectedControlType,
                                                            std::wstring_view value,
                                                            std::wstring_view label) noexcept
{
    return SetVisibleDescendantValueWithMessagePump(hwnd, expectedControlType, {}, value, label);
}

[[nodiscard]] bool ToggleVisibleDescendantByName(HWND hwnd, std::wstring_view expectedName) noexcept
{
    wil::com_ptr<IUIAutomationElement> element;
    if (! FindVisibleToggleDescendantElement(hwnd, expectedName, element.put()) || ! element)
    {
        return false;
    }

    wil::com_ptr<IUIAutomationTogglePattern> togglePattern;
    if (FAILED(element->GetCurrentPatternAs(UIA_TogglePatternId, __uuidof(IUIAutomationTogglePattern), togglePattern.put_void())) || ! togglePattern)
    {
        return false;
    }

    const HRESULT actionHr = togglePattern->Toggle();
    if (FAILED(actionHr))
    {
        SelfTest::AppendSelfTestTrace(std::format(L"UIA helper: TogglePattern.Toggle failed with HRESULT 0x{:08X}.", static_cast<uint32_t>(actionHr)));
    }
    return SUCCEEDED(actionHr);
}

[[nodiscard]] bool ToggleVisibleDescendantByNameWithMessagePump(HWND hwnd, std::wstring_view expectedName, std::wstring_view label) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    const std::wstring nameCopy = std::wstring(expectedName);
    return RunUiaActionWithMessagePump(L"TogglePattern Toggle", label, [hwnd, nameCopy]() noexcept { return ToggleVisibleDescendantByName(hwnd, nameCopy); });
}

[[nodiscard]] bool InvokeVisibleDescendantByName(HWND hwnd, const CONTROLTYPEID expectedControlType, std::wstring_view expectedName) noexcept
{
    wil::com_ptr<IUIAutomationElement> element;
    if (! FindMatchingVisibleDescendantElement(hwnd, expectedControlType, expectedName, element.put()) || ! element)
    {
        return InvokeWindowHostRawProviderDescendantByName(hwnd, expectedControlType, expectedName);
    }

    wil::com_ptr<IUIAutomationInvokePattern> invokePattern;
    if (FAILED(element->GetCurrentPatternAs(UIA_InvokePatternId, __uuidof(IUIAutomationInvokePattern), invokePattern.put_void())) || ! invokePattern)
    {
        return InvokeWindowHostRawProviderDescendantByName(hwnd, expectedControlType, expectedName);
    }

    // Once lookup succeeds, Invoke may close the window before returning its HRESULT. Retrying through
    // the raw provider here can execute the action twice, so raw fallback is lookup-only.
    const HRESULT actionHr = invokePattern->Invoke();
    if (FAILED(actionHr))
    {
        SelfTest::AppendSelfTestTrace(std::format(L"UIA helper: InvokePattern.Invoke failed with HRESULT 0x{:08X}.", static_cast<uint32_t>(actionHr)));
    }
    return SUCCEEDED(actionHr);
}

[[nodiscard]] bool InvokeVisibleDescendantByNameWithMessagePump(HWND hwnd,
                                                                const CONTROLTYPEID expectedControlType,
                                                                std::wstring_view expectedName,
                                                                std::wstring_view label) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    const std::wstring nameCopy = std::wstring(expectedName);
    return RunUiaActionWithMessagePump(L"InvokePattern", label, [hwnd, expectedControlType, nameCopy]() noexcept {
        return InvokeVisibleDescendantByName(hwnd, expectedControlType, nameCopy);
    });
}

[[nodiscard]] bool ClickVisibleDescendantByName(HWND hwnd, const CONTROLTYPEID expectedControlType, std::wstring_view expectedName) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    wil::com_ptr<IUIAutomationElement> element;
    if (! FindMatchingVisibleDescendantElement(hwnd, expectedControlType, expectedName, element.put()) || ! element)
    {
        return false;
    }

    RECT bounds{};
    if (FAILED(element->get_CurrentBoundingRectangle(&bounds)) || bounds.right <= bounds.left || bounds.bottom <= bounds.top)
    {
        return false;
    }

    POINT center{
        bounds.left + ((bounds.right - bounds.left) / 2),
        bounds.top + ((bounds.bottom - bounds.top) / 2),
    };
    if (ScreenToClient(hwnd, &center) == FALSE)
    {
        return false;
    }

    SendMouseClickToResolvedPointWindow(hwnd, MAKELPARAM(center.x, center.y));
    return true;
}

void AppendVisibleDescendantNamesToTrace(HWND hwnd, const CONTROLTYPEID expectedControlType, std::wstring_view label) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return;
    }

    std::wstring trace = std::format(L"UIA helper: visible descendants {} type={}: ", label, expectedControlType);
    bool appended      = false;
    for (const auto& element : FindMatchingVisibleDescendantElements(hwnd, expectedControlType))
    {
        if (! element)
        {
            continue;
        }

        if (appended)
        {
            trace.append(L" | ");
        }

        CONTROLTYPEID controlType = expectedControlType;
        static_cast<void>(element->get_CurrentControlType(&controlType));

        wil::unique_bstr name;
        std::wstring nameText;
        if (SUCCEEDED(element->get_CurrentName(&name)))
        {
            nameText.assign(name.get() ? name.get() : L"");
        }

        trace.append(std::format(L"[type={} name='{}']", controlType, nameText));
        appended = true;
    }

    if (! appended)
    {
        trace.append(L"(none)");
    }

    SelfTest::AppendSelfTestTrace(trace);
}

template <typename Predicate>
[[nodiscard]] bool WaitForConnectionCredentialPromptSnapshot(Predicate&& predicate,
                                                             std::chrono::milliseconds timeout,
                                                             ConnectionCredentialPromptDebugSnapshot* outSnapshot = nullptr) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        ConnectionCredentialPromptDebugSnapshot snapshot{};
        if (DebugGetConnectionCredentialPromptSnapshot(snapshot) && predicate(snapshot))
        {
            if (outSnapshot)
            {
                *outSnapshot = std::move(snapshot);
            }
            return true;
        }

        std::this_thread::sleep_for(10ms);
    }

    if (outSnapshot)
    {
        ConnectionCredentialPromptDebugSnapshot snapshot{};
        if (DebugGetConnectionCredentialPromptSnapshot(snapshot))
        {
            *outSnapshot = std::move(snapshot);
        }
    }
    return false;
}

struct WindowEnumContext final
{
    DWORD processId                        = 0;
    std::unordered_set<uintptr_t>* windows = nullptr;
};

BOOL CALLBACK EnumTopLevelWindowsProc(HWND hwnd, LPARAM lParam) noexcept
{
    auto* ctx = reinterpret_cast<WindowEnumContext*>(lParam);
    if (! ctx || ! ctx->windows || ! hwnd)
    {
        return TRUE;
    }

    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid != ctx->processId || DirectedSelfTestInputWarning::IsWarningWindow(hwnd))
    {
        return TRUE;
    }

    ctx->windows->insert(reinterpret_cast<uintptr_t>(hwnd));
    return TRUE;
}

[[nodiscard]] std::unordered_set<uintptr_t> SnapshotTopLevelWindowsForProcess(DWORD processId) noexcept
{
    std::unordered_set<uintptr_t> windows;
    WindowEnumContext ctx{};
    ctx.processId = processId;
    ctx.windows   = &windows;
    EnumWindows(EnumTopLevelWindowsProc, reinterpret_cast<LPARAM>(&ctx));
    return windows;
}

void CloseNonBaselineWindows(DWORD processId, const std::unordered_set<uintptr_t>& baseline, HWND mainWindow) noexcept
{
    const auto current = SnapshotTopLevelWindowsForProcess(processId);
    for (const uintptr_t raw : current)
    {
        if (baseline.contains(raw))
        {
            continue;
        }

        const HWND hwnd = reinterpret_cast<HWND>(raw);
        if (! hwnd || hwnd == mainWindow)
        {
            continue;
        }
        if (IsWindowVisible(hwnd) == FALSE)
        {
            continue;
        }

        PostMessageW(hwnd, WM_KEYDOWN, VK_ESCAPE, 0);
        PostMessageW(hwnd, WM_KEYUP, VK_ESCAPE, 0);
        PostMessageW(hwnd, WM_CLOSE, 0, 0);
    }
}

void AutoCloseTransientUi(std::stop_token stopToken, DWORD uiThreadId, DWORD processId, const std::unordered_set<uintptr_t>& baseline, HWND mainWindow) noexcept
{
    using namespace std::chrono_literals;

    while (! stopToken.stop_requested())
    {
        GUITHREADINFO gti{};
        gti.cbSize = sizeof(gti);
        if (GetGUIThreadInfo(uiThreadId, &gti) != FALSE && (gti.flags & GUI_INMENUMODE) != 0)
        {
            const HWND target = gti.hwndMenuOwner ? gti.hwndMenuOwner : (gti.hwndActive ? gti.hwndActive : mainWindow);
            if (target)
            {
                PostMessageW(target, WM_KEYDOWN, VK_ESCAPE, 0);
                PostMessageW(target, WM_KEYUP, VK_ESCAPE, 0);
            }
        }

        CloseNonBaselineWindows(processId, baseline, mainWindow);
        std::this_thread::sleep_for(30ms);
    }
}

[[nodiscard]] bool HasNonBaselineWindows(DWORD processId, const std::unordered_set<uintptr_t>& baseline, HWND mainWindow) noexcept
{
    const auto current = SnapshotTopLevelWindowsForProcess(processId);
    for (const uintptr_t raw : current)
    {
        if (baseline.contains(raw))
        {
            continue;
        }

        const HWND hwnd = reinterpret_cast<HWND>(raw);
        if (! hwnd || hwnd == mainWindow)
        {
            continue;
        }
        if (IsWindowVisible(hwnd) == FALSE)
        {
            continue;
        }

        return true;
    }

    return false;
}

[[nodiscard]] std::wstring DescribeNonBaselineWindows(DWORD processId, const std::unordered_set<uintptr_t>& baseline, HWND mainWindow)
{
    const auto current = SnapshotTopLevelWindowsForProcess(processId);
    std::wstring details;
    size_t reported = 0u;
    size_t total    = 0u;

    for (const uintptr_t raw : current)
    {
        if (baseline.contains(raw))
        {
            continue;
        }

        const HWND hwnd = reinterpret_cast<HWND>(raw);
        if (! hwnd || hwnd == mainWindow)
        {
            continue;
        }
        if (IsWindowVisible(hwnd) == FALSE)
        {
            continue;
        }

        ++total;
        if (reported >= 8u)
        {
            continue;
        }

        std::array<wchar_t, 128> className{};
        static_cast<void>(GetClassNameW(hwnd, className.data(), static_cast<int>(className.size())));

        std::wstring title;
        const int titleLength = GetWindowTextLengthW(hwnd);
        if (titleLength > 0)
        {
            std::wstring buffer(static_cast<size_t>(titleLength) + 1u, L'\0');
            const int copied = GetWindowTextW(hwnd, buffer.data(), static_cast<int>(buffer.size()));
            if (copied > 0)
            {
                buffer.resize(static_cast<size_t>(copied));
                title = std::move(buffer);
            }
        }

        if (! details.empty())
        {
            details.append(L"; ");
        }
        details.append(std::format(L"0x{:X} class='{}' title='{}' visible={} enabled={} owner=0x{:X} style=0x{:X} exStyle=0x{:X}",
                                   reinterpret_cast<uintptr_t>(hwnd),
                                   className.data(),
                                   title,
                                   IsWindowVisible(hwnd) != FALSE ? 1 : 0,
                                   IsWindowEnabled(hwnd) != FALSE ? 1 : 0,
                                   reinterpret_cast<uintptr_t>(GetWindow(hwnd, GW_OWNER)),
                                   static_cast<uintptr_t>(GetWindowLongPtrW(hwnd, GWL_STYLE)),
                                   static_cast<uintptr_t>(GetWindowLongPtrW(hwnd, GWL_EXSTYLE))));
        ++reported;
    }

    if (details.empty())
    {
        return L"none";
    }
    if (total > reported)
    {
        details.append(std::format(L"; ... {} more", total - reported));
    }
    return details;
}

[[nodiscard]] bool EnsureUiNotInMenuMode(DWORD uiThreadId, HWND fallbackTarget, std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();

        GUITHREADINFO gti{};
        gti.cbSize = sizeof(gti);
        if (GetGUIThreadInfo(uiThreadId, &gti) == FALSE)
        {
            return false;
        }

        if ((gti.flags & GUI_INMENUMODE) == 0)
        {
            return true;
        }

        const HWND target = gti.hwndMenuOwner ? gti.hwndMenuOwner : (gti.hwndActive ? gti.hwndActive : fallbackTarget);
        if (target)
        {
            PostMessageW(target, WM_KEYDOWN, VK_ESCAPE, 0);
            PostMessageW(target, WM_KEYUP, VK_ESCAPE, 0);
        }

        std::this_thread::sleep_for(30ms);
    }

    GUITHREADINFO gti{};
    gti.cbSize = sizeof(gti);
    return GetGUIThreadInfo(uiThreadId, &gti) != FALSE && (gti.flags & GUI_INMENUMODE) == 0;
}

[[nodiscard]] bool WaitForNoNonBaselineWindows(DWORD processId,
                                               const std::unordered_set<uintptr_t>& baseline,
                                               HWND mainWindow,
                                               std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();

        CloseNonBaselineWindows(processId, baseline, mainWindow);
        if (! HasNonBaselineWindows(processId, baseline, mainWindow))
        {
            return true;
        }
        std::this_thread::sleep_for(30ms);
    }

    return ! HasNonBaselineWindows(processId, baseline, mainWindow);
}

[[nodiscard]] bool CloseNonMainTopLevelWindowsForSelfTest(DWORD processId, HWND mainWindow, std::chrono::milliseconds timeout) noexcept
{
    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        return false;
    }

    const HWND rootWindow     = GetAncestor(mainWindow, GA_ROOT);
    const HWND baselineWindow = rootWindow && IsWindow(rootWindow) != FALSE ? rootWindow : mainWindow;
    std::unordered_set<uintptr_t> baseline;
    baseline.insert(reinterpret_cast<uintptr_t>(baselineWindow));
    return WaitForNoNonBaselineWindows(processId, baseline, baselineWindow, timeout);
}

void FocusFolderViewPane(FolderWindow::Pane pane) noexcept;
[[nodiscard]] bool WaitForFolderViewPaneFocus(FolderWindow::Pane pane, HWND expectedFolderView, std::chrono::milliseconds timeout) noexcept;

void ClearPaneIncrementalSearchForSelfTest(FolderWindow::Pane pane) noexcept
{
    // A previous directed-input case can leave a queued activation or character
    // behind the state visible to the next fixture. Drain first, then clear again
    // after dispatch so the shared FolderView is genuinely quiescent.
    for (size_t attempt = 0u; attempt < 2u; ++attempt)
    {
        PumpPendingMessages();
        g_folderWindow.DebugExitIncrementalSearch(pane);
    }
}

void ClearPaneNavigationTransientStateForSelfTest(FolderWindow::Pane pane) noexcept
{
    constexpr size_t kMaximumEscapeAttempts = 4u;
    for (size_t attempt = 0u; attempt < kMaximumEscapeAttempts; ++attempt)
    {
        NavigationViewDebugSnapshot snapshot{};
        if (! g_folderWindow.DebugGetNavigationViewSnapshot(pane, snapshot))
        {
            return;
        }

        const bool transientStateActive = snapshot.editMode || snapshot.historyDropdownVisible || snapshot.editSuggestPopupVisible ||
                                          snapshot.fullPathPopupVisible || snapshot.currentEditValidationPopupVisible ||
                                          snapshot.dropdownKind != NavigationViewDebugDropdownKind::None;
        if (! transientStateActive)
        {
            return;
        }

        const HWND navigationView = g_folderWindow.DebugGetNavigationViewHwnd(pane);
        if (! navigationView || IsWindow(navigationView) == FALSE)
        {
            return;
        }

        static_cast<void>(SendMessageW(navigationView, WM_KEYDOWN, VK_ESCAPE, 0));
        static_cast<void>(SendMessageW(navigationView, WM_KEYUP, VK_ESCAPE, 0));
        PumpPendingMessages();
    }
}

[[nodiscard]] bool PrepareMainWindowForIsolatedUiCase(HWND mainWindow, CaseState& state, std::wstring_view context) noexcept
{
    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, std::format(L"Main window handle invalid before {}.", context));
        return false;
    }

    state.Require(CloseNonMainTopLevelWindowsForSelfTest(GetCurrentProcessId(), mainWindow, SelfTest::Scale(std::chrono::milliseconds(3000))),
                  std::format(L"Inherited top-level windows did not close before {}.", context));
    // Do not let UI Automation cache providers for a window destroyed by the
    // previous case. HWND reuse in a broad shared process can otherwise expose
    // stale names/values from the retired provider to the next fixture.
    ReleaseThreadUiAutomationForSelfTest();
    PumpPendingMessages();
    state.Require(IsWindowEnabled(mainWindow) != FALSE, std::format(L"Main window remained disabled before {}.", context));
    const DWORD uiThreadId = GetWindowThreadProcessId(mainWindow, nullptr);
    state.Require(uiThreadId != 0u && EnsureUiNotInMenuMode(uiThreadId, mainWindow, SelfTest::Scale(std::chrono::milliseconds(2000))),
                  std::format(L"Inherited native menu mode did not close before {}.", context));
    if (! state.failure.empty())
    {
        return false;
    }

    DebugSetMainMenuBarHoverSuppressionCursorOverride(std::nullopt);
    DebugHideThemeCycleOverlay();

    const HWND rootWindow  = GetAncestor(mainWindow, GA_ROOT);
    const HWND inputWindow = rootWindow && IsWindow(rootWindow) != FALSE ? rootWindow : mainWindow;
    ShowWindow(inputWindow, SW_SHOWNORMAL);
    static_cast<void>(BringWindowToTop(inputWindow));
    static_cast<void>(SetActiveWindow(inputWindow));
    static_cast<void>(SetForegroundWindow(inputWindow));
    PumpPendingMessages();

    // Terminal and preview surfaces share the pane content host. Close terminal
    // children first so the preview-retirement wait counts only viewer roots.
    g_folderWindow.DebugCloseTerminalPane(FolderWindow::Pane::Left);
    g_folderWindow.DebugCloseTerminalPane(FolderWindow::Pane::Right);
    PumpPendingMessages();
    state.Require(CloseActivePreviewPaneForSelfTest(SelfTest::Scale(std::chrono::milliseconds(3000))),
                  std::format(L"Inherited preview pane did not close before {}.", context));
    if (! state.failure.empty())
    {
        return false;
    }
    g_folderWindow.SetZoomState(std::nullopt, std::nullopt);
    g_folderWindow.SetSplitRatio(0.5f);
    g_folderWindow.DebugResetPaneVisibilityState(FolderWindow::Pane::Left);
    g_folderWindow.DebugResetPaneVisibilityState(FolderWindow::Pane::Right);
    g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
    g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Right);
    ClearPaneNavigationTransientStateForSelfTest(FolderWindow::Pane::Left);
    ClearPaneNavigationTransientStateForSelfTest(FolderWindow::Pane::Right);
    ClearPaneIncrementalSearchForSelfTest(FolderWindow::Pane::Left);
    ClearPaneIncrementalSearchForSelfTest(FolderWindow::Pane::Right);
    const HWND leftFolderView = g_folderWindow.GetFolderViewHwnd(FolderWindow::Pane::Left);
    state.Require(WaitForFolderViewPaneFocus(FolderWindow::Pane::Left, leftFolderView, SelfTest::Scale(std::chrono::milliseconds(1500))),
                  std::format(L"Main folder view did not regain stable focus before {}.", context));
    if (! state.failure.empty())
    {
        return false;
    }

    // Directed input and teardown completions from the previous case may be
    // delivered after the first focus handoff. Give that queue a bounded quiet
    // point, then clear any transient navigation/search state they created and
    // prove focus again before the next case begins.
    for (size_t settleAttempt = 0u; settleAttempt < 3u; ++settleAttempt)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds{20});
        PumpPendingMessages();
    }
    ClearPaneNavigationTransientStateForSelfTest(FolderWindow::Pane::Left);
    ClearPaneNavigationTransientStateForSelfTest(FolderWindow::Pane::Right);
    ClearPaneIncrementalSearchForSelfTest(FolderWindow::Pane::Left);
    ClearPaneIncrementalSearchForSelfTest(FolderWindow::Pane::Right);
    state.Require(WaitForFolderViewPaneFocus(FolderWindow::Pane::Left, leftFolderView, SelfTest::Scale(std::chrono::milliseconds(1000))),
                  std::format(L"Main folder view focus was not stable after input settling before {}.", context));
    return state.failure.empty();
}

void FocusFolderViewPane(FolderWindow::Pane pane) noexcept
{
    using namespace std::chrono_literals;

    g_folderWindow.SetActivePane(pane);

    const HWND view = g_folderWindow.GetFolderViewHwnd(pane);
    if (! view || IsWindow(view) == FALSE)
    {
        return;
    }

    const auto deadline  = std::chrono::steady_clock::now() + SelfTest::Scale(250ms);
    size_t stableSamples = 0u;
    while (std::chrono::steady_clock::now() < deadline)
    {
        const HWND rootWindow          = GetAncestor(view, GA_ROOT);
        const HWND foregroundWindow    = GetForegroundWindow();
        const DWORD currentThreadId    = GetCurrentThreadId();
        const DWORD foregroundThreadId = foregroundWindow ? GetWindowThreadProcessId(foregroundWindow, nullptr) : 0u;
        const bool attachedForegroundThread =
            foregroundThreadId != 0u && foregroundThreadId != currentThreadId && AttachThreadInput(foregroundThreadId, currentThreadId, TRUE) != FALSE;
        const auto detachForegroundThread = wil::scope_exit([&]() noexcept
        {
            if (attachedForegroundThread)
            {
                static_cast<void>(AttachThreadInput(foregroundThreadId, currentThreadId, FALSE));
            }
        });

        if (rootWindow && IsWindow(rootWindow) != FALSE && IsWindowEnabled(rootWindow) != FALSE)
        {
            ShowWindow(rootWindow, SW_SHOWNORMAL);
            static_cast<void>(BringWindowToTop(rootWindow));
            static_cast<void>(SetActiveWindow(rootWindow));
            static_cast<void>(SetForegroundWindow(rootWindow));
        }

        if (GetFocus() != view)
        {
            static_cast<void>(SetFocus(view));
        }

        PumpPendingMessages();
        if (GetFocus() == view && g_folderWindow.GetFocusedFolderViewHwnd() == view && g_folderWindow.GetFocusedPane() == pane)
        {
            ++stableSamples;
            if (stableSamples >= 2u)
            {
                return;
            }
        }
        else
        {
            stableSamples = 0u;
        }

        std::this_thread::sleep_for(10ms);
    }

    static_cast<void>(SetFocus(view));
    PumpPendingMessages();
}

[[nodiscard]] bool WaitForFolderViewPaneFocus(FolderWindow::Pane pane, HWND expectedFolderView, std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    if (! expectedFolderView || IsWindow(expectedFolderView) == FALSE)
    {
        return false;
    }

    FocusFolderViewPane(pane);

    const auto deadline  = std::chrono::steady_clock::now() + timeout;
    size_t stableSamples = 0u;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        if (GetFocus() == expectedFolderView && g_folderWindow.GetFocusedFolderViewHwnd() == expectedFolderView && g_folderWindow.GetFocusedPane() == pane)
        {
            ++stableSamples;
            if (stableSamples >= 3u)
            {
                return true;
            }
        }
        else
        {
            stableSamples = 0u;
            FocusFolderViewPane(pane);
        }

        std::this_thread::sleep_for(10ms);
    }

    PumpPendingMessages();
    return GetFocus() == expectedFolderView && g_folderWindow.GetFocusedFolderViewHwnd() == expectedFolderView && g_folderWindow.GetFocusedPane() == pane;
}

[[nodiscard]] bool WaitForTextFileFirstLine(std::filesystem::path const& path,
                                            std::string_view expected,
                                            std::chrono::milliseconds timeout,
                                            std::string& outText) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    std::error_code ec;
    while (std::chrono::steady_clock::now() < deadline)
    {
        outText.clear();
        if (std::filesystem::exists(path, ec))
        {
            std::ifstream input(path);
            std::getline(input, outText);
            if (outText == expected)
            {
                return true;
            }
        }
        ec.clear();

        PumpPendingMessages();
        std::this_thread::sleep_for(20ms);
    }

    outText.clear();
    if (std::filesystem::exists(path, ec))
    {
        std::ifstream input(path);
        std::getline(input, outText);
    }
    return outText == expected;
}

template <typename Predicate>
[[nodiscard]] bool WaitForNavigationViewSnapshot(FolderWindow::Pane pane,
                                                 Predicate&& predicate,
                                                 std::chrono::milliseconds timeout,
                                                 NavigationViewDebugSnapshot* outSnapshot = nullptr) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();

        NavigationViewDebugSnapshot snapshot{};
        if (g_folderWindow.DebugGetNavigationViewSnapshot(pane, snapshot))
        {
            if (outSnapshot != nullptr)
            {
                *outSnapshot = snapshot;
            }

            if (predicate(snapshot))
            {
                return true;
            }
        }

        std::this_thread::sleep_for(20ms);
    }

    NavigationViewDebugSnapshot snapshot{};
    if (g_folderWindow.DebugGetNavigationViewSnapshot(pane, snapshot))
    {
        if (outSnapshot != nullptr)
        {
            *outSnapshot = snapshot;
        }

        if (predicate(snapshot))
        {
            return true;
        }
    }

    return false;
}

[[nodiscard]] bool WaitForPanePath(FolderWindow::Pane pane, const std::filesystem::path& expected, std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();

        const std::optional<std::filesystem::path> current = g_folderWindow.GetCurrentPath(pane);
        if (current.has_value() && OrdinalString::EqualsNoCasePath(current.value(), expected))
        {
            return true;
        }
        std::this_thread::sleep_for(20ms);
    }

    return false;
}

[[nodiscard]] bool WaitForPaneItems(FolderWindow::Pane pane,
                                    std::initializer_list<std::wstring_view> expectedDisplayNames,
                                    std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();

        bool allFound = true;
        for (const std::wstring_view displayName : expectedDisplayNames)
        {
            if (! g_folderWindow.DebugHasItemDisplayName(pane, displayName))
            {
                allFound = false;
                break;
            }
        }

        if (allFound)
        {
            return true;
        }

        std::this_thread::sleep_for(20ms);
    }

    std::wstring missing;
    for (const std::wstring_view displayName : expectedDisplayNames)
    {
        if (g_folderWindow.DebugHasItemDisplayName(pane, displayName))
        {
            continue;
        }

        if (! missing.empty())
        {
            missing.append(L", ");
        }
        missing.append(displayName);
    }

    const std::optional<std::filesystem::path> current = g_folderWindow.GetCurrentPath(pane);
    const FolderView::NameFilterState filterState      = g_folderWindow.DebugGetNameFilterState(pane);
    const wchar_t* paneText                            = pane == FolderWindow::Pane::Left ? L"Left" : L"Right";
    size_t diskEntryCount                              = 0;
    std::error_code ec;
    if (current.has_value())
    {
        for (std::filesystem::directory_iterator it(current.value(), ec), end; ! ec && it != end; it.increment(ec))
        {
            ++diskEntryCount;
        }
    }

    Trace(std::format(L"WaitForPaneItems timeout pane={} path='{}' itemCount={} diskEntryCount={} filterEnabled={} filterText='{}' hiddenNames={} missing='{}'",
                      paneText,
                      current.has_value() ? current->native() : std::wstring(L"<none>"),
                      g_folderWindow.DebugGetItemCount(pane),
                      diskEntryCount,
                      filterState.enabled ? 1 : 0,
                      filterState.text,
                      g_folderWindow.CanShowHiddenNames(pane) ? 1 : 0,
                      missing));

    return false;
}

[[nodiscard]] bool ForceRefreshPaneForCommandSelfTest(HWND mainWindow, FolderWindow::Pane pane, std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        return false;
    }

    g_folderWindow.SetActivePane(pane);
    const uint64_t refreshBefore = g_folderWindow.DebugGetForceRefreshCount(pane);
    if (! DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/refresh"))
    {
        return false;
    }

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetForceRefreshCount(pane) >= refreshBefore + 1u)
        {
            return true;
        }

        std::this_thread::sleep_for(20ms);
    }

    return g_folderWindow.DebugGetForceRefreshCount(pane) >= refreshBefore + 1u;
}

[[nodiscard]] std::wstring DescribeFindSnapshotBrief(const FindFilesDebugSnapshot& snapshot);

[[nodiscard]] bool OpenFindWindowFromLocalPaneRoot(HWND mainWindow,
                                                   const std::filesystem::path& root,
                                                   std::initializer_list<std::wstring_view> expectedItems,
                                                   HWND& outFindWindow,
                                                   std::optional<std::filesystem::path>& outLeftBefore) noexcept;

template <typename Predicate>
[[nodiscard]] bool WaitForFindSnapshot(Predicate&& predicate, std::chrono::milliseconds timeout, FindFilesDebugSnapshot* outSnapshot = nullptr) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    FindFilesDebugSnapshot snapshot{};
    FindFilesDebugSnapshot lastSnapshot{};
    bool hasLastSnapshot = false;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        if (DebugGetFindFilesWindowSnapshot(snapshot))
        {
            lastSnapshot    = snapshot;
            hasLastSnapshot = true;
            if (predicate(snapshot))
            {
                if (outSnapshot)
                {
                    *outSnapshot = snapshot;
                }
                return true;
            }
        }

        std::this_thread::sleep_for(20ms);
    }

    if (DebugGetFindFilesWindowSnapshot(snapshot))
    {
        if (outSnapshot)
        {
            *outSnapshot = snapshot;
        }
        return predicate(snapshot);
    }

    if (outSnapshot && hasLastSnapshot)
    {
        *outSnapshot = lastSnapshot;
    }
    else if (outSnapshot)
    {
        outSnapshot->statusText =
            std::format(L"[snapshot unavailable hwnd=0x{:X}]", static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(GetFindFilesWindowHandle())));
        outSnapshot->backendStatusText = GetFindFilesWindowHandle() ? L"[window present]" : L"[no window]";
    }
    return false;
}

[[nodiscard]] bool SelectPublishedFindResult(const std::wstring& fullPath,
                                             std::chrono::milliseconds timeout,
                                             FindFilesDebugSnapshot* outSnapshot = nullptr) noexcept
{
    FindFilesDebugSnapshot snapshot{};
    const auto containsPath = [&](const FindFilesDebugSnapshot& value) noexcept
    {
        return std::find_if(value.fullPaths.begin(), value.fullPaths.end(), [&](const std::wstring& candidate) noexcept {
            return OrdinalString::EqualsNoCase(std::wstring_view(candidate), std::wstring_view(fullPath));
        }) != value.fullPaths.end();
    };

    if (! WaitForFindSnapshot(containsPath, timeout, &snapshot) || ! DebugSelectFindFilesWindowResult(fullPath))
    {
        if (outSnapshot)
        {
            *outSnapshot = std::move(snapshot);
        }
        return false;
    }

    const bool selected = WaitForFindSnapshot([&](const FindFilesDebugSnapshot& value) noexcept {
        return value.selectedResultCount == 1u && OrdinalString::EqualsNoCase(std::wstring_view(value.selectedResultFullPath), std::wstring_view(fullPath));
    }, timeout, &snapshot);
    if (outSnapshot)
    {
        *outSnapshot = std::move(snapshot);
    }
    return selected;
}

[[nodiscard]] bool WaitForFindWindowUnavailable(std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    FindFilesDebugSnapshot snapshot{};
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();

        const HWND findWindow = GetFindFilesWindowHandle();
        if ((! findWindow || IsWindow(findWindow) == FALSE) && ! DebugGetFindFilesWindowSnapshot(snapshot))
        {
            return true;
        }

        std::this_thread::sleep_for(20ms);
    }

    const HWND findWindow = GetFindFilesWindowHandle();
    return (! findWindow || IsWindow(findWindow) == FALSE) && ! DebugGetFindFilesWindowSnapshot(snapshot);
}

[[nodiscard]] bool WaitForFindWindowReady(std::chrono::milliseconds timeout, FindFilesDebugSnapshot* outSnapshot = nullptr) noexcept
{
    return WaitForFindSnapshot(
        [](const FindFilesDebugSnapshot& value) noexcept
    {
        return value.usesDxUiHost && value.visibleChildWindowCount <= 1u && value.resultColumnIds.size() >= 2u && value.resultColumnWidthsDip.size() >= 2u &&
               value.firstResultHeaderRect.right > value.firstResultHeaderRect.left && value.secondResultHeaderRect.right > value.secondResultHeaderRect.left &&
               value.rootComboEnabled && value.nameComboEnabled && value.nameModeComboEnabled && value.contentComboEnabled && value.contentModeComboEnabled &&
               value.dxResizeFailureCount == 0u;
    },
        timeout,
        outSnapshot);
}

[[nodiscard]] bool ApplyFindVisibleHeaderReorderViaDebug(FindFilesDebugSnapshot& snapshot, std::chrono::milliseconds timeout) noexcept
{
    if (! DebugReorderFindFilesWindowVisibleResultColumn(1u, 0u))
    {
        return false;
    }

    return WaitForFindSnapshot(
        [](const FindFilesDebugSnapshot& value) noexcept
    {
        return value.resultColumnIds.size() >= 2u && value.resultColumnIds[0] == L"path" && value.resultColumnIds[1] == L"name" &&
               value.resultColumnWidthsDip.size() >= 2u && value.visibleChildWindowCount <= 1u && value.dxResizeFailureCount == 0u;
    },
        timeout,
        &snapshot);
}

[[nodiscard]] bool ApplyFindFirstVisibleColumnResizeViaDebug(FindFilesDebugSnapshot& snapshot, float deltaDip, std::chrono::milliseconds timeout) noexcept
{
    if (! std::isfinite(deltaDip) || deltaDip == 0.0f || snapshot.resultColumnWidthsDip.empty())
    {
        return false;
    }

    const float resizeDeltaDip               = std::copysign(std::max(std::fabs(deltaDip), 96.0f), deltaDip);
    const float baselineFirstVisibleWidthDip = snapshot.resultColumnWidthsDip[0];
    if (! DebugResizeFindFilesWindowVisibleResultColumn(0u, resizeDeltaDip))
    {
        return false;
    }

    return WaitForFindSnapshot(
        [&](const FindFilesDebugSnapshot& value) noexcept
    {
        return value.resultColumnIds.size() >= 2u && value.resultColumnIds[0] == L"path" && value.resultColumnIds[1] == L"name" &&
               value.resultColumnWidthsDip.size() >= 2u && value.resultColumnWidthsDip[0] >= baselineFirstVisibleWidthDip + 20.0f &&
               value.visibleChildWindowCount <= 1u && value.dxResizeFailureCount == 0u;
    },
        timeout,
        &snapshot);
}

[[nodiscard]] std::wstring NewGuidText() noexcept
{
    std::wstring id;
    return SUCCEEDED(Common::Settings::CreateConnectionProfileId(id)) ? id : std::format(L"tick_{}", GetTickCount64());
}

constexpr std::wstring_view kBuiltinLocalFileSystemId = L"builtin/file-system";

using CreateFactoryFunc = HRESULT(__stdcall*)(REFIID, const FactoryOptions*, IHost*, const wchar_t*, void**);

struct CreatedFileSystemInstance final
{
    wil::unique_hmodule module;
    wil::com_ptr<IFileSystem> fileSystem;

    CreatedFileSystemInstance()                                            = default;
    CreatedFileSystemInstance(const CreatedFileSystemInstance&)            = delete;
    CreatedFileSystemInstance& operator=(const CreatedFileSystemInstance&) = delete;
    CreatedFileSystemInstance(CreatedFileSystemInstance&&)                 = default;
    CreatedFileSystemInstance& operator=(CreatedFileSystemInstance&&)      = default;
};

[[nodiscard]] const FileSystemPluginManager::PluginEntry* FindFileSystemPluginById(std::wstring_view pluginId) noexcept
{
    return FileSystemPluginManager::GetInstance().FindPluginById(pluginId);
}

[[nodiscard]] HRESULT TryCreateFileSystemInstance(std::wstring_view pluginId, CreatedFileSystemInstance& out) noexcept
{
    out = {};

    const FileSystemPluginManager::PluginEntry* entry = FindFileSystemPluginById(pluginId);
    if (! entry || entry->id.empty() || entry->disabled || ! entry->loadable || entry->path.empty())
    {
        return HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
    }

    wil::unique_hmodule module(::LoadLibraryExW(entry->path.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH));
    if (! module)
    {
        return HRESULT_FROM_WIN32(::GetLastError());
    }

#pragma warning(push)
#pragma warning(disable : 4191) // FARPROC to typed factory function
    const auto createFactory = reinterpret_cast<CreateFactoryFunc>(::GetProcAddress(module.get(), "RedSalamanderCreate"));
#pragma warning(pop)
    if (! createFactory)
    {
        return HRESULT_FROM_WIN32(ERROR_PROC_NOT_FOUND);
    }

    FactoryOptions options{};
    options.debugLevel = DEBUG_LEVEL_NONE;

    wil::com_ptr<IFileSystem> fileSystem;
    const std::wstring requestedPluginId = entry->factoryPluginId.empty() ? entry->id : entry->factoryPluginId;
    if (requestedPluginId.empty())
    {
        return E_INVALIDARG;
    }
    const HRESULT createHr = createFactory(__uuidof(IFileSystem), &options, GetHostServices(), requestedPluginId.c_str(), fileSystem.put_void());

    if (FAILED(createHr) || ! fileSystem)
    {
        return createHr;
    }

    if (entry->informations)
    {
        wil::com_ptr<IInformations> informations;
        const HRESULT qiInfos = fileSystem->QueryInterface(__uuidof(IInformations), informations.put_void());
        if (FAILED(qiInfos) || ! informations)
        {
            return qiInfos;
        }

        const char* configuration = nullptr;
        static_cast<void>(entry->informations->GetConfiguration(&configuration));
        if (configuration && configuration[0] != '\0')
        {
            static_cast<void>(informations->SetConfiguration(configuration));
        }
    }

    out.module     = std::move(module);
    out.fileSystem = std::move(fileSystem);
    return S_OK;
}

[[nodiscard]] bool CreateInformations(const wil::com_ptr<IFileSystem>& fs, wil::com_ptr<IInformations>& outInfo) noexcept
{
    outInfo.reset();
    if (! fs)
    {
        return false;
    }

    const HRESULT hr = fs->QueryInterface(__uuidof(IInformations), outInfo.put_void());
    return SUCCEEDED(hr) && static_cast<bool>(outInfo);
}

[[nodiscard]] bool TestFileSystemCurlPluginNamesAreLocalized(CaseState& state) noexcept
{
    using PluginNameExpectation                                    = std::pair<std::wstring_view, std::wstring_view>;
    constexpr std::array<PluginNameExpectation, 4> expectedPlugins = {{
        {L"builtin/file-system-ftp", L"FTP"},
        {L"builtin/file-system-sftp", L"SFTP"},
        {L"builtin/file-system-scp", L"SCP"},
        {L"builtin/file-system-imap", L"IMAP"},
    }};

    for (const auto& [pluginId, expectedName] : expectedPlugins)
    {
        const FileSystemPluginManager::PluginEntry* entry = FindFileSystemPluginById(pluginId);
        state.Require(entry != nullptr, std::format(L"Expected plugin {} to be registered.", pluginId));
        if (! entry)
        {
            continue;
        }

        state.Require(! entry->name.empty(), std::format(L"Plugin {} should expose a non-empty display name.", pluginId));
        state.Require(entry->name == expectedName, std::format(L"Plugin {} expected display name '{}', actual '{}'.", pluginId, expectedName, entry->name));
        state.Require(! entry->description.empty(), std::format(L"Plugin {} should expose a non-empty description.", pluginId));
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestIconBitmapAlphaNormalization(CaseState& state) noexcept
{
    std::array<BYTE, 8> pixels{
        0,
        0,
        0,
        0,
        64,
        32,
        16,
        0,
    };

    state.Require(DebugNormalizeIconBitmapAlphaForD2D(std::span<BYTE>(pixels)), L"Icon alpha normalization should accept whole BGRA pixels.");
    state.Require(pixels[3] == 255, L"Icon alpha normalization should preserve opaque black pixels when no alpha channel is present.");
    state.Require(pixels[7] == 255, L"Icon alpha normalization should mark non-black color pixels opaque when no alpha channel is present.");

    std::array<BYTE, 5> invalidPixels{};
    state.Require(! DebugNormalizeIconBitmapAlphaForD2D(std::span<BYTE>(invalidPixels)), L"Icon alpha normalization should reject partial BGRA pixels.");

    std::array<BYTE, 4> translucentPixel{
        100,
        50,
        200,
        128,
    };
    state.Require(DebugNormalizeIconBitmapAlphaForD2D(std::span<BYTE>(translucentPixel)), L"Icon alpha normalization should accept a translucent BGRA pixel.");
    state.Require(translucentPixel[0] == 50 && translucentPixel[1] == 25 && translucentPixel[2] == 100 && translucentPixel[3] == 128,
                  L"Icon alpha normalization should premultiply translucent RGB channels for D2D.");

    BITMAPINFO maskInfo{};
    maskInfo.bmiHeader.biSize        = sizeof(BITMAPINFOHEADER);
    maskInfo.bmiHeader.biWidth       = 2;
    maskInfo.bmiHeader.biHeight      = -1;
    maskInfo.bmiHeader.biPlanes      = 1;
    maskInfo.bmiHeader.biBitCount    = 32;
    maskInfo.bmiHeader.biCompression = BI_RGB;

    void* maskBits = nullptr;
#pragma warning(push)
#pragma warning(disable : 4625 4626 5026 5027) // WIL move-only wrappers intentionally delete copy operations.
    wil::unique_hdc maskDc{CreateCompatibleDC(nullptr)};
    wil::unique_hbitmap maskBitmap{CreateDIBSection(maskDc.get(), &maskInfo, DIB_RGB_COLORS, &maskBits, nullptr, 0)};
#pragma warning(pop)
    state.Require(static_cast<bool>(maskDc) && static_cast<bool>(maskBitmap) && maskBits != nullptr,
                  L"Icon alpha mask test should create a synthetic mask bitmap.");
    if (maskDc && maskBitmap && maskBits)
    {
        auto* maskPixels = static_cast<DWORD*>(maskBits);
        maskPixels[0]    = RGB(0, 0, 0);
        maskPixels[1]    = RGB(255, 255, 255);

        std::array<BYTE, 8> maskedPixels{
            9,
            8,
            7,
            0,
            90,
            80,
            70,
            0,
        };
        state.Require(DebugNormalizeIconBitmapAlphaForD2DWithMask(std::span<BYTE>(maskedPixels), maskBitmap.get(), 2, 1, maskDc.get()),
                      L"Icon alpha normalization should accept a matching synthetic mask.");
        state.Require(maskedPixels[0] == 9 && maskedPixels[1] == 8 && maskedPixels[2] == 7 && maskedPixels[3] == 255,
                      L"Black mask pixels should mark source icon pixels opaque.");
        state.Require(maskedPixels[4] == 0 && maskedPixels[5] == 0 && maskedPixels[6] == 0 && maskedPixels[7] == 0,
                      L"Non-black mask pixels should clear transparent icon pixels.");
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestFolderViewIconBitmapInterpolation(CaseState& state) noexcept
{
    const D2D1_INTERPOLATION_MODE downscaleMode = DebugResolveFolderViewIconBitmapInterpolation(D2D1::SizeU(32u, 32u), 16.0f, 144.0f);
    state.Require(downscaleMode != D2D1_INTERPOLATION_MODE_NEAREST_NEIGHBOR,
                  L"FolderView should filter shell icons when source and destination pixel sizes differ.");

    const D2D1_INTERPOLATION_MODE exactMode = DebugResolveFolderViewIconBitmapInterpolation(D2D1::SizeU(16u, 16u), 16.0f, 96.0f);
    state.Require(exactMode == D2D1_INTERPOLATION_MODE_NEAREST_NEIGHBOR, L"FolderView should keep nearest-neighbor for exact 1:1 shell icon draws.");

    return state.failure.empty();
}

[[nodiscard]] bool TestIconCacheSelectsNonUpscaledSource(CaseState& state) noexcept
{
    state.Require(DebugSelectIconCacheImageListSize(16.0f, 96.0f) == SHIL_SMALL,
                  L"IconCache should keep the small shell image list for exact 16px list-mode icons.");
    state.Require(DebugSelectIconCacheImageListSize(16.0f, 120.0f) == SHIL_LARGE,
                  L"IconCache should choose a larger shell image list for 20px high-DPI list-mode icons.");
    state.Require(DebugSelectIconCacheImageListSize(32.0f, 144.0f) == SHIL_EXTRALARGE, L"IconCache should choose the 48px shell image list for 48px targets.");

    return state.failure.empty();
}

[[nodiscard]] bool TestRedSalamanderHelpListsDiagnosticsOptions(CaseState& state) noexcept
{
    const std::wstring_view help = DebugGetRedSalamanderHelpText();
    state.Require(help.find(L"--etw") != std::wstring_view::npos, L"RedSalamander --help should list the Release diagnostics ETW switch.");
    state.Require(help.find(L"--perf") != std::wstring_view::npos, L"RedSalamander --help should list the default perf JSONL output switch.");
    state.Require(help.find(L"--perf=PATH") != std::wstring_view::npos, L"RedSalamander --help should list the custom perf JSONL output switch.");
    state.Require(help.find(L"Debug and ASan Debug") != std::wstring_view::npos,
                  L"RedSalamander --help should explain that Debug and ASan Debug enable ETW/perf by default.");
#if defined(_DEBUG) || defined(RS_ASAN_DEBUG_BUILD)
    state.Require(DebugIsRedSalamanderDiagnosticsEnabledByDefault(),
                  L"RedSalamander Debug and ASan Debug builds should enable ETW/perf defaults without command-line switches.");
#else
    state.Require(! DebugIsRedSalamanderDiagnosticsEnabledByDefault(),
                  L"RedSalamander Release builds should require command-line switches for ETW/perf defaults.");
#endif
    state.Require(help.find(L"--diagnostics-etw") == std::wstring_view::npos, L"RedSalamander --help should not keep the retired diagnostics ETW switch.");
    state.Require(help.find(L"--perf-jsonl") == std::wstring_view::npos, L"RedSalamander --help should not keep the retired perf JSONL switch.");
    state.Require(help.find(L"Release") != std::wstring_view::npos, L"RedSalamander --help should explain the Release diagnostics activation contract.");

    return state.failure.empty();
}

enum class CommandSurfaceClassification : uint8_t
{
    ClassicMenu,
    ContextualDynamic,
    ShortcutFunctionBar,
    PaletteOnly,
    InternalParameterized,
};

struct CommandSurfaceCoverageEntry final
{
    std::wstring_view commandId;
    CommandSurfaceClassification classification = CommandSurfaceClassification::InternalParameterized;
};

constexpr auto kCommandSurfaceCoverage = std::to_array<CommandSurfaceCoverageEntry>({
#define RS_COMMAND_SURFACE(commandId, classification) CommandSurfaceCoverageEntry{commandId, CommandSurfaceClassification::classification},
#include "CommandSurfaceCoverage.inc"
#undef RS_COMMAND_SURFACE
});

[[nodiscard]] bool TestCommandSurfaceCoverageContract(HWND mainWindow, CaseState& state) noexcept
{
    const std::span<const CommandInfo> commands = GetAllCommands();
    state.Require(kCommandSurfaceCoverage.size() == commands.size(),
                  std::format(L"Command-surface ledger has {} rows for {} canonical commands.", kCommandSurfaceCoverage.size(), commands.size()));

    std::unordered_set<std::wstring_view> ledgerIds;
    std::array<size_t, 5> classificationCounts{};
    for (const CommandSurfaceCoverageEntry& entry : kCommandSurfaceCoverage)
    {
        state.Require(! entry.commandId.empty(), L"Command-surface ledger rows must name a canonical command.");
        state.Require(ledgerIds.insert(entry.commandId).second, std::format(L"Command-surface ledger duplicates {}.", entry.commandId));
        state.Require(FindCommandInfo(entry.commandId) != nullptr, std::format(L"Command-surface ledger names unregistered command {}.", entry.commandId));
        ++classificationCounts[static_cast<size_t>(entry.classification)];
    }

    for (const CommandInfo& command : commands)
    {
        state.Require(ledgerIds.contains(command.id), std::format(L"Canonical command {} is unclassified in CommandSurfaceCoverage.inc.", command.id));
    }
    for (size_t index = 0u; index < classificationCounts.size(); ++index)
    {
        state.Require(classificationCounts[index] > 0u, std::format(L"Command-surface classification {} has no reviewed entries.", index));
    }

    constexpr uint8_t kFolderPaletteScopeMask =
        static_cast<uint8_t>(CommandShortcutScopeMask(CommandShortcutScope::Application) | CommandShortcutScopeMask(CommandShortcutScope::FunctionBar) |
                             CommandShortcutScopeMask(CommandShortcutScope::FolderView));
    constexpr uint8_t kTerminalPaletteScopeMask =
        static_cast<uint8_t>(CommandShortcutScopeMask(CommandShortcutScope::Application) | CommandShortcutScopeMask(CommandShortcutScope::FunctionBar) |
                             CommandShortcutScopeMask(CommandShortcutScope::Terminal));
    for (const CommandInfo& command : commands)
    {
        state.Require(! command.paletteVisible || (command.shortcutScopeMask & (kFolderPaletteScopeMask | kTerminalPaletteScopeMask)) != 0u,
                      std::format(L"Palette-visible command {} is unreachable from both command-palette contexts.", command.id));
    }

    const Common::Settings::ShortcutsSettings shortcuts = g_settings.shortcuts.value_or(Common::Settings::ShortcutsSettings{});
    const AppTheme theme                                = ResolveAppTheme(ThemeMode::Dark, L"command-surface-coverage-selftest");
    const auto requirePaletteContextCoverage            = [&](bool terminalContext, uint8_t eligibleScopeMask, std::wstring_view contextName) noexcept
    {
        const size_t expectedRowCount = static_cast<size_t>(std::ranges::count_if(commands, [eligibleScopeMask](const CommandInfo& command) noexcept {
            return command.paletteVisible && (command.shortcutScopeMask & eligibleScopeMask) != 0u;
        }));
        ShowCommandPaletteWindow(mainWindow, shortcuts, terminalContext, theme);
        PumpPendingMessages();
        CommandPaletteDebugSnapshot snapshot{};
        state.Require(DebugGetCommandPaletteSnapshot(snapshot),
                      std::format(L"{} Command Palette should expose its unfiltered coverage snapshot.", contextName));
        state.Require(snapshot.rowCount == expectedRowCount,
                      std::format(L"{} Command Palette exposes {} rows for {} context-eligible, palette-visible canonical commands.",
                                  contextName,
                                  snapshot.rowCount,
                                  expectedRowCount));
        if (const HWND palette = GetCommandPaletteWindowHandle(); palette != nullptr && IsWindow(palette) != FALSE)
        {
            SendMessageW(palette, WM_CLOSE, 0u, 0);
            PumpPendingMessages();
        }
        state.Require(GetCommandPaletteWindowHandle() == nullptr,
                      std::format(L"Command-surface coverage test should close the transient {} Command Palette.", contextName));
    };

    requirePaletteContextCoverage(false, kFolderPaletteScopeMask, L"Folder");
    requirePaletteContextCoverage(true, kTerminalPaletteScopeMask, L"Terminal");

    return state.failure.empty();
}

[[nodiscard]] bool TestRegistryIntegrity(CaseState& state) noexcept
{
    const auto commands = GetAllCommands();
    state.Require(! commands.empty(), L"GetAllCommands returned empty.");

    std::unordered_set<std::wstring_view> ids;
    std::unordered_set<unsigned int> wmCommandIds;

    for (const CommandInfo& cmd : commands)
    {
        state.Require(! cmd.id.empty(), L"Command id must not be empty.");
        state.Require(CanonicalizeCommandId(cmd.id) == cmd.id, std::format(L"Registered command {} must already be canonical.", cmd.id));
        state.Require(cmd.displayNameStringId != 0, std::format(L"Command {} missing displayNameStringId.", cmd.id));
        state.Require(cmd.descriptionStringId != 0, std::format(L"Command {} missing descriptionStringId.", cmd.id));

        const std::optional<unsigned int> shortDisplayNameStringId = TryGetCommandShortDisplayNameStringId(cmd.id);
        state.Require(shortDisplayNameStringId.has_value(), std::format(L"Command {} missing shortDisplayNameStringId.", cmd.id));

        if (cmd.displayNameStringId != 0)
        {
            const std::wstring name = LoadStringResource(nullptr, cmd.displayNameStringId);
            state.Require(! name.empty(), std::format(L"Command {} display name resource {} is empty.", cmd.id, cmd.displayNameStringId));
        }
        if (shortDisplayNameStringId.has_value())
        {
            state.Require(
                shortDisplayNameStringId.value() >= IDS_CMD_SHORT_BASE && shortDisplayNameStringId.value() <= IDS_CMD_SHORT_BASE + 1999u,
                std::format(L"Command {} short display name resource {} is outside the reserved short-label range.", cmd.id, shortDisplayNameStringId.value()));
            const std::wstring shortName = LoadStringResource(nullptr, shortDisplayNameStringId.value());
            state.Require(! shortName.empty(), std::format(L"Command {} short display name resource {} is empty.", cmd.id, shortDisplayNameStringId.value()));
            state.Require(shortName.size() <= 12u, std::format(L"Command {} short display name '{}' is too long for the function bar.", cmd.id, shortName));
        }
        if (cmd.descriptionStringId != 0)
        {
            const std::wstring desc = LoadStringResource(nullptr, cmd.descriptionStringId);
            state.Require(! desc.empty(), std::format(L"Command {} description resource {} is empty.", cmd.id, cmd.descriptionStringId));
        }

        state.Require(ids.insert(cmd.id).second, std::format(L"Duplicate command id: {}.", cmd.id));
        if (cmd.wmCommandId != 0)
        {
            state.Require(wmCommandIds.insert(cmd.wmCommandId).second, std::format(L"Duplicate wmCommandId: {}.", cmd.wmCommandId));
        }

        const CommandInfo* found = FindCommandInfo(cmd.id);
        state.Require(found != nullptr, std::format(L"FindCommandInfo failed for {}.", cmd.id));

        if (cmd.wmCommandId != 0)
        {
            const CommandInfo* byWm = FindCommandInfoByWmCommandId(cmd.wmCommandId);
            state.Require(byWm == found, std::format(L"FindCommandInfoByWmCommandId mismatch for wmCommandId {}.", cmd.wmCommandId));
        }
    }

    const auto requireShortName = [&](std::wstring_view commandId, std::wstring_view expected) noexcept
    {
        const std::optional<unsigned int> shortId = TryGetCommandShortDisplayNameStringId(commandId);
        state.Require(shortId.has_value(), std::format(L"{} should expose a short display name.", commandId));
        if (! shortId.has_value())
        {
            return;
        }

        const std::wstring actual = LoadStringResource(nullptr, shortId.value());
        state.Require(actual == expected, std::format(L"{} expected short display name '{}', saw '{}'.", commandId, expected, actual));
    };
    requireShortName(L"cmd/pane/createDirectory", L"MakeDir");
    requireShortName(L"cmd/pane/userMenu", L"UsrMenu");
    requireShortName(L"cmd/pane/sort/time", L"ByTime");

    const CommandInfo* viewWidth = FindCommandInfo(L"cmd/app/viewWidth");
    state.Require(viewWidth != nullptr, L"cmd/app/viewWidth should remain the implemented pane width command.");
    if (viewWidth != nullptr)
    {
        state.Require(viewWidth->displayNameStringId == IDS_CMD_VIEW_WIDTH, L"cmd/app/viewWidth should keep the View Width display resource.");
        state.Require(viewWidth->descriptionStringId == IDS_CMD_DESC_VIEW_WIDTH, L"cmd/app/viewWidth should keep the View Width description resource.");
        state.Require(viewWidth->wmCommandId == IDM_APP_VIEW_WIDTH, L"cmd/app/viewWidth should keep the implemented WM_COMMAND id.");
    }

    const auto requireRegisteredCommand = [&](std::wstring_view commandId) noexcept
    { state.Require(FindCommandInfo(commandId) != nullptr, std::format(L"{} should be registered in the command registry.", commandId)); };
    requireRegisteredCommand(L"cmd/pane/alternateEdit");
    requireRegisteredCommand(L"cmd/app/theme/selectNext");
    requireRegisteredCommand(L"cmd/app/theme/selectPrev");

    const CommandInfo* permanentDelete = FindCommandInfo(L"cmd/pane/permanentDelete");
    state.Require(permanentDelete != nullptr, L"Permanent Delete should remain registered.");
    const std::optional<UINT> permanentDeleteWmCommand = TryGetWmCommandId(L"cmd/pane/permanentDelete");
    state.Require(permanentDeleteWmCommand.has_value() && permanentDeleteWmCommand.value() == static_cast<UINT>(IDM_PANE_PERMANENT_DELETE),
                  L"Permanent Delete should expose the canonical WM_COMMAND binding.");
    state.Require(FindCommandInfo(L"cmd/pane/permanentDeleteWithValidation") == nullptr,
                  L"The legacy validation-suffixed permanent-delete command should not remain registered.");
    state.Require(! TryGetWmCommandId(L"cmd/pane/permanentDeleteWithValidation").has_value(),
                  L"The legacy validation-suffixed permanent-delete command should not expose a WM_COMMAND binding.");
    if (permanentDelete != nullptr)
    {
        const std::wstring permanentDeleteName = LoadStringResource(nullptr, permanentDelete->displayNameStringId);
        state.Require(permanentDeleteName == L"Permanent Delete", L"Permanent Delete should be displayed as 'Permanent Delete'.");
        state.Require(permanentDeleteName.find(L"Validation") == std::wstring::npos, L"Permanent Delete display name should not include validation wording.");
    }

    using CanonicalizationExpectation                                                    = std::pair<std::wstring_view, std::wstring_view>;
    constexpr std::array<CanonicalizationExpectation, 13> kParameterizedCanonicalization = {
        CanonicalizationExpectation{L"cmd/app/openFileExplorerKnownFolder/downloads", L"cmd/app/openFileExplorerKnownFolder"},
        CanonicalizationExpectation{L"cmd/app/plugins/configure/builtin-file-system", L"cmd/app/plugins/configure"},
        CanonicalizationExpectation{L"cmd/app/plugins/toggleEnabled/builtin-file-system", L"cmd/app/plugins/toggleEnabled"},
        CanonicalizationExpectation{L"cmd/app/theme/select/builtin/dark", L"cmd/app/theme/select"},
        CanonicalizationExpectation{L"cmd/pane/editWith/default", L"cmd/pane/editWith"},
        CanonicalizationExpectation{L"cmd/pane/goDriveRoot/C", L"cmd/pane/goDriveRoot"},
        CanonicalizationExpectation{L"cmd/pane/hotPath/1", L"cmd/pane/hotPath"},
        CanonicalizationExpectation{L"cmd/pane/navigatePath/history-1", L"cmd/pane/navigatePath"},
        CanonicalizationExpectation{L"cmd/pane/newFromShellTemplate/txt", L"cmd/pane/newFromShellTemplate"},
        CanonicalizationExpectation{L"cmd/pane/selectFileSystemPlugin/builtin-file-system", L"cmd/pane/selectFileSystemPlugin"},
        CanonicalizationExpectation{L"cmd/pane/setHotPath/1", L"cmd/pane/setHotPath"},
        CanonicalizationExpectation{L"cmd/pane/userMenu/open-terminal", L"cmd/pane/userMenu"},
        CanonicalizationExpectation{L"cmd/pane/viewWith/text", L"cmd/pane/viewWith"},
    };
    for (const auto& [parameterizedId, expectedCanonicalId] : kParameterizedCanonicalization)
    {
        state.Require(CanonicalizeCommandId(parameterizedId) == expectedCanonicalId,
                      std::format(L"{} should canonicalize to {}.", parameterizedId, expectedCanonicalId));
        state.Require(FindCommandInfo(parameterizedId) == FindCommandInfo(expectedCanonicalId),
                      std::format(L"{} should resolve through its canonical command registry entry.", parameterizedId));
    }
    state.Require(CanonicalizeCommandId(L"cmd/pane/viewOptions/toggleStatusBar/active") == L"cmd/pane/viewOptions/toggleStatusBar/active",
                  L"Status bar toggle should not accept a parameterized suffix.");
    state.Require(FindCommandInfo(L"cmd/pane/viewOptions/toggleStatusBar/active") == nullptr,
                  L"Status bar toggle with a parameterized suffix should not resolve as a registered command.");

    state.Require(FindCommandInfo(L"cmd/pane/editWidth") == nullptr, L"Retired cmd/pane/editWidth should not remain registered.");
    state.Require(! TryGetWmCommandId(L"cmd/pane/editWidth").has_value(), L"Retired cmd/pane/editWidth should not expose a WM_COMMAND binding.");

    state.Require(FindCommandInfo(L"cmd/pane/copyPathAndFileName") == nullptr,
                  L"Legacy cmd/pane/copyPathAndFileName should not resolve after canonical-id cleanup.");
    state.Require(! TryGetWmCommandId(L"cmd/pane/copyPathAndFileName").has_value(),
                  L"Legacy cmd/pane/copyPathAndFileName should not expose a WM_COMMAND binding.");

    return state.failure.empty();
}

[[nodiscard]] HMENU FindMenuContainingCommandId(HMENU menu, UINT commandId) noexcept
{
    if (! menu)
    {
        return nullptr;
    }

    const int itemCount = GetMenuItemCount(menu);
    if (itemCount <= 0)
    {
        return nullptr;
    }

    for (int pos = 0; pos < itemCount; ++pos)
    {
        const UINT id = GetMenuItemID(menu, pos);
        if (id == commandId)
        {
            return menu;
        }

        if (const HMENU subMenu = GetSubMenu(menu, pos))
        {
            if (const HMENU found = FindMenuContainingCommandId(subMenu, commandId))
            {
                return found;
            }
        }
    }

    return nullptr;
}

[[nodiscard]] bool MenuContainsCommandId(HMENU menu, UINT commandId) noexcept
{
    if (! menu)
    {
        return false;
    }

    const int itemCount = GetMenuItemCount(menu);
    if (itemCount <= 0)
    {
        return false;
    }

    for (int pos = 0; pos < itemCount; ++pos)
    {
        if (GetMenuItemID(menu, pos) == commandId)
        {
            return true;
        }
    }

    return false;
}

[[nodiscard]] int FindMenuItemPosById(HMENU menu, UINT commandId) noexcept
{
    if (! menu)
    {
        return -1;
    }

    const int itemCount = GetMenuItemCount(menu);
    if (itemCount <= 0)
    {
        return -1;
    }

    for (int pos = 0; pos < itemCount; ++pos)
    {
        if (GetMenuItemID(menu, pos) == commandId)
        {
            return pos;
        }
    }

    return -1;
}

[[nodiscard]] bool IsMenuSeparatorAt(HMENU menu, int pos) noexcept
{
    if (! menu || pos < 0)
    {
        return false;
    }

    MENUITEMINFOW itemInfo{};
    itemInfo.cbSize = sizeof(itemInfo);
    itemInfo.fMask  = MIIM_FTYPE;
    if (! GetMenuItemInfoW(menu, static_cast<UINT>(pos), TRUE, &itemInfo))
    {
        return false;
    }

    return (itemInfo.fType & MFT_SEPARATOR) != 0;
}

[[nodiscard]] std::wstring GetMenuItemTextByPosition(HMENU menu, int pos) noexcept
{
    if (! menu || pos < 0)
    {
        return {};
    }

    std::array<wchar_t, 256> buffer{};
    const int length = GetMenuStringW(menu, static_cast<UINT>(pos), buffer.data(), static_cast<int>(buffer.size()), MF_BYPOSITION);
    if (length <= 0)
    {
        return {};
    }

    return std::wstring(buffer.data(), static_cast<size_t>(length));
}

[[nodiscard]] HMENU FindSubMenuByTextFragment(HMENU menu, std::wstring_view textFragment) noexcept
{
    if (! menu || textFragment.empty())
    {
        return nullptr;
    }

    const int itemCount = GetMenuItemCount(menu);
    if (itemCount <= 0)
    {
        return nullptr;
    }

    for (int pos = 0; pos < itemCount; ++pos)
    {
        const std::wstring text = GetMenuItemTextByPosition(menu, pos);
        if (text.find(textFragment) != std::wstring::npos)
        {
            return GetSubMenu(menu, pos);
        }

        if (const HMENU subMenu = GetSubMenu(menu, pos))
        {
            if (const HMENU found = FindSubMenuByTextFragment(subMenu, textFragment))
            {
                return found;
            }
        }
    }

    return nullptr;
}

[[nodiscard]] std::wstring FindMenuItemTextByFragment(HMENU menu, std::wstring_view textFragment) noexcept
{
    if (! menu || textFragment.empty())
    {
        return {};
    }

    const int itemCount = GetMenuItemCount(menu);
    if (itemCount <= 0)
    {
        return {};
    }

    for (int pos = 0; pos < itemCount; ++pos)
    {
        const std::wstring text = GetMenuItemTextByPosition(menu, pos);
        if (text.find(textFragment) != std::wstring::npos)
        {
            return text;
        }

        if (const HMENU subMenu = GetSubMenu(menu, pos))
        {
            if (std::wstring found = FindMenuItemTextByFragment(subMenu, textFragment); ! found.empty())
            {
                return found;
            }
        }
    }

    return {};
}

[[nodiscard]] bool TestImplementedCommandMenuLabelsAreNotMarkedTodo(CaseState& state) noexcept
{
    const HMENU mainMenu = DebugGetMainMenuModelHandle();
    state.Require(mainMenu != nullptr, L"Main menu handle not available.");
    if (! mainMenu)
    {
        return false;
    }

    using MenuLabelExpectation                                              = std::pair<UINT, std::wstring_view>;
    constexpr std::array<MenuLabelExpectation, 26> kImplementedMenuCommands = {
        MenuLabelExpectation{IDM_PANE_PERMANENT_DELETE, std::wstring_view{L"cmd/pane/permanentDelete"}},
        MenuLabelExpectation{IDM_PANE_SELECTION_SELECT_SAME_NAME, std::wstring_view{L"cmd/pane/selection/selectSameName"}},
        MenuLabelExpectation{IDM_PANE_SELECTION_UNSELECT_SAME_NAME, std::wstring_view{L"cmd/pane/selection/unselectSameName"}},
        MenuLabelExpectation{IDM_PANE_VIEW, std::wstring_view{L"cmd/pane/view"}},
        MenuLabelExpectation{IDM_PANE_ALTERNATE_VIEW, std::wstring_view{L"cmd/pane/alternateView"}},
        MenuLabelExpectation{IDM_PANE_EDIT, std::wstring_view{L"cmd/pane/edit"}},
        MenuLabelExpectation{IDM_PANE_ALTERNATE_EDIT, std::wstring_view{L"cmd/pane/alternateEdit"}},
        MenuLabelExpectation{IDM_VIEW_PLUGINS_MANAGE, std::wstring_view{L"cmd/app/plugins/manage"}},
        MenuLabelExpectation{IDM_VIEW_WINDOW_MENU, std::wstring_view{L"cmd/pane/windowMenu"}},
        MenuLabelExpectation{IDM_LEFT_STATUSBAR, std::wstring_view{L"cmd/pane/viewOptions/toggleStatusBar left menu"}},
        MenuLabelExpectation{IDM_RIGHT_STATUSBAR, std::wstring_view{L"cmd/pane/viewOptions/toggleStatusBar right menu"}},
        MenuLabelExpectation{IDM_VIEW_FUNCTIONBAR, std::wstring_view{L"cmd/app/toggleFunctionBar"}},
        MenuLabelExpectation{IDM_VIEW_MENUBAR, std::wstring_view{L"cmd/app/toggleMenuBar"}},
        MenuLabelExpectation{IDM_LEFT_HOT_PATHS, std::wstring_view{L"cmd/pane/hotPaths left menu"}},
        MenuLabelExpectation{IDM_RIGHT_HOT_PATHS, std::wstring_view{L"cmd/pane/hotPaths right menu"}},
        MenuLabelExpectation{IDM_LEFT_SORT_ATTRIBUTES, std::wstring_view{L"cmd/pane/sort/attributes left menu"}},
        MenuLabelExpectation{IDM_RIGHT_SORT_ATTRIBUTES, std::wstring_view{L"cmd/pane/sort/attributes right menu"}},
        MenuLabelExpectation{IDM_PANE_QUICK_SEARCH, std::wstring_view{L"cmd/pane/quickSearch"}},
        MenuLabelExpectation{IDM_PANE_BRING_CURRENT_DIR_TO_COMMAND_LINE, std::wstring_view{L"cmd/pane/bringCurrentDirToCommandLine"}},
        MenuLabelExpectation{IDM_PANE_BRING_FILENAME_TO_COMMAND_LINE, std::wstring_view{L"cmd/pane/bringFilenameToCommandLine"}},
        MenuLabelExpectation{IDM_APP_REREAD_ASSOCIATIONS, std::wstring_view{L"cmd/app/rereadAssociations"}},
        MenuLabelExpectation{IDM_PANE_MAKE_FILE_LIST, std::wstring_view{L"cmd/pane/makeFileList"}},
        MenuLabelExpectation{IDM_PANE_LIST_OPENED_FILES, std::wstring_view{L"cmd/pane/listOpenedFiles"}},
        MenuLabelExpectation{IDM_PANE_SHARES, std::wstring_view{L"cmd/pane/shares"}},
        MenuLabelExpectation{IDM_PANE_PACK, std::wstring_view{L"cmd/pane/pack"}},
        MenuLabelExpectation{IDM_PANE_UNPACK, std::wstring_view{L"cmd/pane/unpack"}},
    };

    for (const auto& [commandId, label] : kImplementedMenuCommands)
    {
        const HMENU ownerMenu = FindMenuContainingCommandId(mainMenu, commandId);
        state.Require(ownerMenu != nullptr, std::format(L"Menu command {} should be present.", label));
        if (! ownerMenu)
        {
            continue;
        }

        const int itemPos = FindMenuItemPosById(ownerMenu, commandId);
        state.Require(itemPos >= 0, std::format(L"Menu command {} should have a position.", label));
        if (itemPos < 0)
        {
            continue;
        }

        const std::wstring text = GetMenuItemTextByPosition(ownerMenu, itemPos);
        state.Require(! text.empty(), std::format(L"Menu command {} should have non-empty text.", label));
        state.Require(text.find(L"[todo]") == std::wstring::npos, std::format(L"Implemented menu command {} must not be marked [todo].", label));
        if (commandId == IDM_PANE_PERMANENT_DELETE)
        {
            state.Require(text.find(L"Validation") == std::wstring::npos, L"Permanent Delete menu item should not include validation wording.");
        }
    }
    using PopupLabelExpectation                                            = std::pair<std::wstring_view, std::wstring_view>;
    constexpr std::array<PopupLabelExpectation, 2> kImplementedPopupLabels = {
        PopupLabelExpectation{std::wstring_view{L"View &With"}, std::wstring_view{L"cmd/pane/viewWith popup"}},
        PopupLabelExpectation{std::wstring_view{L"Ed&it With"}, std::wstring_view{L"cmd/pane/editWith popup"}},
    };

    for (const auto& [textFragment, label] : kImplementedPopupLabels)
    {
        const std::wstring text = FindMenuItemTextByFragment(mainMenu, textFragment);
        state.Require(! text.empty(), std::format(L"Menu popup {} should be present.", label));
        state.Require(text.find(L"[todo]") == std::wstring::npos, std::format(L"Implemented menu popup {} must not be marked [todo].", label));
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestThemeMenuNavigationCommandsAreLast(CaseState& state) noexcept
{
    const HMENU mainMenu = DebugGetMainMenuModelHandle();
    state.Require(mainMenu != nullptr, L"Main menu handle not available.");
    if (! mainMenu)
    {
        return false;
    }

    const HMENU themeMenu = FindMenuContainingCommandId(mainMenu, IDM_VIEW_THEME_SYSTEM);
    state.Require(themeMenu != nullptr, L"Theme submenu should be available from the main menu model.");
    if (! themeMenu)
    {
        return false;
    }

    const int itemCount = GetMenuItemCount(themeMenu);
    const int prevPos   = FindMenuItemPosById(themeMenu, IDM_VIEW_THEME_PREV);
    const int nextPos   = FindMenuItemPosById(themeMenu, IDM_VIEW_THEME_NEXT);
    state.Require(prevPos >= 0, L"Previous Theme command should be present in the Theme menu.");
    state.Require(nextPos >= 0, L"Next Theme command should be present in the Theme menu.");
    state.Require(itemCount >= 2, L"Theme menu should have enough items for the trailing navigation commands.");
    if (itemCount >= 2 && prevPos >= 0 && nextPos >= 0)
    {
        state.Require(prevPos == itemCount - 2,
                      std::format(L"Previous Theme should be the second-to-last Theme menu item; got position {} of {}.", prevPos, itemCount));
        state.Require(nextPos == itemCount - 1, std::format(L"Next Theme should be the last Theme menu item; got position {} of {}.", nextPos, itemCount));
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestHelpMenuLinksExternalDocumentation(CaseState& state) noexcept
{
    const HMENU mainMenu = DebugGetMainMenuModelHandle();
    state.Require(mainMenu != nullptr, L"Main menu handle not available.");
    if (! mainMenu)
    {
        return false;
    }

    const HMENU helpMenu = FindMenuContainingCommandId(mainMenu, IDM_APP_SHOW_SHORTCUTS);
    state.Require(helpMenu != nullptr, L"Help menu should contain the shortcuts command.");
    if (! helpMenu)
    {
        return false;
    }

    state.Require(FindMenuContainingCommandId(mainMenu, IDM_APP_EXTERNAL_HELP) == helpMenu, L"External help should live in the Help menu.");
    const int shortcutsPos    = FindMenuItemPosById(helpMenu, IDM_APP_SHOW_SHORTCUTS);
    const int externalHelpPos = FindMenuItemPosById(helpMenu, IDM_APP_EXTERNAL_HELP);
    const int aboutPos        = FindMenuItemPosById(helpMenu, IDM_ABOUT);
    state.Require(shortcutsPos >= 0, L"Display Shortcuts should have a Help-menu position.");
    state.Require(externalHelpPos >= 0, L"External Help should have a Help-menu position.");
    state.Require(aboutPos >= 0, L"About should have a Help-menu position.");
    if (shortcutsPos >= 0 && externalHelpPos >= 0 && aboutPos >= 0)
    {
        state.Require(shortcutsPos < externalHelpPos, L"External Help should follow Display Shortcuts.");
        state.Require(externalHelpPos < aboutPos, L"External Help should appear before About.");
        state.Require(IsMenuSeparatorAt(helpMenu, aboutPos - 1), L"About should remain separated from help actions.");
    }

    const std::wstring externalHelpText = GetMenuItemTextByPosition(helpMenu, externalHelpPos);
    state.Require(! externalHelpText.empty(), L"External Help menu text should be localized and non-empty.");
    state.Require(externalHelpText.find(L"[todo]") == std::wstring::npos, L"External Help menu text should not be marked as TODO.");

    const CommandInfo* command = FindCommandInfo(L"cmd/app/externalHelp");
    state.Require(command != nullptr, L"cmd/app/externalHelp should be registered.");
    if (command != nullptr)
    {
        state.Require(command->wmCommandId == IDM_APP_EXTERNAL_HELP, L"cmd/app/externalHelp should map to the Help menu command.");
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestPaneViewOptionsLiveInLeftRightMenus(CaseState& state) noexcept
{
    const HMENU mainMenu = DebugGetMainMenuModelHandle();
    state.Require(mainMenu != nullptr, L"Main menu handle not available.");
    if (! mainMenu)
    {
        return false;
    }

    const HMENU viewMenu = FindMenuContainingCommandId(mainMenu, IDM_VIEW_MENUBAR);
    state.Require(viewMenu != nullptr, L"View menu should be available from the main menu model.");
    if (viewMenu)
    {
        state.Require(FindSubMenuByTextFragment(viewMenu, L"&Pane") == nullptr, L"View menu must not keep the Pane submenu.");
    }

    constexpr std::array<UINT, 10> kRetiredViewPaneMenuIds = {{
        IDM_VIEW_PANE_HIDDEN_FILES,
        IDM_VIEW_PANE_SYSTEM_FILES,
        IDM_VIEW_PANE_FILE_EXTENSIONS,
        IDM_VIEW_PANE_THUMBNAILS,
        IDM_VIEW_PANE_PREVIEW_PANE,
        IDM_VIEW_PANE_FILTER_BAR,
        IDM_VIEW_PANE_NAVBAR_LEFT,
        IDM_VIEW_PANE_NAVBAR_RIGHT,
        IDM_VIEW_PANE_STATUSBAR_LEFT,
        IDM_VIEW_PANE_STATUSBAR_RIGHT,
    }};
    for (const UINT commandId : kRetiredViewPaneMenuIds)
    {
        state.Require(FindMenuContainingCommandId(mainMenu, commandId) == nullptr,
                      std::format(L"Retired View > Pane menu command {} should not appear in any menu.", commandId));
    }

    auto requirePaneMenuShape = [&](HMENU paneMenu,
                                    std::wstring_view paneName,
                                    UINT changeDriveId,
                                    UINT goToAnchorId,
                                    UINT pathFromOtherPaneId,
                                    UINT briefId,
                                    UINT detailedId,
                                    UINT extraDetailedId,
                                    UINT thumbnailsId,
                                    UINT previewPaneId,
                                    UINT terminalPaneId,
                                    UINT sortAnchorId,
                                    UINT hiddenFilesId,
                                    UINT systemFilesId,
                                    UINT fileExtensionsId,
                                    UINT zoomId,
                                    UINT refreshId,
                                    UINT filterId,
                                    UINT filterBarId,
                                    UINT navigationBarId,
                                    UINT statusBarId) noexcept
    {
        state.Require(paneMenu != nullptr, std::format(L"{} pane menu should be available.", paneName));
        if (! paneMenu)
        {
            return;
        }

        const int changeDrivePos           = FindMenuItemPosById(paneMenu, changeDriveId);
        const int briefPos                 = FindMenuItemPosById(paneMenu, briefId);
        const int detailedPos              = FindMenuItemPosById(paneMenu, detailedId);
        const int extraDetailedPos         = FindMenuItemPosById(paneMenu, extraDetailedId);
        const int thumbnailsPos            = FindMenuItemPosById(paneMenu, thumbnailsId);
        const int previewPanePos           = FindMenuItemPosById(paneMenu, previewPaneId);
        const int terminalPanePos          = FindMenuItemPosById(paneMenu, terminalPaneId);
        const int zoomPos                  = FindMenuItemPosById(paneMenu, zoomId);
        const int swapPos                  = FindMenuItemPosById(paneMenu, IDM_APP_SWAP_PANES);
        const int pathFromOtherPanePos     = FindMenuItemPosById(paneMenu, pathFromOtherPaneId);
        const int refreshPos               = FindMenuItemPosById(paneMenu, refreshId);
        const int filterPos                = FindMenuItemPosById(paneMenu, filterId);
        const int paneFilterBarPos         = FindMenuItemPosById(paneMenu, filterBarId);
        const int paneNavigationBarPos     = FindMenuItemPosById(paneMenu, navigationBarId);
        const int paneStatusBarPos         = FindMenuItemPosById(paneMenu, statusBarId);
        const HMENU goToMenu               = FindMenuContainingCommandId(paneMenu, goToAnchorId);
        const HMENU sortMenu               = FindMenuContainingCommandId(paneMenu, sortAnchorId);
        const HMENU showMenu               = FindMenuContainingCommandId(paneMenu, hiddenFilesId);
        const int goToPathFromOtherPanePos = FindMenuItemPosById(goToMenu, pathFromOtherPaneId);
        const int hiddenFilesPos           = FindMenuItemPosById(showMenu, hiddenFilesId);
        const int systemFilesPos           = FindMenuItemPosById(showMenu, systemFilesId);
        const int fileExtensionsPos        = FindMenuItemPosById(showMenu, fileExtensionsId);
        const int filterBarPos             = FindMenuItemPosById(showMenu, filterBarId);
        const int navigationBarPos         = FindMenuItemPosById(showMenu, navigationBarId);
        const int statusBarPos             = FindMenuItemPosById(showMenu, statusBarId);

        state.Require(changeDrivePos >= 0, std::format(L"{} menu should start with Change Drive.", paneName));
        state.Require(goToMenu != nullptr && goToMenu != paneMenu, std::format(L"{} menu should contain Go to submenu.", paneName));
        state.Require(sortMenu != nullptr && sortMenu != paneMenu, std::format(L"{} menu should contain Sort By submenu.", paneName));
        state.Require(showMenu != nullptr && showMenu != paneMenu, std::format(L"{} menu should contain Show submenu.", paneName));
        state.Require(goToPathFromOtherPanePos >= 0, std::format(L"{} Go to submenu should keep Path from Other Pane.", paneName));
        state.Require(pathFromOtherPanePos >= 0, std::format(L"{} menu should expose Path from Other Pane after Swap Panes.", paneName));
        state.Require(MenuContainsCommandId(showMenu, hiddenFilesId), std::format(L"{} Show submenu should contain Hidden Files.", paneName));
        state.Require(MenuContainsCommandId(showMenu, systemFilesId), std::format(L"{} Show submenu should contain System Files.", paneName));
        state.Require(MenuContainsCommandId(showMenu, fileExtensionsId), std::format(L"{} Show submenu should contain File Extensions.", paneName));
        state.Require(MenuContainsCommandId(showMenu, filterBarId), std::format(L"{} Show submenu should contain Filter Bar.", paneName));
        state.Require(MenuContainsCommandId(showMenu, navigationBarId), std::format(L"{} Show submenu should contain Navigation Bar.", paneName));
        state.Require(MenuContainsCommandId(showMenu, statusBarId), std::format(L"{} Show submenu should contain Status Bar.", paneName));
        state.Require(paneFilterBarPos < 0 && paneNavigationBarPos < 0 && paneStatusBarPos < 0,
                      std::format(L"{} menu should not keep Filter Bar, Navigation Bar, or Status Bar at top level.", paneName));

        state.Require(changeDrivePos < briefPos && briefPos < detailedPos && detailedPos < extraDetailedPos && extraDetailedPos < thumbnailsPos &&
                          thumbnailsPos < previewPanePos && previewPanePos < terminalPanePos,
                      std::format(L"{} menu display block should be Brief, Detailed, Extra Detailed, Thumbnails, Preview Pane, Terminal Pane.", paneName));
        state.Require(terminalPanePos < refreshPos && refreshPos < filterPos && filterPos < zoomPos && zoomPos < swapPos && swapPos < pathFromOtherPanePos,
                      std::format(L"{} menu action blocks should be Refresh, Filter, then Maximize, Swap, Path from Other Pane.", paneName));
        state.Require(hiddenFilesPos < systemFilesPos && systemFilesPos < fileExtensionsPos,
                      std::format(L"{} Show submenu should start Hidden Files, System Files, File Extensions.", paneName));
        state.Require(IsMenuSeparatorAt(showMenu, fileExtensionsPos + 1),
                      std::format(L"{} Show submenu should separate file visibility from bar toggles.", paneName));
        state.Require(fileExtensionsPos < filterBarPos && filterBarPos < navigationBarPos && navigationBarPos < statusBarPos,
                      std::format(L"{} Show submenu tail should be Filter Bar, Navigation Bar, Status Bar.", paneName));
    };

    requirePaneMenuShape(FindMenuContainingCommandId(mainMenu, IDM_LEFT_CHANGE_DRIVE),
                         L"Left",
                         IDM_LEFT_CHANGE_DRIVE,
                         IDM_LEFT_GO_TO_BACK,
                         IDM_LEFT_GO_TO_PATH_FROM_OTHER_PANE,
                         IDM_LEFT_DISPLAY_BRIEF,
                         IDM_LEFT_DISPLAY_DETAILED,
                         IDM_LEFT_DISPLAY_EXTRA_DETAILED,
                         IDM_LEFT_DISPLAY_THUMBNAILS,
                         IDM_LEFT_PREVIEW_PANE,
                         IDM_LEFT_TERMINAL_PANE,
                         IDM_LEFT_SORT_NAME,
                         IDM_LEFT_SHOW_HIDDEN_FILES,
                         IDM_LEFT_SHOW_SYSTEM_FILES,
                         IDM_LEFT_SHOW_FILE_EXTENSIONS,
                         IDM_LEFT_ZOOM_PANEL,
                         IDM_LEFT_REFRESH,
                         IDM_LEFT_FILTER,
                         IDM_LEFT_FILTER_BAR,
                         IDM_LEFT_NAVIGATION_BAR,
                         IDM_LEFT_STATUSBAR);
    requirePaneMenuShape(FindMenuContainingCommandId(mainMenu, IDM_RIGHT_CHANGE_DRIVE),
                         L"Right",
                         IDM_RIGHT_CHANGE_DRIVE,
                         IDM_RIGHT_GO_TO_BACK,
                         IDM_RIGHT_GO_TO_PATH_FROM_OTHER_PANE,
                         IDM_RIGHT_DISPLAY_BRIEF,
                         IDM_RIGHT_DISPLAY_DETAILED,
                         IDM_RIGHT_DISPLAY_EXTRA_DETAILED,
                         IDM_RIGHT_DISPLAY_THUMBNAILS,
                         IDM_RIGHT_PREVIEW_PANE,
                         IDM_RIGHT_TERMINAL_PANE,
                         IDM_RIGHT_SORT_NAME,
                         IDM_RIGHT_SHOW_HIDDEN_FILES,
                         IDM_RIGHT_SHOW_SYSTEM_FILES,
                         IDM_RIGHT_SHOW_FILE_EXTENSIONS,
                         IDM_RIGHT_ZOOM_PANEL,
                         IDM_RIGHT_REFRESH,
                         IDM_RIGHT_FILTER,
                         IDM_RIGHT_FILTER_BAR,
                         IDM_RIGHT_NAVIGATION_BAR,
                         IDM_RIGHT_STATUSBAR);

    return state.failure.empty();
}

[[nodiscard]] bool TestMainMenuInformationArchitecture(CaseState& state) noexcept
{
    const HMENU mainMenu = DebugGetMainMenuModelHandle();
    state.Require(mainMenu != nullptr, L"Main menu handle not available.");
    if (! mainMenu)
    {
        return false;
    }

    const HMENU filesMenu    = FindMenuContainingCommandId(mainMenu, IDM_PANE_EXECUTE_OPEN);
    const HMENU editMenu     = FindMenuContainingCommandId(mainMenu, IDM_PANE_CLIPBOARD_CUT);
    const HMENU commandsMenu = FindMenuContainingCommandId(mainMenu, IDM_PANE_CHANGE_DIRECTORY);
    const HMENU viewMenu     = FindMenuContainingCommandId(mainMenu, IDM_APP_FULL_SCREEN);
    const HMENU helpMenu     = FindMenuContainingCommandId(mainMenu, IDM_APP_SHOW_SHORTCUTS);
    state.Require(filesMenu && editMenu && commandsMenu && viewMenu && helpMenu, L"Files, Edit, Commands, View, and Help menus should all be present.");
    if (! filesMenu || ! editMenu || ! commandsMenu || ! viewMenu || ! helpMenu)
    {
        return false;
    }

    const auto requireDirectOrder = [&](HMENU menu, std::span<const UINT> commandIds, std::wstring_view label) noexcept
    {
        int previousPos = -1;
        for (const UINT commandId : commandIds)
        {
            const int pos = FindMenuItemPosById(menu, commandId);
            state.Require(pos >= 0, std::format(L"{} should directly contain command {}.", label, commandId));
            state.Require(pos > previousPos,
                          std::format(L"{} command {} should follow the preceding command; positions {} then {}.", label, commandId, previousPos, pos));
            previousPos = pos;
        }
    };

    constexpr std::array<UINT, 20> kFilesOrder = {{
        IDM_PANE_EXECUTE_OPEN,
        IDM_PANE_VIEW,
        IDM_PANE_ALTERNATE_VIEW,
        IDM_PANE_EDIT,
        IDM_PANE_ALTERNATE_EDIT,
        IDM_PANE_RENAME,
        IDM_PANE_BATCH_RENAME,
        IDM_PANE_CHANGE_CASE,
        IDM_PANE_CHANGE_ATTRIBUTES,
        IDM_PANE_COPY_TO_OTHER,
        IDM_PANE_COPY_TO_OTHER_WITH_OPTIONS,
        IDM_PANE_MOVE_TO_OTHER,
        IDM_PANE_MOVE_TO_OTHER_WITH_OPTIONS,
        IDM_PANE_PACK,
        IDM_PANE_UNPACK,
        IDM_PANE_DELETE,
        IDM_PANE_MOVE_TO_RECYCLE_BIN,
        IDM_PANE_PERMANENT_DELETE,
        IDM_PANE_OPEN_PROPERTIES,
        IDM_EXIT,
    }};
    requireDirectOrder(filesMenu, kFilesOrder, L"Files menu");
    const auto fileMenuText = [&](UINT commandId) noexcept { return GetMenuItemTextByPosition(filesMenu, FindMenuItemPosById(filesMenu, commandId)); };
    const std::wstring routineCopyText = fileMenuText(IDM_PANE_COPY_TO_OTHER);
    const std::wstring optionsCopyText = fileMenuText(IDM_PANE_COPY_TO_OTHER_WITH_OPTIONS);
    const std::wstring routineMoveText = fileMenuText(IDM_PANE_MOVE_TO_OTHER);
    const std::wstring optionsMoveText = fileMenuText(IDM_PANE_MOVE_TO_OTHER_WITH_OPTIONS);
    state.Require(! routineCopyText.empty() && routineCopyText.find(L"...") == std::wstring::npos,
                  std::format(L"Routine Copy menu label should not imply a dialog; got '{}'.", routineCopyText));
    state.Require(! routineMoveText.empty() && routineMoveText.find(L"...") == std::wstring::npos,
                  std::format(L"Routine Move menu label should not imply a dialog; got '{}'.", routineMoveText));
    state.Require(optionsCopyText.find(L"...") != std::wstring::npos,
                  std::format(L"Copy with Options menu label should advertise a dialog; got '{}'.", optionsCopyText));
    state.Require(optionsMoveText.find(L"...") != std::wstring::npos,
                  std::format(L"Move with Options menu label should advertise a dialog; got '{}'.", optionsMoveText));
    state.Require(FindSubMenuByTextFragment(filesMenu, L"&New") != nullptr, L"Files menu should keep the New submenu.");
    state.Require(FindSubMenuByTextFragment(filesMenu, L"Shell &Context Menu") != nullptr, L"Files menu should keep the Shell Context Menu submenu.");

    constexpr std::array<UINT, 11> kEditOrder = {{
        IDM_PANE_CLIPBOARD_CUT,
        IDM_PANE_CLIPBOARD_COPY,
        IDM_PANE_CLIPBOARD_PASTE,
        IDM_PANE_CLIPBOARD_PASTE_SHORTCUT,
        IDM_PANE_SELECTION_SELECT_DIALOG,
        IDM_PANE_SELECTION_UNSELECT_DIALOG,
        IDM_PANE_SELECTION_INVERT,
        IDM_PANE_SELECTION_SELECT_ALL,
        IDM_PANE_SELECTION_UNSELECT_ALL,
        IDM_PANE_SELECT_NEXT,
        IDM_PANE_SELECT_CALC_DIR_SIZE_NEXT,
    }};
    requireDirectOrder(editMenu, kEditOrder, L"Edit menu");
    state.Require(FindSubMenuByTextFragment(editMenu, L"Copy as &Text") != nullptr, L"Edit menu should contain Copy as Text.");
    state.Require(FindSubMenuByTextFragment(editMenu, L"A&dvanced Selection") != nullptr, L"Edit menu should contain Advanced Selection.");

    constexpr std::array<UINT, 11> kCommandsOrder = {{
        IDM_PANE_CHANGE_DIRECTORY,
        IDM_PANE_FIND,
        IDM_PANE_QUICK_SEARCH,
        IDM_APP_COMPARE,
        IDM_PANE_VIEW_SPACE,
        IDM_PANE_MAKE_FILE_LIST,
        IDM_PANE_GO_TO_SHORTCUT_OR_LINK_TARGET,
        IDM_PANE_LIST_OPENED_FILES,
        IDM_PANE_SHOW_FOLDERS_HISTORY,
        IDM_PANE_MENU,
        IDM_APP_COMMAND_PALETTE,
    }};
    requireDirectOrder(commandsMenu, kCommandsOrder, L"Commands menu");
    const HMENU connectionsMenu = FindSubMenuByTextFragment(commandsMenu, L"&Connections");
    const HMENU terminalMenu    = FindSubMenuByTextFragment(commandsMenu, L"&Terminal");
    state.Require(connectionsMenu != nullptr && MenuContainsCommandId(connectionsMenu, IDM_PANE_CONNECTION_MANAGER),
                  L"Commands should group connection actions under Connections.");
    state.Require(terminalMenu != nullptr && MenuContainsCommandId(terminalMenu, IDM_TERMINAL_OPEN_FLOATING_WINDOW) &&
                      MenuContainsCommandId(terminalMenu, IDM_PANE_BRING_FULL_PATH_TO_TERMINAL),
                  L"Commands should group popup terminal and terminal-insertion actions under Terminal.");
    state.Require(FindMenuItemPosById(commandsMenu, IDM_APP_REREAD_ASSOCIATIONS) < FindMenuItemPosById(commandsMenu, IDM_FILE_PREFERENCES),
                  L"Commands should end with Reread Associations followed by Preferences.");

    constexpr std::array<UINT, 8> kViewOrder = {{
        IDM_APP_FULL_SCREEN,
        IDM_APP_VIEW_WIDTH,
        IDM_VIEW_WINDOW_MENU,
        IDM_VIEW_SWITCH_PANE_FOCUS,
        IDM_VIEW_FILE_OPERATIONS,
        IDM_VIEW_FILEOPS_FAILED_ITEMS,
        IDM_VIEW_FUNCTIONBAR,
        IDM_VIEW_MENUBAR,
    }};
    state.Require(FindSubMenuByTextFragment(viewMenu, L"&Theme") != nullptr, L"View menu should begin with Theme.");
    requireDirectOrder(viewMenu, kViewOrder, L"View menu");

    const int shortcutsPos = FindMenuItemPosById(helpMenu, IDM_APP_SHOW_SHORTCUTS);
    const int helpPos      = FindMenuItemPosById(helpMenu, IDM_APP_EXTERNAL_HELP);
    const int aboutPos     = FindMenuItemPosById(helpMenu, IDM_ABOUT);
    state.Require(shortcutsPos == 0 && helpPos == 1 && IsMenuSeparatorAt(helpMenu, 2) && aboutPos == 3,
                  L"Help should be Shortcuts, External Help, separator, About.");

    using CommandBinding                              = std::pair<std::wstring_view, UINT>;
    constexpr std::array<CommandBinding, 9> kBindings = {{
        {L"cmd/pane/changeCase", IDM_PANE_CHANGE_CASE},
        {L"cmd/pane/changeAttributes", IDM_PANE_CHANGE_ATTRIBUTES},
        {L"cmd/app/commandPalette", IDM_APP_COMMAND_PALETTE},
        {L"cmd/pane/connections", IDM_PANE_CONNECTION_MANAGER},
        {L"cmd/terminal/openFloatingWindow", IDM_TERMINAL_OPEN_FLOATING_WINDOW},
        {L"cmd/pane/bringFullPathToTerminal", IDM_PANE_BRING_FULL_PATH_TO_TERMINAL},
        {L"cmd/app/viewWidth", IDM_APP_VIEW_WIDTH},
        {L"cmd/app/showFileOperations", IDM_VIEW_FILE_OPERATIONS},
        {L"cmd/app/toggleFileOperationsFailedItems", IDM_VIEW_FILEOPS_FAILED_ITEMS},
    }};
    for (const auto& [commandId, menuId] : kBindings)
    {
        const CommandInfo* command = FindCommandInfo(commandId);
        state.Require(command != nullptr && command->wmCommandId == menuId, std::format(L"{} should map to WM_COMMAND {}.", commandId, menuId));
    }

    ShortcutManager shortcutManager;
    shortcutManager.Load(ShortcutDefaults::CreateDefaultShortcuts());
    const auto requireShortcut = [&](std::wstring_view commandId, uint32_t vk, uint32_t modifiers, std::wstring_view label) noexcept
    {
        const std::optional<ShortcutManager::ShortcutChord> shortcut = shortcutManager.TryGetShortcutForCommand(commandId);
        state.Require(shortcut.has_value() && shortcut->vk == vk && shortcut->modifiers == modifiers,
                      std::format(L"{} should have its documented default shortcut.", label));
    };
    requireShortcut(L"cmd/pane/changeCase", VK_F7, ShortcutManager::kModCtrl, L"Change Case");
    requireShortcut(L"cmd/pane/changeAttributes", VK_F8, ShortcutManager::kModCtrl, L"Change Attributes");
    requireShortcut(L"cmd/app/commandPalette", static_cast<uint32_t>('P'), ShortcutManager::kModCtrl | ShortcutManager::kModShift, L"Command Palette");
    requireShortcut(L"cmd/app/showFileOperations", static_cast<uint32_t>('J'), ShortcutManager::kModCtrl | ShortcutManager::kModShift, L"Show File Operations");
    requireShortcut(
        L"cmd/terminal/openFloatingWindow", static_cast<uint32_t>('T'), ShortcutManager::kModCtrl | ShortcutManager::kModAlt, L"Command Shell Window");

    static_cast<void>(TestPaneViewOptionsLiveInLeftRightMenus(state));
    return state.failure.empty();
}

void RequireFunctionBarBinding(
    CaseState& state, const ShortcutManager& manager, uint32_t vk, uint32_t modifiers, std::wstring_view expectedCommandId, std::wstring_view label) noexcept
{
    if (const auto cmd = manager.FindFunctionBarCommand(vk, modifiers))
    {
        state.Require(cmd.value() == expectedCommandId, std::format(L"{} expected {}.", label, expectedCommandId));
    }
    else
    {
        state.Require(false, std::format(L"{} missing.", label));
    }
}

void RequireFolderViewBinding(CaseState& state,
                              const ShortcutManager& manager,
                              uint32_t vk,
                              uint32_t modifiers,
                              std::wstring_view expectedCommandId,
                              std::wstring_view label,
                              bool requireReverseLookup = true) noexcept
{
    if (const auto cmd = manager.FindFolderViewCommand(vk, modifiers))
    {
        state.Require(cmd.value() == expectedCommandId, std::format(L"{} expected {}.", label, expectedCommandId));
    }
    else
    {
        state.Require(false, std::format(L"{} missing.", label));
    }

    if (! requireReverseLookup)
    {
        return;
    }

    const auto chordOpt = manager.TryGetShortcutForCommand(expectedCommandId);
    state.Require(chordOpt.has_value(), std::format(L"{} reverse lookup missing for {}.", label, expectedCommandId));
    if (chordOpt.has_value())
    {
        state.Require(chordOpt->vk == vk, std::format(L"{} reverse lookup expected vk {}.", label, vk));
        state.Require(chordOpt->modifiers == modifiers, std::format(L"{} reverse lookup expected modifiers {}.", label, modifiers));
    }
}

[[nodiscard]] bool OpenClipboardForSelfTest(HWND ownerWindow, std::chrono::milliseconds timeout) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (OpenClipboard(ownerWindow) != 0)
        {
            return true;
        }

        PumpPendingMessages();
        std::this_thread::sleep_for(10ms);
    } while (std::chrono::steady_clock::now() < deadline);

    return false;
}

// Fixture setup can notify desktop clipboard readers. Wait for their bounded quiet point before
// issuing the product's single copy/cut/paste action; this helper never retries a product command.
[[nodiscard]] bool WaitForClipboardQuietForSelfTest(HWND ownerWindow) noexcept
{
    using namespace std::chrono_literals;
    const auto deadline    = std::chrono::steady_clock::now() + SelfTest::Scale(3000ms);
    auto quietSince        = std::chrono::steady_clock::now();
    DWORD previousSequence = GetClipboardSequenceNumber();
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        const auto now       = std::chrono::steady_clock::now();
        const DWORD sequence = GetClipboardSequenceNumber();
        if (sequence != previousSequence || GetOpenClipboardWindow() != nullptr)
        {
            previousSequence = sequence;
            quietSince       = now;
        }
        else if (now - quietSince >= 250ms)
        {
            // A null open-window handle alone does not rule out a null-owner clipboard lock.
            if (OpenClipboard(ownerWindow) != FALSE)
            {
                const auto closeClipboard = wil::scope_exit([]() noexcept { static_cast<void>(CloseClipboard()); });
                return true;
            }
            quietSince = now;
        }
        std::this_thread::sleep_for(10ms);
    }
    return false;
}

[[nodiscard]] bool SkipIfCommandsSelfTestClipboardUnavailable(CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (OpenClipboardForSelfTest(nullptr, SelfTest::Scale(250ms)))
    {
        static_cast<void>(CloseClipboard());
        return false;
    }

    if (OpenClipboard(nullptr) != FALSE)
    {
        static_cast<void>(CloseClipboard());
        return false;
    }
    const DWORD error = GetLastError();
    return state.Skip(std::format(L"OS clipboard unavailable for Commands selftest (OpenClipboard error={}, openWindow=0x{:X}, owner=0x{:X}).",
                                  error,
                                  reinterpret_cast<UINT_PTR>(GetOpenClipboardWindow()),
                                  reinterpret_cast<UINT_PTR>(GetClipboardOwner())));
}

[[nodiscard]] bool SkipIfExternalProcessOwnsForeground(CaseState& state, HWND mainWindow, std::wstring_view context) noexcept
{
    const HWND foregroundWindow = GetForegroundWindow();
    if (! foregroundWindow || foregroundWindow == mainWindow)
    {
        return false;
    }

    DWORD foregroundProcessId = 0u;
    static_cast<void>(GetWindowThreadProcessId(foregroundWindow, &foregroundProcessId));
    if (foregroundProcessId == GetCurrentProcessId())
    {
        return false;
    }

    return state.Skip(std::format(L"{} requires foreground ownership; another process retained the desktop foreground (foreground=0x{:X}, pid={}).",
                                  context,
                                  reinterpret_cast<UINT_PTR>(foregroundWindow),
                                  foregroundProcessId));
}

[[nodiscard]] std::wstring ReadClipboardUnicodeText(HWND ownerWindow) noexcept
{
    using namespace std::chrono_literals;

    const auto readFallback = []() noexcept -> std::wstring
    {
        const std::optional<std::wstring> fallback = DxUi::DebugReadClipboardFallbackText();
        return fallback.value_or(std::wstring{});
    };

    std::wstring clipText;
    if (! OpenClipboardForSelfTest(ownerWindow, SelfTest::Scale(3000ms)))
    {
        return readFallback();
    }

    const auto closeClipboard = wil::scope_exit([&] { CloseClipboard(); });
    HANDLE hText              = GetClipboardData(CF_UNICODETEXT);
    if (! hText)
    {
        return readFallback();
    }

    const auto* text = static_cast<const wchar_t*>(GlobalLock(hText));
    if (! text)
    {
        return readFallback();
    }

    clipText.assign(text);
    GlobalUnlock(hText);
    return clipText;
}

void ClearClipboardContents(HWND ownerWindow) noexcept
{
    using namespace std::chrono_literals;

    DxUi::DebugClearClipboardFallbackText();

    if (! OpenClipboardForSelfTest(ownerWindow, SelfTest::Scale(3000ms)))
    {
        return;
    }

    {
        const auto closeClipboard = wil::scope_exit([&] { CloseClipboard(); });
        EmptyClipboard();
    }
    if (! WaitForClipboardQuietForSelfTest(ownerWindow))
    {
        Debug::Warning(L"Commands clipboard fixture did not reach a quiet point after clearing.");
    }
}

[[nodiscard]] std::wstring BuildLocalAdministrativeUncPath(std::wstring_view path) noexcept
{
    if (path.size() < 3u || std::iswalpha(static_cast<wint_t>(path[0])) == 0 || path[1] != L':' || (path[2] != L'\\' && path[2] != L'/'))
    {
        return {};
    }

    wchar_t computerName[MAX_COMPUTERNAME_LENGTH + 1]{};
    DWORD computerNameLength = static_cast<DWORD>(std::size(computerName));
    if (GetComputerNameW(computerName, &computerNameLength) == FALSE || computerNameLength == 0u)
    {
        return {};
    }

    std::wstring uncPath = LR"(\\)";
    uncPath.append(computerName, computerNameLength);
    uncPath.push_back(L'\\');
    uncPath.push_back(static_cast<wchar_t>(std::towupper(static_cast<wint_t>(path[0]))));
    uncPath.push_back(L'$');
    uncPath.append(path.substr(2));
    return uncPath;
}

[[nodiscard]] bool TestShortcutDefaultsMapping(CaseState& state) noexcept
{
    ShortcutManager manager;
    manager.Load(ShortcutDefaults::CreateDefaultShortcuts());

    state.Require(manager.GetApplicationConflicts().empty(), L"Default application shortcuts have conflicts.");
    state.Require(manager.GetFunctionBarConflicts().empty(), L"Default function bar shortcuts have conflicts.");
    state.Require(manager.GetFolderViewConflicts().empty(), L"Default folder view shortcuts have conflicts.");

    const std::optional<std::wstring_view> showFileOperations =
        manager.FindApplicationCommand(static_cast<uint32_t>('J'), ShortcutManager::kModCtrl | ShortcutManager::kModShift);
    state.Require(showFileOperations.has_value() && showFileOperations.value() == std::wstring_view{L"cmd/app/showFileOperations"},
                  L"Ctrl+Shift+J should show the File Operations window from application scope.");

    using ShortcutBindingExpectation                                          = std::tuple<uint32_t, uint32_t, std::wstring_view, std::wstring_view>;
    constexpr std::array<ShortcutBindingExpectation, 16> kFunctionBarBindings = {
        ShortcutBindingExpectation{VK_F3, 0u, std::wstring_view{L"cmd/pane/view"}, std::wstring_view{L"F3 default shortcut"}},
        ShortcutBindingExpectation{VK_F2, ShortcutManager::kModCtrl, std::wstring_view{L"cmd/pane/sort/none"}, std::wstring_view{L"Ctrl+F2 default shortcut"}},
        ShortcutBindingExpectation{VK_F3, ShortcutManager::kModCtrl, std::wstring_view{L"cmd/pane/sort/name"}, std::wstring_view{L"Ctrl+F3 default shortcut"}},
        ShortcutBindingExpectation{VK_F3,
                                   ShortcutManager::kModCtrl | ShortcutManager::kModShift,
                                   std::wstring_view{L"cmd/app/viewWidth"},
                                   std::wstring_view{L"Ctrl+Shift+F3 default shortcut"}},
        ShortcutBindingExpectation{
            VK_F4, ShortcutManager::kModCtrl, std::wstring_view{L"cmd/pane/sort/extension"}, std::wstring_view{L"Ctrl+F4 default shortcut"}},
        ShortcutBindingExpectation{VK_F4,
                                   ShortcutManager::kModCtrl | ShortcutManager::kModShift,
                                   std::wstring_view{L"cmd/pane/alternateEdit"},
                                   std::wstring_view{L"Ctrl+Shift+F4 default shortcut"}},
        ShortcutBindingExpectation{VK_F5, ShortcutManager::kModCtrl, std::wstring_view{L"cmd/pane/sort/time"}, std::wstring_view{L"Ctrl+F5 default shortcut"}},
        ShortcutBindingExpectation{VK_F6, ShortcutManager::kModCtrl, std::wstring_view{L"cmd/pane/sort/size"}, std::wstring_view{L"Ctrl+F6 default shortcut"}},
        ShortcutBindingExpectation{
            VK_F5, ShortcutManager::kModShift, std::wstring_view{L"cmd/pane/copyToOtherPaneWithOptions"}, std::wstring_view{L"Shift+F5 default shortcut"}},
        ShortcutBindingExpectation{
            VK_F6, ShortcutManager::kModShift, std::wstring_view{L"cmd/pane/moveToOtherPaneWithOptions"}, std::wstring_view{L"Shift+F6 default shortcut"}},
        ShortcutBindingExpectation{VK_F12, ShortcutManager::kModCtrl, std::wstring_view{L"cmd/pane/filter"}, std::wstring_view{L"Ctrl+F12 default shortcut"}},
        ShortcutBindingExpectation{
            VK_F11, ShortcutManager::kModShift, std::wstring_view{L"cmd/app/theme/selectPrev"}, std::wstring_view{L"Shift+F11 default shortcut"}},
        ShortcutBindingExpectation{
            VK_F12, ShortcutManager::kModShift, std::wstring_view{L"cmd/app/theme/selectNext"}, std::wstring_view{L"Shift+F12 default shortcut"}},
        ShortcutBindingExpectation{VK_F5,
                                   ShortcutManager::kModCtrl | ShortcutManager::kModShift,
                                   std::wstring_view{L"cmd/pane/selection/save"},
                                   std::wstring_view{L"Ctrl+Shift+F5 default shortcut"}},
        ShortcutBindingExpectation{VK_F6,
                                   ShortcutManager::kModCtrl | ShortcutManager::kModShift,
                                   std::wstring_view{L"cmd/pane/selection/restore"},
                                   std::wstring_view{L"Ctrl+Shift+F6 default shortcut"}},
        ShortcutBindingExpectation{
            VK_F8, ShortcutManager::kModShift, std::wstring_view{L"cmd/pane/permanentDelete"}, std::wstring_view{L"Shift+F8 default shortcut"}},
    };
    for (const auto& [vk, modifiers, commandId, label] : kFunctionBarBindings)
    {
        RequireFunctionBarBinding(state, manager, vk, modifiers, commandId, label);
    }

    state.Require(! manager.FindFunctionBarCommand(VK_F2, ShortcutManager::kModCtrl | ShortcutManager::kModShift).has_value(),
                  L"Ctrl+Shift+F2 should not have a default shortcut binding.");

    constexpr std::array<ShortcutBindingExpectation, 22> kFolderViewBindings = {
        ShortcutBindingExpectation{
            static_cast<uint32_t>('U'), ShortcutManager::kModCtrl, std::wstring_view{L"cmd/app/swapPanes"}, std::wstring_view{L"Ctrl+U default shortcut"}},
        ShortcutBindingExpectation{
            static_cast<uint32_t>('F'), ShortcutManager::kModCtrl, std::wstring_view{L"cmd/pane/find"}, std::wstring_view{L"Ctrl+F default shortcut"}},
        ShortcutBindingExpectation{static_cast<uint32_t>('T'),
                                   ShortcutManager::kModCtrl | ShortcutManager::kModAlt,
                                   std::wstring_view{L"cmd/terminal/openFloatingWindow"},
                                   std::wstring_view{L"Ctrl+Alt+T default shortcut"}},
        ShortcutBindingExpectation{static_cast<uint32_t>('7'),
                                   ShortcutManager::kModAlt,
                                   std::wstring_view{L"cmd/pane/openCommandShell"},
                                   std::wstring_view{L"Alt+7 default shortcut"}},
        ShortcutBindingExpectation{static_cast<uint32_t>('5'),
                                   ShortcutManager::kModAlt,
                                   std::wstring_view{L"cmd/pane/viewOptions/toggleThumbnails"},
                                   std::wstring_view{L"Alt+5 default shortcut"}},
        ShortcutBindingExpectation{static_cast<uint32_t>('6'),
                                   ShortcutManager::kModAlt,
                                   std::wstring_view{L"cmd/pane/viewOptions/togglePreviewPane"},
                                   std::wstring_view{L"Alt+6 default shortcut"}},
        ShortcutBindingExpectation{VK_ESCAPE, 0u, std::wstring_view{L"cmd/pane/selection/unselectAll"}, std::wstring_view{L"Esc default shortcut"}},
        ShortcutBindingExpectation{
            VK_BACK, ShortcutManager::kModShift, std::wstring_view{L"cmd/pane/goRootDirectory"}, std::wstring_view{L"Shift+Backspace default shortcut"}},
        ShortcutBindingExpectation{
            VK_OEM_PERIOD, ShortcutManager::kModCtrl, std::wstring_view{L"cmd/pane/setPathFromOtherPane"}, std::wstring_view{L"Ctrl+. default shortcut"}},
        ShortcutBindingExpectation{
            static_cast<uint32_t>('X'), ShortcutManager::kModCtrl, std::wstring_view{L"cmd/pane/clipboardCut"}, std::wstring_view{L"Ctrl+X default shortcut"}},
        ShortcutBindingExpectation{
            VK_UP, ShortcutManager::kModAlt, std::wstring_view{L"cmd/pane/selection/goToPreviousSelectedName"}, std::wstring_view{L"Alt+Up default shortcut"}},
        ShortcutBindingExpectation{
            VK_DOWN, ShortcutManager::kModAlt, std::wstring_view{L"cmd/pane/selection/goToNextSelectedName"}, std::wstring_view{L"Alt+Down default shortcut"}},
        ShortcutBindingExpectation{
            VK_LEFT, ShortcutManager::kModAlt, std::wstring_view{L"cmd/pane/historyBack"}, std::wstring_view{L"Alt+Left default shortcut"}},
        ShortcutBindingExpectation{
            VK_RIGHT, ShortcutManager::kModAlt, std::wstring_view{L"cmd/pane/historyForward"}, std::wstring_view{L"Alt+Right default shortcut"}},
        ShortcutBindingExpectation{VK_INSERT, 0u, std::wstring_view{L"cmd/pane/selectNext"}, std::wstring_view{L"Insert default shortcut"}},
        ShortcutBindingExpectation{
            VK_INSERT, ShortcutManager::kModCtrl, std::wstring_view{L"cmd/pane/clipboardCopy"}, std::wstring_view{L"Ctrl+Insert default shortcut"}},
        ShortcutBindingExpectation{
            VK_INSERT, ShortcutManager::kModShift, std::wstring_view{L"cmd/pane/clipboardPaste"}, std::wstring_view{L"Shift+Insert default shortcut"}},
        ShortcutBindingExpectation{
            VK_INSERT, ShortcutManager::kModAlt, std::wstring_view{L"cmd/pane/copyPathAndNameAsText"}, std::wstring_view{L"Alt+Insert default shortcut"}},
        ShortcutBindingExpectation{VK_INSERT,
                                   ShortcutManager::kModAlt | ShortcutManager::kModShift,
                                   std::wstring_view{L"cmd/pane/copyNameAsText"},
                                   std::wstring_view{L"Alt+Shift+Insert default shortcut"}},
        ShortcutBindingExpectation{VK_INSERT,
                                   ShortcutManager::kModCtrl | ShortcutManager::kModAlt,
                                   std::wstring_view{L"cmd/pane/copyPathAsText"},
                                   std::wstring_view{L"Ctrl+Alt+Insert default shortcut"}},
        ShortcutBindingExpectation{VK_INSERT,
                                   ShortcutManager::kModCtrl | ShortcutManager::kModShift,
                                   std::wstring_view{L"cmd/pane/copyUncPathAndNameAsText"},
                                   std::wstring_view{L"Ctrl+Shift+Insert default shortcut"}},
        ShortcutBindingExpectation{
            VK_DELETE, ShortcutManager::kModShift, std::wstring_view{L"cmd/pane/permanentDelete"}, std::wstring_view{L"Shift+Del default shortcut"}},
    };
    for (const auto& [vk, modifiers, commandId, label] : kFolderViewBindings)
    {
        const bool permanentDeleteDuplicate     = commandId == std::wstring_view{L"cmd/pane/permanentDelete"};
        const bool findAlternateBinding         = commandId == std::wstring_view{L"cmd/pane/find"};
        const bool commandShellAlternateBinding = commandId == std::wstring_view{L"cmd/pane/openCommandShell"};
        RequireFolderViewBinding(
            state, manager, vk, modifiers, commandId, label, ! permanentDeleteDuplicate && ! findAlternateBinding && ! commandShellAlternateBinding);
    }

    state.Require(! manager.TryGetShortcutForCommand(L"cmd/pane/permanentDeleteWithValidation").has_value(),
                  L"The legacy validation-suffixed permanent-delete command should not have a default shortcut.");

    Common::Settings::Settings legacySettings{};
    legacySettings.shortcuts = Common::Settings::ShortcutsSettings{};
    Common::Settings::ShortcutBinding legacyFunctionBarBinding{};
    legacyFunctionBarBinding.vk        = VK_F8;
    legacyFunctionBarBinding.modifiers = ShortcutManager::kModShift;
    legacyFunctionBarBinding.commandId = L"cmd/pane/permanentDeleteWithValidation";
    legacySettings.shortcuts->functionBar.push_back(std::move(legacyFunctionBarBinding));
    Common::Settings::ShortcutBinding legacyFolderViewBinding{};
    legacyFolderViewBinding.vk        = VK_DELETE;
    legacyFolderViewBinding.modifiers = ShortcutManager::kModShift;
    legacyFolderViewBinding.commandId = L"cmd/pane/permanentDeleteWithValidation";
    legacySettings.shortcuts->folderView.push_back(std::move(legacyFolderViewBinding));
    Common::Settings::ShortcutBinding legacyTerminalWindowBinding{};
    legacyTerminalWindowBinding.vk        = static_cast<uint32_t>('T');
    legacyTerminalWindowBinding.modifiers = ShortcutManager::kModCtrl | ShortcutManager::kModAlt;
    legacyTerminalWindowBinding.commandId = L"cmd/pane/openCommandShell";
    legacySettings.shortcuts->folderView.push_back(std::move(legacyTerminalWindowBinding));
    ShortcutDefaults::EnsureShortcutsInitialized(legacySettings);
    ShortcutManager legacyManager;
    legacyManager.Load(legacySettings.shortcuts.value());
    RequireFunctionBarBinding(state,
                              legacyManager,
                              VK_F8,
                              ShortcutManager::kModShift,
                              std::wstring_view{L"cmd/pane/permanentDelete"},
                              std::wstring_view{L"legacy Shift+F8 migrated shortcut"});
    RequireFolderViewBinding(state,
                             legacyManager,
                             VK_DELETE,
                             ShortcutManager::kModShift,
                             std::wstring_view{L"cmd/pane/permanentDelete"},
                             std::wstring_view{L"legacy Shift+Del migrated shortcut"},
                             false);
    RequireFolderViewBinding(state,
                             legacyManager,
                             static_cast<uint32_t>('T'),
                             ShortcutManager::kModCtrl | ShortcutManager::kModAlt,
                             std::wstring_view{L"cmd/terminal/openFloatingWindow"},
                             std::wstring_view{L"legacy Ctrl+Alt+T floating-terminal migration"},
                             false);
    state.Require(legacySettings.shortcuts->migrationVersion == 1u, L"Legacy Ctrl+Alt+T migration should persist its one-shot version.");
    Common::Settings::ShortcutBinding* migratedCtrlAltT = nullptr;
    for (Common::Settings::ShortcutBinding& binding : legacySettings.shortcuts->folderView)
    {
        if (binding.vk == static_cast<uint32_t>('T') && binding.modifiers == (ShortcutManager::kModCtrl | ShortcutManager::kModAlt))
        {
            migratedCtrlAltT = &binding;
            break;
        }
    }
    state.Require(migratedCtrlAltT != nullptr, L"Migrated Ctrl+Alt+T binding should remain addressable.");
    if (migratedCtrlAltT != nullptr)
    {
        migratedCtrlAltT->commandId = L"cmd/pane/openCommandShell";
        ShortcutDefaults::EnsureShortcutsInitialized(legacySettings);
        const auto reboundCtrlAltT = std::ranges::find_if(legacySettings.shortcuts->folderView, [](const Common::Settings::ShortcutBinding& binding) noexcept {
            return binding.vk == static_cast<uint32_t>('T') && binding.modifiers == (ShortcutManager::kModCtrl | ShortcutManager::kModAlt);
        });
        state.Require(reboundCtrlAltT != legacySettings.shortcuts->folderView.end() && reboundCtrlAltT->commandId == L"cmd/pane/openCommandShell",
                      L"A post-migration Ctrl+Alt+T user rebind must survive later shortcut initialization.");
    }
    RequireFolderViewBinding(state,
                             legacyManager,
                             static_cast<uint32_t>('F'),
                             ShortcutManager::kModCtrl,
                             std::wstring_view{L"cmd/pane/find"},
                             std::wstring_view{L"legacy Ctrl+F added shortcut"},
                             false);

    const auto selectDialogChordOpt = manager.TryGetShortcutForCommand(L"cmd/pane/selection/selectDialog");
    state.Require(selectDialogChordOpt.has_value(), L"Select dialog default shortcut missing.");
    if (selectDialogChordOpt.has_value())
    {
        state.Require(selectDialogChordOpt->vk == 0u, L"Select dialog should not retain a layout-dependent virtual key.");
        state.Require(selectDialogChordOpt->keyPosition == Common::Keyboard::KeyPosition::NumberRowPlus,
                      L"Select dialog should use the physical number-row-plus position.");
        state.Require(selectDialogChordOpt->modifiers == ShortcutManager::kModCtrl, L"Select dialog default shortcut expected Ctrl+<key>.");
    }

    const auto unselectDialogChordOpt = manager.TryGetShortcutForCommand(L"cmd/pane/selection/unselectDialog");
    state.Require(unselectDialogChordOpt.has_value(), L"Unselect dialog default shortcut missing.");
    if (unselectDialogChordOpt.has_value())
    {
        state.Require(unselectDialogChordOpt->vk == 0u, L"Unselect dialog should not retain a layout-dependent virtual key.");
        state.Require(unselectDialogChordOpt->keyPosition == Common::Keyboard::KeyPosition::NumberRowMinus,
                      L"Unselect dialog should use the physical number-row-minus position.");
        state.Require(unselectDialogChordOpt->modifiers == ShortcutManager::kModCtrl, L"Unselect dialog default shortcut expected Ctrl+<key>.");
    }

    if (selectDialogChordOpt.has_value() && unselectDialogChordOpt.has_value())
    {
        state.Require(selectDialogChordOpt->keyPosition != unselectDialogChordOpt->keyPosition,
                      L"Select and Unselect dialog physical positions must be distinct.");
    }

    const auto selectSameExtChordOpt = manager.TryGetShortcutForCommand(L"cmd/pane/selection/selectSameExtension");
    state.Require(selectSameExtChordOpt.has_value(), L"Select same extension default shortcut missing.");
    if (selectSameExtChordOpt.has_value() && selectDialogChordOpt.has_value())
    {
        state.Require(selectSameExtChordOpt->keyPosition == selectDialogChordOpt->keyPosition,
                      L"Select same extension expected the same physical position as Select dialog.");
        state.Require(selectSameExtChordOpt->modifiers == (ShortcutManager::kModCtrl | ShortcutManager::kModShift),
                      L"Select same extension default shortcut expected Ctrl+Shift+<key>.");
    }

    const auto unselectSameExtChordOpt = manager.TryGetShortcutForCommand(L"cmd/pane/selection/unselectSameExtension");
    state.Require(unselectSameExtChordOpt.has_value(), L"Unselect same extension default shortcut missing.");
    if (unselectSameExtChordOpt.has_value() && unselectDialogChordOpt.has_value())
    {
        state.Require(unselectSameExtChordOpt->keyPosition == unselectDialogChordOpt->keyPosition,
                      L"Unselect same extension expected the same physical position as Unselect dialog.");
        state.Require(unselectSameExtChordOpt->modifiers == (ShortcutManager::kModCtrl | ShortcutManager::kModShift),
                      L"Unselect same extension default shortcut expected Ctrl+Shift+<key>.");
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestThemeCycleCommands(HWND mainWindow, CaseState& state) noexcept
{
    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::wstring originalThemeId = g_settings.theme.currentThemeId;
    const auto restoreTheme            = wil::scope_exit([&]() noexcept
    {
        const auto restoreBuiltIn = [&](UINT commandId) noexcept
        {
            SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(commandId, 0), 0);
            PumpPendingMessages();
        };

        if (originalThemeId == L"builtin/system")
        {
            restoreBuiltIn(IDM_VIEW_THEME_SYSTEM);
        }
        else if (originalThemeId == L"builtin/light")
        {
            restoreBuiltIn(IDM_VIEW_THEME_LIGHT);
        }
        else if (originalThemeId == L"builtin/dark")
        {
            restoreBuiltIn(IDM_VIEW_THEME_DARK);
        }
        else if (originalThemeId == L"builtin/rainbow")
        {
            restoreBuiltIn(IDM_VIEW_THEME_RAINBOW);
        }
        else if (originalThemeId == L"builtin/highContrast")
        {
            restoreBuiltIn(IDM_VIEW_THEME_HIGH_CONTRAST_APP);
        }
        else
        {
            g_settings.theme.currentThemeId = originalThemeId;
        }
    });

    SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(IDM_VIEW_THEME_SYSTEM, 0), 0);
    PumpPendingMessages();
    state.Require(g_settings.theme.currentThemeId == L"builtin/system", L"Theme cycle setup should select the built-in system theme.");

    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/app/theme/selectNext"),
                  L"cmd/app/theme/selectNext should dispatch through the shortcut path.");
    PumpPendingMessages();
    state.Require(g_settings.theme.currentThemeId == L"builtin/light", L"cmd/app/theme/selectNext should advance from System to Light.");

    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/app/theme/selectPrev"),
                  L"cmd/app/theme/selectPrev should dispatch through the shortcut path.");
    PumpPendingMessages();
    state.Require(g_settings.theme.currentThemeId == L"builtin/system", L"cmd/app/theme/selectPrev should return from Light to System.");

    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/app/theme/select/builtin/dark"),
                  L"cmd/app/theme/select/<themeId> should dispatch through the shortcut path.");
    PumpPendingMessages();
    state.Require(g_settings.theme.currentThemeId == L"builtin/dark", L"cmd/app/theme/select/<themeId> should apply the requested built-in theme.");

    return state.failure.empty();
}

[[nodiscard]] bool TestGenericStatusBarCommandRoutesActivePane(HWND mainWindow, CaseState& state) noexcept
{
    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }
    const bool originalLeft  = g_folderWindow.GetStatusBarVisible(FolderWindow::Pane::Left);
    const bool originalRight = g_folderWindow.GetStatusBarVisible(FolderWindow::Pane::Right);
    const auto restoreState  = wil::scope_exit([&]() noexcept
    {
        g_folderWindow.SetStatusBarVisible(FolderWindow::Pane::Left, originalLeft);
        g_folderWindow.SetStatusBarVisible(FolderWindow::Pane::Right, originalRight);
    });

    g_folderWindow.SetStatusBarVisible(FolderWindow::Pane::Left, true);
    g_folderWindow.SetStatusBarVisible(FolderWindow::Pane::Right, true);
    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);

    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/toggleStatusBar"),
                  L"cmd/pane/viewOptions/toggleStatusBar should dispatch through the shortcut path.");
    PumpPendingMessages();
    state.Require(! g_folderWindow.GetStatusBarVisible(FolderWindow::Pane::Left), L"Generic status bar command should toggle the active left pane.");
    state.Require(g_folderWindow.GetStatusBarVisible(FolderWindow::Pane::Right), L"Generic status bar command should not toggle the inactive right pane.");

    g_folderWindow.SetActivePane(FolderWindow::Pane::Right);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/toggleStatusBar"),
                  L"cmd/pane/viewOptions/toggleStatusBar should dispatch for the active right pane.");
    PumpPendingMessages();
    state.Require(! g_folderWindow.GetStatusBarVisible(FolderWindow::Pane::Right), L"Generic status bar command should toggle the active right pane.");
    state.Require(! g_folderWindow.GetStatusBarVisible(FolderWindow::Pane::Left), L"Generic status bar command should leave the inactive left pane unchanged.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStorePaneViewOptionsRoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestPaneViewOptionsRoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings settings{};
    Common::Settings::FoldersSettings folders{};
    folders.active = L"right";

    Common::Settings::FolderPane left{};
    left.slot                       = L"left";
    left.current                    = std::filesystem::path(L"C:\\pane-left");
    left.view.display               = Common::Settings::FolderDisplayMode::Thumbnails;
    left.view.fileExtensionsVisible = false;
    left.view.thumbnailsVisible     = false;
    left.view.navigationBarVisible  = false;
    left.view.filterBarVisible      = true;
    left.view.statusBarVisible      = false;
    folders.items.push_back(std::move(left));

    Common::Settings::FolderPane right{};
    right.slot                       = L"right";
    right.current                    = std::filesystem::path(L"C:\\pane-right");
    right.view.display               = Common::Settings::FolderDisplayMode::ExtraDetailed;
    right.view.fileExtensionsVisible = true;
    right.view.thumbnailsVisible     = false;
    right.view.navigationBarVisible  = true;
    right.view.filterBarVisible      = false;
    right.view.statusBarVisible      = true;
    folders.items.push_back(std::move(right));

    settings.folders = folders;

    const Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
    state.Require(prepared.folders.has_value(), L"Pane view options should survive canonical save preparation.");

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, prepared);
    state.Require(SUCCEEDED(saveHr), L"Failed to save pane view options round-trip settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Failed to load pane view options round-trip settings.");
    state.Require(loaded.schemaVersion == 16u, L"Pane view options should persist through settings schema v16.");
    state.Require(loaded.folders.has_value(), L"Folders settings block missing after pane view options round-trip.");
    if (FAILED(loadHr) || ! loaded.folders.has_value())
    {
        return false;
    }

    const auto& actualFolders = loaded.folders.value();
    state.Require(actualFolders.items.size() == 2u, L"Expected two pane entries after pane view options round-trip.");
    if (actualFolders.items.size() != 2u)
    {
        return false;
    }

    const auto findPane = [&](std::wstring_view slot) noexcept -> const Common::Settings::FolderPane*
    {
        const auto it = std::find_if(
            actualFolders.items.begin(), actualFolders.items.end(), [&](const Common::Settings::FolderPane& pane) noexcept { return pane.slot == slot; });
        return it == actualFolders.items.end() ? nullptr : std::addressof(*it);
    };

    const Common::Settings::FolderPane* actualLeft  = findPane(L"left");
    const Common::Settings::FolderPane* actualRight = findPane(L"right");
    state.Require(actualLeft != nullptr, L"Left pane settings missing after pane view options round-trip.");
    state.Require(actualRight != nullptr, L"Right pane settings missing after pane view options round-trip.");
    if (! actualLeft || ! actualRight)
    {
        return false;
    }

    state.Require(actualLeft->view.display == Common::Settings::FolderDisplayMode::Thumbnails,
                  L"Left display mode should round-trip as exclusive thumbnail mode.");
    state.Require(! actualLeft->view.fileExtensionsVisible, L"Left fileExtensionsVisible flag did not round-trip.");
    state.Require(! actualLeft->view.thumbnailsVisible, L"Left legacy thumbnailsVisible flag should stay suppressed when display=thumbnails.");
    state.Require(! actualLeft->view.navigationBarVisible, L"Left navigationBarVisible flag did not round-trip.");
    state.Require(actualLeft->view.filterBarVisible, L"Left filterBarVisible flag did not round-trip.");
    state.Require(! actualLeft->view.statusBarVisible, L"Left statusBarVisible flag should still round-trip.");

    state.Require(actualRight->view.display == Common::Settings::FolderDisplayMode::ExtraDetailed, L"Right extra-detailed display mode did not round-trip.");
    state.Require(actualRight->view.fileExtensionsVisible, L"Right fileExtensionsVisible flag did not round-trip.");
    state.Require(! actualRight->view.thumbnailsVisible, L"Right thumbnailsVisible flag did not round-trip.");
    state.Require(actualRight->view.navigationBarVisible, L"Right navigationBarVisible flag did not round-trip.");
    state.Require(! actualRight->view.filterBarVisible, L"Right filterBarVisible flag did not round-trip.");
    state.Require(actualRight->view.statusBarVisible, L"Right statusBarVisible flag should still round-trip.");
    return state.failure.empty();
}

[[nodiscard]] bool TestFolderViewThumbnailSettingsRoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestThumbnailSettingsRoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::FolderViewSettings defaults{};
    state.Require(defaults.thumbnailSizeDip == Common::Settings::Thumbnail::kDefaultSizeDip,
                  L"Missing thumbnail size settings should default to the current thumbnail size stop.");
    state.Require(Common::Settings::Thumbnail::NormalizeSizeDip(99u) == 96u, L"99 DIP thumbnail settings should normalize to the nearest 96 DIP stop.");
    state.Require(Common::Settings::Thumbnail::StopIndexForSizeDip(99u) == 2u, L"99 DIP should map to the 96 DIP slider stop index.");

    Common::Settings::Settings settings{};
    Common::Settings::FoldersSettings folders{};
    folders.active = L"left";

    Common::Settings::FolderPane left{};
    left.slot                  = L"left";
    left.current               = std::filesystem::path(L"C:\\thumb-left");
    left.view.display          = Common::Settings::FolderDisplayMode::Thumbnails;
    left.view.thumbnailSizeDip = Common::Settings::Thumbnail::StopsDip[0u];
    folders.items.push_back(std::move(left));

    Common::Settings::FolderPane right{};
    right.slot                  = L"right";
    right.current               = std::filesystem::path(L"C:\\thumb-right");
    right.view.display          = Common::Settings::FolderDisplayMode::Thumbnails;
    right.view.thumbnailSizeDip = 99u;
    folders.items.push_back(std::move(right));

    settings.folders = std::move(folders);

    const Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
    const HRESULT saveHr                      = Common::Settings::SaveSettings(kTestAppId, prepared);
    state.Require(SUCCEEDED(saveHr), L"Failed to save thumbnail size settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Failed to load thumbnail size settings.");
    state.Require(loaded.folders.has_value(), L"Folders settings block missing after thumbnail settings round-trip.");
    if (FAILED(loadHr) || ! loaded.folders.has_value())
    {
        return false;
    }

    const auto& actualFolders = loaded.folders.value();
    const auto findPane       = [&](std::wstring_view slot) noexcept -> const Common::Settings::FolderPane*
    {
        const auto it = std::find_if(
            actualFolders.items.begin(), actualFolders.items.end(), [&](const Common::Settings::FolderPane& pane) noexcept { return pane.slot == slot; });
        return it == actualFolders.items.end() ? nullptr : std::addressof(*it);
    };

    const Common::Settings::FolderPane* actualLeft  = findPane(L"left");
    const Common::Settings::FolderPane* actualRight = findPane(L"right");
    state.Require(actualLeft != nullptr, L"Left pane missing after thumbnail settings round-trip.");
    state.Require(actualRight != nullptr, L"Right pane missing after thumbnail settings round-trip.");
    if (! actualLeft || ! actualRight)
    {
        return false;
    }

    state.Require(actualLeft->view.thumbnailSizeDip == Common::Settings::Thumbnail::StopsDip[0u],
                  std::format(L"Left thumbnail size should round-trip independently; actual={} DIP.", actualLeft->view.thumbnailSizeDip));
    state.Require(actualRight->view.thumbnailSizeDip == 96u,
                  std::format(L"Right off-stop thumbnail size should quantize to 96 DIP; actual={} DIP.", actualRight->view.thumbnailSizeDip));

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreMakeFileListRoundTrip(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestMakeFileListRoundTrip";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings settings{};
    Common::Settings::MakeFileListSettings makeFileList{};
    makeFileList.sourceMode         = Common::Settings::MakeFileListSourceMode::CurrentFolder;
    makeFileList.recursive          = true;
    makeFileList.format             = Common::Settings::MakeFileListFormat::Csv;
    makeFileList.outputTarget       = Common::Settings::MakeFileListOutputTarget::File;
    makeFileList.textMacro          = L"{fullPath}|{size}|{modified}|{attributes}";
    makeFileList.outputFile         = std::filesystem::path(L"C:\\Reports\\file-list.csv");
    makeFileList.includeName        = true;
    makeFileList.includeFullPath    = true;
    makeFileList.includeSize        = true;
    makeFileList.includeModified    = true;
    makeFileList.includeAttributes  = true;
    makeFileList.includeDirectories = true;
    settings.makeFileList           = makeFileList;

    const Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
    state.Require(prepared.makeFileList.has_value(), L"Make File List settings should survive canonical save preparation.");

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, prepared);
    state.Require(SUCCEEDED(saveHr), L"Failed to save Make File List round-trip settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Failed to load Make File List round-trip settings.");
    state.Require(loaded.schemaVersion == 16u, L"Make File List should persist through settings schema v16.");
    state.Require(loaded.makeFileList.has_value(), L"Make File List settings block missing after round-trip.");
    if (FAILED(loadHr) || ! loaded.makeFileList.has_value())
    {
        return false;
    }

    const Common::Settings::MakeFileListSettings& actual = loaded.makeFileList.value();
    state.Require(actual.sourceMode == Common::Settings::MakeFileListSourceMode::CurrentFolder, L"Make File List source mode did not round-trip.");
    state.Require(actual.recursive, L"Make File List recursive flag did not round-trip.");
    state.Require(actual.format == Common::Settings::MakeFileListFormat::Csv, L"Make File List format did not round-trip.");
    state.Require(actual.outputTarget == Common::Settings::MakeFileListOutputTarget::File, L"Make File List output target did not round-trip.");
    state.Require(actual.textMacro == makeFileList.textMacro, L"Make File List text macro did not round-trip.");
    state.Require(actual.outputFile == makeFileList.outputFile, L"Make File List output file did not round-trip.");
    state.Require(actual.includeName && actual.includeFullPath && actual.includeSize && actual.includeModified && actual.includeAttributes,
                  L"Make File List field selection did not round-trip.");
    state.Require(actual.includeDirectories, L"Make File List directory inclusion flag did not round-trip.");
    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsStoreMakeFileListSuppressesDefaultFields(CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestMakeFileListDefaultSuppression";
    CleanupSettingsArtifacts(kTestAppId);
    const auto cleanup = wil::scope_exit([&] { CleanupSettingsArtifacts(kTestAppId); });

    Common::Settings::Settings settings{};
    Common::Settings::MakeFileListSettings makeFileList{};
    makeFileList.format   = Common::Settings::MakeFileListFormat::Csv;
    settings.makeFileList = makeFileList;

    const Common::Settings::Settings prepared = SettingsSave::PrepareForSave(settings);
    state.Require(prepared.makeFileList.has_value(), L"Make File List non-default format should survive save preparation.");

    const HRESULT saveHr = Common::Settings::SaveSettings(kTestAppId, prepared);
    state.Require(SUCCEEDED(saveHr), L"Failed to save Make File List default-suppression settings.");
    if (FAILED(saveHr))
    {
        return false;
    }

    const std::filesystem::path settingsPath = Common::Settings::GetSettingsPath(kTestAppId);
    std::string json;
    std::ifstream input(settingsPath, std::ios::binary);
    state.Require(input.is_open(), L"Failed to open Make File List settings JSON.");
    if (input.is_open())
    {
        json.assign(std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>());
    }
    state.Require(! json.empty(), L"Failed to read Make File List settings JSON.");
    if (! state.failure.empty())
    {
        return false;
    }

    state.Require(json.find("\"makeFileList\"") != std::string::npos, L"Make File List section should be written for a non-default format.");
    state.Require(json.find("\"format\"") != std::string::npos, L"Make File List non-default format should be written.");
    state.Require(json.find("\"sourceMode\"") == std::string::npos, L"Default Make File List sourceMode should be suppressed.");
    state.Require(json.find("\"recursive\"") == std::string::npos, L"Default Make File List recursive flag should be suppressed.");
    state.Require(json.find("\"outputTarget\"") == std::string::npos, L"Default Make File List outputTarget should be suppressed.");
    state.Require(json.find("\"textMacro\"") == std::string::npos, L"Default Make File List textMacro should be suppressed.");
    state.Require(json.find("\"includeName\"") == std::string::npos, L"Default Make File List includeName flag should be suppressed.");
    state.Require(json.find("\"includeFullPath\"") == std::string::npos, L"Default Make File List includeFullPath flag should be suppressed.");
    state.Require(json.find("\"includeSize\"") == std::string::npos, L"Default Make File List includeSize flag should be suppressed.");
    state.Require(json.find("\"includeModified\"") == std::string::npos, L"Default Make File List includeModified flag should be suppressed.");
    state.Require(json.find("\"includeAttributes\"") == std::string::npos, L"Default Make File List includeAttributes flag should be suppressed.");
    state.Require(json.find("\"includeDirectories\"") == std::string::npos, L"Default Make File List includeDirectories flag should be suppressed.");

    Common::Settings::Settings loaded{};
    const HRESULT loadHr = Common::Settings::TryLoadSettingsNoRecovery(kTestAppId, loaded);
    state.Require(loadHr == S_OK, L"Failed to reload Make File List default-suppression settings.");
    state.Require(loaded.makeFileList.has_value(), L"Make File List section should reload when only a non-default format is written.");
    if (FAILED(loadHr) || ! loaded.makeFileList.has_value())
    {
        return false;
    }

    const Common::Settings::MakeFileListSettings& actual = loaded.makeFileList.value();
    const Common::Settings::MakeFileListSettings defaults{};
    state.Require(actual.format == Common::Settings::MakeFileListFormat::Csv, L"Make File List non-default format did not reload.");
    state.Require(actual.sourceMode == defaults.sourceMode, L"Omitted Make File List sourceMode should reload as default.");
    state.Require(actual.recursive == defaults.recursive, L"Omitted Make File List recursive flag should reload as default.");
    state.Require(actual.outputTarget == defaults.outputTarget, L"Omitted Make File List outputTarget should reload as default.");
    state.Require(actual.textMacro == defaults.textMacro, L"Omitted Make File List textMacro should reload as default.");
    state.Require(actual.includeName == defaults.includeName && actual.includeFullPath == defaults.includeFullPath &&
                      actual.includeSize == defaults.includeSize && actual.includeModified == defaults.includeModified &&
                      actual.includeAttributes == defaults.includeAttributes && actual.includeDirectories == defaults.includeDirectories,
                  L"Omitted Make File List include flags should reload as defaults.");
    return state.failure.empty();
}

[[nodiscard]] bool TestPaneViewOptionsToggleFileExtensionsNavigationAndFilterBar(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"pane_view_options_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create pane view-options test folder.");
    state.Require(SelfTest::EnsureDirectory(root / L"folder.name"), L"Failed to create dotted folder.");
    state.Require(SelfTest::WriteTextFile(root / L"alpha.txt", "alpha"), L"Failed to create alpha.txt.");
    state.Require(SelfTest::WriteTextFile(root / L"readme", "readme"), L"Failed to create extensionless file.");
    if (! state.failure.empty())
    {
        return false;
    }

    FolderWindow::PaneViewOptionsDebugSnapshot originalLeft{};
    FolderWindow::PaneViewOptionsDebugSnapshot originalRight{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, originalLeft),
                  L"Could not capture original left pane view-options state.");
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Right, originalRight),
                  L"Could not capture original right pane view-options state.");

    const std::optional<std::filesystem::path> leftBefore = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const FolderView::NameFilterState filterBefore        = g_folderWindow.DebugGetNameFilterState(FolderWindow::Pane::Left);
    const auto restoreState                               = wil::scope_exit([&]
    {
        g_folderWindow.SetFileExtensionsVisible(FolderWindow::Pane::Left, originalLeft.fileExtensionsVisible);
        g_folderWindow.SetNavigationBarVisible(FolderWindow::Pane::Left, originalLeft.navigationBarVisible);
        g_folderWindow.SetFilterBarVisible(FolderWindow::Pane::Left, originalLeft.filterBarVisible);
        g_folderWindow.SetFileExtensionsVisible(FolderWindow::Pane::Right, originalRight.fileExtensionsVisible);
        g_folderWindow.SetNavigationBarVisible(FolderWindow::Pane::Right, originalRight.navigationBarVisible);
        g_folderWindow.SetFilterBarVisible(FolderWindow::Pane::Right, originalRight.filterBarVisible);
        g_folderWindow.SetNameFilterState(FolderWindow::Pane::Left, filterBefore);
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_folderWindow.SetFileExtensionsVisible(FolderWindow::Pane::Left, true);
    g_folderWindow.SetFileExtensionsVisible(FolderWindow::Pane::Right, true);
    g_folderWindow.SetNavigationBarVisible(FolderWindow::Pane::Left, true);
    g_folderWindow.SetNavigationBarVisible(FolderWindow::Pane::Right, true);
    g_folderWindow.SetFilterBarVisible(FolderWindow::Pane::Left, false);
    g_folderWindow.SetFilterBarVisible(FolderWindow::Pane::Right, false);

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for pane view-options test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for pane view-options test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"alpha.txt", L"readme", L"folder.name"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for pane view-options test.");
    const uint64_t paneViewOptionsItemCount = g_folderWindow.DebugGetItemCount(FolderWindow::Pane::Left);
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"alpha.txt"),
                  L"Failed to focus alpha.txt before file-extension toggle.");

    SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(IDM_RIGHT_SHOW_FILE_EXTENSIONS, 0), 0);
    PumpPendingMessages();
    FolderWindow::PaneViewOptionsDebugSnapshot leftAfterRightExtensionsMenu{};
    FolderWindow::PaneViewOptionsDebugSnapshot rightAfterRightExtensionsMenu{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, leftAfterRightExtensionsMenu),
                  L"Could not capture left pane state after right file-extension menu command.");
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Right, rightAfterRightExtensionsMenu),
                  L"Could not capture right pane state after right file-extension menu command.");
    state.Require(leftAfterRightExtensionsMenu.fileExtensionsVisible, L"Right file-extension menu command should leave the inactive left pane unchanged.");
    state.Require(! rightAfterRightExtensionsMenu.fileExtensionsVisible, L"Right file-extension menu command should hide extensions in the right pane.");
    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);

    const auto dispatchShortcut = [&](std::wstring_view commandId) noexcept -> std::chrono::microseconds
    {
        const auto started = std::chrono::steady_clock::now();
        state.Require(DebugDispatchShortcutCommand(mainWindow, commandId), std::format(L"{} should dispatch through the shortcut path.", commandId));
        PumpPendingMessages();
        return std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - started);
    };

    const std::chrono::microseconds fileExtensionsToggleUs = dispatchShortcut(L"cmd/pane/viewOptions/toggleFileExtensions");
    FolderWindow::PaneViewOptionsDebugSnapshot leftAfterExtensions{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, leftAfterExtensions),
                  L"Could not capture left pane state after file-extension toggle.");
    state.Require(! leftAfterExtensions.fileExtensionsVisible, L"File-extension toggle should hide extensions in the active left pane.");
    state.Require(leftAfterExtensions.focusedItemRealDisplayName == L"alpha.txt", L"File-extension toggle should keep the real focused item name intact.");
    state.Require(leftAfterExtensions.focusedItemVisualDisplayName == L"alpha", L"File-extension toggle should hide the .txt suffix in the rendered label.");
    state.Require(g_folderWindow.DebugHasItemDisplayName(FolderWindow::Pane::Left, L"alpha.txt"),
                  L"Operations should still resolve the real alpha.txt display name while extensions are hidden.");

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"readme"),
                  L"Failed to focus extensionless file while extensions are hidden.");
    FolderWindow::PaneViewOptionsDebugSnapshot leftExtensionless{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, leftExtensionless), L"Could not capture extensionless-file state.");
    state.Require(leftExtensionless.focusedItemVisualDisplayName == L"readme", L"Extensionless file labels should not change when file extensions are hidden.");

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"folder.name"),
                  L"Failed to focus dotted folder while extensions are hidden.");
    FolderWindow::PaneViewOptionsDebugSnapshot leftFolder{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, leftFolder), L"Could not capture dotted-folder state.");
    state.Require(leftFolder.focusedItemVisualDisplayName == L"folder.name", L"Folder labels should keep dotted names when file extensions are hidden.");

    g_folderWindow.SetActivePane(FolderWindow::Pane::Right);
    const std::chrono::microseconds navigationToggleUs = dispatchShortcut(L"cmd/pane/viewOptions/toggleNavigationBar");
    FolderWindow::PaneViewOptionsDebugSnapshot leftAfterNavigation{};
    FolderWindow::PaneViewOptionsDebugSnapshot rightAfterNavigation{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, leftAfterNavigation),
                  L"Could not capture left pane state after navigation toggle.");
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Right, rightAfterNavigation),
                  L"Could not capture right pane state after navigation toggle.");
    state.Require(leftAfterNavigation.navigationBarVisible, L"Generic navigation-bar shortcut should leave the inactive left pane unchanged.");
    state.Require(! rightAfterNavigation.navigationBarVisible, L"Generic navigation-bar shortcut should hide the active right pane navigation bar.");
    state.Require(! rightAfterNavigation.navigationViewWindowVisible, L"Hiding the navigation bar should hide its NavigationView child window.");

    SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(IDM_LEFT_NAVIGATION_BAR, 0), 0);
    PumpPendingMessages();
    FolderWindow::PaneViewOptionsDebugSnapshot leftAfterExplicitNavigation{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, leftAfterExplicitNavigation),
                  L"Could not capture left pane state after explicit navigation-bar menu command.");
    state.Require(! leftAfterExplicitNavigation.navigationBarVisible, L"Explicit left navigation-bar menu command should toggle the left pane.");

    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    g_folderWindow.SetNameFilterState(FolderWindow::Pane::Left, FolderView::NameFilterState{.enabled = true, .text = L"*.txt"}, false /* refresh */);
    PumpPendingMessages();
    const std::chrono::microseconds filterToggleUs = dispatchShortcut(L"cmd/pane/viewOptions/toggleFilterBar");
    FolderWindow::PaneViewOptionsDebugSnapshot leftAfterFilter{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, leftAfterFilter),
                  L"Could not capture left pane state after filter-bar toggle.");
    state.Require(leftAfterFilter.filterBarVisible, L"Filter-bar toggle should show the active left pane filter bar.");
    state.Require(leftAfterFilter.filterBarWindowVisible, L"Visible filter bar should have a visible child window.");
    state.Require(leftAfterFilter.filterBarUsesDxUiHost, L"Visible filter bar should be rendered by the themed DxUi host.");
    state.Require(leftAfterFilter.filterEnabled && leftAfterFilter.filterText == L"*.txt",
                  L"Showing the filter bar should preserve and expose the current pane filter.");
    state.Require(leftAfterFilter.filterBarText.find(L"*.txt") != std::wstring::npos, L"Filter bar text should include the active filter text.");

    SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(IDM_RIGHT_FILTER_BAR, 0), 0);
    PumpPendingMessages();
    FolderWindow::PaneViewOptionsDebugSnapshot rightAfterExplicitFilter{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Right, rightAfterExplicitFilter),
                  L"Could not capture right pane state after explicit filter-bar menu command.");
    state.Require(rightAfterExplicitFilter.filterBarVisible, L"Right filter-bar menu command should show the right pane filter bar.");
    state.Require(rightAfterExplicitFilter.filterBarUsesDxUiHost, L"Right filter bar should use the themed DxUi host.");

    const std::wstring perfArtifactText      = std::format(L"{{\n"
                                                           L"  \"case\": \"pane_view_options_toggle_file_extensions_navigation_filter_bar\",\n"
                                                           L"  \"itemCount\": {},\n"
                                                           L"  \"metrics\": {{\n"
                                                           L"    \"paneViewOptions.fileExtensionsToggleUs\": {},\n"
                                                           L"    \"paneViewOptions.navigationToggleUs\": {},\n"
                                                           L"    \"paneViewOptions.filterToggleUs\": {}\n"
                                                           L"  }}\n"
                                                           L"}}\n",
                                                           paneViewOptionsItemCount,
                                                           fileExtensionsToggleUs.count(),
                                                           navigationToggleUs.count(),
                                                           filterToggleUs.count());
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"pane_view_options_toggle_metrics.json");
    const bool artifactWriteOk               = ! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, perfArtifactText);
    state.Require(artifactWriteOk && SelfTest::PathExists(artifactPath), L"Failed to write pane view-options toggle perf artifact.");

    return state.failure.empty();
}

[[nodiscard]] HWND FindPaneFilterBarHostForTest(HWND mainWindow, int controlId) noexcept
{
    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        return nullptr;
    }

    HWND found = nullptr;
    std::pair<int, HWND*> payload{controlId, &found};
    EnumChildWindows(mainWindow,
                     [](HWND child, LPARAM lParam) noexcept -> BOOL
    {
        auto* payload = reinterpret_cast<std::pair<int, HWND*>*>(lParam);
        if (! payload || ! payload->second)
        {
            return TRUE;
        }

        if (GetDlgCtrlID(child) == payload->first)
        {
            *payload->second = child;
            return FALSE;
        }

        return TRUE;
    },
                     reinterpret_cast<LPARAM>(&payload));
    return found;
}

[[nodiscard]] bool TestPaneFilterBarInlineWorkflow(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"pane_filter_bar_inline_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create pane filter-bar inline test root.");
    state.Require(SelfTest::WriteTextFile(root / L"a.txt", "a"), L"Failed to create a.txt.");
    state.Require(SelfTest::WriteTextFile(root / L"b.log", "b"), L"Failed to create b.log.");
    state.Require(SelfTest::WriteTextFile(root / L"c.txt", "c"), L"Failed to create c.txt.");
    if (! state.failure.empty())
    {
        return false;
    }

    FolderWindow::PaneViewOptionsDebugSnapshot originalLeft{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, originalLeft),
                  L"Could not capture original left pane view-options state.");
    const std::optional<std::filesystem::path> leftBefore                     = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const FolderView::NameFilterState filterBefore                            = g_folderWindow.DebugGetNameFilterState(FolderWindow::Pane::Left);
    const std::optional<Common::Settings::SelectionMasksSettings> masksBefore = g_settings.selectionMasks;
    const auto restoreState                                                   = wil::scope_exit([&]
    {
        g_folderWindow.SetFilterBarVisible(FolderWindow::Pane::Left, originalLeft.filterBarVisible);
        g_folderWindow.SetNameFilterState(FolderWindow::Pane::Left, filterBefore);
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
        g_settings.selectionMasks = masksBefore;
    });

    Common::Settings::SelectionMasksSettings& masks =
        g_settings.selectionMasks.has_value() ? g_settings.selectionMasks.value() : g_settings.selectionMasks.emplace();
    masks.filterHistory = {L"*.txt", L"*.log"};

    g_folderWindow.DebugResetPaneVisibilityState(FolderWindow::Pane::Left);
    g_folderWindow.SetFilterBarVisible(FolderWindow::Pane::Left, true);
    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for pane filter-bar inline test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for pane filter-bar inline test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"a.txt", L"b.log", L"c.txt"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready before filter-bar inline test.");
    if (! state.failure.empty())
    {
        return false;
    }

    const HWND filterBar = FindPaneFilterBarHostForTest(mainWindow, 1009);
    state.Require(filterBar && IsWindow(filterBar) != FALSE && IsWindowVisible(filterBar) != FALSE,
                  L"Left pane filter bar host should be visible for inline workflow validation.");
    if (! filterBar || ! state.failure.empty())
    {
        return false;
    }

    FolderWindow::PaneViewOptionsDebugSnapshot barSnapshot{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, barSnapshot),
                  L"Could not capture visible filter-bar snapshot before inline edit.");
    state.Require(barSnapshot.filterBarComboVisible, L"Filter bar should show the editable history combo.");
    state.Require(! barSnapshot.filterBarLabelVisible, L"Filter bar should not show a redundant static Filter label when the combo already has a placeholder.");
    state.Require(barSnapshot.filterBarToggleVisible, L"Filter bar should show the Use Filter toggle.");
    state.Require(barSnapshot.filterBarHistoryItemCount >= 2u, L"Filter bar should load the same filter history entries as the dialog.");
    state.Require(barSnapshot.filterBarHistoryItems == masks.filterHistory,
                  L"Filter bar history entries should match the shared selectionMasks.filterHistory source exactly.");

    g_folderWindow.SetNameFilterState(FolderWindow::Pane::Left, FolderView::NameFilterState{.enabled = true, .text = L"*.log"});
    const auto waitForFilterState = [&](bool enabled, std::wstring_view text) noexcept
    {
        const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(3000ms);
        while (std::chrono::steady_clock::now() < deadline)
        {
            PumpPendingMessages();
            const FolderView::NameFilterState current = g_folderWindow.DebugGetNameFilterState(FolderWindow::Pane::Left);
            if (current.enabled == enabled && current.text == text)
            {
                return true;
            }
            std::this_thread::sleep_for(20ms);
        }
        return false;
    };
    state.Require(waitForFilterState(true, L"*.log"), L"Typing in the filter bar should update the pane filter state.");
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, barSnapshot),
                  L"Could not capture visible filter-bar snapshot after inline edit.");
    state.Require(barSnapshot.filterBarFieldText == L"*.log", L"Filter bar field should mirror the typed filter text.");
    state.Require(barSnapshot.filterBarToggleChecked, L"Filter bar toggle should be checked after typing a non-empty filter.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"b.log"}, SelfTest::Scale(3000ms)),
                  L"Filter bar typed mask should refresh the pane and keep b.log visible.");
    state.Require(! g_folderWindow.DebugHasItemDisplayName(FolderWindow::Pane::Left, L"a.txt"), L"Filter bar typed mask should hide a.txt.");

    g_folderWindow.SetNameFilterState(FolderWindow::Pane::Left, FolderView::NameFilterState{.enabled = false, .text = L"*.log"});
    state.Require(waitForFilterState(false, L"*.log"), L"Turning the filter-bar toggle off should keep the mask text but disable filtering.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"a.txt", L"b.log", L"c.txt"}, SelfTest::Scale(3000ms)),
                  L"Turning the filter-bar toggle off should restore unfiltered pane items.");

    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, barSnapshot),
                  L"Could not capture visible filter-bar snapshot after disabling filter.");
    state.Require(! barSnapshot.filterBarToggleChecked, L"Filter bar toggle should mirror disabled filter state.");

    g_folderWindow.SetNameFilterState(FolderWindow::Pane::Left, FolderView::NameFilterState{.enabled = true, .text = L"*.log"});
    state.Require(waitForFilterState(true, L"*.log"), L"Turning the filter-bar toggle on should reapply the filter text.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"b.log"}, SelfTest::Scale(3000ms)),
                  L"Turning the filter-bar toggle back on should re-filter the pane.");
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, barSnapshot),
                  L"Could not capture visible filter-bar snapshot after re-enabling filter.");
    state.Require(barSnapshot.filterBarToggleChecked, L"Filter bar toggle should mirror enabled filter state.");

    return state.failure.empty();
}

[[nodiscard]] bool WaitForPaneThumbnailStats(FolderWindow::Pane pane,
                                             const std::function<bool(const FolderWindow::PaneViewOptionsDebugSnapshot&)>& predicate,
                                             std::chrono::milliseconds timeout,
                                             FolderWindow::PaneViewOptionsDebugSnapshot* outSnapshot = nullptr) noexcept
{
    using namespace std::chrono_literals;

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();

        FolderWindow::PaneViewOptionsDebugSnapshot snapshot{};
        if (g_folderWindow.DebugGetPaneViewOptionsSnapshot(pane, snapshot))
        {
            if (outSnapshot != nullptr)
            {
                *outSnapshot = snapshot;
            }

            if (predicate(snapshot))
            {
                return true;
            }
        }

        std::this_thread::sleep_for(20ms);
    }

    return false;
}

[[nodiscard]] std::wstring ReadUtf8TextFileForCommandSelfTest(const std::filesystem::path& path) noexcept
{
    std::ifstream input(path, std::ios::binary);
    if (! input)
    {
        return {};
    }

    std::error_code ec;
    const auto size = std::filesystem::file_size(path, ec);
    if (ec || size == 0u || size > static_cast<uintmax_t>((std::numeric_limits<int>::max)()))
    {
        return {};
    }

    std::string bytes(static_cast<size_t>(size), '\0');
    input.read(bytes.data(), static_cast<std::streamsize>(bytes.size()));
    if (! input && ! input.eof())
    {
        return {};
    }

    if (bytes.size() >= 3u && static_cast<unsigned char>(bytes[0]) == 0xEFu && static_cast<unsigned char>(bytes[1]) == 0xBBu &&
        static_cast<unsigned char>(bytes[2]) == 0xBFu)
    {
        bytes.erase(0, 3);
    }

    if (bytes.empty())
    {
        return {};
    }

    return Common::Strings::Utf16FromUtf8StrictOrEmpty(bytes);
}

void AppendZipFixtureLe16(std::vector<unsigned char>& bytes, uint16_t value)
{
    bytes.push_back(static_cast<unsigned char>(value & 0xFFu));
    bytes.push_back(static_cast<unsigned char>((value >> 8u) & 0xFFu));
}

void AppendZipFixtureLe32(std::vector<unsigned char>& bytes, uint32_t value)
{
    AppendZipFixtureLe16(bytes, static_cast<uint16_t>(value & 0xFFFFu));
    AppendZipFixtureLe16(bytes, static_cast<uint16_t>((value >> 16u) & 0xFFFFu));
}

[[nodiscard]] uint32_t Crc32ForCommandSelfTest(std::string_view payload) noexcept
{
    uint32_t crc = 0xFFFFFFFFu;
    for (const char ch : payload)
    {
        crc ^= static_cast<unsigned char>(ch);
        for (int bit = 0; bit < 8; ++bit)
        {
            crc = (crc >> 1u) ^ ((crc & 1u) ? 0xEDB88320u : 0u);
        }
    }
    return crc ^ 0xFFFFFFFFu;
}

[[nodiscard]] bool WriteStoredZipFixtureForCommandSelfTest(const std::filesystem::path& archivePath,
                                                           std::string_view rawEntryName,
                                                           uint16_t flags,
                                                           std::string_view payload) noexcept
{
    if (rawEntryName.empty() || rawEntryName.size() > static_cast<size_t>((std::numeric_limits<uint16_t>::max)()) ||
        payload.size() > static_cast<size_t>((std::numeric_limits<uint32_t>::max)()))
    {
        return false;
    }

    std::vector<unsigned char> bytes;
    bytes.reserve(30u + rawEntryName.size() + payload.size() + 46u + rawEntryName.size() + 22u);
    const uint32_t crc32 = Crc32ForCommandSelfTest(payload);
    const uint32_t size  = static_cast<uint32_t>(payload.size());

    AppendZipFixtureLe32(bytes, 0x04034B50u);
    AppendZipFixtureLe16(bytes, 20u);
    AppendZipFixtureLe16(bytes, flags);
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe16(bytes, 33u);
    AppendZipFixtureLe32(bytes, crc32);
    AppendZipFixtureLe32(bytes, size);
    AppendZipFixtureLe32(bytes, size);
    AppendZipFixtureLe16(bytes, static_cast<uint16_t>(rawEntryName.size()));
    AppendZipFixtureLe16(bytes, 0u);
    bytes.insert(bytes.end(), rawEntryName.begin(), rawEntryName.end());
    bytes.insert(bytes.end(), payload.begin(), payload.end());

    const uint32_t centralOffset = static_cast<uint32_t>(bytes.size());
    AppendZipFixtureLe32(bytes, 0x02014B50u);
    AppendZipFixtureLe16(bytes, 20u);
    AppendZipFixtureLe16(bytes, 20u);
    AppendZipFixtureLe16(bytes, flags);
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe16(bytes, 33u);
    AppendZipFixtureLe32(bytes, crc32);
    AppendZipFixtureLe32(bytes, size);
    AppendZipFixtureLe32(bytes, size);
    AppendZipFixtureLe16(bytes, static_cast<uint16_t>(rawEntryName.size()));
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe32(bytes, 0u);
    AppendZipFixtureLe32(bytes, 0u);
    bytes.insert(bytes.end(), rawEntryName.begin(), rawEntryName.end());

    const uint32_t centralSize = static_cast<uint32_t>(bytes.size()) - centralOffset;
    AppendZipFixtureLe32(bytes, 0x06054B50u);
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe16(bytes, 1u);
    AppendZipFixtureLe16(bytes, 1u);
    AppendZipFixtureLe32(bytes, centralSize);
    AppendZipFixtureLe32(bytes, centralOffset);
    AppendZipFixtureLe16(bytes, 0u);

    std::ofstream output(archivePath, std::ios::binary | std::ios::trunc);
    if (! output)
    {
        return false;
    }

    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    return output.good();
}

struct StoredZipDeclaredEntryForCommandSelfTest
{
    std::string_view rawEntryName;
    uint16_t flags        = 0u;
    uint32_t declaredSize = 0u;
};

[[nodiscard]] bool WriteStoredZipDeclaredSizeFixtureForCommandSelfTest(const std::filesystem::path& archivePath,
                                                                       std::initializer_list<StoredZipDeclaredEntryForCommandSelfTest> entries) noexcept
{
    if (entries.size() == 0u || entries.size() > static_cast<size_t>((std::numeric_limits<uint16_t>::max)()))
    {
        return false;
    }

    struct CentralRecord
    {
        std::string rawEntryName;
        uint16_t flags             = 0u;
        uint32_t declaredSize      = 0u;
        uint32_t localHeaderOffset = 0u;
    };

    std::vector<unsigned char> bytes;
    std::vector<CentralRecord> records;
    records.reserve(entries.size());
    for (const StoredZipDeclaredEntryForCommandSelfTest& entry : entries)
    {
        if (entry.rawEntryName.empty() || entry.rawEntryName.size() > static_cast<size_t>((std::numeric_limits<uint16_t>::max)()))
        {
            return false;
        }
        if (bytes.size() > static_cast<size_t>((std::numeric_limits<uint32_t>::max)()))
        {
            return false;
        }

        const uint32_t localHeaderOffset = static_cast<uint32_t>(bytes.size());
        AppendZipFixtureLe32(bytes, 0x04034B50u);
        AppendZipFixtureLe16(bytes, 20u);
        AppendZipFixtureLe16(bytes, entry.flags);
        AppendZipFixtureLe16(bytes, 0u);
        AppendZipFixtureLe16(bytes, 0u);
        AppendZipFixtureLe16(bytes, 33u);
        AppendZipFixtureLe32(bytes, 0u);
        AppendZipFixtureLe32(bytes, entry.declaredSize);
        AppendZipFixtureLe32(bytes, entry.declaredSize);
        AppendZipFixtureLe16(bytes, static_cast<uint16_t>(entry.rawEntryName.size()));
        AppendZipFixtureLe16(bytes, 0u);
        bytes.insert(bytes.end(), entry.rawEntryName.begin(), entry.rawEntryName.end());

        records.push_back(CentralRecord{
            .rawEntryName = std::string(entry.rawEntryName), .flags = entry.flags, .declaredSize = entry.declaredSize, .localHeaderOffset = localHeaderOffset});
    }

    if (bytes.size() > static_cast<size_t>((std::numeric_limits<uint32_t>::max)()))
    {
        return false;
    }
    const uint32_t centralOffset = static_cast<uint32_t>(bytes.size());
    for (const CentralRecord& record : records)
    {
        AppendZipFixtureLe32(bytes, 0x02014B50u);
        AppendZipFixtureLe16(bytes, 20u);
        AppendZipFixtureLe16(bytes, 20u);
        AppendZipFixtureLe16(bytes, record.flags);
        AppendZipFixtureLe16(bytes, 0u);
        AppendZipFixtureLe16(bytes, 0u);
        AppendZipFixtureLe16(bytes, 33u);
        AppendZipFixtureLe32(bytes, 0u);
        AppendZipFixtureLe32(bytes, record.declaredSize);
        AppendZipFixtureLe32(bytes, record.declaredSize);
        AppendZipFixtureLe16(bytes, static_cast<uint16_t>(record.rawEntryName.size()));
        AppendZipFixtureLe16(bytes, 0u);
        AppendZipFixtureLe16(bytes, 0u);
        AppendZipFixtureLe16(bytes, 0u);
        AppendZipFixtureLe16(bytes, 0u);
        AppendZipFixtureLe32(bytes, 0u);
        AppendZipFixtureLe32(bytes, record.localHeaderOffset);
        bytes.insert(bytes.end(), record.rawEntryName.begin(), record.rawEntryName.end());
    }

    if (bytes.size() > static_cast<size_t>((std::numeric_limits<uint32_t>::max)()))
    {
        return false;
    }
    const uint32_t centralSize = static_cast<uint32_t>(bytes.size()) - centralOffset;
    AppendZipFixtureLe32(bytes, 0x06054B50u);
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe16(bytes, 0u);
    AppendZipFixtureLe16(bytes, static_cast<uint16_t>(records.size()));
    AppendZipFixtureLe16(bytes, static_cast<uint16_t>(records.size()));
    AppendZipFixtureLe32(bytes, centralSize);
    AppendZipFixtureLe32(bytes, centralOffset);
    AppendZipFixtureLe16(bytes, 0u);

    std::ofstream output(archivePath, std::ios::binary | std::ios::trunc);
    if (! output)
    {
        return false;
    }

    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    return output.good();
}

[[nodiscard]] bool TestMakeFileListGeneratesFormatsAndSavesOptions(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid for Make File List command test.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"make_file_list_" + NewGuidText());
    const std::filesystem::path sub  = root / L"sub";
    const std::filesystem::path bulk = root / L"bulk";
    state.Require(SelfTest::EnsureDirectory(sub) && SelfTest::EnsureDirectory(bulk), L"Failed to create Make File List test folders.");
    state.Require(SelfTest::WriteTextFile(root / L"alpha.txt", "alpha"), L"Failed to create alpha fixture.");
    state.Require(SelfTest::WriteTextFile(root / L"comma,name.txt", "csv"), L"Failed to create CSV escaping fixture.");
    state.Require(SelfTest::WriteTextFile(sub / L"nested.log", "nested"), L"Failed to create nested fixture.");
    constexpr uint64_t bulkFileCount = 1024u;
    for (uint64_t index = 0u; index < bulkFileCount; ++index)
    {
        state.Require(SelfTest::WriteTextFile(bulk / std::format(L"item-{:04}.txt", index), "x"), L"Failed to create bulk Make File List fixture.");
        if (! state.failure.empty())
        {
            return false;
        }
    }

    const std::optional<std::filesystem::path> leftBefore = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const std::wstring leftPluginBefore                   = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const auto settingsBefore                             = g_settings.makeFileList;
    const auto restoreState                               = wil::scope_exit([&]
    {
        g_settings.makeFileList = settingsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
        DebugClearMakeFileListAutomation();
    });

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for Make File List.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set pane path for Make File List.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"alpha.txt", L"comma,name.txt", L"sub"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for Make File List.");
    if (! state.failure.empty())
    {
        return false;
    }

    Common::Settings::MakeFileListSettings jsonOptions{};
    jsonOptions.sourceMode        = Common::Settings::MakeFileListSourceMode::CurrentFolder;
    jsonOptions.recursive         = true;
    jsonOptions.format            = Common::Settings::MakeFileListFormat::Json;
    jsonOptions.outputTarget      = Common::Settings::MakeFileListOutputTarget::File;
    jsonOptions.outputFile        = root / L"out.json";
    jsonOptions.includeName       = true;
    jsonOptions.includeFullPath   = true;
    jsonOptions.includeSize       = true;
    jsonOptions.includeModified   = true;
    jsonOptions.includeAttributes = true;

    DebugSetMakeFileListAutomation(jsonOptions);
    const auto jsonStarted = std::chrono::steady_clock::now();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/makeFileList"), L"cmd/pane/makeFileList should dispatch through the shortcut path.");
    const auto jsonUs = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - jsonStarted);
    state.Require(jsonUs < 250ms, L"Make File List command should return promptly while enumeration continues in the background.");
    state.Require(WaitForMakeFileListWorkerIdle(SelfTest::Scale(15000ms)), L"Make File List JSON worker did not complete.");
    state.Require(SelfTest::PathExists(jsonOptions.outputFile), L"Make File List JSON output file was not created.");

    const std::wstring jsonText = ReadUtf8TextFileForCommandSelfTest(jsonOptions.outputFile);
    state.Require(jsonText.find(L"\"format\":\"json\"") != std::wstring::npos, L"Make File List JSON should declare its format.");
    state.Require(jsonText.find(L"alpha.txt") != std::wstring::npos, L"Make File List JSON should include root files.");
    state.Require(jsonText.find(L"nested.log") != std::wstring::npos, L"Make File List JSON should include recursive files.");
    state.Require(g_settings.makeFileList.has_value() && g_settings.makeFileList->format == Common::Settings::MakeFileListFormat::Json,
                  L"Make File List should save last JSON options.");

    Common::Settings::MakeFileListSettings cancelOptions = jsonOptions;
    cancelOptions.outputFile                             = root / L"cancelled.json";
    DebugSetMakeFileListAutomation(cancelOptions);
    DebugSetMakeFileListWorkerDelay(500u);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/makeFileList"), L"Make File List cancellable worker should start.");
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/makeFileList"), L"Running Make File List command should request cancellation.");
    state.Require(WaitForMakeFileListWorkerIdle(SelfTest::Scale(5000ms)), L"Cancelled Make File List worker did not stop.");
    state.Require(! SelfTest::PathExists(cancelOptions.outputFile), L"Cancelled Make File List must not publish an output file.");

    Common::Settings::MakeFileListSettings csvOptions = jsonOptions;
    csvOptions.format                                 = Common::Settings::MakeFileListFormat::Csv;
    csvOptions.recursive                              = false;
    csvOptions.outputFile                             = root / L"out.csv";
    DebugSetMakeFileListAutomation(csvOptions);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/makeFileList"), L"cmd/pane/makeFileList CSV should dispatch.");
    state.Require(WaitForMakeFileListWorkerIdle(SelfTest::Scale(15000ms)), L"Make File List CSV worker did not complete.");
    const std::wstring csvText = ReadUtf8TextFileForCommandSelfTest(csvOptions.outputFile);
    state.Require(csvText.find(L"\"comma,name.txt\"") != std::wstring::npos, L"Make File List CSV should quote fields containing commas.");
    state.Require(csvText.find(L"nested.log") == std::wstring::npos, L"Make File List CSV should respect non-recursive current-folder scope.");

    Common::Settings::MakeFileListSettings textOptions = jsonOptions;
    textOptions.format                                 = Common::Settings::MakeFileListFormat::Text;
    textOptions.outputFile                             = root / L"out.txt";
    textOptions.textMacro                              = L"{filename}|{size}|{attributes}";
    DebugSetMakeFileListAutomation(textOptions);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/makeFileList"), L"cmd/pane/makeFileList text should dispatch.");
    state.Require(WaitForMakeFileListWorkerIdle(SelfTest::Scale(15000ms)), L"Make File List text worker did not complete.");
    const std::wstring textOutput = ReadUtf8TextFileForCommandSelfTest(textOptions.outputFile);
    state.Require(textOutput.find(L"alpha.txt|5|") != std::wstring::npos, L"Make File List text macro should expand filename, size, and attributes.");

    const std::wstring perfArtifactText      = std::format(L"{{\n"
                                                           L"  \"scenario\": \"cmd/pane/makeFileList\",\n"
                                                           L"  \"makeFileList.command_return_us\": {},\n"
                                                           L"  \"entryCount\": {}\n"
                                                           L"}}\n",
                                                           jsonUs.count(),
                                                           bulkFileCount + 5u);
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"make_file_list_metrics.json");
    const bool artifactWriteOk               = ! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, perfArtifactText);
    state.Require(artifactWriteOk && SelfTest::PathExists(artifactPath), L"Failed to write Make File List perf artifact.");
    return state.failure.empty();
}

[[nodiscard]] bool TestListOpenedFilesShowsSourcesPrunesClosedEditorsAndFocusesItems(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid for List Opened Files command test.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root      = suiteRoot / L"work" / (L"list_opened_files_" + NewGuidText());
    const std::filesystem::path otherRoot = root / L"other";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(otherRoot), L"Failed to create List Opened Files test folders.");
    state.Require(SelfTest::WriteTextFile(root / L"editor.opened", "editor"), L"Failed to create external editor fixture.");
    state.Require(SelfTest::WriteTextFile(root / L"closed.opened", "closed"), L"Failed to create closed editor fixture.");
    state.Require(SelfTest::WriteTextFile(root / L"beta-preview.txt", "beta preview body"), L"Failed to create preview fixture.");
    state.Require(SelfTest::WriteTextFile(root / L"gamma.opened", "viewer"), L"Failed to create viewer fixture.");
    state.Require(SelfTest::WriteTextFile(otherRoot / L"placeholder.txt", "placeholder"), L"Failed to create alternate folder fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const AppTheme themeBefore                                      = g_folderWindow.GetTheme();
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.DebugCloseOpenedFilesDialogForTest();
        g_folderWindow.DebugClearOpenedExternalEditorsForTest();
        g_folderWindow.CloseAllViewers();
        FolderWindow::PreviewPaneDebugSnapshot preview{};
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(preview) && preview.active)
        {
            g_folderWindow.SetActivePane(preview.sourcePane);
            static_cast<void>(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"));
            PumpPendingMessages();
        }
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
        g_folderWindow.ApplyTheme(themeBefore);
    });

    const AppTheme listOpenedFilesTheme = ResolveAppTheme(ThemeMode::Dark, L"list-opened-files-selftest");
    g_folderWindow.ApplyTheme(listOpenedFilesTheme);

    g_folderWindow.DebugCloseOpenedFilesDialogForTest();
    g_folderWindow.DebugClearOpenedExternalEditorsForTest();
    g_folderWindow.CloseAllViewers();
    FolderWindow::PreviewPaneDebugSnapshot previewBeforeEmpty{};
    if (g_folderWindow.DebugGetPreviewPaneSnapshot(previewBeforeEmpty) && previewBeforeEmpty.active)
    {
        g_folderWindow.SetActivePane(previewBeforeEmpty.sourcePane);
        static_cast<void>(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"));
        PumpPendingMessages();
    }

    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/listOpenedFiles"),
                  L"cmd/pane/listOpenedFiles should dispatch through the shortcut path for the empty state.");
    PumpPendingMessages();
    FolderWindow::OpenedFilesDebugSnapshot emptySnapshot{};
    state.Require(g_folderWindow.DebugGetOpenedFilesDialogSnapshot(emptySnapshot), L"List Opened Files dialog snapshot should be available.");
    state.Require(emptySnapshot.visible, L"List Opened Files should show a dialog.");
    state.Require(emptySnapshot.usesDxUiHost, L"List Opened Files should use the themed DxUi host instead of the Win32 dialog-template surface.");
    state.Require(emptySnapshot.visibleNativeChildControlCount <= 1u,
                  L"List Opened Files should not expose visible native dialog-template controls in DxUi mode.");
    state.Require(emptySnapshot.dialogClassName == L"RedSalamander.OpenedFilesWindow",
                  std::format(L"List Opened Files should use the DxUi window class; got '{}'.", emptySnapshot.dialogClassName));
    state.Require(emptySnapshot.themeWindowBackground == listOpenedFilesTheme.windowBackground,
                  L"List Opened Files should receive the active app theme background.");
    state.Require(emptySnapshot.themeText == listOpenedFilesTheme.menu.text, L"List Opened Files should receive the active app theme text color.");
    state.Require(emptySnapshot.emptyStateVisible, L"List Opened Files should show an empty state when nothing is open.");
    state.Require(emptySnapshot.rows.empty(), L"Empty List Opened Files dialog should have no rows.");
    g_folderWindow.DebugCloseOpenedFilesDialogForTest();
    if (! state.failure.empty())
    {
        return false;
    }

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition viewerAction{};
    viewerAction.id          = L"opened-files-viewer";
    viewerAction.displayName = L"Opened Files Text Viewer";
    viewerAction.enabled     = true;
    viewerAction.kind        = Common::Settings::FileActionKind::ViewerPlugin;
    viewerAction.pluginId    = L"builtin/viewer-text";
    TestSetActionExtensions(viewerAction, {L".opened"});
    g_settings.fileActions.viewers.actions.push_back(std::move(viewerAction));
    g_settings.fileActions.viewers.associations.push_back(TestViewerAssociation(L".opened", L"opened-files-viewer"));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for List Opened Files.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for List Opened Files.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"editor.opened", L"beta-preview.txt", L"gamma.opened"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for List Opened Files.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"beta-preview.txt"), L"Failed to focus beta preview item.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.DebugAddOpenedExternalEditorForTest(root / L"editor.opened", L"Manual Test Editor", FolderWindow::Pane::Left, false);
    g_folderWindow.DebugAddOpenedExternalEditorForTest(root / L"closed.opened", L"Closed Test Editor", FolderWindow::Pane::Left, true);

    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    FocusFolderViewPane(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"),
                  L"Preview pane should dispatch before List Opened Files.");
    PumpPendingMessages();
    FolderWindow::PreviewPaneDebugSnapshot previewSnapshot{};
    state.Require(g_folderWindow.DebugGetPreviewPaneSnapshot(previewSnapshot) && previewSnapshot.active,
                  L"Preview pane should be active before List Opened Files.");

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"gamma.opened"), L"Failed to focus viewer fixture.");
    const size_t viewerBaseline = g_folderWindow.DebugGetViewerInstanceCount();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/view"), L"cmd/pane/view should open the configured viewer for List Opened Files.");
    const auto viewerDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < viewerDeadline && g_folderWindow.DebugGetViewerInstanceCount() <= viewerBaseline)
    {
        PumpPendingMessages();
        std::this_thread::sleep_for(20ms);
    }
    state.Require(g_folderWindow.DebugGetViewerInstanceCount() > viewerBaseline, L"List Opened Files setup should create an internal viewer instance.");

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"beta-preview.txt"), L"Failed to restore preview fixture focus.");
    PumpPendingMessages();

    const auto listStarted = std::chrono::steady_clock::now();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/listOpenedFiles"),
                  L"cmd/pane/listOpenedFiles should dispatch through the shortcut path with active sources.");
    PumpPendingMessages();
    const auto listUs = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - listStarted);

    FolderWindow::OpenedFilesDebugSnapshot snapshot{};
    state.Require(g_folderWindow.DebugGetOpenedFilesDialogSnapshot(snapshot), L"List Opened Files populated snapshot should be available.");
    state.Require(snapshot.visible, L"Populated List Opened Files should keep the dialog visible.");
    state.Require(! snapshot.emptyStateVisible, L"Populated List Opened Files should hide the empty state.");
    state.Require(snapshot.rows.size() == 3u, std::format(L"List Opened Files should contain viewer, editor, and preview rows; got {}.", snapshot.rows.size()));

    const auto findRow = [&](std::wstring_view filename, std::wstring_view sourceFragment) noexcept -> std::optional<size_t>
    {
        for (size_t index = 0; index < snapshot.rows.size(); ++index)
        {
            const FolderWindow::OpenedFilesDebugRow& row = snapshot.rows[index];
            if (OrdinalString::EqualsNoCase(row.path.filename().wstring(), filename) && row.source.find(sourceFragment) != std::wstring::npos)
            {
                return index;
            }
        }
        return std::nullopt;
    };

    const std::optional<size_t> editorIndex  = findRow(L"editor.opened", L"Editor");
    const std::optional<size_t> previewIndex = findRow(L"beta-preview.txt", L"Preview");
    const std::optional<size_t> viewerIndex  = findRow(L"gamma.opened", L"Viewer");
    state.Require(editorIndex.has_value(), L"List Opened Files should show the tracked external editor row.");
    state.Require(previewIndex.has_value(), L"List Opened Files should show the preview pane row.");
    state.Require(viewerIndex.has_value(), L"List Opened Files should show the viewer row.");
    state.Require(! findRow(L"closed.opened", L"Editor").has_value(), L"List Opened Files should prune closed external editor rows.");
    if (editorIndex.has_value())
    {
        const FolderWindow::OpenedFilesDebugRow& row = snapshot.rows[editorIndex.value()];
        state.Require(row.openedBy.find(L"Manual Test Editor") != std::wstring::npos, L"Editor row should display the configured editor name.");
        state.Require(row.focusable, L"Editor row should be focusable.");
    }
    if (viewerIndex.has_value())
    {
        const FolderWindow::OpenedFilesDebugRow& row = snapshot.rows[viewerIndex.value()];
        state.Require(row.openedBy.find(L"Opened Files Text Viewer") != std::wstring::npos, L"Viewer row should display the viewer action name.");
        state.Require(row.focusable, L"Viewer row should be focusable.");
    }

    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, otherRoot);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, otherRoot, SelfTest::Scale(3000ms)),
                  L"Failed to move away from the opened file before focusing its row.");
    state.Require(g_folderWindow.DebugSelectOpenedFilesDialogRow(editorIndex.value()), L"Failed to select external editor row.");
    state.Require(g_folderWindow.DebugInvokeOpenedFilesDialogFocusItem(), L"Failed to invoke List Opened Files focus action.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Focusing an opened file should navigate back to its folder.");
    state.Require(OrdinalString::EqualsNoCase(g_folderWindow.DebugGetFocusedItemDisplayName(FolderWindow::Pane::Left), L"editor.opened"),
                  L"Focusing an opened file should select the matching pane item.");
    PumpPendingMessages();
    FolderWindow::OpenedFilesDebugSnapshot closedSnapshot{};
    state.Require(! g_folderWindow.DebugGetOpenedFilesDialogSnapshot(closedSnapshot),
                  L"List Opened Files should close after Focus Item without leaving a stale dialog state.");

    const std::wstring perfArtifactText      = std::format(L"{{\n"
                                                           L"  \"scenario\": \"cmd/pane/listOpenedFiles\",\n"
                                                           L"  \"listOpenedFiles.open_us\": {},\n"
                                                           L"  \"rowCount\": {}\n"
                                                           L"}}\n",
                                                           listUs.count(),
                                                           static_cast<unsigned long long>(snapshot.rows.size()));
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"list_opened_files_metrics.json");
    const bool artifactWriteOk               = ! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, perfArtifactText);
    state.Require(artifactWriteOk && SelfTest::PathExists(artifactPath), L"Failed to write List Opened Files perf artifact.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSharedDirectoriesShowsSyntheticRowsOpensPathsAndReportsAccessDenied(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid for Shared Directories command test.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root      = suiteRoot / L"work" / (L"shared_directories_" + NewGuidText());
    const std::filesystem::path sharePath = root / L"AlphaShareRoot";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(sharePath), L"Failed to create Shared Directories test folder.");
    state.Require(SelfTest::WriteTextFile(sharePath / L"visible.txt", "share"), L"Failed to create Shared Directories fixture file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                   = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const auto restoreState                               = wil::scope_exit([&]
    {
        g_folderWindow.DebugCloseSharedDirectoriesDialogForTest();
        g_folderWindow.DebugClearSharedDirectoriesProviderForTest();
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for Shared Directories.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for Shared Directories.");
    if (! state.failure.empty())
    {
        return false;
    }

    FolderWindow::SharedDirectoriesDebugProviderResult providerResult{};
    FolderWindow::SharedDirectoryDebugRow beta{};
    beta.name      = L"BetaShare";
    beta.localPath = (root / L"BetaRoot").wstring();
    beta.type      = L"Disk";
    beta.remark    = L"Second synthetic share";
    beta.openable  = false;
    providerResult.rows.push_back(std::move(beta));

    FolderWindow::SharedDirectoryDebugRow alpha{};
    alpha.name      = L"AlphaShare";
    alpha.localPath = sharePath.wstring();
    alpha.type      = L"Disk";
    alpha.remark    = L"Primary synthetic share";
    alpha.openable  = true;
    providerResult.rows.push_back(std::move(alpha));

    g_folderWindow.DebugSetSharedDirectoriesProviderResultForTest(providerResult);

    const auto started = std::chrono::steady_clock::now();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/shares"), L"cmd/pane/shares should dispatch through the shortcut path.");
    PumpPendingMessages();
    const auto openUs = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - started);

    FolderWindow::SharedDirectoriesDebugSnapshot snapshot{};
    state.Require(g_folderWindow.DebugGetSharedDirectoriesDialogSnapshot(snapshot), L"Shared Directories dialog snapshot should be available.");
    state.Require(snapshot.visible, L"Shared Directories should show a dialog.");
    state.Require(snapshot.usesDxUiHost, L"Shared Directories should use the DxUi host instead of a native common-control list.");
    state.Require(snapshot.visibleNativeChildControlCount == 0u,
                  std::format(L"Shared Directories should not expose visible native child controls; got {}.", snapshot.visibleNativeChildControlCount));
    state.Require(! OrdinalString::EqualsNoCase(snapshot.dialogClassName, L"#32770"),
                  L"Shared Directories should not use a native dialog-template window class.");
    state.Require(! snapshot.emptyStateVisible, L"Shared Directories populated dialog should hide the empty state.");
    state.Require(SUCCEEDED(snapshot.lastError), L"Shared Directories populated snapshot should not report an error.");
    state.Require(snapshot.rows.size() == 2u, std::format(L"Shared Directories should show two synthetic rows; got {}.", snapshot.rows.size()));
    if (snapshot.rows.size() == 2u)
    {
        state.Require(OrdinalString::EqualsNoCase(snapshot.rows[0].name, L"AlphaShare"), L"Shared Directories rows should be sorted by share name.");
        state.Require(snapshot.rows[0].localPath == sharePath.wstring(), L"Shared Directories should preserve local share path.");
        state.Require(snapshot.rows[0].remark == L"Primary synthetic share", L"Shared Directories should display share remarks.");
        state.Require(snapshot.rows[0].openable, L"Shared Directories row with an existing local path should be openable.");
    }

    state.Require(g_folderWindow.DebugSelectSharedDirectoriesDialogRow(0u), L"Failed to select Shared Directories row.");
    state.Require(g_folderWindow.DebugInvokeSharedDirectoriesDialogOpenPath(), L"Failed to invoke Shared Directories open action.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, sharePath, SelfTest::Scale(3000ms)),
                  L"Opening a shared directory should navigate the focused pane to the local shared path.");
    PumpPendingMessages();
    FolderWindow::SharedDirectoriesDebugSnapshot closedSnapshot{};
    state.Require(! g_folderWindow.DebugGetSharedDirectoriesDialogSnapshot(closedSnapshot),
                  L"Shared Directories should close after Open Path without leaving a stale dialog state.");

    FolderWindow::SharedDirectoriesDebugProviderResult accessDenied{};
    accessDenied.hr = HRESULT_FROM_WIN32(ERROR_ACCESS_DENIED);
    g_folderWindow.DebugSetSharedDirectoriesProviderResultForTest(accessDenied);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/shares"), L"cmd/pane/shares should dispatch for access denied provider result.");
    PumpPendingMessages();

    FolderWindow::SharedDirectoriesDebugSnapshot deniedSnapshot{};
    state.Require(g_folderWindow.DebugGetSharedDirectoriesDialogSnapshot(deniedSnapshot), L"Shared Directories access denied snapshot should be available.");
    state.Require(deniedSnapshot.visible, L"Shared Directories access denied path should keep the dialog visible.");
    state.Require(deniedSnapshot.emptyStateVisible, L"Shared Directories access denied path should show the empty/error state.");
    state.Require(deniedSnapshot.rows.empty(), L"Shared Directories access denied path should not show stale rows.");
    state.Require(deniedSnapshot.lastError == HRESULT_FROM_WIN32(ERROR_ACCESS_DENIED),
                  L"Shared Directories should report access denied through the debug snapshot.");

    const std::wstring perfArtifactText      = std::format(L"{{\n"
                                                           L"  \"scenario\": \"cmd/pane/shares\",\n"
                                                           L"  \"sharedDirectories.open_us\": {},\n"
                                                           L"  \"rowCount\": {}\n"
                                                           L"}}\n",
                                                           openUs.count(),
                                                           2u);
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"shared_directories_metrics.json");
    const bool artifactWriteOk               = ! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, perfArtifactText);
    state.Require(artifactWriteOk && SelfTest::PathExists(artifactPath), L"Failed to write Shared Directories perf artifact.");

    return state.failure.empty();
}

[[nodiscard]] bool TestArchiveCommandsPackUnpackZipRoundTripAndValidation(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid for archive command test.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root       = suiteRoot / L"work" / (L"archive_commands_" + NewGuidText());
    const std::filesystem::path sourceRoot = root / L"source";
    const std::filesystem::path nestedRoot = sourceRoot / L"nested";
    const std::filesystem::path emptyRoot  = sourceRoot / L"empty-dir";
    const std::filesystem::path outputRoot = root / L"output";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(nestedRoot), L"Failed to create archive nested fixture folder.");
    state.Require(SelfTest::EnsureDirectory(emptyRoot), L"Failed to create archive empty fixture folder.");
    state.Require(SelfTest::EnsureDirectory(outputRoot), L"Failed to create archive output folder.");
    state.Require(SelfTest::WriteTextFile(sourceRoot / L"alpha.txt", "alpha"), L"Failed to create archive alpha fixture.");
    state.Require(SelfTest::WriteTextFile(nestedRoot / L"beta.txt", "beta"), L"Failed to create archive beta fixture.");
    for (int index = 0; index < 12; ++index)
    {
        const std::wstring fileName = std::format(L"item_{:02}.txt", index);
        state.Require(SelfTest::WriteTextFile(nestedRoot / fileName, std::format("{}", index)), std::format(L"Failed to create archive fixture {}.", fileName));
    }
    if (! state.failure.empty())
    {
        return false;
    }

    const std::optional<std::filesystem::path> leftBefore = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const std::wstring leftPluginBefore                   = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const auto restoreState                               = wil::scope_exit([&]
    {
        g_folderWindow.DebugClearArchiveCommandOptionsForTest();
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for archive commands.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, sourceRoot);
    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, sourceRoot, SelfTest::Scale(3000ms)), L"Failed to set pane path for archive commands.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"alpha.txt", L"nested", L"empty-dir"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for archive commands.");
    g_folderWindow.SetPaneSelectionByDisplayNamePredicate(FolderWindow::Pane::Left, [](std::wstring_view displayName) noexcept {
        return displayName == L"alpha.txt" || displayName == L"nested" || displayName == L"empty-dir";
    });
    state.Require(g_folderWindow.DebugGetSelectedCount(FolderWindow::Pane::Left) == 3u, L"Archive pack test should select three top-level items.");
    if (! state.failure.empty())
    {
        return false;
    }

    const auto containsEntry = [](const std::vector<std::wstring>& entries, std::wstring_view expected) noexcept
    { return std::find_if(entries.begin(), entries.end(), [&](const std::wstring& entry) noexcept { return entry == expected; }) != entries.end(); };
    const auto entriesAreSorted = [](const std::vector<std::wstring>& entries) noexcept
    {
        for (size_t index = 1u; index < entries.size(); ++index)
        {
            if (entries[index - 1u] > entries[index])
            {
                return false;
            }
        }
        return true;
    };

    const std::filesystem::path archivePath = outputRoot / L"selected.zip";
    FolderWindow::ArchiveCommandDebugOptions packOptions{};
    packOptions.archivePath = archivePath;
    packOptions.overwrite   = true;
    g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(packOptions);

    const auto packStarted = std::chrono::steady_clock::now();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/pack"), L"cmd/pane/pack should dispatch through the shortcut path.");
    PumpPendingMessages();
    const auto packUs = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - packStarted);

    const std::optional<FolderWindow::ArchiveCommandDebugResult> packResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
    state.Require(packResult.has_value(), L"Pack command should record a debug result.");
    if (packResult.has_value())
    {
        state.Require(packResult->operation == L"pack", L"Pack command debug result should identify the operation.");
        state.Require(SUCCEEDED(packResult->hr), L"Pack command should succeed for local selected items.");
        state.Require(packResult->archivePath == archivePath, L"Pack command should write the requested archive path.");
        state.Require(packResult->entryCount >= 15u,
                      std::format(L"Pack command should include files and empty folders; got {} entries.", packResult->entryCount));
        state.Require(packResult->bytesProcessed >= 11u, L"Pack command should report processed payload bytes.");
        state.Require(entriesAreSorted(packResult->entries), L"Pack command should emit deterministic sorted archive entries.");
        state.Require(containsEntry(packResult->entries, L"alpha.txt"), L"Pack command should include selected root file.");
        state.Require(containsEntry(packResult->entries, L"nested/beta.txt"), L"Pack command should include nested files.");
        state.Require(containsEntry(packResult->entries, L"empty-dir/"), L"Pack command should preserve empty selected directories.");
    }
    state.Require(SelfTest::PathExists(archivePath), L"Pack command should create the ZIP archive.");

    const std::filesystem::path existingArchivePath = outputRoot / L"existing.zip";
    state.Require(SelfTest::WriteTextFile(existingArchivePath, "old"), L"Failed to create existing archive overwrite fixture.");
    FolderWindow::ArchiveCommandDebugOptions noOverwritePackOptions{};
    noOverwritePackOptions.archivePath = existingArchivePath;
    noOverwritePackOptions.overwrite   = false;
    g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(noOverwritePackOptions);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/pack"), L"cmd/pane/pack overwrite validation should dispatch.");
    PumpPendingMessages();
    const std::optional<FolderWindow::ArchiveCommandDebugResult> noOverwritePackResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
    state.Require(noOverwritePackResult.has_value(), L"Pack overwrite validation should record a debug result.");
    if (noOverwritePackResult.has_value())
    {
        state.Require(noOverwritePackResult->hr == HRESULT_FROM_WIN32(ERROR_FILE_EXISTS),
                      L"Pack command should reject existing archives when overwrite is off.");
    }
    state.Require(ReadUtf8TextFileForCommandSelfTest(existingArchivePath) == L"old", L"Pack overwrite rejection should preserve the existing archive.");

    const std::filesystem::path unsafeArchivePath = nestedRoot / L"inside.zip";
    FolderWindow::ArchiveCommandDebugOptions unsafePackOptions{};
    unsafePackOptions.archivePath = unsafeArchivePath;
    unsafePackOptions.overwrite   = true;
    g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(unsafePackOptions);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/pack"), L"cmd/pane/pack unsafe-output validation should dispatch.");
    PumpPendingMessages();
    const std::optional<FolderWindow::ArchiveCommandDebugResult> unsafePackResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
    state.Require(unsafePackResult.has_value(), L"Pack unsafe-output validation should record a debug result.");
    if (unsafePackResult.has_value())
    {
        state.Require(unsafePackResult->hr == HRESULT_FROM_WIN32(ERROR_ACCESS_DENIED),
                      L"Pack command should reject an archive output inside a selected source directory.");
    }
    state.Require(! SelfTest::PathExists(unsafeArchivePath), L"Rejected pack output must not create an archive inside the selected source.");
    state.Require(ReadUtf8TextFileForCommandSelfTest(nestedRoot / L"beta.txt") == L"beta", L"Rejected pack output must preserve selected source contents.");

    const std::filesystem::path extractRoot = root / L"extracted";
    state.Require(SelfTest::EnsureDirectory(extractRoot), L"Failed to create archive extraction root.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, outputRoot);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, outputRoot, SelfTest::Scale(3000ms)), L"Failed to navigate to archive output folder.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"selected.zip"}, SelfTest::Scale(3000ms)), L"Archive output folder did not show selected.zip.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"selected.zip"), L"Failed to focus selected.zip for unpack command.");
    if (! state.failure.empty())
    {
        return false;
    }

    FolderWindow::ArchiveCommandDebugOptions unpackOptions{};
    unpackOptions.destinationPath = extractRoot;
    unpackOptions.overwrite       = true;
    g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(unpackOptions);

    const auto unpackStarted = std::chrono::steady_clock::now();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/unpack"), L"cmd/pane/unpack should dispatch through the shortcut path.");
    PumpPendingMessages();
    const auto unpackUs = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - unpackStarted);

    const std::optional<FolderWindow::ArchiveCommandDebugResult> unpackResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
    state.Require(unpackResult.has_value(), L"Unpack command should record a debug result.");
    if (unpackResult.has_value())
    {
        state.Require(unpackResult->operation == L"unpack", L"Unpack command debug result should identify the operation.");
        state.Require(SUCCEEDED(unpackResult->hr), L"Unpack command should succeed for stored ZIP archives.");
        state.Require(unpackResult->archivePath == archivePath, L"Unpack command should read the focused archive.");
        state.Require(unpackResult->destinationPath == extractRoot, L"Unpack command should use the requested destination path.");
        state.Require(unpackResult->entryCount >= 15u, L"Unpack command should report extracted archive entries.");
        state.Require(unpackResult->bytesProcessed >= 11u, L"Unpack command should report extracted payload bytes.");
        state.Require(containsEntry(unpackResult->entries, L"nested/beta.txt"), L"Unpack command should report extracted nested entries.");
    }
    state.Require(ReadUtf8TextFileForCommandSelfTest(extractRoot / L"alpha.txt") == L"alpha", L"Unpack command should extract root file content.");
    state.Require(ReadUtf8TextFileForCommandSelfTest(extractRoot / L"nested" / L"beta.txt") == L"beta", L"Unpack command should extract nested file content.");
    state.Require(std::filesystem::is_directory(extractRoot / L"empty-dir", ec), L"Unpack command should recreate empty directories.");

    state.Require(SelfTest::WriteTextFile(extractRoot / L"alpha.txt", "stale"), L"Failed to set up unpack overwrite validation.");
    FolderWindow::ArchiveCommandDebugOptions noOverwriteUnpackOptions{};
    noOverwriteUnpackOptions.destinationPath = extractRoot;
    noOverwriteUnpackOptions.overwrite       = false;
    g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(noOverwriteUnpackOptions);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/unpack"), L"cmd/pane/unpack overwrite validation should dispatch.");
    PumpPendingMessages();
    const std::optional<FolderWindow::ArchiveCommandDebugResult> noOverwriteUnpackResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
    state.Require(noOverwriteUnpackResult.has_value(), L"Unpack skip-existing validation should record a debug result.");
    if (noOverwriteUnpackResult.has_value())
    {
        state.Require(SUCCEEDED(noOverwriteUnpackResult->hr), L"Unpack skip-existing policy should complete successfully.");
        state.Require(noOverwriteUnpackResult->skippedConflictCount >= 1u,
                      L"Unpack skip-existing policy should report at least the preserved conflicting file.");
    }
    state.Require(ReadUtf8TextFileForCommandSelfTest(extractRoot / L"alpha.txt") == L"stale",
                  L"Unpack skip-existing policy should preserve existing destination file.");

    FolderWindow::ArchiveCommandDebugOptions replaceUnpackOptions{};
    replaceUnpackOptions.destinationPath = extractRoot;
    replaceUnpackOptions.overwrite       = true;
    g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(replaceUnpackOptions);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/unpack"), L"cmd/pane/unpack replace-existing validation should dispatch.");
    PumpPendingMessages();
    const std::optional<FolderWindow::ArchiveCommandDebugResult> replaceUnpackResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
    state.Require(replaceUnpackResult.has_value(), L"Unpack replace-existing validation should record a debug result.");
    if (replaceUnpackResult.has_value())
    {
        state.Require(SUCCEEDED(replaceUnpackResult->hr), L"Unpack replace-existing policy should complete successfully.");
        state.Require(replaceUnpackResult->skippedConflictCount == 0u, L"Unpack replace-existing policy should not report skipped conflicts.");
    }
    state.Require(ReadUtf8TextFileForCommandSelfTest(extractRoot / L"alpha.txt") == L"alpha",
                  L"Unpack replace-existing policy should publish the archive content.");

    const std::filesystem::path cp437ArchivePath = outputRoot / L"cp437.zip";
    std::string cp437EntryName                   = "caf";
    cp437EntryName.push_back(static_cast<char>(0x82u));
    cp437EntryName.append(".txt");
    state.Require(WriteStoredZipFixtureForCommandSelfTest(cp437ArchivePath, cp437EntryName, 0u, "cp437"), L"Failed to create CP437 ZIP fixture.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, outputRoot);
    state.Require(ForceRefreshPaneForCommandSelfTest(mainWindow, FolderWindow::Pane::Left, SelfTest::Scale(3000ms)),
                  L"Failed to refresh archive output folder for CP437 ZIP fixture.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, outputRoot, SelfTest::Scale(3000ms)),
                  L"Failed to refresh archive output folder for CP437 ZIP fixture.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"cp437.zip"}, SelfTest::Scale(3000ms)), L"Archive output folder did not show cp437.zip.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"cp437.zip"), L"Failed to focus CP437 ZIP fixture.");
    const std::filesystem::path cp437ExtractRoot = root / L"cp437-extracted";
    FolderWindow::ArchiveCommandDebugOptions cp437UnpackOptions{};
    cp437UnpackOptions.destinationPath = cp437ExtractRoot;
    cp437UnpackOptions.overwrite       = true;
    g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(cp437UnpackOptions);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/unpack"), L"cmd/pane/unpack should dispatch for CP437 ZIP fixture.");
    PumpPendingMessages();
    const std::optional<FolderWindow::ArchiveCommandDebugResult> cp437UnpackResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
    state.Require(cp437UnpackResult.has_value(), L"CP437 ZIP unpack should record a debug result.");
    if (cp437UnpackResult.has_value())
    {
        state.Require(SUCCEEDED(cp437UnpackResult->hr),
                      std::format(L"CP437 ZIP extraction should succeed; hr=0x{:08X}.", static_cast<unsigned long>(cp437UnpackResult->hr)));
    }
    state.Require(ReadUtf8TextFileForCommandSelfTest(cp437ExtractRoot / L"caf\x00E9.txt") == L"cp437",
                  L"Stored ZIP extraction should honor CP437 names when the UTF-8 flag is not set.");

    const std::filesystem::path cp437ARingArchivePath = outputRoot / L"cp437_a_ring.zip";
    std::string cp437ARingEntryName;
    cp437ARingEntryName.push_back(static_cast<char>(0x8Fu));
    cp437ARingEntryName.append("ngstrom.txt");
    state.Require(WriteStoredZipFixtureForCommandSelfTest(cp437ARingArchivePath, cp437ARingEntryName, 0u, "aring"),
                  L"Failed to create CP437 ZIP fixture with A-ring path.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, outputRoot);
    state.Require(ForceRefreshPaneForCommandSelfTest(mainWindow, FolderWindow::Pane::Left, SelfTest::Scale(3000ms)),
                  L"Failed to refresh archive output folder for CP437 A-ring ZIP fixture.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"cp437_a_ring.zip"}, SelfTest::Scale(3000ms)),
                  L"Archive output folder did not show cp437_a_ring.zip.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"cp437_a_ring.zip"), L"Failed to focus CP437 A-ring ZIP fixture.");
    const std::filesystem::path cp437ARingExtractRoot = root / L"cp437-a-ring-extracted";
    FolderWindow::ArchiveCommandDebugOptions cp437ARingUnpackOptions{};
    cp437ARingUnpackOptions.destinationPath = cp437ARingExtractRoot;
    cp437ARingUnpackOptions.overwrite       = true;
    g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(cp437ARingUnpackOptions);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/unpack"), L"cmd/pane/unpack should dispatch for CP437 A-ring ZIP fixture.");
    PumpPendingMessages();
    const std::optional<FolderWindow::ArchiveCommandDebugResult> cp437ARingUnpackResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
    state.Require(cp437ARingUnpackResult.has_value(), L"CP437 A-ring ZIP unpack should record a debug result.");
    if (cp437ARingUnpackResult.has_value())
    {
        state.Require(SUCCEEDED(cp437ARingUnpackResult->hr),
                      std::format(L"CP437 A-ring ZIP extraction should succeed; hr=0x{:08X}.", static_cast<unsigned long>(cp437ARingUnpackResult->hr)));
    }
    state.Require(ReadUtf8TextFileForCommandSelfTest(cp437ARingExtractRoot / L"\x00C5ngstrom.txt") == L"aring",
                  L"Stored ZIP extraction should decode non-UTF-8 CP437 A-ring paths.");

    const std::filesystem::path reservedArchivePath = outputRoot / L"reserved.zip";
    state.Require(WriteStoredZipFixtureForCommandSelfTest(reservedArchivePath, "CON.txt", 0x0800u, "reserved"), L"Failed to create reserved-name ZIP fixture.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, outputRoot);
    state.Require(ForceRefreshPaneForCommandSelfTest(mainWindow, FolderWindow::Pane::Left, SelfTest::Scale(3000ms)),
                  L"Failed to refresh archive output folder for reserved-name ZIP fixture.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"reserved.zip"}, SelfTest::Scale(3000ms)), L"Archive output folder did not show reserved.zip.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"reserved.zip"), L"Failed to focus reserved-name ZIP fixture.");
    const std::filesystem::path reservedExtractRoot = root / L"reserved-extracted";
    FolderWindow::ArchiveCommandDebugOptions reservedUnpackOptions{};
    reservedUnpackOptions.destinationPath = reservedExtractRoot;
    reservedUnpackOptions.overwrite       = true;
    g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(reservedUnpackOptions);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/unpack"), L"cmd/pane/unpack should dispatch for reserved-name ZIP fixture.");
    PumpPendingMessages();
    const std::optional<FolderWindow::ArchiveCommandDebugResult> reservedUnpackResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
    state.Require(reservedUnpackResult.has_value(), L"Reserved-name ZIP unpack should record a debug result.");
    if (reservedUnpackResult.has_value())
    {
        state.Require(reservedUnpackResult->hr == HRESULT_FROM_WIN32(ERROR_INVALID_NAME),
                      L"Stored ZIP extraction should reject reserved DOS device names before writing.");
    }
    state.Require(! SelfTest::PathExists(reservedExtractRoot / L"CON.txt"), L"Reserved-name ZIP extraction should not create the reserved target.");

    const std::filesystem::path bombArchivePath = outputRoot / L"zip-bomb.zip";
    state.Require(WriteStoredZipDeclaredSizeFixtureForCommandSelfTest(bombArchivePath,
                                                                      {{.rawEntryName = "huge-a.bin", .flags = 0x0800u, .declaredSize = 0xFFFFFFFFu},
                                                                       {.rawEntryName = "huge-b.bin", .flags = 0x0800u, .declaredSize = 0xFFFFFFFFu},
                                                                       {.rawEntryName = "huge-c.bin", .flags = 0x0800u, .declaredSize = 0xFFFFFFFFu}}),
                  L"Failed to create declared-size ZIP bomb fixture.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, outputRoot);
    state.Require(ForceRefreshPaneForCommandSelfTest(mainWindow, FolderWindow::Pane::Left, SelfTest::Scale(3000ms)),
                  L"Failed to refresh archive output folder for zip-bomb ZIP fixture.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"zip-bomb.zip"}, SelfTest::Scale(3000ms)), L"Archive output folder did not show zip-bomb.zip.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"zip-bomb.zip"), L"Failed to focus declared-size ZIP bomb fixture.");
    const std::filesystem::path bombExtractRoot = root / L"zip-bomb-extracted";
    FolderWindow::ArchiveCommandDebugOptions bombUnpackOptions{};
    bombUnpackOptions.destinationPath = bombExtractRoot;
    bombUnpackOptions.overwrite       = true;
    g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(bombUnpackOptions);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/unpack"), L"cmd/pane/unpack should dispatch for declared-size ZIP bomb fixture.");
    PumpPendingMessages();
    const std::optional<FolderWindow::ArchiveCommandDebugResult> bombUnpackResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
    state.Require(bombUnpackResult.has_value(), L"Declared-size ZIP bomb unpack should record a debug result.");
    if (bombUnpackResult.has_value())
    {
        state.Require(bombUnpackResult->hr == HRESULT_FROM_WIN32(ERROR_FILE_TOO_LARGE),
                      L"Stored ZIP extraction should reject archives whose decompressed size exceeds the cap.");
    }
    state.Require(! SelfTest::PathExists(bombExtractRoot / L"huge-a.bin"), L"Declared-size ZIP bomb extraction should not create output files.");

    FolderWindow::ArchiveCommandDebugOptions invalidDestinationOptions{};
    invalidDestinationOptions.destinationPath.clear();
    invalidDestinationOptions.overwrite = true;
    g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(invalidDestinationOptions);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/unpack"), L"cmd/pane/unpack invalid destination validation should dispatch.");
    PumpPendingMessages();
    const std::optional<FolderWindow::ArchiveCommandDebugResult> invalidDestinationResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
    state.Require(invalidDestinationResult.has_value(), L"Unpack invalid destination validation should record a debug result.");
    if (invalidDestinationResult.has_value())
    {
        state.Require(invalidDestinationResult->hr == HRESULT_FROM_WIN32(ERROR_INVALID_NAME), L"Unpack command should reject missing destination path.");
    }

    if (SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system-dummy")))
    {
        g_folderWindow.DebugSetNextArchiveCommandOptionsForTest(packOptions);
        state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/pack"), L"cmd/pane/pack unsupported provider validation should dispatch.");
        PumpPendingMessages();
        const std::optional<FolderWindow::ArchiveCommandDebugResult> unsupportedPackResult = g_folderWindow.DebugGetLastArchiveCommandResultForTest();
        state.Require(unsupportedPackResult.has_value(), L"Pack unsupported provider validation should record a debug result.");
        if (unsupportedPackResult.has_value())
        {
            state.Require(unsupportedPackResult->hr == HRESULT_FROM_WIN32(ERROR_NOT_SUPPORTED),
                          L"Pack command should report unsupported non-local file-system providers.");
        }

        FolderView::AlertOverlayDebugSnapshot alert{};
        state.Require(g_folderWindow.DebugGetPaneAlertSnapshot(FolderWindow::Pane::Left, alert),
                      L"Archive unsupported provider alert snapshot should be available.");
        state.Require(alert.visible, L"Archive unsupported provider should show a pane alert.");
        state.Require(alert.severity == FolderView::OverlaySeverity::Warning, L"Archive unsupported provider should report a warning.");
    }

    const std::wstring perfArtifactText      = std::format(L"{{\n"
                                                           L"  \"scenario\": \"cmd/pane/archive\",\n"
                                                           L"  \"archive.pack_us\": {},\n"
                                                           L"  \"archive.unpack_us\": {},\n"
                                                           L"  \"entryCount\": {},\n"
                                                           L"  \"bytesProcessed\": {}\n"
                                                           L"}}\n",
                                                           packUs.count(),
                                                           unpackUs.count(),
                                                           packResult.has_value() ? packResult->entryCount : 0u,
                                                           packResult.has_value() ? packResult->bytesProcessed : 0u);
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"archive_commands_metrics.json");
    const bool artifactWriteOk               = ! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, perfArtifactText);
    state.Require(artifactWriteOk && SelfTest::PathExists(artifactPath), L"Failed to write archive command perf artifact.");

    return state.failure.empty();
}

[[nodiscard]] bool TestPaneViewOptionsToggleThumbnailsSchedulesBoundedAsyncWork(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"pane_thumbnails_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create thumbnail test folder.");
    for (int i = 0; i < 18; ++i)
    {
        const std::wstring fileName = std::format(L"thumb_{:02}.txt", i);
        state.Require(SelfTest::WriteTextFile(root / fileName, "thumbnail fallback"), std::format(L"Failed to create {}.", fileName));
    }
    if (! state.failure.empty())
    {
        return false;
    }

    FolderWindow::PaneViewOptionsDebugSnapshot originalLeft{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, originalLeft), L"Could not capture original thumbnail pane state.");
    const FolderView::DisplayMode originalLeftDisplayMode = g_folderWindow.GetDisplayMode(FolderWindow::Pane::Left);

    const std::optional<std::filesystem::path> leftBefore = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const auto restoreState                               = wil::scope_exit([&]
    {
        g_folderWindow.DebugSetThumbnailProviderMode(FolderWindow::Pane::Left, FolderView::DebugThumbnailProviderMode::Shell);
        g_folderWindow.SetDisplayMode(FolderWindow::Pane::Left, originalLeftDisplayMode);
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_folderWindow.SetDisplayMode(FolderWindow::Pane::Left, FolderView::DisplayMode::Detailed);
    g_folderWindow.DebugSetThumbnailProviderMode(FolderWindow::Pane::Left, FolderView::DebugThumbnailProviderMode::ForceFallback);
    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for thumbnail test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set thumbnail test path.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"thumb_00.txt", L"thumb_17.txt"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for thumbnail test.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    const uint64_t itemCount = g_folderWindow.DebugGetItemCount(FolderWindow::Pane::Left);
    const auto started       = std::chrono::steady_clock::now();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/toggleThumbnails"),
                  L"cmd/pane/viewOptions/toggleThumbnails should dispatch through the shortcut path.");
    PumpPendingMessages();
    const auto toggleUs = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - started);

    FolderWindow::PaneViewOptionsDebugSnapshot afterToggle{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, afterToggle),
                  L"Could not capture thumbnail pane state after toggle.");
    state.Require(g_folderWindow.GetDisplayMode(FolderWindow::Pane::Left) == FolderView::DisplayMode::Thumbnails,
                  L"Thumbnail command should select the exclusive Thumbnails display mode.");
    state.Require(afterToggle.thumbnailsVisible, L"Thumbnail display mode should expose thumbnail visuals in the active pane.");
    state.Require(afterToggle.thumbnailTargetDip >= 48.0f, L"Thumbnail mode should use a larger DPI-aware visual target than list icons.");
    state.Require(afterToggle.thumbnailQueuedCount > 0, L"Thumbnail mode should queue visible thumbnail work.");
    state.Require(afterToggle.thumbnailQueuedCount <= itemCount, L"Thumbnail queue should be bounded by the current pane item count.");

    FolderWindow::PaneViewOptionsDebugSnapshot settled{};
    state.Require(WaitForPaneThumbnailStats(FolderWindow::Pane::Left,
                                            [](const FolderWindow::PaneViewOptionsDebugSnapshot& snapshot) noexcept
    { return snapshot.thumbnailPendingCount == 0 && snapshot.thumbnailFallbackCount > 0; },
                                            SelfTest::Scale(5000ms),
                                            &settled),
                  L"Thumbnail fallback work did not settle deterministically.");
    state.Require(settled.thumbnailFallbackCount == settled.thumbnailCompletedCount,
                  L"Forced thumbnail fallback should complete every queued thumbnail request as fallback.");
    state.Require(settled.thumbnailStaleDropCount == 0, L"Initial thumbnail run should not drop stale payloads.");

    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/display/detailed"),
                  L"Detailed display command should dispatch through the shortcut path.");
    PumpPendingMessages();
    FolderWindow::PaneViewOptionsDebugSnapshot afterDetailed{};
    state.Require(g_folderWindow.DebugGetPaneViewOptionsSnapshot(FolderWindow::Pane::Left, afterDetailed),
                  L"Could not capture thumbnail pane state after selecting Detailed.");
    state.Require(g_folderWindow.GetDisplayMode(FolderWindow::Pane::Left) == FolderView::DisplayMode::Detailed,
                  L"Selecting Detailed should leave the exclusive Thumbnails display mode.");
    state.Require(! afterDetailed.thumbnailsVisible, L"Detailed display mode should not keep thumbnail visuals layered on top.");
    state.Require(afterDetailed.thumbnailPendingCount == 0, L"Leaving thumbnail display mode should cancel pending thumbnail work.");

    const std::wstring perfArtifactText      = std::format(L"{{\n"
                                                           L"  \"case\": \"pane_view_options_toggle_thumbnails\",\n"
                                                           L"  \"itemCount\": {},\n"
                                                           L"  \"metrics\": {{\n"
                                                           L"    \"paneViewOptions.thumbnailsToggleUs\": {},\n"
                                                           L"    \"thumbnails.queued\": {},\n"
                                                           L"    \"thumbnails.completed\": {},\n"
                                                           L"    \"thumbnails.fallback\": {},\n"
                                                           L"    \"thumbnails.staleDrops\": {}\n"
                                                           L"  }}\n"
                                                           L"}}\n",
                                                           itemCount,
                                                           toggleUs.count(),
                                                           settled.thumbnailQueuedCount,
                                                           settled.thumbnailCompletedCount,
                                                           settled.thumbnailFallbackCount,
                                                           settled.thumbnailStaleDropCount);
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"pane_view_options_thumbnails_metrics.json");
    const bool artifactWriteOk               = ! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, perfArtifactText);
    state.Require(artifactWriteOk && SelfTest::PathExists(artifactPath), L"Failed to write thumbnail pane view-options perf artifact.");

    return state.failure.empty();
}

[[nodiscard]] bool TestPaneViewOptionsTogglePreviewPaneUsesOppositePaneTabsAndSelection(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path leftRoot  = suiteRoot / L"work" / (L"pane_preview_left_" + NewGuidText());
    const std::filesystem::path rightRoot = suiteRoot / L"work" / (L"pane_preview_right_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(leftRoot, ec);
    ec.clear();
    std::filesystem::remove_all(rightRoot, ec);
    state.Require(SelfTest::EnsureDirectory(leftRoot), L"Failed to create preview source folder.");
    state.Require(SelfTest::EnsureDirectory(rightRoot), L"Failed to create preview host folder.");
    state.Require(SelfTest::WriteTextFile(leftRoot / L"alpha-preview.txt", "alpha preview body"), L"Failed to create alpha preview file.");
    state.Require(SelfTest::WriteTextFile(leftRoot / L"beta-preview.txt", "beta preview body"), L"Failed to create beta preview file.");
    state.Require(SelfTest::WriteTextFile(rightRoot / L"right-folder.txt", "right folder content"), L"Failed to create right pane folder file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                    = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::wstring rightPluginBefore                   = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Right));
    const std::optional<std::filesystem::path> leftBefore  = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const std::optional<std::filesystem::path> rightBefore = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Right);
    const bool functionBarBefore                           = g_folderWindow.GetFunctionBarVisible();
    const auto restoreState                                = wil::scope_exit([&]
    {
        FolderWindow::PreviewPaneDebugSnapshot preview{};
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(preview) && preview.active)
        {
            const FolderWindow::Pane sourcePane = preview.sourcePane;
            g_folderWindow.SetActivePane(sourcePane);
            static_cast<void>(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"));
            PumpPendingMessages();
        }

        g_folderWindow.SetFunctionBarVisible(functionBarBefore);
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, rightPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
        if (rightBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightBefore.value());
        }
    });

    state.Require(CloseActivePreviewPaneForSelfTest(SelfTest::Scale(1500ms)), L"Failed to close pre-existing preview pane before preview tab-selection test.");
    if (! state.failure.empty())
    {
        return false;
    }

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for preview source pane.");
    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for preview host pane.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftRoot);
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightRoot);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, leftRoot, SelfTest::Scale(3000ms)), L"Failed to set left pane path for preview test.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Right, rightRoot, SelfTest::Scale(3000ms)), L"Failed to set right pane path for preview test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"alpha-preview.txt", L"beta-preview.txt"}, SelfTest::Scale(3000ms)),
                  L"Left pane contents not ready for preview test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Right, {L"right-folder.txt"}, SelfTest::Scale(3000ms)),
                  L"Right pane contents not ready for preview test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"alpha-preview.txt"), L"Failed to focus alpha preview item.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetFunctionBarVisible(true);
    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    FocusFolderViewPane(FolderWindow::Pane::Left);
    const auto toggleStarted = std::chrono::steady_clock::now();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"),
                  L"cmd/pane/viewOptions/togglePreviewPane should dispatch through the shortcut path.");
    PumpPendingMessages();
    const auto toggleUs = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - toggleStarted);

    FolderWindow::PreviewPaneDebugSnapshot afterOpen{};
    state.Require(g_folderWindow.DebugGetPreviewPaneSnapshot(afterOpen), L"Could not capture preview-pane state after open.");
    const auto describePreviewSnapshot = [](const FolderWindow::PreviewPaneDebugSnapshot& snapshot) noexcept
    {
        const auto paneName  = [](FolderWindow::Pane pane) noexcept { return pane == FolderWindow::Pane::Left ? L"left" : L"right"; };
        const auto boolName  = [](bool value) noexcept { return value ? L"yes" : L"no"; };
        const auto rectText  = [](const RECT& rect) { return std::format(L"({},{} - {},{})", rect.left, rect.top, rect.right, rect.bottom); };
        const LONG_PTR style = snapshot.previewTabsHwnd ? GetWindowLongPtrW(snapshot.previewTabsHwnd, GWL_STYLE) : 0;
        return std::format(L"active={}, source={}, host={}, activePane={}, tabsVisible={}, tabsHwnd=0x{:X}, tabsIsWindow={}, "
                           L"tabsWinVisible={}, tabsStyle=0x{:X}, tabsUseDxUi={}, previewTabSelected={}, folderTabSelected={}, "
                           L"previewContentVisible={}, folderViewVisible={}, tabRect={}, contentRect={}, clientRect={}, previewedPath='{}'",
                           boolName(snapshot.active),
                           paneName(snapshot.sourcePane),
                           paneName(snapshot.hostPane),
                           paneName(g_folderWindow.GetActivePane()),
                           boolName(snapshot.tabsVisible),
                           reinterpret_cast<uintptr_t>(snapshot.previewTabsHwnd),
                           boolName(snapshot.previewTabsHwnd && IsWindow(snapshot.previewTabsHwnd) != FALSE),
                           boolName(snapshot.previewTabsHwnd && IsWindowVisible(snapshot.previewTabsHwnd) != FALSE),
                           static_cast<uintptr_t>(style),
                           boolName(snapshot.tabsUseDxUiHost),
                           boolName(snapshot.previewTabSelected),
                           boolName(snapshot.folderTabSelected),
                           boolName(snapshot.previewContentVisible),
                           boolName(snapshot.folderViewVisible),
                           rectText(snapshot.tabRect),
                           rectText(snapshot.contentRect),
                           rectText(snapshot.clientRect),
                           snapshot.previewedPath.wstring());
    };
    state.Require(afterOpen.active, L"Preview pane should be active after toggle.");
    state.Require(afterOpen.sourcePane == FolderWindow::Pane::Left, L"Preview source should be the active left pane.");
    state.Require(afterOpen.hostPane == FolderWindow::Pane::Right, L"Preview host should be the opposite right pane.");
    state.Require(afterOpen.tabsVisible, std::format(L"Preview host pane should show Folder/Preview tabs. Snapshot: {}", describePreviewSnapshot(afterOpen)));
    state.Require(afterOpen.tabsUseDxUiHost, L"Preview Folder/Preview tabs should use the themed DxUi tab host.");
    state.Require(afterOpen.previewTabsHasHeaderDivider, L"Preview Folder/Preview tabs should expose a horizontal divider under the tab strip.");
    state.Require(afterOpen.previewTabSelected, L"Opening preview should select the Preview tab.");
    state.Require(afterOpen.previewContentVisible, L"Preview content window should be visible on the Preview tab.");
    state.Require(afterOpen.previewContentUsesDxUiHost, L"Preview content background should use the themed DxUi host.");
    state.Require(afterOpen.previewUsesEmbeddedViewer, L"Preview should host the embedded viewer instead of the legacy text edit box.");
    state.Require(afterOpen.previewViewerPluginId == L"builtin/viewer-text", L"Text preview should use the embedded text viewer plugin.");
    state.Require(! afterOpen.folderViewVisible, L"Folder view should be hidden while the Preview tab is selected.");
    state.Require(afterOpen.previewedPath.filename() == L"alpha-preview.txt", L"Preview should load the focused alpha file.");
    state.Require(afterOpen.sourceFocusedDisplayName == L"alpha-preview.txt", L"Preview toggle should not steal source pane focus.");
    state.Require(g_folderWindow.GetFocusedFolderViewHwnd() == g_folderWindow.GetFolderViewHwnd(FolderWindow::Pane::Left),
                  L"Embedded text preview should not take keyboard focus from the source pane.");

    const auto previewTextContains = [](const FolderWindow::PreviewPaneDebugSnapshot& snapshot, std::wstring_view expected) noexcept
    { return snapshot.previewText.find(expected) != std::wstring::npos; };
    const auto waitForPreviewText = [&](std::wstring_view expected, std::wstring_view forbidden, FolderWindow::PreviewPaneDebugSnapshot& outSnapshot) noexcept
    {
        const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(3000ms);
        do
        {
            PumpPendingMessages();
            if (g_folderWindow.DebugGetPreviewPaneSnapshot(outSnapshot) && previewTextContains(outSnapshot, expected) &&
                (forbidden.empty() || ! previewTextContains(outSnapshot, forbidden)))
            {
                return true;
            }
            Sleep(10);
        } while (std::chrono::steady_clock::now() < deadline);
        return false;
    };

    FolderWindow::PreviewPaneDebugSnapshot alphaPreview{};
    state.Require(waitForPreviewText(L"alpha preview body", L"beta preview body", alphaPreview),
                  L"Embedded preview should expose the focused alpha file text before reuse.");
    state.Require(alphaPreview.previewViewerInstanceId != 0, L"Embedded text preview should expose a stable viewer instance id.");
    state.Require(alphaPreview.previewEmbeddedViewerHwnd != nullptr, L"Embedded text preview should expose its hosted viewer HWND.");
    state.Require(alphaPreview.previewTabsHwnd != nullptr, L"Embedded preview should expose its tab strip HWND for pointer validation.");

    const auto rectIsUsable    = [](const RECT& rect) noexcept { return rect.right > rect.left && rect.bottom > rect.top; };
    const auto rectCenterPoint = [](const RECT& rect) noexcept
    { return MAKELPARAM(rect.left + ((rect.right - rect.left) / 2), rect.top + ((rect.bottom - rect.top) / 2)); };
    // The delivered client-point WM_MOUSEMOVE/WM_LBUTTON* messages drive production
    // hover/click routing directly; no live cursor warp is needed because routing reads
    // the message lParam, never GetCursorPos.
    const auto clickPreviewTabsPoint = [](HWND hwnd, LPARAM point) noexcept
    {
        SendMessageW(hwnd, WM_MOUSEMOVE, 0, point);
        SendMessageW(hwnd, WM_LBUTTONDOWN, MK_LBUTTON, point);
        SendMessageW(hwnd, WM_LBUTTONUP, 0, point);
        PumpPendingMessages();
    };
    const auto movePreviewTabsPoint = [](HWND hwnd, LPARAM point) noexcept { SendMessageW(hwnd, WM_MOUSEMOVE, 0, point); };

    const auto switchStarted = std::chrono::steady_clock::now();
    state.Require(rectIsUsable(alphaPreview.folderTabClientRect), L"Embedded preview should expose a usable Folder tab hit rectangle.");
    state.Require(alphaPreview.previewCloseButtonVisible, L"Selected Preview tab should display its close button.");
    clickPreviewTabsPoint(alphaPreview.previewTabsHwnd, rectCenterPoint(alphaPreview.folderTabClientRect));
    PumpPendingMessages();
    const auto switchUs = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - switchStarted);

    FolderWindow::PreviewPaneDebugSnapshot folderTab{};
    state.Require(g_folderWindow.DebugGetPreviewPaneSnapshot(folderTab), L"Could not capture preview-pane state after Folder tab switch.");
    state.Require(folderTab.active && folderTab.tabsVisible, L"Folder tab should keep preview mode open with tabs visible.");
    state.Require(folderTab.tabsUseDxUiHost, L"Folder tab should keep the DxUi tab host.");
    state.Require(folderTab.folderTabSelected, L"Folder tab should be selected after a pointer click.");
    state.Require(folderTab.folderViewVisible, L"Right folder view should be visible on the Folder tab.");
    state.Require(! folderTab.previewContentVisible, L"Preview content should be hidden on the Folder tab.");
    state.Require(! folderTab.previewCloseButtonVisible, L"Inactive Preview tab should hide its close button when it is not hovered.");
    movePreviewTabsPoint(folderTab.previewTabsHwnd, rectCenterPoint(folderTab.folderTabClientRect));
    FolderWindow::PreviewPaneDebugSnapshot folderTabImmediateHover{};
    state.Require(g_folderWindow.DebugGetPreviewPaneSnapshot(folderTabImmediateHover),
                  L"Could not capture preview-pane state immediately after hovering Folder tab.");
    state.Require(folderTabImmediateHover.previewTabsTooltipText.empty(), L"Folder tab tooltip should wait for the standard hover delay before appearing.");
    state.Require(folderTabImmediateHover.previewTabsPendingTooltipText == rightRoot.wstring(),
                  std::format(L"Folder tab hover should schedule the delayed host path tooltip. Expected='{}' Actual='{}'",
                              rightRoot.wstring(),
                              folderTabImmediateHover.previewTabsPendingTooltipText));
    state.Require(g_folderWindow.DebugAdvancePreviewTabsTooltipDelayForTest(folderTab.hostPane),
                  L"Folder tab hover should advance the delayed host path tooltip after the standard delay.");
    FolderWindow::PreviewPaneDebugSnapshot folderTabDelayedHover{};
    state.Require(g_folderWindow.DebugGetPreviewPaneSnapshot(folderTabDelayedHover),
                  L"Could not capture preview-pane state after advancing the Folder tab tooltip delay.");
    state.Require(folderTabDelayedHover.previewTabsTooltipText == rightRoot.wstring(),
                  std::format(L"Folder tab tooltip should display the host pane path while hovered. Expected='{}' Actual='{}' Pending='{}'",
                              rightRoot.wstring(),
                              folderTabDelayedHover.previewTabsTooltipText,
                              folderTabDelayedHover.previewTabsPendingTooltipText));

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"beta-preview.txt"), L"Failed to focus beta preview item.");
    PumpPendingMessages();
    state.Require(rectIsUsable(folderTab.previewTabClientRect), L"Embedded preview should expose a usable Preview tab hit rectangle.");
    movePreviewTabsPoint(folderTab.previewTabsHwnd, rectCenterPoint(folderTab.previewTabClientRect));
    FolderWindow::PreviewPaneDebugSnapshot hoveredPreviewTab{};
    state.Require(g_folderWindow.DebugGetPreviewPaneSnapshot(hoveredPreviewTab), L"Could not capture preview-pane state after hovering Preview tab.");
    state.Require(hoveredPreviewTab.previewCloseButtonVisible, L"Inactive Preview tab should display its close button while hovered.");
    clickPreviewTabsPoint(folderTab.previewTabsHwnd, rectCenterPoint(folderTab.previewTabClientRect));
    PumpPendingMessages();
    FolderWindow::PreviewPaneDebugSnapshot betaPreview{};
    state.Require(waitForPreviewText(L"beta preview body", L"alpha preview body", betaPreview),
                  L"Reused embedded preview should clear the old alpha content before rendering beta.");
    state.Require(betaPreview.previewTabSelected, L"Preview tab should be selected after returning from Folder tab.");
    state.Require(betaPreview.previewUsesEmbeddedViewer, L"Preview should keep using the embedded viewer after focus changes.");
    state.Require(betaPreview.previewViewerPluginId == L"builtin/viewer-text", L"Updated text preview should still use the embedded text viewer plugin.");
    state.Require(betaPreview.previewedPath.filename() == L"beta-preview.txt", L"Preview should update to the newly focused beta file.");
    state.Require(betaPreview.previewViewerInstanceId == alphaPreview.previewViewerInstanceId,
                  L"Same-plugin text preview refresh should reuse the embedded viewer instance.");
    state.Require(betaPreview.previewEmbeddedViewerHwnd == alphaPreview.previewEmbeddedViewerHwnd,
                  L"Same-plugin text preview refresh should keep the embedded viewer HWND instead of closing and recreating it.");
    state.Require(g_folderWindow.GetFocusedFolderViewHwnd() == g_folderWindow.GetFolderViewHwnd(FolderWindow::Pane::Left),
                  L"Refreshing embedded text preview should keep keyboard focus in the source pane.");

    state.Require(betaPreview.previewTabsHwnd != nullptr, L"Embedded preview should keep exposing its tab strip HWND before close.");
    state.Require(rectIsUsable(betaPreview.previewCloseClientRect), L"Preview tab should expose a usable close-button hit rectangle.");
    state.Require(betaPreview.previewCloseButtonVisible, L"Selected Preview tab should keep its close button visible before close.");
    clickPreviewTabsPoint(betaPreview.previewTabsHwnd, rectCenterPoint(betaPreview.previewCloseClientRect));
    PumpPendingMessages();
    FolderWindow::PreviewPaneDebugSnapshot afterClose{};
    state.Require(g_folderWindow.DebugGetPreviewPaneSnapshot(afterClose), L"Could not capture preview-pane state after close.");
    state.Require(! afterClose.active, L"Clicking the Preview tab close button should close preview mode.");
    state.Require(! afterClose.tabsVisible, L"Closing preview from the tab strip should remove the preview tab strip.");
    state.Require(afterClose.folderViewVisible, L"Closing preview from the tab strip should restore the host pane folder view.");

    const std::wstring perfArtifactText      = std::format(L"{{\n"
                                                           L"  \"case\": \"pane_view_options_toggle_preview_pane_tabs_and_selection\",\n"
                                                           L"  \"metrics\": {{\n"
                                                           L"    \"paneViewOptions.previewToggleUs\": {},\n"
                                                           L"    \"paneViewOptions.previewSwitchTabUs\": {},\n"
                                                           L"    \"preview.bytes\": {}\n"
                                                           L"  }}\n"
                                                           L"}}\n",
                                                           toggleUs.count(),
                                                           switchUs.count(),
                                                           betaPreview.previewBytes);
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"pane_view_options_preview_metrics.json");
    const bool artifactWriteOk               = ! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, perfArtifactText);
    state.Require(artifactWriteOk && SelfTest::PathExists(artifactPath), L"Failed to write preview pane perf artifact.");

    return state.failure.empty();
}

[[nodiscard]] bool TestPaneViewOptionsPreviewUsesConfiguredEmbeddedViewerAndPreservesFocus(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    if (! PrepareMainWindowForIsolatedUiCase(mainWindow, state, L"configured embedded-preview focus validation"))
    {
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path leftRoot  = suiteRoot / L"work" / (L"pane_preview_config_left_" + NewGuidText());
    const std::filesystem::path rightRoot = suiteRoot / L"work" / (L"pane_preview_config_right_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(leftRoot, ec);
    ec.clear();
    std::filesystem::remove_all(rightRoot, ec);
    state.Require(SelfTest::EnsureDirectory(leftRoot), L"Failed to create configured preview source folder.");
    state.Require(SelfTest::EnsureDirectory(rightRoot), L"Failed to create configured preview host folder.");
    state.Require(TestWriteTinyBmpFile(leftRoot / L"image-preview.bmp"), L"Failed to create configured preview fixture.");
    state.Require(TestWriteTinyBmpFile(leftRoot / L"image-preview-next.bmp"), L"Failed to create second configured image preview fixture.");
    state.Require(SelfTest::WriteTextFile(leftRoot / L"media-preview.mp4", "dummy media preview body"), L"Failed to create configured media preview fixture.");
    state.Require(SelfTest::WriteTextFile(leftRoot / L"media-preview-next.mp4", "dummy media preview next body"),
                  L"Failed to create second configured media preview fixture.");
    state.Require(SelfTest::WriteTextFile(leftRoot / L"audio-preview.m4a", "dummy audio preview body"), L"Failed to create configured audio preview fixture.");
    state.Require(SelfTest::WriteTextFile(rightRoot / L"host.txt", "host"), L"Failed to create configured preview host fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::wstring rightPluginBefore                            = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Right));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const std::optional<std::filesystem::path> rightBefore          = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Right);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto pluginConfigurationsBefore                           = g_settings.plugins.configurationByPluginId;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        FolderWindow::PreviewPaneDebugSnapshot preview{};
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(preview) && preview.active)
        {
            g_folderWindow.SetActivePane(preview.sourcePane);
            static_cast<void>(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"));
            PumpPendingMessages();
        }

        g_folderWindow.CloseAllViewers();
        g_settings.fileActions.viewers             = viewersBefore;
        g_settings.plugins.configurationByPluginId = pluginConfigurationsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, rightPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
        if (rightBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightBefore.value());
        }
    });

    state.Require(CloseActivePreviewPaneForSelfTest(SelfTest::Scale(1500ms)),
                  L"Failed to close pre-existing preview pane before configured embedded preview test.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition imageViewer{};
    imageViewer.id          = L"preview-image-viewer";
    imageViewer.displayName = L"Preview Image Viewer";
    imageViewer.enabled     = true;
    imageViewer.kind        = Common::Settings::FileActionKind::ViewerPlugin;
    imageViewer.pluginId    = L"builtin/viewer-imgraw";
    TestSetActionExtensions(imageViewer, {L".bmp"});
    g_settings.fileActions.viewers.actions.push_back(std::move(imageViewer));
    g_settings.fileActions.viewers.associations.push_back(TestViewerAssociation(L".bmp", L"preview-image-viewer"));
    Common::Settings::FileActionDefinition mediaViewer{};
    mediaViewer.id          = L"preview-media-viewer";
    mediaViewer.displayName = L"Preview Media Viewer";
    mediaViewer.enabled     = true;
    mediaViewer.kind        = Common::Settings::FileActionKind::ViewerPlugin;
    mediaViewer.pluginId    = L"builtin/viewer-vlc";
    TestSetActionExtensions(mediaViewer, {L".mp4", L".m4a"});
    g_settings.fileActions.viewers.actions.push_back(std::move(mediaViewer));
    g_settings.fileActions.viewers.associations.push_back(TestViewerAssociation(L".mp4", L"preview-media-viewer"));
    g_settings.fileActions.viewers.associations.push_back(TestViewerAssociation(L".m4a", L"preview-media-viewer"));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for configured preview source pane.");
    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for configured preview host pane.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftRoot);
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightRoot);
    Trace(L"Configured preview: waiting for pane paths.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, leftRoot, SelfTest::Scale(3000ms)), L"Failed to set left pane path for configured preview test.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Right, rightRoot, SelfTest::Scale(3000ms)),
                  L"Failed to set right pane path for configured preview test.");
    Trace(L"Configured preview: pane paths ready; waiting for items.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left,
                                   {L"image-preview.bmp", L"image-preview-next.bmp", L"media-preview.mp4", L"media-preview-next.mp4", L"audio-preview.m4a"},
                                   SelfTest::Scale(3000ms)),
                  L"Left pane contents not ready for configured preview test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Right, {L"host.txt"}, SelfTest::Scale(3000ms)),
                  L"Right pane contents not ready for configured preview test.");
    Trace(L"Configured preview: pane items ready; focusing first image.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"image-preview.bmp"), L"Failed to focus configured preview item.");
    Trace(L"Configured preview: first image focus request returned.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    Trace(L"Configured preview: focusing left FolderView HWND.");
    FocusFolderViewPane(FolderWindow::Pane::Left);
    const HWND expectedFocus = g_folderWindow.GetFolderViewHwnd(FolderWindow::Pane::Left);
    state.Require(WaitForFolderViewPaneFocus(FolderWindow::Pane::Left, expectedFocus, SelfTest::Scale(1000ms)),
                  std::format(L"Configured preview focus precondition failed; focusHwnd=0x{:X}, focusedFolderView=0x{:X}, expectedFolderView=0x{:X}, "
                              L"foregroundHwnd=0x{:X}.",
                              reinterpret_cast<uintptr_t>(GetFocus()),
                              reinterpret_cast<uintptr_t>(g_folderWindow.GetFocusedFolderViewHwnd()),
                              reinterpret_cast<uintptr_t>(expectedFocus),
                              reinterpret_cast<uintptr_t>(GetForegroundWindow())));
    if (! state.failure.empty())
    {
        return false;
    }
    const auto requireSourcePaneFocusAfterPreview = [&](std::wstring_view transition, HWND previewHwnd) noexcept
    {
        const HWND focusWindow      = GetFocus();
        const HWND rootWindow       = GetAncestor(expectedFocus, GA_ROOT);
        const HWND foregroundWindow = GetForegroundWindow();
        if (! focusWindow && foregroundWindow != rootWindow)
        {
            Trace(std::format(L"Configured preview: app externally deactivated after {}; restoring source-pane focus (foreground=0x{:X}).",
                              transition,
                              reinterpret_cast<uintptr_t>(foregroundWindow)));
            static_cast<void>(WaitForFolderViewPaneFocus(FolderWindow::Pane::Left, expectedFocus, SelfTest::Scale(1000ms)));
        }

        state.Require(g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus,
                      std::format(L"Configured preview should keep keyboard focus in the source pane after {}; focusHwnd=0x{:X}, "
                                  L"focusedFolderView=0x{:X}, expectedFolderView=0x{:X}, foregroundHwnd=0x{:X}, rootHwnd=0x{:X}, previewHwnd=0x{:X}.",
                                  transition,
                                  reinterpret_cast<uintptr_t>(GetFocus()),
                                  reinterpret_cast<uintptr_t>(g_folderWindow.GetFocusedFolderViewHwnd()),
                                  reinterpret_cast<uintptr_t>(expectedFocus),
                                  reinterpret_cast<uintptr_t>(GetForegroundWindow()),
                                  reinterpret_cast<uintptr_t>(rootWindow),
                                  reinterpret_cast<uintptr_t>(previewHwnd)));
    };
    Trace(L"Configured preview: left FolderView focus returned; toggling preview.");
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"),
                  L"Preview pane toggle should dispatch for configured embedded viewer test.");
    Trace(L"Configured preview: preview toggle returned; waiting for ViewerImgRaw snapshot.");

    FolderWindow::PreviewPaneDebugSnapshot snapshot{};
    const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active &&
            OrdinalString::EqualsNoCase(snapshot.previewViewerPluginId, L"builtin/viewer-imgraw"))
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }
    Trace(L"Configured preview: first ViewerImgRaw snapshot wait returned.");

    state.Require(snapshot.active, L"Configured embedded preview should be active.");
    state.Require(snapshot.previewUsesEmbeddedViewer, L"Configured preview should use an embedded viewer instance.");
    state.Require(snapshot.previewViewerPluginId == L"builtin/viewer-imgraw",
                  L"Preview should use the configured embedded viewer plugin instead of forcing ViewerText.");
    state.Require(snapshot.previewedPath.filename() == L"image-preview.bmp", L"Configured preview should load the focused file.");
    requireSourcePaneFocusAfterPreview(L"the initial image publication", snapshot.previewEmbeddedViewerHwnd);

    const uintptr_t firstImagePreviewInstanceId = snapshot.previewViewerInstanceId;
    const HWND firstImagePreviewHwnd            = snapshot.previewEmbeddedViewerHwnd;
    state.Require(firstImagePreviewInstanceId != 0, L"Configured image preview should expose a stable embedded viewer instance id.");
    state.Require(firstImagePreviewHwnd != nullptr, L"Configured image preview should expose its hosted viewer HWND.");

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"image-preview-next.bmp"),
                  L"Failed to focus second configured image preview item.");
    Trace(L"Configured preview: second image focus returned; waiting for ViewerImgRaw reuse.");

    snapshot                     = {};
    const auto nextImageDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < nextImageDeadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active &&
            OrdinalString::EqualsNoCase(snapshot.previewViewerPluginId, L"builtin/viewer-imgraw") &&
            snapshot.previewedPath.filename() == L"image-preview-next.bmp")
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }
    Trace(L"Configured preview: second ViewerImgRaw snapshot wait returned.");

    state.Require(snapshot.active, L"Configured second image preview should remain active.");
    state.Require(snapshot.previewViewerPluginId == L"builtin/viewer-imgraw", L"Second image preview should keep using the configured image viewer plugin.");
    state.Require(snapshot.previewedPath.filename() == L"image-preview-next.bmp", L"Second image preview should load the newly focused image file.");
    state.Require(snapshot.previewViewerInstanceId == firstImagePreviewInstanceId,
                  L"Switching between image files that resolve to ViewerImgRaw should reuse the embedded image preview instance.");
    state.Require(snapshot.previewEmbeddedViewerHwnd == firstImagePreviewHwnd,
                  L"Switching between image files that resolve to ViewerImgRaw should keep the embedded image preview HWND hot.");

    requireSourcePaneFocusAfterPreview(L"the second image publication", snapshot.previewEmbeddedViewerHwnd);

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"media-preview.mp4"),
                  L"Failed to focus configured media preview item.");
    Trace(L"Configured preview: first media focus returned; waiting for ViewerVLC snapshot.");

    snapshot                 = {};
    const auto mediaDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < mediaDeadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active &&
            OrdinalString::EqualsNoCase(snapshot.previewViewerPluginId, L"builtin/viewer-vlc"))
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }
    Trace(L"Configured preview: first ViewerVLC snapshot wait returned.");

    state.Require(snapshot.active, L"Configured media preview should remain active.");
    state.Require(snapshot.previewUsesEmbeddedViewer, L"Configured media preview should use an embedded viewer instance.");
    state.Require(snapshot.previewViewerPluginId == L"builtin/viewer-vlc",
                  L"Preview should use the configured media viewer plugin instead of forcing ViewerText.");
    state.Require(snapshot.previewedPath.filename() == L"media-preview.mp4", L"Configured media preview should load the focused file.");
    requireSourcePaneFocusAfterPreview(L"the initial media publication", snapshot.previewEmbeddedViewerHwnd);

    const uintptr_t firstVlcPreviewInstanceId = snapshot.previewViewerInstanceId;
    state.Require(firstVlcPreviewInstanceId != 0, L"Configured media preview should expose a stable embedded viewer instance id.");
    const HWND firstVlcPreviewHwnd = snapshot.previewEmbeddedViewerHwnd;
    state.Require(firstVlcPreviewHwnd != nullptr, L"Configured media preview should expose its hosted viewer HWND.");
    HWND vlcWindow = snapshot.previewEmbeddedViewerHwnd;
    state.Require(WindowHasClass(vlcWindow, L"RedSalamander.ViewerVLC"), L"Configured media preview should track its active VLC viewer window.");
    if (vlcWindow)
    {
        WndMsg::ViewerVlcDebugPlaybackState playbackState{};
        playbackState.timeMs   = 20'000;
        playbackState.lengthMs = 120'000;
        playbackState.volume   = 64;
        playbackState.muted    = false;
        state.Require(SendMessageW(vlcWindow, WndMsg::kViewerVlcDebugSetPlaybackState, 0, reinterpret_cast<LPARAM>(&playbackState)) == TRUE,
                      L"Failed to seed VLC preview playback state.");

        WndMsg::ViewerVlcDebugWheel wheel{};
        wheel.wheelDelta = WHEEL_DELTA;
        state.Require(SendMessageW(vlcWindow, WndMsg::kViewerVlcDebugWheelVideoChild, 0, reinterpret_cast<LPARAM>(&wheel)) == TRUE,
                      L"VLC preview wheel forwarding child did not accept the wheel message.");

        WndMsg::ViewerVlcDebugSnapshot vlcSnapshot{};
        state.Require(SendMessageW(vlcWindow, WndMsg::kViewerVlcDebugGetSnapshot, 0, reinterpret_cast<LPARAM>(&vlcSnapshot)) == TRUE,
                      L"Failed to read VLC preview snapshot after wheel forwarding.");
        state.Require(vlcSnapshot.timeMs == 30'000, L"Mouse wheel over a VLC child surface should seek by the normal 10-second step.");
        state.Require(vlcSnapshot.hasVideoChild, L"VLC preview should expose an embedded video child window.");
        state.Require(vlcSnapshot.videoChildIsChildWindow, L"VLC preview video surface should stay a child window.");
        state.Require(vlcSnapshot.videoChildParentIsViewer, L"VLC preview video surface should stay parented to the embedded viewer window.");
    }

    wil::unique_event_nothrow vlcRetirementReleaseGate;
    vlcRetirementReleaseGate.reset(CreateEventW(nullptr, TRUE, FALSE, nullptr));
    state.Require(vlcRetirementReleaseGate != nullptr, L"Failed to create deterministic VLC retirement release gate.");
    if (! vlcRetirementReleaseGate)
    {
        return false;
    }
    const auto releaseVlcRetirement = wil::scope_exit([&]() noexcept { static_cast<void>(SetEvent(vlcRetirementReleaseGate.get())); });

    WndMsg::ViewerVlcDebugStopDelay gatedVlcStop{};
    gatedVlcStop.releaseGate = vlcRetirementReleaseGate.get();
    state.Require(vlcWindow != nullptr && SendMessageW(vlcWindow, WndMsg::kViewerVlcDebugSetStopDelay, 0, reinterpret_cast<LPARAM>(&gatedVlcStop)) == TRUE,
                  L"Failed to enable gated VLC retirement for preview responsiveness coverage.");

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"media-preview-next.mp4"),
                  L"Failed to focus second configured media preview item.");
    Trace(L"Configured preview: second media focus returned; waiting for ViewerVLC reuse.");

    const auto samePluginSwitchStarted = std::chrono::steady_clock::now();
    snapshot                           = {};
    const auto nextMediaDeadline       = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < nextMediaDeadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active &&
            OrdinalString::EqualsNoCase(snapshot.previewViewerPluginId, L"builtin/viewer-vlc") &&
            snapshot.previewedPath.filename() == L"media-preview-next.mp4")
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }
    Trace(L"Configured preview: second ViewerVLC snapshot wait returned.");

    state.Require(snapshot.active, L"Configured second media preview should remain active.");
    state.Require(snapshot.previewViewerPluginId == L"builtin/viewer-vlc", L"Second media preview should keep using the configured media viewer plugin.");
    state.Require(snapshot.previewedPath.filename() == L"media-preview-next.mp4", L"Second media preview should load the newly focused media file.");
    state.Require(snapshot.previewViewerInstanceId == firstVlcPreviewInstanceId,
                  L"Switching between media files that resolve to VLC should reuse the embedded VLC preview instance.");
    state.Require(snapshot.previewEmbeddedViewerHwnd == firstVlcPreviewHwnd,
                  L"Switching between media files that resolve to VLC should keep the embedded VLC preview HWND hot.");
    requireSourcePaneFocusAfterPreview(L"the second media publication", snapshot.previewEmbeddedViewerHwnd);
    state.Require(std::chrono::steady_clock::now() - samePluginSwitchStarted < SelfTest::Scale(900ms),
                  L"Refreshing VLC preview for another media file should not block on slow media-player teardown.");

    vlcWindow = FindDescendantWindowByClass(snapshot.previewContentHwnd, L"RedSalamander.ViewerVLC");
    state.Require(vlcWindow != nullptr, L"Second media preview should still host a VLC viewer window.");
    if (vlcWindow)
    {
        WndMsg::ViewerVlcDebugSnapshot nextVlcSnapshot{};
        state.Require(SendMessageW(vlcWindow, WndMsg::kViewerVlcDebugGetSnapshot, 0, reinterpret_cast<LPARAM>(&nextVlcSnapshot)) == TRUE,
                      L"Failed to read second VLC preview snapshot.");
        state.Require(nextVlcSnapshot.hasVideoChild, L"Second VLC preview should expose an embedded video child window.");
        state.Require(nextVlcSnapshot.videoChildIsChildWindow, L"Second VLC preview video surface should stay a child window.");
        state.Require(nextVlcSnapshot.videoChildParentIsViewer,
                      L"Switching to the next video should keep the VLC video surface parented to the embedded viewer window.");

        state.Require(SendMessageW(vlcWindow, WndMsg::kViewerVlcDebugSetStopDelay, 0, reinterpret_cast<LPARAM>(&gatedVlcStop)) == TRUE,
                      L"Failed to keep gated VLC retirement enabled for audio preview coverage.");
    }

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"audio-preview.m4a"),
                  L"Failed to focus configured audio preview item.");
    Trace(L"Configured preview: audio focus returned; waiting for ViewerVLC reuse.");

    const auto audioSwitchStarted = std::chrono::steady_clock::now();
    snapshot                      = {};
    const auto audioDeadline      = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < audioDeadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active &&
            OrdinalString::EqualsNoCase(snapshot.previewViewerPluginId, L"builtin/viewer-vlc") && snapshot.previewedPath.filename() == L"audio-preview.m4a")
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }
    Trace(L"Configured preview: audio ViewerVLC snapshot wait returned.");

    state.Require(snapshot.active, L"Configured audio preview should remain active.");
    state.Require(snapshot.previewUsesEmbeddedViewer, L"Configured audio preview should use an embedded viewer instance.");
    state.Require(snapshot.previewViewerPluginId == L"builtin/viewer-vlc", L"Audio preview should keep using the configured VLC preview plugin.");
    state.Require(snapshot.previewedPath.filename() == L"audio-preview.m4a", L"Audio preview should load the newly focused audio file.");
    state.Require(snapshot.previewViewerInstanceId == firstVlcPreviewInstanceId,
                  L"Switching from video to audio that resolves to VLC should reuse the embedded VLC preview instance.");
    state.Require(snapshot.previewEmbeddedViewerHwnd == firstVlcPreviewHwnd,
                  L"Switching from video to audio that resolves to VLC should keep the embedded VLC preview HWND hot.");
    requireSourcePaneFocusAfterPreview(L"the audio publication", snapshot.previewEmbeddedViewerHwnd);
    state.Require(std::chrono::steady_clock::now() - audioSwitchStarted < SelfTest::Scale(900ms),
                  L"Refreshing VLC preview from video to audio should not block on slow media-player teardown.");

    vlcWindow = snapshot.previewEmbeddedViewerHwnd;
    state.Require(WindowHasClass(vlcWindow, L"RedSalamander.ViewerVLC"), L"Audio preview should still track the active VLC viewer window.");
    if (vlcWindow)
    {
        WndMsg::ViewerVlcDebugSnapshot audioVlcSnapshot{};
        state.Require(SendMessageW(vlcWindow, WndMsg::kViewerVlcDebugGetSnapshot, 0, reinterpret_cast<LPARAM>(&audioVlcSnapshot)) == TRUE,
                      L"Failed to read audio VLC preview snapshot.");
        state.Require(audioVlcSnapshot.hasVideoChild, L"Audio VLC preview should keep the embedded video child available.");
        state.Require(audioVlcSnapshot.videoChildIsChildWindow, L"Audio VLC preview video surface should stay a child window.");
        state.Require(audioVlcSnapshot.videoChildParentIsViewer, L"Audio-only VLC preview must keep media output parented to the embedded viewer window.");

        WndMsg::ViewerVlcDebugPlaybackState volumeState{};
        volumeState.timeMs   = 5'000;
        volumeState.lengthMs = 90'000;
        volumeState.volume   = 37;
        volumeState.muted    = true;
        state.Require(SendMessageW(vlcWindow, WndMsg::kViewerVlcDebugSetPlaybackState, 0, reinterpret_cast<LPARAM>(&volumeState)) == TRUE,
                      L"Failed to seed VLC preview volume state.");
    }

    // The retirement gate measures cleanup after Close, not unrelated VLC discovery
    // jobs started by the rapid same-plugin preview sequence. Let those loads settle
    // while the gate keeps their retired states deterministic.
    WndMsg::ViewerVlcDebugSnapshot settledVlcSnapshot{};
    const auto pendingLoadDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(30'000ms);
    while (std::chrono::steady_clock::now() < pendingLoadDeadline)
    {
        PumpPendingMessages();
        settledVlcSnapshot = {};
        if (vlcWindow && SendMessageW(vlcWindow, WndMsg::kViewerVlcDebugGetSnapshot, 0, reinterpret_cast<LPARAM>(&settledVlcSnapshot)) == TRUE &&
            settledVlcSnapshot.pendingLoadWorkCount == 0u)
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }
    state.Require(settledVlcSnapshot.pendingLoadWorkCount == 0u,
                  std::format(L"VLC preview initialization did not settle before gated retirement; pendingLoads={} acceptedLoads={} staleLoads={}.",
                              settledVlcSnapshot.pendingLoadWorkCount,
                              settledVlcSnapshot.loadQueueAccepted,
                              settledVlcSnapshot.staleLoadResults));
    if (! state.failure.empty())
    {
        return false;
    }

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"image-preview.bmp"),
                  L"Failed to focus image preview item after media preview.");
    Trace(L"Configured preview: image refocus returned; waiting for recreated ViewerImgRaw.");

    const auto crossPluginSwitchStarted = std::chrono::steady_clock::now();
    snapshot                            = {};
    const auto crossPluginDeadline      = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < crossPluginDeadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active &&
            OrdinalString::EqualsNoCase(snapshot.previewViewerPluginId, L"builtin/viewer-imgraw") && snapshot.previewedPath.filename() == L"image-preview.bmp")
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }
    Trace(L"Configured preview: recreated ViewerImgRaw snapshot wait returned.");

    state.Require(snapshot.active, L"Configured image preview should reopen after media preview.");
    state.Require(snapshot.previewViewerPluginId == L"builtin/viewer-imgraw",
                  L"Switching from media preview back to image preview should resolve to ViewerImgRaw.");
    Trace(std::format(L"Configured preview: cross-plugin direct children={}, visible={}, activeHwnd=0x{:X}.",
                      snapshot.previewDirectChildCount,
                      snapshot.previewVisibleDirectChildCount,
                      reinterpret_cast<uintptr_t>(snapshot.previewEmbeddedViewerHwnd)));
    state.Require(snapshot.previewDirectChildCount >= 2u,
                  L"Cross-plugin preview should retain the hidden retiring VLC child beside the active image viewer during delayed cleanup.");
    state.Require(snapshot.previewVisibleDirectChildCount == 1u,
                  L"Cross-plugin preview should keep only the active embedded viewer visible while retired viewers finish asynchronously.");
    state.Require(snapshot.previewOwnVisibleDirectChildCount == 1u,
                  L"Cross-plugin preview should clear WS_VISIBLE on every retiring root while keeping the active root style-visible.");
    state.Require(snapshot.previewEmbeddedViewerHwnd != nullptr && IsWindowVisible(snapshot.previewEmbeddedViewerHwnd) != FALSE,
                  L"Cross-plugin preview should keep the tracked active image viewer visible.");
    requireSourcePaneFocusAfterPreview(L"the cross-plugin image publication", snapshot.previewEmbeddedViewerHwnd);
    state.Require(std::chrono::steady_clock::now() - crossPluginSwitchStarted < SelfTest::Scale(900ms),
                  L"Switching away from VLC preview should not block on slow media-player teardown.");

    state.Require(SetEvent(vlcRetirementReleaseGate.get()) != FALSE, L"Failed to release deterministic VLC retirement gate.");
    FolderWindow::PreviewPaneDebugSnapshot retiredVlcReleased{};
    // Broad Commands coverage can leave independent thread-pool work draining. Wait on the
    // actual HWND retirement condition with the same bounded budget used by the VLC gate.
    const auto retirementDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(30'000ms);
    while (std::chrono::steady_clock::now() < retirementDeadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(retiredVlcReleased) && retiredVlcReleased.previewDirectChildCount == 1u)
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }
    WndMsg::ViewerVlcDebugSnapshot retirementVlcSnapshot{};
    const bool retirementVlcSnapshotAvailable =
        vlcWindow != nullptr && IsWindow(vlcWindow) != FALSE &&
        SendMessageW(vlcWindow, WndMsg::kViewerVlcDebugGetSnapshot, 0, reinterpret_cast<LPARAM>(&retirementVlcSnapshot)) == TRUE;
    state.Require(retiredVlcReleased.previewDirectChildCount == 1u && retiredVlcReleased.previewOwnVisibleDirectChildCount == 1u,
                  std::format(L"Releasing gated VLC retirement should destroy the hidden root and leave only the active image viewer root. "
                              L"directChildren={} ownVisibleChildren={} vlcWindowAlive={} vlcSnapshotAvailable={} closePending={} "
                              L"cleanupCompletions={} deferredCleanupCount={} cleanupDeferrals={} cleanupSubmitFailures={} "
                              L"cleanupAllocationFailures={} asyncResultPostFailures={} cleanupPostFallbacks={}.",
                              retiredVlcReleased.previewDirectChildCount,
                              retiredVlcReleased.previewOwnVisibleDirectChildCount,
                              vlcWindow != nullptr && IsWindow(vlcWindow) != FALSE,
                              retirementVlcSnapshotAvailable,
                              retirementVlcSnapshot.closePending,
                              retirementVlcSnapshot.cleanupCompletions,
                              retirementVlcSnapshot.deferredCleanupCount,
                              retirementVlcSnapshot.cleanupDeferrals,
                              retirementVlcSnapshot.cleanupSubmitFailures,
                              retirementVlcSnapshot.cleanupAllocationFailures,
                              retirementVlcSnapshot.asyncResultPostFailures,
                              retirementVlcSnapshot.cleanupPostFallbacks));

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"media-preview-next.mp4"),
                  L"Failed to refocus media preview before close/reopen persistence check.");
    Trace(L"Configured preview: final media refocus returned; waiting for recreated ViewerVLC.");
    snapshot                        = {};
    const auto mediaRefocusDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < mediaRefocusDeadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active &&
            OrdinalString::EqualsNoCase(snapshot.previewViewerPluginId, L"builtin/viewer-vlc") &&
            snapshot.previewedPath.filename() == L"media-preview-next.mp4" && g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus)
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }
    Trace(L"Configured preview: recreated ViewerVLC snapshot wait returned.");
    state.Require(snapshot.active && snapshot.previewViewerPluginId == L"builtin/viewer-vlc",
                  L"Media preview should reopen before close/reopen persistence check.");
    vlcWindow = snapshot.previewEmbeddedViewerHwnd;
    state.Require(WindowHasClass(vlcWindow, L"RedSalamander.ViewerVLC"), L"Refocused media preview should track the active VLC viewer window.");

    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"),
                  L"Preview pane toggle should close the configured media preview.");
    Trace(L"Configured preview: close dispatch returned.");
    PumpPendingMessages();

    FolderWindow::PreviewPaneDebugSnapshot closedPreview{};
    state.Require(g_folderWindow.DebugGetPreviewPaneSnapshot(closedPreview), L"Could not capture configured preview after closing.");
    state.Require(! closedPreview.active, L"Configured media preview should close before checking persisted VLC volume.");
    state.Require(closedPreview.previewVisibleDirectChildCount == 0u, L"Closing preview should hide every active or retiring embedded viewer child.");
    state.Require(closedPreview.previewOwnVisibleDirectChildCount == 0u,
                  L"Closing preview should clear each direct embedded child root's own WS_VISIBLE style, independent of ancestor visibility.");

    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"),
                  L"Preview pane toggle should reopen the configured media preview.");
    Trace(L"Configured preview: reopen dispatch returned; waiting for ViewerVLC snapshot.");

    snapshot                    = {};
    const auto restoredDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < restoredDeadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active &&
            OrdinalString::EqualsNoCase(snapshot.previewViewerPluginId, L"builtin/viewer-vlc") && g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus)
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }
    Trace(L"Configured preview: reopened ViewerVLC snapshot wait returned.");

    state.Require(snapshot.active, L"Reopened configured media preview should become active.");
    state.Require(snapshot.previewViewerPluginId == L"builtin/viewer-vlc", L"Reopened media preview should use the configured VLC viewer.");
    state.Require(snapshot.previewVisibleDirectChildCount == 1u, L"Reopened media preview should expose exactly one visible embedded viewer child.");
    state.Require(snapshot.previewOwnVisibleDirectChildCount == 1u,
                  L"Reopened media preview should expose exactly one direct child root with its own WS_VISIBLE style.");
    vlcWindow = snapshot.previewEmbeddedViewerHwnd;
    state.Require(WindowHasClass(vlcWindow, L"RedSalamander.ViewerVLC"), L"Reopened media preview should track the active VLC viewer window.");
    if (vlcWindow)
    {
        WndMsg::ViewerVlcDebugSnapshot restoredVlc{};
        state.Require(SendMessageW(vlcWindow, WndMsg::kViewerVlcDebugGetSnapshot, 0, reinterpret_cast<LPARAM>(&restoredVlc)) == TRUE,
                      L"Failed to read reopened VLC preview snapshot.");
        state.Require(restoredVlc.volume == 37, L"Reopened VLC preview should restore the last preview volume.");
        state.Require(restoredVlc.muted, L"Reopened VLC preview should restore the muted state.");
        state.Require(restoredVlc.hudButtonsUseFilledButtonStyle, L"VLC preview HUD icon controls should render as filled buttons.");
        state.Require(restoredVlc.hudIconsUseIconFont, L"VLC preview HUD controls should use Segoe Fluent Icons glyphs.");
        state.Require(restoredVlc.playPauseIconGlyph == static_cast<wchar_t>(0xE768), L"VLC preview should expose the Fluent play glyph when paused.");
        state.Require(restoredVlc.stopIconGlyph == static_cast<wchar_t>(0xE71A), L"VLC preview should expose the Fluent stop glyph.");
        state.Require(restoredVlc.snapshotIconGlyph == static_cast<wchar_t>(0xE722), L"VLC preview should expose the Fluent camera glyph for snapshots.");
        state.Require(restoredVlc.volumeIconUsesIconFont, L"VLC preview should draw the volume button with the system icon font.");
        state.Require(restoredVlc.volumeIconGlyph == static_cast<wchar_t>(0xE74F), L"Muted VLC preview should expose the Fluent mute glyph.");
    }

    return state.failure.empty();
}

[[nodiscard]] bool TestThemeV2RuntimeResolutionAndDynamicPerf(CaseState& state) noexcept
{
    constexpr size_t kPaletteCount         = 128u;
    constexpr size_t kSemanticCount        = 512u;
    constexpr size_t kResolutionSamples    = 200u;
    constexpr size_t kDynamicSamples       = 250u;
    constexpr size_t kEvaluationsPerSample = 1000u;

    Common::Settings::ThemeDefinition theme;
    theme.id          = L"user/selftest-theme-v2-perf";
    theme.name        = L"Theme V2 Performance";
    theme.baseThemeId = L"builtin/dark";
    for (size_t index = 0u; index < kPaletteCount; ++index)
    {
        const uint32_t rgb = static_cast<uint32_t>((index * 0x010307u) & 0x00FFFFFFu);
        theme.palette.emplace(std::format(L"p{}", index), Common::Settings::ThemeColorSource(0xFF000000u | rgb));
    }
    for (size_t index = 0u; index < kSemanticCount - 1u; ++index)
    {
        Common::Settings::ThemeColorSource source;
        source.kind = Common::Settings::ThemeColorSourceKind::Reference;
        source.references.push_back(std::format(L"palette.p{}", index % kPaletteCount));
        theme.colors.emplace(std::format(L"selftest.color.{}", index), std::move(source));
    }
    Common::Settings::ThemeColorSource dynamicSource;
    dynamicSource.kind = Common::Settings::ThemeColorSourceKind::SeededChoice;
    for (size_t index = 0u; index < 8u; ++index)
        dynamicSource.references.push_back(std::format(L"palette.p{}", index));
    theme.colors.emplace(L"folderView.itemBackgroundSelected", std::move(dynamicSource));

    const AppTheme darkBase = ResolveAppTheme(ThemeMode::Dark, L"theme-v2-selftest");
    const auto context      = MakeAppThemeResolutionContext(darkBase);
    Common::Settings::ResolvedThemeColors resolved;
    std::wstring message;
    uint64_t maxResolveUs = 0u;
    for (size_t sample = 0u; sample < kResolutionSamples; ++sample)
    {
        const auto startedAt      = std::chrono::steady_clock::now();
        const HRESULT hr          = Common::Settings::ResolveThemeDefinition(theme, context, resolved, &message);
        const uint64_t durationUs = Debug::Perf::ElapsedUs(startedAt);
        maxResolveUs              = std::max(maxResolveUs, durationUs);
        state.Require(SUCCEEDED(hr), std::format(L"Worst-case version 2 theme resolution failed: {}", message));
        if (FAILED(hr))
            return false;
    }

#ifdef NDEBUG
    constexpr uint64_t kResolveBudgetUs = 16667u;
#else
    constexpr uint64_t kResolveBudgetUs = 100000u;
#endif
    state.Require(maxResolveUs <= kResolveBudgetUs,
                  std::format(L"Worst-case version 2 theme resolution exceeded the {} us guard (max={} us).", kResolveBudgetUs, maxResolveUs));
    state.Require(resolved.colors.size() == kSemanticCount && resolved.dynamicColors.size() == 1u,
                  L"Worst-case version 2 theme should resolve every semantic source and one compiled dynamic source.");

    const auto dynamic = resolved.dynamicColors.find(L"folderView.itemBackgroundSelected");
    state.Require(dynamic != resolved.dynamicColors.end(), L"The allowlisted selection program should be compiled.");
    if (dynamic == resolved.dynamicColors.end())
        return false;

    Common::Settings::CompiledThemeColor rainbowProgram;
    rainbowProgram.kind         = Common::Settings::CompiledThemeColorKind::SeededRainbow;
    rainbowProgram.parameters   = {{0.85, 0.75, 1.0, 0.0}};
    rainbowProgram.fallbackArgb = 0xFF445566u;

    uint32_t checksum          = 0u;
    uint64_t maxDynamicBatchUs = 0u;
    for (size_t sample = 0u; sample < kDynamicSamples; ++sample)
    {
        const auto startedAt = std::chrono::steady_clock::now();
        for (size_t evaluation = 0u; evaluation < kEvaluationsPerSample; ++evaluation)
        {
            checksum ^= Common::Settings::EvaluateDynamicThemeColor(
                dynamic->second,
                Common::Settings::ThemeRuntimeContext{.seedHash32   = static_cast<uint32_t>((sample * kEvaluationsPerSample) + evaluation),
                                                      .highContrast = false});
            checksum ^= Common::Settings::EvaluateDynamicThemeColor(
                rainbowProgram,
                Common::Settings::ThemeRuntimeContext{.seedHash32   = static_cast<uint32_t>((sample * kEvaluationsPerSample) + evaluation),
                                                      .highContrast = false});
        }
        const uint64_t durationUs = Debug::Perf::ElapsedUs(startedAt);
        maxDynamicBatchUs         = std::max(maxDynamicBatchUs, durationUs);
        Debug::Perf::EmitDurationUs(L"theme.dynamic.evaluate_us", durationUs, kEvaluationsPerSample * 2u, checksum, S_OK);
    }
    Debug::Perf::EmitValue(L"theme.dynamic.evaluate_count", kDynamicSamples * kEvaluationsPerSample * 2u, S_OK);
    state.Require(checksum != 0u, L"Dynamic evaluation checksum should prove the measured loop executed.");
#ifdef NDEBUG
    constexpr uint64_t kDynamicBatchBudgetUs = 5000u;
#else
    constexpr uint64_t kDynamicBatchBudgetUs = 50000u;
#endif
    state.Require(maxDynamicBatchUs <= kDynamicBatchBudgetUs,
                  std::format(L"A 2,000-evaluation dynamic batch exceeded the {} us guard (max={} us).", kDynamicBatchBudgetUs, maxDynamicBatchUs));
    state.Require(Common::Settings::EvaluateDynamicThemeColor(rainbowProgram, Common::Settings::ThemeRuntimeContext{.seedHash32 = 42u, .highContrast = true}) ==
                      rainbowProgram.fallbackArgb,
                  L"High Contrast should suppress seededRainbow through its compiled fallback.");

    Common::Settings::ThemeDefinition depthTheme;
    depthTheme.id          = L"user/selftest-theme-depth";
    depthTheme.name        = L"Theme Depth";
    depthTheme.baseThemeId = L"builtin/dark";
    depthTheme.palette.emplace(L"d0", Common::Settings::ThemeColorSource(0xFF123456u));
    for (size_t index = 1u; index < 31u; ++index)
    {
        Common::Settings::ThemeColorSource source;
        source.kind = Common::Settings::ThemeColorSourceKind::Reference;
        source.references.push_back(std::format(L"palette.d{}", index - 1u));
        depthTheme.palette.emplace(std::format(L"d{}", index), std::move(source));
    }
    Common::Settings::ThemeColorSource depthColor;
    depthColor.kind = Common::Settings::ThemeColorSourceKind::Reference;
    depthColor.references.push_back(L"palette.d30");
    depthTheme.colors.emplace(L"app.accent", std::move(depthColor));
    Common::Settings::ResolvedThemeColors depthResolved;
    state.Require(SUCCEEDED(Common::Settings::ResolveThemeDefinition(depthTheme, context, depthResolved, &message)) &&
                      depthResolved.colors[L"app.accent"] == 0xFF123456u,
                  L"A depth-32 authored dependency chain should resolve at the documented bound.");

    Common::Settings::ThemeDefinition excessiveDepthTheme = depthTheme;
    Common::Settings::ThemeColorSource excessiveDepth;
    excessiveDepth.kind = Common::Settings::ThemeColorSourceKind::Reference;
    excessiveDepth.references.push_back(L"palette.d30");
    excessiveDepthTheme.palette.emplace(L"d31", std::move(excessiveDepth));
    excessiveDepthTheme.colors.at(L"app.accent").references.front() = L"palette.d31";
    Common::Settings::ResolvedThemeColors excessiveDepthResolved;
    state.Require(FAILED(Common::Settings::ResolveThemeDefinition(excessiveDepthTheme, context, excessiveDepthResolved, &message)) &&
                      message.find(L"depth exceeds 32") != std::wstring::npos,
                  L"A dependency chain beyond depth 32 should fail with an actionable diagnostic.");

    AppTheme rainbowTheme = ResolveAppTheme(ThemeMode::Rainbow, L"theme-v2-rainbow-precedence");
    state.Require(rainbowTheme.folderView.itemBackgroundSelectedUsesInheritedRainbow,
                  L"The built-in Rainbow base should initially own per-item selection color.");
    Common::Settings::ResolvedThemeColors unrelatedOverride;
    unrelatedOverride.colors.emplace(L"menu.background", 0xFF112233u);
    ApplyResolvedDynamicThemeOverrides(rainbowTheme, unrelatedOverride);
    state.Require(rainbowTheme.folderView.itemBackgroundSelectedUsesInheritedRainbow,
                  L"An unrelated static override should preserve inherited Rainbow selection.");
    Common::Settings::ResolvedThemeColors staticOverride;
    staticOverride.colors.emplace(L"folderView.itemBackgroundSelected", 0xFF445566u);
    ApplyResolvedDynamicThemeOverrides(rainbowTheme, staticOverride);
    state.Require(! rainbowTheme.folderView.itemBackgroundSelectedUsesInheritedRainbow && ! rainbowTheme.folderView.itemBackgroundSelectedDynamic.has_value(),
                  L"A static selection override should suppress Rainbow only for that token.");

    AppTheme dynamicTheme = ResolveAppTheme(ThemeMode::Rainbow, L"theme-v2-dynamic-precedence");
    ApplyResolvedDynamicThemeOverrides(dynamicTheme, resolved);
    state.Require(! dynamicTheme.folderView.itemBackgroundSelectedUsesInheritedRainbow && dynamicTheme.folderView.itemBackgroundSelectedDynamic.has_value(),
                  L"An authored dynamic selection source should beat inherited Rainbow for the same token.");
    if (dynamicTheme.folderView.itemBackgroundSelectedDynamic.has_value())
    {
        const auto& program = dynamicTheme.folderView.itemBackgroundSelectedDynamic.value();
        state.Require(Common::Settings::EvaluateDynamicThemeColor(program, Common::Settings::ThemeRuntimeContext{.seedHash32 = 3u, .highContrast = true}) ==
                          program.fallbackArgb,
                      L"High Contrast should force the compiled dynamic fallback without parsing or system calls.");
    }

    Common::Settings::ThemeDefinition eventTheme;
    eventTheme.id          = L"user/selftest-event-theme";
    eventTheme.name        = L"Event Theme";
    eventTheme.baseThemeId = L"builtin/dark";
    Common::Settings::ThemeColorSource eventSource;
    eventSource.kind       = Common::Settings::ThemeColorSourceKind::SystemColor;
    eventSource.systemRole = Common::Settings::ThemeSystemColorRole::Accent;
    eventTheme.colors.emplace(L"app.accent", eventSource);
    auto firstEventContext                                                                               = context;
    firstEventContext.systemColors[static_cast<size_t>(Common::Settings::ThemeSystemColorRole::Accent)]  = 0xFF102030u;
    auto secondEventContext                                                                              = firstEventContext;
    secondEventContext.systemColors[static_cast<size_t>(Common::Settings::ThemeSystemColorRole::Accent)] = 0xFF405060u;
    Common::Settings::ResolvedThemeColors firstEvent;
    Common::Settings::ResolvedThemeColors secondEvent;
    state.Require(SUCCEEDED(Common::Settings::ResolveThemeDefinition(eventTheme, firstEventContext, firstEvent, &message)) &&
                      SUCCEEDED(Common::Settings::ResolveThemeDefinition(eventTheme, secondEventContext, secondEvent, &message)) &&
                      firstEvent.colors[L"app.accent"] == 0xFF102030u && secondEvent.colors[L"app.accent"] == 0xFF405060u,
                  L"Event-time system colors should refresh only when the host re-resolves on a system theme event.");
    return state.failure.empty();
}

[[nodiscard]] bool TestPaneViewOptionsPreviewRejectsInvalidEmbeddedChildCardinality(HWND mainWindow,
                                                                                    CaseState& state,
                                                                                    FolderWindow::PreviewEmbeddedChildFaultForTest fault,
                                                                                    size_t expectedCreatedChildCount,
                                                                                    size_t expectedDetectedChildCount,
                                                                                    std::wstring_view scenario) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    if (! PrepareMainWindowForIsolatedUiCase(mainWindow, state, L"preview embedded-child cardinality validation"))
    {
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path leftRoot  = suiteRoot / L"work" / (L"pane_preview_child_fault_left_" + NewGuidText());
    const std::filesystem::path rightRoot = suiteRoot / L"work" / (L"pane_preview_child_fault_right_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(leftRoot, ec);
    ec.clear();
    std::filesystem::remove_all(rightRoot, ec);
    state.Require(SelfTest::EnsureDirectory(leftRoot), L"Failed to create embedded-child fault source folder.");
    state.Require(SelfTest::EnsureDirectory(rightRoot), L"Failed to create embedded-child fault host folder.");
    state.Require(TestWriteTinyBmpFile(leftRoot / L"fault-preview.bmp"), L"Failed to create embedded-child fault image fixture.");
    state.Require(SelfTest::WriteTextFile(rightRoot / L"host.txt", "host"), L"Failed to create embedded-child fault host fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::wstring rightPluginBefore                            = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Right));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const std::optional<std::filesystem::path> rightBefore          = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Right);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.DebugSetNextPreviewEmbeddedChildFaultForTest(FolderWindow::PreviewEmbeddedChildFaultForTest::None);
        FolderWindow::PreviewPaneDebugSnapshot preview{};
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(preview) && preview.active)
        {
            g_folderWindow.SetActivePane(preview.sourcePane);
            static_cast<void>(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"));
            PumpPendingMessages();
        }
        g_folderWindow.CloseAllViewers();
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, rightPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
        if (rightBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightBefore.value());
        }
    });

    state.Require(CloseActivePreviewPaneForSelfTest(SelfTest::Scale(1500ms)),
                  std::format(L"Failed to close pre-existing preview pane before {} child-cardinality coverage.", scenario));
    if (! state.failure.empty())
    {
        return false;
    }

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition imageViewer{};
    imageViewer.id          = L"preview-child-fault-image-viewer";
    imageViewer.displayName = L"Preview Child Fault Image Viewer";
    imageViewer.enabled     = true;
    imageViewer.kind        = Common::Settings::FileActionKind::ViewerPlugin;
    imageViewer.pluginId    = L"builtin/viewer-imgraw";
    TestSetActionExtensions(imageViewer, {L".bmp"});
    g_settings.fileActions.viewers.actions.push_back(std::move(imageViewer));
    g_settings.fileActions.viewers.associations.push_back(TestViewerAssociation(L".bmp", L"preview-child-fault-image-viewer"));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for embedded-child fault source pane.");
    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for embedded-child fault host pane.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftRoot);
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightRoot);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, leftRoot, SelfTest::Scale(3000ms)) &&
                      WaitForPaneItems(FolderWindow::Pane::Left, {L"fault-preview.bmp"}, SelfTest::Scale(3000ms)),
                  L"Embedded-child fault source pane did not enumerate its fixture.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Right, rightRoot, SelfTest::Scale(3000ms)) &&
                      WaitForPaneItems(FolderWindow::Pane::Right, {L"host.txt"}, SelfTest::Scale(3000ms)),
                  L"Embedded-child fault host pane did not enumerate its fixture.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"fault-preview.bmp"),
                  L"Failed to focus embedded-child fault image fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    FocusFolderViewPane(FolderWindow::Pane::Left);
    const HWND expectedFocus = g_folderWindow.GetFolderViewHwnd(FolderWindow::Pane::Left);
    g_folderWindow.DebugSetNextPreviewEmbeddedChildFaultForTest(fault);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"),
                  std::format(L"Preview pane toggle should dispatch for {} child-cardinality coverage.", scenario));

    FolderWindow::PreviewPaneDebugSnapshot snapshot{};
    const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active && snapshot.previewLastOpenRejectedChildCardinality &&
            snapshot.previewedPath.filename() == L"fault-preview.bmp")
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }

    state.Require(snapshot.active, std::format(L"Preview should remain active after rejecting {} child cardinality.", scenario));
    state.Require(snapshot.previewLastOpenRejectedChildCardinality, std::format(L"Preview should reject the injected {} child cardinality.", scenario));
    state.Require(
        snapshot.previewLastOpenCreatedChildCount == expectedCreatedChildCount,
        std::format(
            L"{} fault should create {} direct child roots; observed {}.", scenario, expectedCreatedChildCount, snapshot.previewLastOpenCreatedChildCount));
    state.Require(snapshot.previewLastOpenDetectedChildCount == expectedDetectedChildCount,
                  std::format(L"{} fault should report {} detected direct child roots; observed {}.",
                              scenario,
                              expectedDetectedChildCount,
                              snapshot.previewLastOpenDetectedChildCount));
    state.Require(snapshot.previewLastOpenHiddenRejectedChildCount == expectedCreatedChildCount,
                  std::format(L"{} fault should hide all {} newly created direct child roots before Close; observed {} hidden.",
                              scenario,
                              expectedCreatedChildCount,
                              snapshot.previewLastOpenHiddenRejectedChildCount));
    state.Require(! snapshot.previewUsesEmbeddedViewer && snapshot.previewViewerPluginId.empty(),
                  std::format(L"Preview must discard the viewer instance after rejecting {} child cardinality.", scenario));
    state.Require(snapshot.previewPropertiesCardMode, L"Rejected embedded-child cardinality should fall back to the Properties preview.");
    state.Require(snapshot.previewVisibleDirectChildCount == 0u && snapshot.previewOwnVisibleDirectChildCount == 0u,
                  L"Rejected embedded-child roots must remain effectively hidden and have WS_VISIBLE cleared.");
    state.Require(g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus,
                  L"Embedded-child cardinality fallback should preserve source-pane keyboard focus.");

    return state.failure.empty();
}

[[nodiscard]] bool TestSettingsHotReloadCreatesMissingDirectory(HWND mainWindow, CaseState& state) noexcept
{
    constexpr std::wstring_view kTestAppId = L"RedSalamanderSelfTestHotReloadMissingDirectory";
    SettingsHotReload::Stop();
    const auto restoreMainWatcher = wil::scope_exit([&]
    {
        SettingsHotReload::Stop();
        RestoreMainSettingsHotReload(mainWindow, state);
    });

    try
    {
        const std::filesystem::path isolatedRoot = SelfTest::SelfTestRoot();
        const std::wstring isolatedRunId         = std::format(L"settings-hot-reload-missing-{}-{}", GetCurrentProcessId(), GetTickCount64());
        RedSalamander::TestSupport::ScopedEnvironmentVariable isolatedRootEnvironment(RedSalamander::TestSupport::kTestRootEnvironmentVariable,
                                                                                      std::wstring_view(isolatedRoot.native()));
        RedSalamander::TestSupport::ScopedEnvironmentVariable isolatedRunEnvironment(RedSalamander::TestSupport::kTestRunIdEnvironmentVariable,
                                                                                     std::wstring_view(isolatedRunId));
        const std::filesystem::path isolatedRunRoot = isolatedRoot / L"runs" / isolatedRunId;
        const auto cleanupIsolatedRun               = wil::scope_exit([&]() noexcept
        {
            SettingsHotReload::Stop();
            static_cast<void>(SelfTest::RemoveAll(isolatedRunRoot));
        });

        CleanupSettingsArtifacts(kTestAppId);
        const std::filesystem::path settingsPath      = Common::Settings::GetSettingsPath(kTestAppId);
        const std::filesystem::path settingsDirectory = settingsPath.parent_path();
        state.Require(! settingsDirectory.empty(), L"Missing-directory hot-reload test could not resolve the settings directory.");
        if (settingsDirectory.empty())
        {
            return false;
        }

        std::error_code removeError;
        std::filesystem::remove_all(settingsDirectory, removeError);
        state.Require(! removeError, L"Failed to remove the isolated self-test settings directory.");
        state.Require(! std::filesystem::exists(settingsDirectory), L"Self-test settings directory should be absent before watcher startup.");

        SettingsHotReloadTestWindowState windowState{};
        HWND hwnd = CreateSettingsHotReloadTestWindow(windowState);
        state.Require(hwnd != nullptr && IsWindow(hwnd) != FALSE, L"Failed to create missing-directory hot-reload self-test window.");
        if (! hwnd || IsWindow(hwnd) == FALSE)
        {
            return false;
        }
        const auto destroyWindow = wil::scope_exit([&]
        {
            if (hwnd && IsWindow(hwnd))
            {
                DestroyWindow(hwnd);
            }
        });

        const auto startBegin = std::chrono::steady_clock::now();
        const HRESULT startHr = SettingsHotReload::Start(hwnd, kTestAppId);
        const auto elapsed    = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - startBegin);
        state.Require(SUCCEEDED(startHr), L"SettingsHotReload::Start should tolerate a missing settings directory.");
        state.Require(elapsed < std::chrono::milliseconds{200}, L"SettingsHotReload::Start blocked while creating a missing settings directory.");
        if (FAILED(startHr))
        {
            return false;
        }

        const auto directoryDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(std::chrono::milliseconds{3000});
        while (! std::filesystem::exists(settingsDirectory) && std::chrono::steady_clock::now() < directoryDeadline)
        {
            std::this_thread::sleep_for(SelfTest::Scale(std::chrono::milliseconds{25}));
        }
        state.Require(std::filesystem::is_directory(settingsDirectory), L"Watcher did not create the missing settings directory while retrying.");

        Common::Settings::Settings external{};
        external.theme.currentThemeId     = L"builtin/dark";
        const uint32_t beforeExternalSave = windowState.changeCount.load(std::memory_order_acquire);
        const HRESULT externalSaveHr      = Common::Settings::SaveSettings(kTestAppId, external);
        state.Require(SUCCEEDED(externalSaveHr), L"Failed to save settings after missing-directory watcher startup.");
        state.Require(WaitForAtomicAtLeast(windowState.changeCount, beforeExternalSave + 1u, SelfTest::Scale(std::chrono::milliseconds{4000})),
                      L"Watcher did not observe a settings write after creating the missing directory.");

        return state.failure.empty();
    }
    catch (const std::bad_alloc&)
    {
        std::terminate();
    }
    catch (const std::system_error& error)
    {
        // noexcept self-test boundary: environment isolation setup failed, so leave the shared settings tree untouched.
        state.Require(false, std::format(L"Could not isolate the missing-directory hot-reload settings run. error={}", error.code().value()));
        return false;
    }
}

[[nodiscard]] bool TestPaneViewOptionsPreviewRejectsInvalidEmbeddedChildSetOnReuse(HWND mainWindow,
                                                                                   CaseState& state,
                                                                                   FolderWindow::PreviewEmbeddedChildFaultForTest fault,
                                                                                   std::wstring_view scenario) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path leftRoot  = suiteRoot / L"work" / (L"pane_preview_reopen_fault_left_" + NewGuidText());
    const std::filesystem::path rightRoot = suiteRoot / L"work" / (L"pane_preview_reopen_fault_right_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(leftRoot, ec);
    ec.clear();
    std::filesystem::remove_all(rightRoot, ec);
    state.Require(SelfTest::EnsureDirectory(leftRoot), L"Failed to create reused-child fault source folder.");
    state.Require(SelfTest::EnsureDirectory(rightRoot), L"Failed to create reused-child fault host folder.");
    state.Require(TestWriteTinyBmpFile(leftRoot / L"reopen-first.bmp"), L"Failed to create first reused-child fault image fixture.");
    state.Require(TestWriteTinyBmpFile(leftRoot / L"reopen-second.bmp"), L"Failed to create second reused-child fault image fixture.");
    state.Require(SelfTest::WriteTextFile(rightRoot / L"host.txt", "host"), L"Failed to create reused-child fault host fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::wstring rightPluginBefore                            = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Right));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const std::optional<std::filesystem::path> rightBefore          = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Right);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto pluginConfigurationsBefore                           = g_settings.plugins.configurationByPluginId;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.DebugSetNextPreviewEmbeddedChildFaultForTest(FolderWindow::PreviewEmbeddedChildFaultForTest::None);
        FolderWindow::PreviewPaneDebugSnapshot preview{};
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(preview) && preview.active)
        {
            g_folderWindow.SetActivePane(preview.sourcePane);
            static_cast<void>(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"));
            PumpPendingMessages();
        }
        g_folderWindow.CloseAllViewers();
        g_settings.fileActions.viewers             = viewersBefore;
        g_settings.plugins.configurationByPluginId = pluginConfigurationsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, rightPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
        if (rightBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightBefore.value());
        }
    });

    state.Require(CloseActivePreviewPaneForSelfTest(SelfTest::Scale(1500ms)),
                  std::format(L"Failed to close pre-existing preview pane before {} reused-child coverage.", scenario));
    if (! state.failure.empty())
    {
        return false;
    }

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition imageViewer{};
    imageViewer.id          = L"preview-reopen-fault-image-viewer";
    imageViewer.displayName = L"Preview Reopen Fault Image Viewer";
    imageViewer.enabled     = true;
    imageViewer.kind        = Common::Settings::FileActionKind::ViewerPlugin;
    imageViewer.pluginId    = L"builtin/viewer-imgraw";
    TestSetActionExtensions(imageViewer, {L".bmp"});
    g_settings.fileActions.viewers.actions.push_back(std::move(imageViewer));
    g_settings.fileActions.viewers.associations.push_back(TestViewerAssociation(L".bmp", L"preview-reopen-fault-image-viewer"));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for reused-child fault source pane.");
    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for reused-child fault host pane.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftRoot);
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightRoot);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, leftRoot, SelfTest::Scale(3000ms)) &&
                      WaitForPaneItems(FolderWindow::Pane::Left, {L"reopen-first.bmp", L"reopen-second.bmp"}, SelfTest::Scale(3000ms)),
                  L"Reused-child fault source pane did not enumerate its fixtures.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Right, rightRoot, SelfTest::Scale(3000ms)) &&
                      WaitForPaneItems(FolderWindow::Pane::Right, {L"host.txt"}, SelfTest::Scale(3000ms)),
                  L"Reused-child fault host pane did not enumerate its fixture.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"reopen-first.bmp"),
                  L"Failed to focus first reused-child fault image fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    FocusFolderViewPane(FolderWindow::Pane::Left);
    const HWND expectedFocus = g_folderWindow.GetFolderViewHwnd(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"),
                  L"Preview pane toggle should dispatch for reused-child fault coverage.");

    FolderWindow::PreviewPaneDebugSnapshot snapshot{};
    const auto firstDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < firstDeadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active && snapshot.previewUsesEmbeddedViewer &&
            OrdinalString::EqualsNoCase(snapshot.previewViewerPluginId, L"builtin/viewer-imgraw") && snapshot.previewedPath.filename() == L"reopen-first.bmp" &&
            snapshot.previewEmbeddedViewerHwnd != nullptr)
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }
    state.Require(snapshot.active && snapshot.previewEmbeddedViewerHwnd != nullptr,
                  L"Initial embedded image viewer did not open before reused-child fault injection.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.DebugSetNextPreviewEmbeddedChildFaultForTest(fault);
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"reopen-second.bmp"),
                  L"Failed to focus second reused-child fault image fixture.");

    snapshot                  = {};
    const auto reopenDeadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < reopenDeadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active && snapshot.previewUsesEmbeddedViewer &&
            OrdinalString::EqualsNoCase(snapshot.previewViewerPluginId, L"builtin/viewer-imgraw") &&
            snapshot.previewedPath.filename() == L"reopen-second.bmp" && snapshot.previewLastReopenRejectedChildSet)
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }

    state.Require(snapshot.previewLastReopenRejectedChildSet, std::format(L"Same-plugin preview should reject the injected {} child set.", scenario));
    state.Require(snapshot.previewLastOpenRejectedChildCardinality && snapshot.previewLastOpenCreatedChildCount == 1u &&
                      snapshot.previewLastOpenDetectedChildCount == 1u && snapshot.previewLastOpenHiddenRejectedChildCount == 1u,
                  std::format(L"{} reuse fault should detect and hide its one unowned new direct root before Close.", scenario));
    state.Require(snapshot.active && snapshot.previewUsesEmbeddedViewer && snapshot.previewViewerPluginId == L"builtin/viewer-imgraw" &&
                      snapshot.previewedPath.filename() == L"reopen-second.bmp",
                  L"Rejected same-plugin child reuse should recover through a fresh tracked embedded image viewer.");
    state.Require(snapshot.previewEmbeddedViewerHwnd != nullptr && IsWindowVisible(snapshot.previewEmbeddedViewerHwnd) != FALSE,
                  L"Recovered same-plugin preview should expose a visible validated active root.");
    state.Require(snapshot.previewVisibleDirectChildCount == 1u && snapshot.previewOwnVisibleDirectChildCount == 1u,
                  L"Recovered same-plugin preview should leave exactly one effectively and own-style-visible direct root.");
    state.Require(g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus, L"Same-plugin child-set recovery should preserve source-pane keyboard focus.");

    return state.failure.empty();
}

[[nodiscard]] bool TestPaneViewOptionsPreviewUsesBuiltInEmbeddedViewerWhenAssociationsAreEmpty(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path leftRoot  = suiteRoot / L"work" / (L"pane_preview_builtin_left_" + NewGuidText());
    const std::filesystem::path rightRoot = suiteRoot / L"work" / (L"pane_preview_builtin_right_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(leftRoot, ec);
    ec.clear();
    std::filesystem::remove_all(rightRoot, ec);
    state.Require(SelfTest::EnsureDirectory(leftRoot), L"Failed to create built-in preview source folder.");
    state.Require(SelfTest::EnsureDirectory(rightRoot), L"Failed to create built-in preview host folder.");
    state.Require(TestWriteTinyBmpFile(leftRoot / L"builtin-image-preview.bmp"), L"Failed to create built-in image preview fixture.");
    state.Require(SelfTest::WriteTextFile(rightRoot / L"host.txt", "host"), L"Failed to create built-in preview host fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::wstring rightPluginBefore                            = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Right));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const std::optional<std::filesystem::path> rightBefore          = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Right);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto pluginConfigurationsBefore                           = g_settings.plugins.configurationByPluginId;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        FolderWindow::PreviewPaneDebugSnapshot preview{};
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(preview) && preview.active)
        {
            g_folderWindow.SetActivePane(preview.sourcePane);
            static_cast<void>(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"));
            PumpPendingMessages();
        }

        g_folderWindow.CloseAllViewers();
        g_settings.fileActions.viewers             = viewersBefore;
        g_settings.plugins.configurationByPluginId = pluginConfigurationsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, rightPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
        if (rightBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightBefore.value());
        }
    });

    state.Require(CloseActivePreviewPaneForSelfTest(SelfTest::Scale(1500ms)),
                  L"Failed to close pre-existing preview pane before built-in embedded preview test.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for built-in preview source pane.");
    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for built-in preview host pane.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftRoot);
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightRoot);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, leftRoot, SelfTest::Scale(3000ms)), L"Failed to set left pane path for built-in preview test.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Right, rightRoot, SelfTest::Scale(3000ms)), L"Failed to set right pane path for built-in preview test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"builtin-image-preview.bmp"}, SelfTest::Scale(3000ms)),
                  L"Left pane contents not ready for built-in preview test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Right, {L"host.txt"}, SelfTest::Scale(3000ms)),
                  L"Right pane contents not ready for built-in preview test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"builtin-image-preview.bmp"),
                  L"Failed to focus built-in image preview item.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    FocusFolderViewPane(FolderWindow::Pane::Left);
    const HWND expectedFocus = g_folderWindow.GetFolderViewHwnd(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"),
                  L"Preview pane toggle should dispatch for built-in embedded viewer test.");

    FolderWindow::PreviewPaneDebugSnapshot snapshot{};
    const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < deadline)
    {
        PumpPendingMessages();
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot) && snapshot.active &&
            OrdinalString::EqualsNoCase(snapshot.previewViewerPluginId, L"builtin/viewer-imgraw") && g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus)
        {
            break;
        }
        std::this_thread::sleep_for(10ms);
    }

    state.Require(snapshot.active, L"Built-in embedded preview should be active.");
    state.Require(snapshot.previewUsesEmbeddedViewer, L"Built-in preview should use an embedded viewer instance.");
    state.Require(snapshot.previewViewerPluginId == L"builtin/viewer-imgraw",
                  L"Preview should use the built-in image viewer before falling back to ViewerText.");
    state.Require(snapshot.previewedPath.filename() == L"builtin-image-preview.bmp", L"Built-in preview should load the focused file.");
    state.Require(g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus,
                  L"Built-in embedded preview should not take keyboard focus from the source pane.");

    return state.failure.empty();
}

[[nodiscard]] bool TestPaneViewOptionsPreviewFallsBackToItemPropertiesWhenNoEmbeddedPreviewMatches(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path leftRoot        = suiteRoot / L"work" / (L"pane_preview_properties_left_" + NewGuidText());
    const std::filesystem::path rightRoot       = suiteRoot / L"work" / (L"pane_preview_properties_right_" + NewGuidText());
    const std::filesystem::path noPreviewFile   = leftRoot / L"mystery.no-preview-props";
    const std::filesystem::path noPreviewFolder = leftRoot / L"folder-no-preview-props";
    std::error_code ec;
    std::filesystem::remove_all(leftRoot, ec);
    ec.clear();
    std::filesystem::remove_all(rightRoot, ec);
    state.Require(SelfTest::EnsureDirectory(leftRoot), L"Failed to create properties-preview source folder.");
    state.Require(SelfTest::EnsureDirectory(rightRoot), L"Failed to create properties-preview host folder.");
    state.Require(SelfTest::WriteTextFile(noPreviewFile, "content that should not be the fallback preview"), L"Failed to create no-preview file fixture.");
    state.Require(SelfTest::EnsureDirectory(noPreviewFolder), L"Failed to create no-preview folder fixture.");
    state.Require(SelfTest::WriteTextFile(rightRoot / L"host.txt", "host"), L"Failed to create properties-preview host fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::wstring rightPluginBefore                            = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Right));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const std::optional<std::filesystem::path> rightBefore          = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Right);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto pluginConfigurationsBefore                           = g_settings.plugins.configurationByPluginId;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        FolderWindow::PreviewPaneDebugSnapshot preview{};
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(preview) && preview.active)
        {
            g_folderWindow.SetActivePane(preview.sourcePane);
            static_cast<void>(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"));
            PumpPendingMessages();
        }

        g_folderWindow.CloseAllViewers();
        g_settings.fileActions.viewers             = viewersBefore;
        g_settings.plugins.configurationByPluginId = pluginConfigurationsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, rightPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
        if (rightBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightBefore.value());
        }
    });

    state.Require(CloseActivePreviewPaneForSelfTest(SelfTest::Scale(1500ms)),
                  L"Failed to close pre-existing preview pane before properties fallback preview test.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for properties-preview source pane.");
    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for properties-preview host pane.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftRoot);
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightRoot);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, leftRoot, SelfTest::Scale(3000ms)), L"Failed to set left pane path for properties-preview test.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Right, rightRoot, SelfTest::Scale(3000ms)),
                  L"Failed to set right pane path for properties-preview test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"folder-no-preview-props", L"mystery.no-preview-props"}, SelfTest::Scale(3000ms)),
                  L"Left pane contents not ready for properties-preview test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Right, {L"host.txt"}, SelfTest::Scale(3000ms)),
                  L"Right pane contents not ready for properties-preview test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"mystery.no-preview-props"), L"Failed to focus no-preview file item.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    FocusFolderViewPane(FolderWindow::Pane::Left);
    const HWND expectedFocus = g_folderWindow.GetFolderViewHwnd(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"),
                  L"Preview pane toggle should dispatch for properties fallback test.");

    FolderWindow::PreviewPaneDebugSnapshot fileSnapshot{};
    state.Require(
        WaitForPreviewPaneTextAndFocus(
            L"Name: mystery.no-preview-props", L"content that should not be the fallback preview", expectedFocus, fileSnapshot, SelfTest::Scale(5000ms)),
        L"No-preview file should fall back to item properties text.");
    state.Require(fileSnapshot.active, L"Properties fallback preview should be active for the no-preview file.");
    state.Require(! fileSnapshot.previewUsesEmbeddedViewer, L"No-preview file properties fallback should not host an embedded viewer.");
    state.Require(fileSnapshot.previewViewerPluginId.empty(), L"No-preview file properties fallback should not retain an embedded viewer plugin id.");
    state.Require(fileSnapshot.previewedPath == noPreviewFile, L"Properties fallback preview should track the focused no-preview file.");
    state.Require(fileSnapshot.previewText.find(L"Type: File") != std::wstring::npos,
                  L"No-preview file properties fallback should include file type metadata.");
    state.Require(g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus,
                  L"No-preview file properties fallback should not take keyboard focus from the source pane.");

    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"folder-no-preview-props"), L"Failed to focus no-preview folder item.");

    FolderWindow::PreviewPaneDebugSnapshot folderSnapshot{};
    state.Require(WaitForPreviewPaneTextAndFocus(
                      L"Name: folder-no-preview-props", L"Folder: folder-no-preview-props", expectedFocus, folderSnapshot, SelfTest::Scale(5000ms)),
                  L"No-preview folder should fall back to item properties text.");
    state.Require(folderSnapshot.active, L"Properties fallback preview should be active for the no-preview folder.");
    state.Require(! folderSnapshot.previewUsesEmbeddedViewer, L"No-preview folder properties fallback should not host an embedded viewer.");
    state.Require(folderSnapshot.previewViewerPluginId.empty(), L"No-preview folder properties fallback should not retain an embedded viewer plugin id.");
    state.Require(folderSnapshot.previewedPath == noPreviewFolder, L"Properties fallback preview should track the focused no-preview folder.");
    state.Require(folderSnapshot.previewText.find(L"Type: Directory") != std::wstring::npos,
                  L"No-preview folder properties fallback should include directory type metadata.");
    state.Require(g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus,
                  L"No-preview folder properties fallback should not take keyboard focus from the source pane.");

    return state.failure.empty();
}

[[nodiscard]] bool TestPaneViewOptionsPreviewPropertiesCardScrollsAndUsesRainbowTheme(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path leftRoot      = suiteRoot / L"work" / (L"pane_preview_properties_cards_left_" + NewGuidText());
    const std::filesystem::path rightRoot     = suiteRoot / L"work" / (L"pane_preview_properties_cards_right_" + NewGuidText());
    const std::filesystem::path noPreviewFile = leftRoot / L"rainbow-properties.no-preview-cards";
    std::error_code ec;
    std::filesystem::remove_all(leftRoot, ec);
    ec.clear();
    std::filesystem::remove_all(rightRoot, ec);
    state.Require(SelfTest::EnsureDirectory(leftRoot), L"Failed to create properties-card preview source folder.");
    state.Require(SelfTest::EnsureDirectory(rightRoot), L"Failed to create properties-card preview host folder.");
    state.Require(SelfTest::WriteTextFile(noPreviewFile, "preview card fallback should render properties, not file text"),
                  L"Failed to create properties-card preview fixture.");
    state.Require(SelfTest::WriteTextFile(rightRoot / L"host.txt", "host"), L"Failed to create properties-card preview host fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    std::filesystem::path longStreamDirectory = leftRoot / L"ads-long-path";
    size_t longPathSegmentIndex               = 0u;
    while ((longStreamDirectory / L"long-stream-base.txt").wstring().size() <= static_cast<size_t>(MAX_PATH) && longPathSegmentIndex < 64u)
    {
        longStreamDirectory /= std::format(L"segment-{0:02}-abcdefghijklmnopqrstuvwxyz0123456789", longPathSegmentIndex);
        ++longPathSegmentIndex;
    }
    const std::filesystem::path longStreamFile = longStreamDirectory / L"long-stream-base.txt";
    state.Require(longStreamFile.wstring().size() > static_cast<size_t>(MAX_PATH),
                  std::format(L"Long-path ADS fixture must exceed MAX_PATH; observed {} characters.", longStreamFile.wstring().size()));
    const HRESULT longDirectoryHr = EnsureExtendedDirectoryForPreviewPropertiesTest(longStreamDirectory);
    state.Require(SUCCEEDED(longDirectoryHr),
                  std::format(L"Failed to create the long-path ADS fixture directory. hr=0x{0:08X}", static_cast<unsigned long>(longDirectoryHr)));
    const HRESULT longBaseFileHr = WriteExtendedTextFileForPreviewPropertiesTest(longStreamFile, "long-path alternate stream base");
    state.Require(SUCCEEDED(longBaseFileHr),
                  std::format(L"Failed to create the long-path ADS base file. hr=0x{0:08X}", static_cast<unsigned long>(longBaseFileHr)));
    if (! state.failure.empty())
    {
        return false;
    }

    bool namedStreamsSupported       = false;
    const HRESULT streamCapabilityHr = QueryNamedStreamSupportForPreviewPropertiesTest(longStreamFile, namedStreamsSupported);
    state.Require(
        SUCCEEDED(streamCapabilityHr),
        std::format(L"Failed to query FILE_NAMED_STREAMS for the long-path ADS fixture. hr=0x{0:08X}", static_cast<unsigned long>(streamCapabilityHr)));
    if (FAILED(streamCapabilityHr))
    {
        return false;
    }
    if (! namedStreamsSupported)
    {
        return state.Skip(L"Alternate data streams are not supported by the temporary filesystem.");
    }

    const HRESULT longStreamHr = WriteAlternateStreamForPreviewPropertiesTest(longStreamFile, L"long-path-stream", "long-path alternate stream payload");
    state.Require(SUCCEEDED(longStreamHr),
                  std::format(L"Failed to create an alternate stream on the >MAX_PATH fixture. hr=0x{0:08X}", static_cast<unsigned long>(longStreamHr)));
    if (! state.failure.empty())
    {
        return false;
    }

    constexpr size_t kStreamCount             = 28u;
    constexpr std::string_view kStreamPayload = "stream payload for preview properties card scroll validation";
    for (size_t index = 0u; index < kStreamCount; ++index)
    {
        const std::wstring streamName = std::format(L"preview-stream-{0:02}", index);
        const HRESULT hr              = WriteAlternateStreamForPreviewPropertiesTest(noPreviewFile, streamName, kStreamPayload);
        state.Require(SUCCEEDED(hr),
                      std::format(L"Failed to create alternate stream '{0}' for preview properties card validation. hr=0x{1:08X}",
                                  streamName,
                                  static_cast<unsigned long>(hr)));
    }
    if (! state.failure.empty())
    {
        return false;
    }

    const AppTheme themeBefore                                      = g_folderWindow.GetTheme();
    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::wstring rightPluginBefore                            = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Right));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const std::optional<std::filesystem::path> rightBefore          = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Right);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto pluginConfigurationsBefore                           = g_settings.plugins.configurationByPluginId;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        FolderWindow::PreviewPaneDebugSnapshot preview{};
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(preview) && preview.active)
        {
            g_folderWindow.SetActivePane(preview.sourcePane);
            static_cast<void>(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"));
            PumpPendingMessages();
        }

        g_folderWindow.CloseAllViewers();
        g_folderWindow.ApplyTheme(themeBefore);
        g_settings.fileActions.viewers             = viewersBefore;
        g_settings.plugins.configurationByPluginId = pluginConfigurationsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, rightPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
        if (rightBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightBefore.value());
        }
    });

    state.Require(CloseActivePreviewPaneForSelfTest(SelfTest::Scale(1500ms)),
                  L"Failed to close pre-existing preview pane before preview properties-card test.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    g_folderWindow.ApplyTheme(ResolveAppTheme(ThemeMode::Rainbow, L"preview-properties-card-selftest-rainbow"));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for preview properties-card source pane.");
    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for preview properties-card host pane.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftRoot);
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightRoot);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, leftRoot, SelfTest::Scale(3000ms)),
                  L"Failed to set left pane path for preview properties-card test.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Right, rightRoot, SelfTest::Scale(3000ms)),
                  L"Failed to set right pane path for preview properties-card test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"rainbow-properties.no-preview-cards"}, SelfTest::Scale(3000ms)),
                  L"Left pane contents not ready for preview properties-card test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Right, {L"host.txt"}, SelfTest::Scale(3000ms)),
                  L"Right pane contents not ready for preview properties-card test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"rainbow-properties.no-preview-cards"),
                  L"Failed to focus preview properties-card item.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    FocusFolderViewPane(FolderWindow::Pane::Left);
    const HWND expectedFocus = g_folderWindow.GetFolderViewHwnd(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"),
                  L"Preview pane toggle should dispatch for preview properties-card test.");

    FolderWindow::PreviewPaneDebugSnapshot snapshot{};
    state.Require(
        WaitForPreviewPaneText(L"Name: rainbow-properties.no-preview-cards", L"preview card fallback should render", snapshot, SelfTest::Scale(5000ms)),
        L"Preview properties-card content did not load.");
    state.Require(snapshot.previewPropertiesCardMode, L"Default properties preview should use card mode instead of the plain fallback label.");
    state.Require(snapshot.previewPropertiesUsesScrollPanel, L"Default properties preview should use the DxUi ScrollPanel.");
    state.Require(snapshot.previewPropertiesCanScroll, L"Long default properties preview should expose a vertical scrollbar.");
    state.Require(snapshot.previewPropertiesSectionCount >= 2u,
                  std::format(L"Default properties preview should expose properties sections; saw {}.", snapshot.previewPropertiesSectionCount));
    state.Require(snapshot.previewPropertiesFieldCount >= kStreamCount,
                  std::format(L"Default properties preview should expose stream/property rows; saw {}.", snapshot.previewPropertiesFieldCount));
    state.Require(snapshot.previewPropertiesUsesRainbow, L"Rainbow theme should add rainbow treatment to default properties preview cards.");
    state.Require(g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus,
                  L"Default properties preview card layout should not take keyboard focus from the source pane.");

    const int beforeScroll = snapshot.previewPropertiesScrollOffsetPx;
    state.Require(g_folderWindow.DebugScrollPreviewPropertiesByWheelDetents(snapshot.hostPane, -4),
                  L"Preview properties card surface should accept wheel scrolling.");
    FolderWindow::PreviewPaneDebugSnapshot scrolled{};
    state.Require(g_folderWindow.DebugGetPreviewPaneSnapshot(scrolled), L"Could not capture scrolled preview properties-card snapshot.");
    state.Require(scrolled.previewPropertiesScrollOffsetPx > beforeScroll,
                  std::format(L"Preview properties card surface should move after wheel scrolling; before={}, after={}.",
                              beforeScroll,
                              scrolled.previewPropertiesScrollOffsetPx));
    state.Require(g_folderWindow.GetFocusedFolderViewHwnd() == expectedFocus,
                  L"Scrolling default properties preview should keep keyboard focus in the source pane.");

    return state.failure.empty();
}

[[nodiscard]] bool TestPaneViewOptionsPreviewPaneExtendsWhenFunctionBarHidden(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"pane_preview_functionbar_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create preview function-bar test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"bottom-preview.txt", "bottom preview body"), L"Failed to create preview function-bar file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                   = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const bool functionBarBefore                          = g_folderWindow.GetFunctionBarVisible();
    const auto restoreState                               = wil::scope_exit([&]
    {
        FolderWindow::PreviewPaneDebugSnapshot preview{};
        if (g_folderWindow.DebugGetPreviewPaneSnapshot(preview) && preview.active)
        {
            g_folderWindow.SetActivePane(preview.sourcePane);
            static_cast<void>(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"));
            PumpPendingMessages();
        }

        g_folderWindow.SetFunctionBarVisible(functionBarBefore);
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    state.Require(CloseActivePreviewPaneForSelfTest(SelfTest::Scale(1500ms)), L"Failed to close pre-existing preview pane before preview function-bar test.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetFunctionBarVisible(false);
    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for preview function-bar test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for preview function-bar test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"bottom-preview.txt"}, SelfTest::Scale(3000ms)),
                  L"Left pane contents not ready for preview function-bar test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"bottom-preview.txt"), L"Failed to focus bottom preview item.");
    if (! state.failure.empty())
    {
        return false;
    }

    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewOptions/togglePreviewPane"),
                  L"Preview pane toggle should dispatch while function bar is hidden.");
    PumpPendingMessages();

    FolderWindow::PreviewPaneDebugSnapshot snapshot{};
    state.Require(g_folderWindow.DebugGetPreviewPaneSnapshot(snapshot), L"Could not capture preview function-bar-hidden snapshot.");
    state.Require(snapshot.active && snapshot.previewContentVisible, L"Preview content should be visible while function bar is hidden.");
    state.Require(snapshot.functionBarRect.bottom == snapshot.functionBarRect.top, L"Function bar rect should collapse while hidden.");
    state.Require(snapshot.contentRect.bottom == snapshot.clientRect.bottom,
                  L"Preview content should extend to the bottom of the FolderWindow when the function bar is hidden.");

    return state.failure.empty();
}

[[nodiscard]] bool TestAlternateViewUsesConfiguredViewerAction(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"alternate_view_action_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create alternate-view action test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"alpha.altview", "alternate view"), L"Failed to create alternate-view action test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.CloseAllViewers();
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition textViewer{};
    textViewer.id          = L"alternate-text";
    textViewer.displayName = L"Alternate Text Viewer";
    textViewer.enabled     = true;
    textViewer.kind        = Common::Settings::FileActionKind::ViewerPlugin;
    textViewer.pluginId    = L"builtin/viewer-text";
    TestSetActionExtensions(textViewer, {L".altview"});
    g_settings.fileActions.viewers.actions.push_back(std::move(textViewer));
    g_settings.fileActions.viewers.associations.push_back(TestDefaultViewerAssociation({}, L"alternate-text"));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for alternate-view action test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for alternate-view action test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"alpha.altview"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for alternate-view action test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"alpha.altview"),
                  L"Failed to focus alpha.altview for alternate-view action test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    const size_t baselineViewerCount = g_folderWindow.DebugGetViewerInstanceCount();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/alternateView"), L"cmd/pane/alternateView should dispatch through the shortcut path.");

    const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < deadline &&
           ! (g_folderWindow.DebugGetViewerInstanceCount() == baselineViewerCount + 1u && g_folderWindow.DebugHasViewerPluginId(L"builtin/viewer-text")))
    {
        PumpPendingMessages();
        std::this_thread::sleep_for(20ms);
    }

    state.Require(g_folderWindow.DebugGetViewerInstanceCount() == baselineViewerCount + 1u,
                  L"Alternate View should open one viewer instance from the configured alternate action.");
    state.Require(g_folderWindow.DebugHasViewerPluginId(L"builtin/viewer-text"), L"Alternate View should use the configured ViewerText action.");

    return state.failure.empty();
}

[[nodiscard]] bool TestAlternateViewLaunchesExternalViewerAction(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root       = suiteRoot / L"work" / (L"alternate_view_external_" + NewGuidText());
    const std::filesystem::path markerPath = root / L"alternate-external-marker.txt";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create alternate-view external action test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"theta.altexternal", "alternate external view"),
                  L"Failed to create alternate-view external action test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.CloseAllViewers();
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition externalViewer{};
    externalViewer.id               = L"alternate-external";
    externalViewer.displayName      = L"Alternate External Viewer";
    externalViewer.enabled          = true;
    externalViewer.kind             = Common::Settings::FileActionKind::ExternalProgram;
    externalViewer.executablePath   = ResolveCommandProcessorPath();
    externalViewer.arguments        = L"/C if exist \"{SelectedPathsFile}\" echo alternate-external>alternate-external-marker.txt";
    externalViewer.workingDirectory = L"{Path}";
    TestSetActionExtensions(externalViewer, {L".altexternal"});
    g_settings.fileActions.viewers.actions.push_back(std::move(externalViewer));
    g_settings.fileActions.viewers.associations.push_back(TestDefaultViewerAssociation({}, L"alternate-external"));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for alternate-view external action test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)),
                  L"Failed to set left pane path for alternate-view external action test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"theta.altexternal"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for alternate-view external action test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"theta.altexternal"),
                  L"Failed to focus theta.altexternal for alternate-view external action test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    const size_t baselineViewerCount = g_folderWindow.DebugGetViewerInstanceCount();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/alternateView"),
                  L"cmd/pane/alternateView should dispatch for a configured external viewer action.");

    std::string markerText;
    state.Require(WaitForTextFileFirstLine(markerPath, "alternate-external", SelfTest::Scale(5000ms), markerText),
                  std::format(L"Alternate external viewer action should receive expanded macros; marker first line was '{}'.",
                              std::wstring(markerText.begin(), markerText.end())));
    state.Require(g_folderWindow.DebugGetViewerInstanceCount() == baselineViewerCount,
                  L"External Alternate View should not create an internal viewer instance.");

    return state.failure.empty();
}

[[nodiscard]] bool TestViewCommandUsesConfiguredPrimaryViewerAction(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root       = suiteRoot / L"work" / (L"primary_view_action_" + NewGuidText());
    const std::filesystem::path markerPath = root / L"primary-view-marker.txt";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create primary-view action test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"eta.primaryview", "primary view"), L"Failed to create primary-view action test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::ExtensionsSettings extensionsBefore     = g_settings.extensions;
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.CloseAllViewers();
        g_settings.extensions          = extensionsBefore;
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};

    Common::Settings::FileActionDefinition primaryViewer{};
    primaryViewer.id               = L"primary-marker";
    primaryViewer.displayName      = L"Primary Marker Viewer";
    primaryViewer.enabled          = true;
    primaryViewer.kind             = Common::Settings::FileActionKind::ExternalProgram;
    primaryViewer.executablePath   = ResolveCommandProcessorPath();
    primaryViewer.arguments        = L"/C if exist {FullPath} echo primary-view>primary-view-marker.txt";
    primaryViewer.workingDirectory = L"{Path}";
    TestSetActionExtensions(primaryViewer, {L".primaryview"});
    g_settings.fileActions.viewers.actions.push_back(std::move(primaryViewer));
    g_settings.fileActions.viewers.associations.push_back(TestViewerAssociation(L".primaryview", L"primary-marker"));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for primary-view action test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for primary-view action test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"eta.primaryview"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for primary-view action test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"eta.primaryview"),
                  L"Failed to focus eta.primaryview for primary-view action test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    const size_t baselineViewerCount = g_folderWindow.DebugGetViewerInstanceCount();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/view"), L"cmd/pane/view should dispatch through the shortcut path.");

    std::string markerText;
    state.Require(WaitForTextFileFirstLine(markerPath, "primary-view", SelfTest::Scale(5000ms), markerText),
                  std::format(L"Primary viewer action should receive expanded path macros; marker first line was '{}'.",
                              std::wstring(markerText.begin(), markerText.end())));
    state.Require(g_folderWindow.DebugGetViewerInstanceCount() == baselineViewerCount,
                  L"External primary View action should not create an internal viewer instance.");

    return state.failure.empty();
}

[[nodiscard]] bool TestViewWithDisabledActionReportsAlert(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"view_with_disabled_alert_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create View With disabled-action alert test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"zeta.disabledview", "view with disabled action"),
                  L"Failed to create View With disabled-action alert test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition disabledViewer{};
    disabledViewer.id               = L"disabled-viewer";
    disabledViewer.displayName      = L"Disabled Viewer";
    disabledViewer.enabled          = false;
    disabledViewer.kind             = Common::Settings::FileActionKind::ExternalProgram;
    disabledViewer.executablePath   = ResolveCommandProcessorPath();
    disabledViewer.arguments        = L"/C exit /B 0";
    disabledViewer.workingDirectory = L"{Path}";
    TestSetActionExtensions(disabledViewer, {L".disabledview"});
    g_settings.fileActions.viewers.actions.push_back(std::move(disabledViewer));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for View With disabled-action alert test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)),
                  L"Failed to set left pane path for View With disabled-action alert test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"zeta.disabledview"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for View With disabled-action alert test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"zeta.disabledview"),
                  L"Failed to focus zeta.disabledview for View With disabled-action alert test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewWith/disabled-viewer"),
                  L"cmd/pane/viewWith/<viewerId> should dispatch through the shortcut path.");
    PumpPendingMessages();

    FolderView::AlertOverlayDebugSnapshot alert{};
    state.Require(g_folderWindow.DebugGetPaneAlertSnapshot(FolderWindow::Pane::Left, alert), L"Pane alert snapshot should be available.");
    state.Require(alert.visible, L"Disabled View With action should show a pane alert.");
    state.Require(alert.severity == FolderView::OverlaySeverity::Warning, L"Disabled View With action should report a warning.");
    state.Require(alert.title == LoadStringResource(nullptr, IDS_FILEACTION_VIEWER_UNAVAILABLE_TITLE),
                  L"Disabled View With action should use the localized viewer-unavailable title.");
    state.Require(alert.message.find(L"disabled-viewer") != std::wstring::npos, L"Disabled View With alert should name the unavailable viewer action id.");
    state.Require(alert.message.find(L"zeta.disabledview") != std::wstring::npos, L"Disabled View With alert should name the focused file.");

    return state.failure.empty();
}

[[nodiscard]] bool TestAlternateViewWithoutConfiguredActionReportsAlert(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"alternate_view_missing_alert_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create missing alternate-view alert test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"omega.noaltview", "missing alternate view"), L"Failed to create missing alternate-view alert test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
        g_folderWindow.CloseAllViewers();
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for missing alternate-view alert test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)),
                  L"Failed to set left pane path for missing alternate-view alert test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"omega.noaltview"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for missing alternate-view alert test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"omega.noaltview"),
                  L"Failed to focus omega.noaltview for missing alternate-view alert test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
    const size_t baselineViewerCount = g_folderWindow.DebugGetViewerInstanceCount();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/alternateView"), L"cmd/pane/alternateView should dispatch through the shortcut path.");
    PumpPendingMessages();

    FolderView::AlertOverlayDebugSnapshot alert{};
    state.Require(g_folderWindow.DebugGetViewerInstanceCount() == baselineViewerCount,
                  L"Alternate View without a configured alternate action should not open the regular viewer fallback.");
    state.Require(g_folderWindow.DebugGetPaneAlertSnapshot(FolderWindow::Pane::Left, alert), L"Pane alert snapshot should be available.");
    state.Require(alert.visible, L"Alternate View without a configured alternate action should show a pane alert.");
    state.Require(alert.severity == FolderView::OverlaySeverity::Warning, L"Missing Alternate View action should report a warning.");
    state.Require(alert.title == LoadStringResource(nullptr, IDS_FILEACTION_VIEWER_UNAVAILABLE_TITLE),
                  L"Missing Alternate View action should use the localized viewer-unavailable title.");
    state.Require(alert.message.find(L"omega.noaltview") != std::wstring::npos, L"Missing Alternate View alert should name the focused file.");

    return state.failure.empty();
}

[[nodiscard]] bool TestEditWithDisabledActionReportsAlert(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"edit_with_disabled_alert_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create Edit With disabled-action alert test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"lambda.disablededit", "edit with disabled action"),
                  L"Failed to create Edit With disabled-action alert test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::EditorFileActionsSettings editorsBefore = g_settings.fileActions.editors;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
        g_settings.fileActions.editors = editorsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.editors = Common::Settings::EditorFileActionsSettings{};
    Common::Settings::FileActionDefinition disabledEditor{};
    disabledEditor.id               = L"disabled-editor";
    disabledEditor.displayName      = L"Disabled Editor";
    disabledEditor.enabled          = false;
    disabledEditor.kind             = Common::Settings::FileActionKind::ExternalProgram;
    disabledEditor.executablePath   = ResolveCommandProcessorPath();
    disabledEditor.arguments        = L"/C exit /B 0";
    disabledEditor.workingDirectory = L"{Path}";
    TestSetActionExtensions(disabledEditor, {L".disablededit"});
    g_settings.fileActions.editors.actions.push_back(std::move(disabledEditor));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for Edit With disabled-action alert test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)),
                  L"Failed to set left pane path for Edit With disabled-action alert test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"lambda.disablededit"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for Edit With disabled-action alert test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"lambda.disablededit"),
                  L"Failed to focus lambda.disablededit for Edit With disabled-action alert test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/editWith/disabled-editor"),
                  L"cmd/pane/editWith/<editorId> should dispatch through the shortcut path.");
    PumpPendingMessages();

    FolderView::AlertOverlayDebugSnapshot alert{};
    state.Require(g_folderWindow.DebugGetPaneAlertSnapshot(FolderWindow::Pane::Left, alert), L"Pane alert snapshot should be available.");
    state.Require(alert.visible, L"Disabled Edit With action should show a pane alert.");
    state.Require(alert.severity == FolderView::OverlaySeverity::Warning, L"Disabled Edit With action should report a warning.");
    state.Require(alert.title == LoadStringResource(nullptr, IDS_FILEACTION_EDITOR_UNAVAILABLE_TITLE),
                  L"Disabled Edit With action should use the localized editor-unavailable title.");
    state.Require(alert.message.find(L"disabled-editor") != std::wstring::npos, L"Disabled Edit With alert should name the unavailable editor action id.");
    state.Require(alert.message.find(L"lambda.disablededit") != std::wstring::npos, L"Disabled Edit With alert should name the focused file.");

    return state.failure.empty();
}

[[nodiscard]] bool TestViewWithLaunchFailureReportsAlert(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"view_with_launch_failure_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create View With launch-failure alert test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"rho.brokenview", "view with broken action"), L"Failed to create View With launch-failure alert test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition brokenViewer{};
    brokenViewer.id               = L"broken-viewer";
    brokenViewer.displayName      = L"Broken Viewer";
    brokenViewer.enabled          = true;
    brokenViewer.kind             = Common::Settings::FileActionKind::ExternalProgram;
    brokenViewer.executablePath   = (root / L"missing-viewer.exe").wstring();
    brokenViewer.arguments        = L"{FullPath}";
    brokenViewer.workingDirectory = L"{Path}";
    TestSetActionExtensions(brokenViewer, {L".brokenview"});
    g_settings.fileActions.viewers.actions.push_back(std::move(brokenViewer));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for View With launch-failure alert test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)),
                  L"Failed to set left pane path for View With launch-failure alert test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"rho.brokenview"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for View With launch-failure alert test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"rho.brokenview"),
                  L"Failed to focus rho.brokenview for View With launch-failure alert test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewWith/broken-viewer"),
                  L"cmd/pane/viewWith/<viewerId> should dispatch through the shortcut path.");
    PumpPendingMessages();

    FolderView::AlertOverlayDebugSnapshot alert{};
    state.Require(g_folderWindow.DebugGetPaneAlertSnapshot(FolderWindow::Pane::Left, alert), L"Pane alert snapshot should be available.");
    state.Require(alert.visible, L"Broken View With action should show a pane alert.");
    state.Require(alert.severity == FolderView::OverlaySeverity::Warning, L"Broken View With action should report a warning.");
    state.Require(alert.title == LoadStringResource(nullptr, IDS_FILEACTION_VIEWER_UNAVAILABLE_TITLE),
                  L"Broken View With action should use the localized viewer-unavailable title.");
    state.Require(alert.message.find(L"broken-viewer") != std::wstring::npos, L"Broken View With alert should name the viewer action id.");
    state.Require(alert.message.find(L"rho.brokenview") != std::wstring::npos, L"Broken View With alert should name the focused file.");
    state.Require(alert.message.find(L"0x") != std::wstring::npos, L"Broken View With alert should include the launch HRESULT.");

    return state.failure.empty();
}

[[nodiscard]] bool TestEditWithLaunchFailureReportsAlert(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"edit_with_launch_failure_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create Edit With launch-failure alert test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"tau.brokenedit", "edit with broken action"), L"Failed to create Edit With launch-failure alert test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::EditorFileActionsSettings editorsBefore = g_settings.fileActions.editors;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
        g_settings.fileActions.editors = editorsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.editors = Common::Settings::EditorFileActionsSettings{};
    Common::Settings::FileActionDefinition brokenEditor{};
    brokenEditor.id               = L"broken-editor";
    brokenEditor.displayName      = L"Broken Editor";
    brokenEditor.enabled          = true;
    brokenEditor.kind             = Common::Settings::FileActionKind::ExternalProgram;
    brokenEditor.executablePath   = (root / L"missing-editor.exe").wstring();
    brokenEditor.arguments        = L"{FullPath}";
    brokenEditor.workingDirectory = L"{Path}";
    TestSetActionExtensions(brokenEditor, {L".brokenedit"});
    g_settings.fileActions.editors.actions.push_back(std::move(brokenEditor));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for Edit With launch-failure alert test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)),
                  L"Failed to set left pane path for Edit With launch-failure alert test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"tau.brokenedit"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for Edit With launch-failure alert test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"tau.brokenedit"),
                  L"Failed to focus tau.brokenedit for Edit With launch-failure alert test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/editWith/broken-editor"),
                  L"cmd/pane/editWith/<editorId> should dispatch through the shortcut path.");
    PumpPendingMessages();

    FolderView::AlertOverlayDebugSnapshot alert{};
    state.Require(g_folderWindow.DebugGetPaneAlertSnapshot(FolderWindow::Pane::Left, alert), L"Pane alert snapshot should be available.");
    state.Require(alert.visible, L"Broken Edit With action should show a pane alert.");
    state.Require(alert.severity == FolderView::OverlaySeverity::Warning, L"Broken Edit With action should report a warning.");
    state.Require(alert.title == LoadStringResource(nullptr, IDS_FILEACTION_EDITOR_UNAVAILABLE_TITLE),
                  L"Broken Edit With action should use the localized editor-unavailable title.");
    state.Require(alert.message.find(L"broken-editor") != std::wstring::npos, L"Broken Edit With alert should name the editor action id.");
    state.Require(alert.message.find(L"tau.brokenedit") != std::wstring::npos, L"Broken Edit With alert should name the focused file.");
    state.Require(alert.message.find(L"0x") != std::wstring::npos, L"Broken Edit With alert should include the launch HRESULT.");

    return state.failure.empty();
}

[[nodiscard]] bool TestAlternateEditWithoutConfiguredActionReportsAlert(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"alternate_edit_missing_alert_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create missing alternate-edit alert test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"sigma.noaltedit", "missing alternate edit"), L"Failed to create missing alternate-edit alert test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::EditorFileActionsSettings editorsBefore = g_settings.fileActions.editors;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
        g_settings.fileActions.editors = editorsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.editors = Common::Settings::EditorFileActionsSettings{};

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for missing alternate-edit alert test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)),
                  L"Failed to set left pane path for missing alternate-edit alert test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"sigma.noaltedit"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for missing alternate-edit alert test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"sigma.noaltedit"),
                  L"Failed to focus sigma.noaltedit for missing alternate-edit alert test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/alternateEdit"), L"cmd/pane/alternateEdit should dispatch through the shortcut path.");
    PumpPendingMessages();

    FolderView::AlertOverlayDebugSnapshot alert{};
    state.Require(g_folderWindow.DebugGetPaneAlertSnapshot(FolderWindow::Pane::Left, alert), L"Pane alert snapshot should be available.");
    state.Require(alert.visible, L"Alternate Edit without a configured alternate action should show a pane alert.");
    state.Require(alert.severity == FolderView::OverlaySeverity::Warning, L"Missing Alternate Edit action should report a warning.");
    state.Require(alert.title == LoadStringResource(nullptr, IDS_FILEACTION_EDITOR_UNAVAILABLE_TITLE),
                  L"Missing Alternate Edit action should use the localized editor-unavailable title.");
    state.Require(alert.message.find(L"sigma.noaltedit") != std::wstring::npos, L"Missing Alternate Edit alert should name the focused file.");

    return state.failure.empty();
}

[[nodiscard]] bool TestViewWithMenuPopulatesApplicableViewerActions(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root       = suiteRoot / L"work" / (L"view_with_menu_" + NewGuidText());
    const std::filesystem::path markerPath = root / L"view-with-menu-marker.txt";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create View With menu test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"epsilon.menuext", "view with menu"), L"Failed to create View With menu test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::ExtensionsSettings extensionsBefore     = g_settings.extensions;
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.CloseAllViewers();
        g_settings.extensions          = extensionsBefore;
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};

    Common::Settings::FileActionDefinition menuViewer{};
    menuViewer.id               = L"menu-marker";
    menuViewer.displayName      = L"Menu Marker Viewer";
    menuViewer.enabled          = true;
    menuViewer.kind             = Common::Settings::FileActionKind::ExternalProgram;
    menuViewer.executablePath   = ResolveCommandProcessorPath();
    menuViewer.arguments        = L"/C if exist {FullPath} echo view-with-menu>view-with-menu-marker.txt";
    menuViewer.workingDirectory = L"{Path}";
    TestSetActionExtensions(menuViewer, {L".menuext"});
    g_settings.fileActions.viewers.actions.push_back(std::move(menuViewer));

    Common::Settings::FileActionDefinition filteredViewer{};
    filteredViewer.id               = L"filtered-marker";
    filteredViewer.displayName      = L"Filtered Marker Viewer";
    filteredViewer.enabled          = true;
    filteredViewer.kind             = Common::Settings::FileActionKind::ExternalProgram;
    filteredViewer.executablePath   = ResolveCommandProcessorPath();
    filteredViewer.arguments        = L"/C echo filtered>filtered-marker.txt";
    filteredViewer.workingDirectory = L"{Path}";
    TestSetActionExtensions(filteredViewer, {L".otherext"});
    g_settings.fileActions.viewers.actions.push_back(std::move(filteredViewer));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for View With menu test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for View With menu test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"epsilon.menuext"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for View With menu test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"epsilon.menuext"),
                  L"Failed to focus epsilon.menuext for View With menu test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);

    const HMENU mainMenu     = DebugGetMainMenuModelHandle();
    const HMENU viewWithMenu = FindSubMenuByTextFragment(mainMenu, L"View &With");
    state.Require(viewWithMenu != nullptr, L"View With menu should exist in the main menu model.");
    if (! viewWithMenu)
    {
        return false;
    }

    SendMessageW(mainWindow, WM_INITMENUPOPUP, reinterpret_cast<WPARAM>(viewWithMenu), 0);
    const int itemCount = GetMenuItemCount(viewWithMenu);
    state.Require(itemCount == 1, L"View With menu should contain only applicable viewer actions for the focused file.");
    if (itemCount != 1)
    {
        return false;
    }

    const UINT commandId        = GetMenuItemID(viewWithMenu, 0);
    const std::wstring menuText = GetMenuItemTextByPosition(viewWithMenu, 0);
    state.Require(commandId == IDM_PANE_VIEW_WITH_BASE, L"First View With action should use the dynamic View With command-id range.");
    state.Require(menuText.find(L"Menu Marker Viewer") != std::wstring::npos, L"View With menu should display the configured action name.");
    state.Require(menuText.find(L"Filtered Marker Viewer") == std::wstring::npos, L"View With menu should not display extension-mismatched actions.");
    if (! state.failure.empty())
    {
        return false;
    }

    SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(commandId, 0), 0);

    std::string markerText;
    state.Require(WaitForTextFileFirstLine(markerPath, "view-with-menu", SelfTest::Scale(5000ms), markerText),
                  std::format(L"View With menu action should receive expanded path macros; marker first line was '{}'.",
                              std::wstring(markerText.begin(), markerText.end())));

    return state.failure.empty();
}

[[nodiscard]] bool TestViewWithParameterizedCommandUsesConfiguredViewerAction(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root = suiteRoot / L"work" / (L"view_with_action_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create view-with action test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"beta.viewwith", "view with"), L"Failed to create view-with action test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::ExtensionsSettings extensionsBefore     = g_settings.extensions;
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.CloseAllViewers();
        g_settings.extensions          = extensionsBefore;
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition textViewer{};
    textViewer.id          = L"Explicit-Text";
    textViewer.displayName = L"Explicit Text Viewer";
    textViewer.enabled     = true;
    textViewer.kind        = Common::Settings::FileActionKind::ViewerPlugin;
    textViewer.pluginId    = L"builtin/viewer-text";
    TestSetActionExtensions(textViewer, {L".viewwith"});
    g_settings.fileActions.viewers.actions.push_back(std::move(textViewer));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for view-with action test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for view-with action test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"beta.viewwith"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for view-with action test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"beta.viewwith"),
                  L"Failed to focus beta.viewwith for view-with action test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    const size_t baselineViewerCount = g_folderWindow.DebugGetViewerInstanceCount();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewWith/explicit-text"),
                  L"cmd/pane/viewWith/<viewerId> should dispatch through the shortcut path.");

    const auto deadline = std::chrono::steady_clock::now() + SelfTest::Scale(5000ms);
    while (std::chrono::steady_clock::now() < deadline &&
           ! (g_folderWindow.DebugGetViewerInstanceCount() == baselineViewerCount + 1u && g_folderWindow.DebugHasViewerPluginId(L"builtin/viewer-text")))
    {
        PumpPendingMessages();
        std::this_thread::sleep_for(20ms);
    }

    state.Require(g_folderWindow.DebugGetViewerInstanceCount() == baselineViewerCount + 1u,
                  L"cmd/pane/viewWith/<viewerId> should open one viewer instance from the named configured action.");
    state.Require(g_folderWindow.DebugHasViewerPluginId(L"builtin/viewer-text"), L"cmd/pane/viewWith/<viewerId> should use the named ViewerText action.");

    return state.failure.empty();
}

[[nodiscard]] bool TestViewWithParameterizedCommandLaunchesExternalViewerAction(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root       = suiteRoot / L"work" / (L"view_with_external_action_" + NewGuidText());
    const std::filesystem::path markerPath = root / L"external-viewer-marker.txt";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create external view-with action test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"gamma.viewext", "external view with"), L"Failed to create external view-with action test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::ExtensionsSettings extensionsBefore     = g_settings.extensions;
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.CloseAllViewers();
        g_settings.extensions          = extensionsBefore;
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition externalViewer{};
    externalViewer.id               = L"External-Marker";
    externalViewer.displayName      = L"External Marker Viewer";
    externalViewer.enabled          = true;
    externalViewer.kind             = Common::Settings::FileActionKind::ExternalProgram;
    externalViewer.executablePath   = ResolveCommandProcessorPath();
    externalViewer.arguments        = L"/C if exist {FullPath} echo external-viewer>external-viewer-marker.txt";
    externalViewer.workingDirectory = L"{Path}";
    TestSetActionExtensions(externalViewer, {L".viewext"});
    g_settings.fileActions.viewers.actions.push_back(std::move(externalViewer));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for external view-with action test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)),
                  L"Failed to set left pane path for external view-with action test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"gamma.viewext"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for external view-with action test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"gamma.viewext"),
                  L"Failed to focus gamma.viewext for external view-with action test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    const size_t baselineViewerCount = g_folderWindow.DebugGetViewerInstanceCount();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/viewWith/external-marker"),
                  L"cmd/pane/viewWith/<viewerId> should dispatch for a named external viewer action.");

    state.Require(g_folderWindow.DebugGetViewerInstanceCount() == baselineViewerCount,
                  L"External cmd/pane/viewWith/<viewerId> should not create an internal viewer instance.");
    std::string markerText;
    state.Require(WaitForTextFileFirstLine(markerPath, "external-viewer", SelfTest::Scale(5000ms), markerText),
                  std::format(L"External viewer action should receive expanded path macros; marker first line was '{}'.",
                              std::wstring(markerText.begin(), markerText.end())));

    return state.failure.empty();
}

[[nodiscard]] bool TestEditWithParameterizedCommandLaunchesExternalEditorAction(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root       = suiteRoot / L"work" / (L"edit_with_external_action_" + NewGuidText());
    const std::filesystem::path markerPath = root / L"external-editor-marker.txt";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create external edit-with action test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"delta.editext", "external edit with"), L"Failed to create external edit-with action test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::EditorFileActionsSettings editorsBefore = g_settings.fileActions.editors;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_settings.fileActions.editors = editorsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.editors = Common::Settings::EditorFileActionsSettings{};
    Common::Settings::FileActionDefinition externalEditor{};
    externalEditor.id               = L"External-Editor";
    externalEditor.displayName      = L"External Marker Editor";
    externalEditor.enabled          = true;
    externalEditor.kind             = Common::Settings::FileActionKind::ExternalProgram;
    externalEditor.executablePath   = ResolveCommandProcessorPath();
    externalEditor.arguments        = L"/C if exist {FullPath} echo external-editor>external-editor-marker.txt";
    externalEditor.workingDirectory = L"{Path}";
    TestSetActionExtensions(externalEditor, {L".editext"});
    g_settings.fileActions.editors.actions.push_back(std::move(externalEditor));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for external edit-with action test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)),
                  L"Failed to set left pane path for external edit-with action test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"delta.editext"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for external edit-with action test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"delta.editext"),
                  L"Failed to focus delta.editext for external edit-with action test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/editWith/external-editor"),
                  L"cmd/pane/editWith/<editorId> should dispatch for a named external editor action.");

    std::string markerText;
    state.Require(WaitForTextFileFirstLine(markerPath, "external-editor", SelfTest::Scale(5000ms), markerText),
                  std::format(L"External editor action should receive expanded path macros; marker first line was '{}'.",
                              std::wstring(markerText.begin(), markerText.end())));

    return state.failure.empty();
}

[[nodiscard]] bool TestEditCommandUsesFocusedPrimaryEditorAction(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root       = suiteRoot / L"work" / (L"edit_primary_action_" + NewGuidText());
    const std::filesystem::path markerPath = root / L"primary-edit-marker.txt";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create primary edit action test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"focused.editcmd", "focused edit"), L"Failed to create focused edit test file.");
    state.Require(SelfTest::WriteTextFile(root / L"selected.editcmd", "selected edit"), L"Failed to create selected edit test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::EditorFileActionsSettings editorsBefore = g_settings.fileActions.editors;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_settings.fileActions.editors = editorsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.editors = Common::Settings::EditorFileActionsSettings{};
    Common::Settings::FileActionDefinition primaryEditor{};
    primaryEditor.id               = L"primary-editor";
    primaryEditor.displayName      = L"Primary Marker Editor";
    primaryEditor.enabled          = true;
    primaryEditor.kind             = Common::Settings::FileActionKind::ExternalProgram;
    primaryEditor.executablePath   = ResolveCommandProcessorPath();
    primaryEditor.arguments        = L"/C if exist \"{SelectedPathsFile}\" echo {Filename}>primary-edit-marker.txt";
    primaryEditor.workingDirectory = L"{Path}";
    TestSetActionExtensions(primaryEditor, {L".editcmd"});
    g_settings.fileActions.editors.actions.push_back(std::move(primaryEditor));
    g_settings.fileActions.editors.associations.push_back(TestEditorAssociation(L".editcmd", L"primary-editor"));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for primary edit action test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for primary edit action test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"focused.editcmd", L"selected.editcmd"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for primary edit action test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"focused.editcmd"),
                  L"Failed to focus focused.editcmd for primary edit action test.");
    g_folderWindow.SetPaneSelectionByDisplayNamePredicate(
        FolderWindow::Pane::Left, [](std::wstring_view name) noexcept { return name == L"selected.editcmd"; }, true);
    state.Require(g_folderWindow.DebugIsItemSelected(FolderWindow::Pane::Left, L"selected.editcmd"),
                  L"Expected selected.editcmd to stay selected for primary edit action test.");
    state.Require(g_folderWindow.DebugGetFocusedItemDisplayName(FolderWindow::Pane::Left) == L"focused.editcmd",
                  L"Expected focused.editcmd to remain focused for primary edit action test.");
    if (! state.failure.empty())
    {
        return false;
    }

    const HWND leftFolderView = g_folderWindow.GetFolderViewHwnd(FolderWindow::Pane::Left);
    state.Require(WaitForFolderViewPaneFocus(FolderWindow::Pane::Left, leftFolderView, SelfTest::Scale(1000ms)),
                  L"Failed to focus the left folder view before primary edit action dispatch.");
    if (! state.failure.empty())
    {
        return false;
    }
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/edit"), L"cmd/pane/edit should dispatch through the shortcut path.");

    std::string markerText;
    state.Require(WaitForTextFileFirstLine(markerPath, "\"focused.editcmd\"", SelfTest::Scale(5000ms), markerText),
                  std::format(L"Primary Edit should expand {{Filename}} from the focused file while preserving argument quoting; actual marker='{}'.",
                              std::wstring(markerText.begin(), markerText.end())));

    return state.failure.empty();
}

[[nodiscard]] bool TestAlternateEditCommandLaunchesConfiguredEditorAction(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root       = suiteRoot / L"work" / (L"edit_alternate_action_" + NewGuidText());
    const std::filesystem::path markerPath = root / L"alternate-edit-marker.txt";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create alternate edit action test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"iota.altedit", "alternate edit"), L"Failed to create alternate edit test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::EditorFileActionsSettings editorsBefore = g_settings.fileActions.editors;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_settings.fileActions.editors = editorsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.editors = Common::Settings::EditorFileActionsSettings{};
    Common::Settings::FileActionDefinition alternateEditor{};
    alternateEditor.id               = L"alternate-editor";
    alternateEditor.displayName      = L"Alternate Marker Editor";
    alternateEditor.enabled          = true;
    alternateEditor.kind             = Common::Settings::FileActionKind::ExternalProgram;
    alternateEditor.executablePath   = ResolveCommandProcessorPath();
    alternateEditor.arguments        = L"/C if exist {FullPath} echo alternate-edit>alternate-edit-marker.txt";
    alternateEditor.workingDirectory = L"{Path}";
    TestSetActionExtensions(alternateEditor, {L".altedit"});
    g_settings.fileActions.editors.actions.push_back(std::move(alternateEditor));
    g_settings.fileActions.editors.associations.push_back(TestDefaultEditorAssociation({}, L"alternate-editor"));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for alternate edit action test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for alternate edit action test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"iota.altedit"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for alternate edit action test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"iota.altedit"),
                  L"Failed to focus iota.altedit for alternate edit action test.");
    if (! state.failure.empty())
    {
        return false;
    }

    const HWND leftFolderView = g_folderWindow.GetFolderViewHwnd(FolderWindow::Pane::Left);
    state.Require(WaitForFolderViewPaneFocus(FolderWindow::Pane::Left, leftFolderView, SelfTest::Scale(1000ms)),
                  L"Failed to focus the left folder view before alternate edit action dispatch.");
    if (! state.failure.empty())
    {
        return false;
    }
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/alternateEdit"), L"cmd/pane/alternateEdit should dispatch through the shortcut path.");

    std::string markerText;
    state.Require(
        WaitForTextFileFirstLine(markerPath, "alternate-edit", SelfTest::Scale(5000ms), markerText),
        std::format(L"Alternate Edit should receive expanded macros; marker first line was '{}'.", std::wstring(markerText.begin(), markerText.end())));

    return state.failure.empty();
}

[[nodiscard]] bool TestEditWithMenuPopulatesApplicableEditorActions(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root       = suiteRoot / L"work" / (L"edit_with_menu_" + NewGuidText());
    const std::filesystem::path markerPath = root / L"edit-with-menu-marker.txt";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create Edit With menu test folder.");
    state.Require(SelfTest::WriteTextFile(root / L"zeta.menuedit", "edit with menu"), L"Failed to create Edit With menu test file.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::EditorFileActionsSettings editorsBefore = g_settings.fileActions.editors;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_settings.fileActions.editors = editorsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.editors = Common::Settings::EditorFileActionsSettings{};

    Common::Settings::FileActionDefinition menuEditor{};
    menuEditor.id               = L"menu-editor";
    menuEditor.displayName      = L"Menu Marker Editor";
    menuEditor.enabled          = true;
    menuEditor.kind             = Common::Settings::FileActionKind::ExternalProgram;
    menuEditor.executablePath   = ResolveCommandProcessorPath();
    menuEditor.arguments        = L"/C if exist {FullPath} echo edit-with-menu>edit-with-menu-marker.txt";
    menuEditor.workingDirectory = L"{Path}";
    TestSetActionExtensions(menuEditor, {L".menuedit"});
    g_settings.fileActions.editors.actions.push_back(std::move(menuEditor));

    Common::Settings::FileActionDefinition filteredEditor{};
    filteredEditor.id               = L"filtered-editor";
    filteredEditor.displayName      = L"Filtered Marker Editor";
    filteredEditor.enabled          = true;
    filteredEditor.kind             = Common::Settings::FileActionKind::ExternalProgram;
    filteredEditor.executablePath   = ResolveCommandProcessorPath();
    filteredEditor.arguments        = L"/C echo filtered>filtered-editor.txt";
    filteredEditor.workingDirectory = L"{Path}";
    TestSetActionExtensions(filteredEditor, {L".otheredit"});
    g_settings.fileActions.editors.actions.push_back(std::move(filteredEditor));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for Edit With menu test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for Edit With menu test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"zeta.menuedit"}, SelfTest::Scale(3000ms)), L"Pane contents not ready for Edit With menu test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"zeta.menuedit"),
                  L"Failed to focus zeta.menuedit for Edit With menu test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);

    const HMENU mainMenu     = DebugGetMainMenuModelHandle();
    const HMENU editWithMenu = FindSubMenuByTextFragment(mainMenu, L"Ed&it With");
    state.Require(editWithMenu != nullptr, L"Edit With menu should exist in the main menu model.");
    if (! editWithMenu)
    {
        return false;
    }

    SendMessageW(mainWindow, WM_INITMENUPOPUP, reinterpret_cast<WPARAM>(editWithMenu), 0);
    const int itemCount = GetMenuItemCount(editWithMenu);
    state.Require(itemCount == 1, L"Edit With menu should contain only applicable editor actions for the focused file.");
    if (itemCount != 1)
    {
        return false;
    }

    const UINT commandId        = GetMenuItemID(editWithMenu, 0);
    const std::wstring menuText = GetMenuItemTextByPosition(editWithMenu, 0);
    state.Require(commandId == IDM_PANE_EDIT_WITH_BASE, L"First Edit With action should use the dynamic Edit With command-id range.");
    state.Require(menuText.find(L"Menu Marker Editor") != std::wstring::npos, L"Edit With menu should display the configured action name.");
    state.Require(menuText.find(L"Filtered Marker Editor") == std::wstring::npos, L"Edit With menu should not display extension-mismatched actions.");
    if (! state.failure.empty())
    {
        return false;
    }

    SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(commandId, 0), 0);

    std::string markerText;
    state.Require(WaitForTextFileFirstLine(markerPath, "edit-with-menu", SelfTest::Scale(5000ms), markerText),
                  std::format(L"Edit With menu action should receive expanded path macros; marker first line was '{}'.",
                              std::wstring(markerText.begin(), markerText.end())));

    return state.failure.empty();
}

[[nodiscard]] bool TestUserMenuPopulatesAndDispatchesConfiguredActions(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root       = suiteRoot / L"work" / (L"user_menu_dispatch_" + NewGuidText());
    const std::filesystem::path focused    = root / L"alpha.usermenu";
    const std::filesystem::path markerPath = root / L"user-menu-marker.txt";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create User Menu dispatch test folder.");
    state.Require(SelfTest::WriteTextFile(focused, "user menu"), L"Failed to create User Menu dispatch fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                     = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore   = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::UserMenuSettings userMenuBefore = g_settings.userMenu;
    const auto restoreState                                 = wil::scope_exit([&]
    {
        g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
        g_settings.userMenu = userMenuBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.userMenu = Common::Settings::UserMenuSettings{};

    Common::Settings::FileActionDefinition markerAction{};
    markerAction.id               = L"marker";
    markerAction.displayName      = L"Marker User Menu";
    markerAction.enabled          = true;
    markerAction.kind             = Common::Settings::FileActionKind::ExternalProgram;
    markerAction.executablePath   = ResolveSiblingExecutablePath(L"RedSalamanderSearchService.exe");
    markerAction.arguments        = L"--test-support-child-probe=file-action-lease \"{SelectedPathsFile}\" \"user-menu-marker.txt\" 0 0";
    markerAction.workingDirectory = L"{Path}";
    TestSetActionExtensions(markerAction, {L".usermenu"});
    g_settings.userMenu.actions.push_back(std::move(markerAction));

    Common::Settings::FileActionDefinition filteredAction{};
    filteredAction.id               = L"filtered";
    filteredAction.displayName      = L"Filtered User Menu";
    filteredAction.enabled          = true;
    filteredAction.kind             = Common::Settings::FileActionKind::ExternalProgram;
    filteredAction.executablePath   = ResolveCommandProcessorPath();
    filteredAction.arguments        = L"/C echo filtered";
    filteredAction.workingDirectory = L"{Path}";
    TestSetActionExtensions(filteredAction, {L".othermenu"});
    g_settings.userMenu.actions.push_back(std::move(filteredAction));

    Common::Settings::FileActionDefinition missingAction{};
    missingAction.id               = L"missing-tool";
    missingAction.displayName      = L"Missing Tool";
    missingAction.enabled          = true;
    missingAction.kind             = Common::Settings::FileActionKind::ExternalProgram;
    missingAction.executablePath   = (root / L"tool-that-does-not-exist.exe").wstring();
    missingAction.arguments        = L"{FullPath}";
    missingAction.workingDirectory = L"{Path}";
    TestSetActionExtensions(missingAction, {L".usermenu"});
    g_settings.userMenu.actions.push_back(std::move(missingAction));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for User Menu dispatch test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for User Menu dispatch test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"alpha.usermenu"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for User Menu dispatch test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"alpha.usermenu"),
                  L"Failed to focus alpha.usermenu for User Menu dispatch test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);

    const std::vector<FolderWindow::UserMenuItem> directItems = g_folderWindow.CollectUserMenuItems(FolderWindow::Pane::Left);
    std::wstring directItemIds;
    for (const FolderWindow::UserMenuItem& item : directItems)
    {
        if (! directItemIds.empty())
        {
            directItemIds.append(L",");
        }
        directItemIds.append(item.id);
        directItemIds.push_back(item.enabled ? L'+' : L'-');
    }
    state.Require(
        directItems.size() == 2u,
        std::format(L"User Menu collection should expose two applicable actions before popup rebuild; got {} ({})", directItems.size(), directItemIds));
    if (! state.failure.empty())
    {
        return false;
    }

    const HMENU mainMenu = DebugGetMainMenuModelHandle();
    const HMENU userMenu = FindSubMenuByTextFragment(mainMenu, L"&User Menu");
    state.Require(userMenu != nullptr, L"User Menu popup should exist in the main menu model.");
    if (! userMenu)
    {
        return false;
    }

    SendMessageW(mainWindow, WM_INITMENUPOPUP, reinterpret_cast<WPARAM>(userMenu), 0);
    const int itemCount = GetMenuItemCount(userMenu);
    state.Require(itemCount == 2, L"User Menu should contain the applicable item and disabled missing-executable item.");
    if (itemCount != 2)
    {
        return false;
    }

    const UINT launchCommandId     = GetMenuItemID(userMenu, 0);
    const UINT missingCommandId    = GetMenuItemID(userMenu, 1);
    const std::wstring launchText  = GetMenuItemTextByPosition(userMenu, 0);
    const std::wstring missingText = GetMenuItemTextByPosition(userMenu, 1);
    state.Require(launchCommandId == IDM_PANE_USER_MENU_BASE, L"First User Menu action should use the dynamic User Menu command-id range.");
    state.Require(missingCommandId == IDM_PANE_USER_MENU_BASE + 1u, L"Second User Menu action should use the next dynamic User Menu command id.");
    state.Require(launchText.find(L"Marker User Menu") != std::wstring::npos, L"User Menu should display the configured action name.");
    state.Require(missingText.find(L"Missing Tool") != std::wstring::npos, L"User Menu should display missing executable entries as disabled items.");
    state.Require((GetMenuState(userMenu, launchCommandId, MF_BYCOMMAND) & MF_GRAYED) == 0u, L"Available User Menu item should be enabled.");
    state.Require((GetMenuState(userMenu, missingCommandId, MF_BYCOMMAND) & MF_GRAYED) != 0u, L"Missing executable User Menu item should be disabled.");
    state.Require(launchText.find(L"Filtered User Menu") == std::wstring::npos, L"User Menu should not display extension-mismatched actions.");
    if (! state.failure.empty())
    {
        return false;
    }

    SendMessageW(mainWindow, WM_COMMAND, MAKEWPARAM(launchCommandId, 0), 0);

    std::string markerText;
    state.Require(WaitForTextFileFirstLine(markerPath, "parsed:1", SelfTest::Scale(5000ms), markerText),
                  std::format(L"User Menu action should launch a child that parses its selected-path manifest; marker first line was '{}'.",
                              std::wstring(markerText.begin(), markerText.end())));

    return state.failure.empty();
}

[[nodiscard]] bool TestFileActionProviderRecordRejectedInCommandRoute(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root        = suiteRoot / L"work" / (L"file_action_invalid_provider_record_" + NewGuidText());
    const std::filesystem::path focused     = root / L"focused.badrecord";
    const std::filesystem::path childMarker = root / L"invalid-provider-child-marker.txt";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create invalid provider-record command-route folder.");
    state.Require(SelfTest::WriteTextFile(focused, "provider record"), L"Failed to create invalid provider-record focused item.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                             = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore           = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::ViewerFileActionsSettings viewersBefore = g_settings.fileActions.viewers;
    const auto restoreState                                         = wil::scope_exit([&]
    {
        g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
        g_settings.fileActions.viewers = viewersBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition action{};
    action.id               = L"invalid-provider-record";
    action.displayName      = L"Invalid Provider Record Viewer";
    action.enabled          = true;
    action.kind             = Common::Settings::FileActionKind::ExternalProgram;
    action.executablePath   = ResolveSiblingExecutablePath(L"RedSalamanderSearchService.exe");
    action.arguments        = L"--test-support-child-probe=file-action-lease \"{SelectedPathsFile}\" \"invalid-provider-child-marker.txt\" 0 0";
    action.workingDirectory = L"{Path}";
    TestSetActionExtensions(action, {L".badrecord"});
    g_settings.fileActions.viewers.actions.push_back(std::move(action));
    g_settings.fileActions.viewers.associations.push_back(TestViewerAssociation(L".badrecord", L"invalid-provider-record"));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for invalid provider-record command-route test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)),
                  L"Failed to set left pane path for invalid provider-record command-route test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"focused.badrecord"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for invalid provider-record command-route test.");
    if (! state.failure.empty())
    {
        return false;
    }

    std::wstring invalidProviderPath = (root / L"provider-record").native();
    invalidProviderPath.append(L"\r\ninjected-record.txt");
    std::vector<std::filesystem::path> selectedPaths{std::filesystem::path(invalidProviderPath)};
    std::vector<std::filesystem::path> displayedPaths{focused};

    g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
    const bool launched = g_folderWindow.TryLaunchResolvedFileAction(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left),
                                                                     g_folderWindow.GetFileSystemInstanceContext(FolderWindow::Pane::Left),
                                                                     focused,
                                                                     std::move(selectedPaths),
                                                                     std::move(displayedPaths),
                                                                     IDM_PANE_VIEW,
                                                                     mainWindow);
    PumpPendingMessages();

    FolderView::AlertOverlayDebugSnapshot alert{};
    state.Require(! launched, L"A provider-supplied CRLF record must be rejected by the real file-action command route.");
    state.Require(g_folderWindow.DebugGetPaneAlertSnapshot(FolderWindow::Pane::Left, alert) && alert.visible,
                  L"Rejected provider records must surface the localized file-action failure overlay.");
    state.Require(alert.severity == FolderView::OverlaySeverity::Warning, L"Rejected provider records must use the file-action launch-failure severity.");
    const std::wstring expectedError = std::format(L"0x{:08X}", static_cast<uint32_t>(HRESULT_FROM_WIN32(ERROR_INVALID_DATA)));
    state.Require(alert.message.find(expectedError) != std::wstring::npos,
                  L"The localized command-route failure must preserve the precise invalid-record HRESULT.");
    state.Require(! std::filesystem::exists(childMarker, ec) && ! ec, L"Rejected provider records must not launch the representative child process.");

    return state.failure.empty();
}

[[nodiscard]] bool TestUserMenuParameterizedCommandReportsUnavailable(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path root    = suiteRoot / L"work" / (L"user_menu_unavailable_" + NewGuidText());
    const std::filesystem::path focused = root / L"disabled.usermenu";
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    state.Require(SelfTest::EnsureDirectory(root), L"Failed to create User Menu unavailable test folder.");
    state.Require(SelfTest::WriteTextFile(focused, "disabled user menu"), L"Failed to create User Menu unavailable fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    const std::wstring leftPluginBefore                     = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::optional<std::filesystem::path> leftBefore   = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const Common::Settings::UserMenuSettings userMenuBefore = g_settings.userMenu;
    const auto restoreState                                 = wil::scope_exit([&]
    {
        g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
        g_settings.userMenu = userMenuBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
    });

    g_settings.userMenu = Common::Settings::UserMenuSettings{};
    Common::Settings::FileActionDefinition disabledAction{};
    disabledAction.id               = L"Disabled-User-Menu";
    disabledAction.displayName      = L"Disabled User Menu";
    disabledAction.enabled          = false;
    disabledAction.kind             = Common::Settings::FileActionKind::ExternalProgram;
    disabledAction.executablePath   = ResolveCommandProcessorPath();
    disabledAction.arguments        = L"/C exit /B 0";
    disabledAction.workingDirectory = L"{Path}";
    TestSetActionExtensions(disabledAction, {L".usermenu"});
    g_settings.userMenu.actions.push_back(std::move(disabledAction));

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set local file-system plugin for User Menu unavailable test.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, root);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, root, SelfTest::Scale(3000ms)), L"Failed to set left pane path for User Menu unavailable test.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"disabled.usermenu"}, SelfTest::Scale(3000ms)),
                  L"Pane contents not ready for User Menu unavailable test.");
    state.Require(g_folderWindow.DebugFocusItemByDisplayName(FolderWindow::Pane::Left, L"disabled.usermenu"),
                  L"Failed to focus disabled.usermenu for User Menu unavailable test.");
    if (! state.failure.empty())
    {
        return false;
    }

    FocusFolderViewPane(FolderWindow::Pane::Left);
    g_folderWindow.DismissPaneAlertOverlay(FolderWindow::Pane::Left);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/pane/userMenu/disabled-user-menu"),
                  L"cmd/pane/userMenu/<itemId> should dispatch through the shortcut path.");
    PumpPendingMessages();

    FolderView::AlertOverlayDebugSnapshot alert{};
    state.Require(g_folderWindow.DebugGetPaneAlertSnapshot(FolderWindow::Pane::Left, alert), L"Pane alert snapshot should be available.");
    state.Require(alert.visible, L"Disabled User Menu action should show a pane alert.");
    state.Require(alert.severity == FolderView::OverlaySeverity::Warning, L"Disabled User Menu action should report a warning.");
    state.Require(alert.title == LoadStringResource(nullptr, IDS_USER_MENU_UNAVAILABLE_TITLE),
                  L"Disabled User Menu action should use the localized unavailable title.");
    state.Require(alert.message.find(L"Disabled-User-Menu") != std::wstring::npos, L"Disabled User Menu alert should name the unavailable action id.");
    state.Require(alert.message.find(L"disabled.usermenu") != std::wstring::npos, L"Disabled User Menu alert should name the focused file.");

    return state.failure.empty();
}

[[nodiscard]] bool TestRereadAssociationsReloadsActionsAndRefreshesPanes(HWND mainWindow, CaseState& state) noexcept
{
    using namespace std::chrono_literals;

    if (! mainWindow || IsWindow(mainWindow) == FALSE)
    {
        state.Require(false, L"Main window handle invalid.");
        return false;
    }

    const std::filesystem::path suiteRoot = SelfTest::GetTempRoot(SelfTest::SelfTestSuite::Commands);
    state.Require(! suiteRoot.empty(), L"SelfTest temp root unavailable.");
    if (suiteRoot.empty())
    {
        return false;
    }

    const std::filesystem::path leftRoot  = suiteRoot / L"work" / (L"reread_associations_left_" + NewGuidText());
    const std::filesystem::path rightRoot = suiteRoot / L"work" / (L"reread_associations_right_" + NewGuidText());
    std::error_code ec;
    std::filesystem::remove_all(leftRoot, ec);
    ec.clear();
    std::filesystem::remove_all(rightRoot, ec);
    state.Require(SelfTest::EnsureDirectory(leftRoot), L"Failed to create Reread Associations left folder.");
    state.Require(SelfTest::EnsureDirectory(rightRoot), L"Failed to create Reread Associations right folder.");
    state.Require(SelfTest::WriteTextFile(leftRoot / L"alpha.reread", "reread left"), L"Failed to create Reread Associations left fixture.");
    state.Require(SelfTest::WriteTextFile(rightRoot / L"beta.reread", "reread right"), L"Failed to create Reread Associations right fixture.");
    if (! state.failure.empty())
    {
        return false;
    }

    const Common::Settings::Settings settingsBefore        = g_settings;
    const FolderWindow::Pane activePaneBefore              = g_folderWindow.GetActivePane();
    const std::wstring leftPluginBefore                    = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Left));
    const std::wstring rightPluginBefore                   = std::wstring(g_folderWindow.GetFileSystemPluginId(FolderWindow::Pane::Right));
    const std::optional<std::filesystem::path> leftBefore  = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Left);
    const std::optional<std::filesystem::path> rightBefore = g_folderWindow.GetCurrentPath(FolderWindow::Pane::Right);
    const auto restoreState                                = wil::scope_exit([&]
    {
        DebugSetRereadAssociationsSettingsForTest(nullptr);
        DebugResetRereadAssociationsSnapshot();
        g_settings = settingsBefore;
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, leftPluginBefore));
        static_cast<void>(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, rightPluginBefore));
        if (leftBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftBefore.value());
        }
        if (rightBefore.has_value())
        {
            g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightBefore.value());
        }
        g_folderWindow.SetActivePane(activePaneBefore);
    });

    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Left, L"builtin/file-system")),
                  L"Failed to set left pane to the local file system for Reread Associations.");
    state.Require(SUCCEEDED(g_folderWindow.SetFileSystemPluginForPane(FolderWindow::Pane::Right, L"builtin/file-system")),
                  L"Failed to set right pane to the local file system for Reread Associations.");
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, leftRoot);
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Right, rightRoot);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, leftRoot, SelfTest::Scale(3000ms)), L"Failed to set left pane path for Reread Associations.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Right, rightRoot, SelfTest::Scale(3000ms)), L"Failed to set right pane path for Reread Associations.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"alpha.reread"}, SelfTest::Scale(3000ms)),
                  L"Left pane contents not ready for Reread Associations.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Right, {L"beta.reread"}, SelfTest::Scale(3000ms)),
                  L"Right pane contents not ready for Reread Associations.");
    if (! state.failure.empty())
    {
        return false;
    }

    Common::Settings::Settings diskSettings = g_settings;
    diskSettings.extensions.openWithFileSystemByExtension.clear();
    diskSettings.extensions.openWithFileSystemByExtension[L".archive"] = L"builtin/file-system-7z";

    diskSettings.fileActions.viewers = Common::Settings::ViewerFileActionsSettings{};
    Common::Settings::FileActionDefinition viewerAction{};
    viewerAction.id          = L"reread-viewer";
    viewerAction.displayName = L"Reread Viewer";
    viewerAction.enabled     = true;
    viewerAction.kind        = Common::Settings::FileActionKind::ViewerPlugin;
    viewerAction.pluginId    = L"builtin/viewer-text";
    TestSetActionExtensions(viewerAction, {L".reread"});
    diskSettings.fileActions.viewers.actions.push_back(std::move(viewerAction));
    diskSettings.fileActions.viewers.associations.push_back(TestViewerAssociation(L".reread", L"reread-viewer", L"reread-viewer"));

    diskSettings.fileActions.editors = Common::Settings::EditorFileActionsSettings{};
    Common::Settings::FileActionDefinition editorAction{};
    editorAction.id               = L"reread-editor";
    editorAction.displayName      = L"Reread Editor";
    editorAction.enabled          = true;
    editorAction.kind             = Common::Settings::FileActionKind::ExternalProgram;
    editorAction.executablePath   = ResolveCommandProcessorPath();
    editorAction.arguments        = L"/C exit /B 0";
    editorAction.workingDirectory = L"{Path}";
    TestSetActionExtensions(editorAction, {L".reread"});
    diskSettings.fileActions.editors.actions.push_back(std::move(editorAction));
    diskSettings.fileActions.editors.associations.push_back(TestEditorAssociation(L".reread", L"reread-editor", L"reread-editor", L"reread-editor"));

    diskSettings.userMenu = Common::Settings::UserMenuSettings{};
    Common::Settings::FileActionDefinition userMenuAction{};
    userMenuAction.id               = L"reread-user-menu";
    userMenuAction.displayName      = L"Reread User Menu";
    userMenuAction.enabled          = true;
    userMenuAction.kind             = Common::Settings::FileActionKind::ExternalProgram;
    userMenuAction.executablePath   = ResolveCommandProcessorPath();
    userMenuAction.arguments        = L"/C exit /B 0";
    userMenuAction.workingDirectory = L"{Path}";
    TestSetActionExtensions(userMenuAction, {L".reread"});
    diskSettings.userMenu.actions.push_back(std::move(userMenuAction));

    Common::Settings::FoldersSettings diskFolders{};
    diskFolders.active = L"right";
    diskFolders.items.push_back(Common::Settings::FolderPane{.slot = L"left", .current = std::filesystem::path(L"C:\\disk-reread-left")});
    diskFolders.items.push_back(Common::Settings::FolderPane{.slot = L"right", .current = std::filesystem::path(L"C:\\disk-reread-right")});
    diskSettings.folders = std::move(diskFolders);

    static_cast<void>(IconCache::GetInstance().GetOrQueryIconIndexByExtension(L".reread", FILE_ATTRIBUTE_NORMAL));
    const size_t associationCacheBefore = DebugGetAssociationIconCacheSize();
    state.Require(associationCacheBefore > 0u, L"Reread Associations test should seed the association icon cache.");

    const uint64_t leftRefreshBefore  = g_folderWindow.DebugGetForceRefreshCount(FolderWindow::Pane::Left);
    const uint64_t rightRefreshBefore = g_folderWindow.DebugGetForceRefreshCount(FolderWindow::Pane::Right);

    DebugResetRereadAssociationsSnapshot();
    DebugSetRereadAssociationsSettingsForTest(&diskSettings);
    g_folderWindow.SetActivePane(FolderWindow::Pane::Left);
    FocusFolderViewPane(FolderWindow::Pane::Left);

    const auto started = std::chrono::steady_clock::now();
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/app/rereadAssociations"),
                  L"cmd/app/rereadAssociations should dispatch through the command path.");
    PumpPendingMessages();
    const auto totalUs = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - started);

    RereadAssociationsDebugSnapshot snapshot{};
    if (! DebugGetRereadAssociationsSnapshot(snapshot))
    {
        state.Require(false, L"cmd/app/rereadAssociations should record a debug snapshot.");
        return false;
    }

    state.Require(snapshot.attempted, L"Reread Associations should attempt the reload.");
    state.Require(snapshot.loaded && SUCCEEDED(snapshot.hr), L"Reread Associations should load the disk settings.");
    state.Require(snapshot.viewerActionCount == 1u, L"Reread Associations should load viewer actions.");
    state.Require(snapshot.editorActionCount == 1u, L"Reread Associations should load editor actions.");
    state.Require(snapshot.userMenuActionCount == 1u, L"Reread Associations should load User Menu actions.");
    state.Require(snapshot.viewerExtensionMappingCount == 1u, L"Reread Associations should load viewer extension mappings.");
    state.Require(snapshot.fileSystemExtensionMappingCount == 1u, L"Reread Associations should load file-system extension mappings.");
    state.Require(snapshot.associationIconCacheSizeBefore >= associationCacheBefore,
                  std::format(L"Reread Associations should observe the seeded icon association cache (seeded={}, observedBefore={}).",
                              associationCacheBefore,
                              snapshot.associationIconCacheSizeBefore));
    state.Require(snapshot.associationIconCacheSizeAfterClear == 0u,
                  std::format(L"Reread Associations should clear the icon association cache before pane refresh can repopulate it (before={}, afterClear={}).",
                              snapshot.associationIconCacheSizeBefore,
                              snapshot.associationIconCacheSizeAfterClear));
    state.Require(snapshot.leftRefreshCountBefore == leftRefreshBefore && snapshot.leftRefreshCountAfter > leftRefreshBefore,
                  L"Reread Associations should refresh the left pane.");
    state.Require(snapshot.rightRefreshCountBefore == rightRefreshBefore && snapshot.rightRefreshCountAfter > rightRefreshBefore,
                  L"Reread Associations should refresh the right pane.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, leftRoot, SelfTest::Scale(3000ms)) &&
                      WaitForPaneItems(FolderWindow::Pane::Left, {L"alpha.reread"}, SelfTest::Scale(3000ms)),
                  L"Plugin refresh should restore and re-enumerate the left pane instead of leaving its model empty.");
    state.Require(WaitForPanePath(FolderWindow::Pane::Right, rightRoot, SelfTest::Scale(3000ms)) &&
                      WaitForPaneItems(FolderWindow::Pane::Right, {L"beta.reread"}, SelfTest::Scale(3000ms)),
                  L"Plugin refresh should restore and re-enumerate the right pane instead of leaving its model empty.");
    state.Require(snapshot.dynamicFileActionMenusRebuilt, L"Reread Associations should rebuild dynamic View With and Edit With menus.");
    state.Require(snapshot.userMenuRebuilt, L"Reread Associations should rebuild the User Menu dynamic entries.");
    state.Require(snapshot.pluginsRefreshed, L"Reread Associations should refresh running plugin managers.");
    state.Require(snapshot.runtimeFoldersPreserved, L"Reread Associations should preserve live folder state over disk folder state.");

    const auto viewerMappingIt = std::find_if(g_settings.fileActions.viewers.associations.begin(),
                                              g_settings.fileActions.viewers.associations.end(),
                                              [](const Common::Settings::ViewerAssociationRule& rule) noexcept
    { return rule.match.kind == Common::Settings::FileActionMatchKind::Extension && rule.match.value == L".reread" && rule.viewActionId == L"reread-viewer"; });
    state.Require(viewerMappingIt != g_settings.fileActions.viewers.associations.end(),
                  L"Reread Associations should apply viewer extension associations from disk settings.");
    const auto fsMappingIt = g_settings.extensions.openWithFileSystemByExtension.find(L".archive");
    state.Require(fsMappingIt != g_settings.extensions.openWithFileSystemByExtension.end() && fsMappingIt->second == L"builtin/file-system-7z",
                  L"Reread Associations should apply file-system extension mappings from disk settings.");
    state.Require(g_settings.fileActions.viewers.actions.size() == 1u && g_settings.fileActions.viewers.actions.front().id == L"reread-viewer",
                  L"Reread Associations should apply viewer actions from disk settings.");
    state.Require(g_settings.fileActions.editors.actions.size() == 1u && g_settings.fileActions.editors.actions.front().id == L"reread-editor",
                  L"Reread Associations should apply editor actions from disk settings.");
    state.Require(g_settings.userMenu.actions.size() == 1u && g_settings.userMenu.actions.front().id == L"reread-user-menu",
                  L"Reread Associations should apply User Menu actions from disk settings.");

    const auto settingsContainPanePath =
        [](const std::optional<Common::Settings::FoldersSettings>& folders, std::wstring_view slot, const std::filesystem::path& expected) noexcept
    {
        if (! folders.has_value())
        {
            return false;
        }

        for (const Common::Settings::FolderPane& pane : folders->items)
        {
            if (pane.slot == slot && pane.current == expected)
            {
                return true;
            }
        }
        return false;
    };
    state.Require(settingsContainPanePath(g_settings.folders, L"left", leftRoot), L"Reread Associations should keep the live left pane path.");
    state.Require(settingsContainPanePath(g_settings.folders, L"right", rightRoot), L"Reread Associations should keep the live right pane path.");

    // Repeat provider refresh with a qualified archive location. Local paths cannot detect the
    // double-qualification regression because their display path and provider path are identical.
    constexpr std::wstring_view kArchivePluginId = L"builtin/file-system-7z";
    const std::filesystem::path archivePath      = leftRoot / L"provider-refresh.zip";
    state.Require(WriteStoredZipFixtureForCommandSelfTest(archivePath, "context-entry.txt", 0x0800u, "provider refresh"),
                  L"Failed to create the qualified-provider Reread Associations fixture.");
    state.Require(SUCCEEDED(FileSystemPluginManager::GetInstance().EnablePlugin(kArchivePluginId.data(), g_settings)),
                  L"Failed to enable the archive provider for qualified-path refresh coverage.");
    state.Require(SUCCEEDED(FileSystemPluginManager::GetInstance().EnablePlugin(kArchivePluginId.data(), diskSettings)),
                  L"Failed to keep the archive provider enabled in reread disk settings.");

    const std::filesystem::path archivePluginPath  = L"/";
    const std::filesystem::path archiveDisplayPath = NavigationLocation::FormatHistoryPath(L"7z", archivePath.wstring(), archivePluginPath);
    g_folderWindow.SetFolderPath(FolderWindow::Pane::Left, archiveDisplayPath);
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, archiveDisplayPath, SelfTest::Scale(3000ms)),
                  L"Failed to enter the qualified archive-provider location before plugin refresh.");
    state.Require(WaitForPaneItems(FolderWindow::Pane::Left, {L"context-entry.txt"}, SelfTest::Scale(3000ms)),
                  L"Archive-provider contents were not enumerated before plugin refresh.");
    state.Require(g_folderWindow.GetCurrentPluginPath(FolderWindow::Pane::Left) == archivePluginPath,
                  L"Qualified archive setup should expose only the raw provider path to FolderView.");
    state.Require(g_folderWindow.GetFileSystemInstanceContext(FolderWindow::Pane::Left) == archivePath.wstring(),
                  L"Qualified archive setup should retain the nonempty provider instance context.");

    DebugResetRereadAssociationsSnapshot();
    DebugSetRereadAssociationsSettingsForTest(&diskSettings);
    state.Require(DebugDispatchShortcutCommand(mainWindow, L"cmd/app/rereadAssociations"),
                  L"Qualified-provider Reread Associations should dispatch through the command path.");
    PumpPendingMessages();
    state.Require(WaitForPanePath(FolderWindow::Pane::Left, archiveDisplayPath, SelfTest::Scale(3000ms)) &&
                      WaitForPaneItems(FolderWindow::Pane::Left, {L"context-entry.txt"}, SelfTest::Scale(3000ms)),
                  L"Plugin refresh should restore and re-enumerate the qualified archive location exactly once.");
    state.Require(g_folderWindow.GetCurrentPluginPath(FolderWindow::Pane::Left) == archivePluginPath,
                  L"Plugin refresh double-qualified the raw archive-provider path.");
    state.Require(g_folderWindow.GetFileSystemInstanceContext(FolderWindow::Pane::Left) == archivePath.wstring(),
                  L"Plugin refresh did not restore the archive-provider instance context.");

    const std::wstring perfArtifactText      = std::format(L"{{\n"
                                                           L"  \"scenario\": \"cmd/app/rereadAssociations\",\n"
                                                           L"  \"rereadAssociations.total_us\": {},\n"
                                                           L"  \"associationIconCacheSizeBefore\": {},\n"
                                                           L"  \"associationIconCacheSizeAfterClear\": {},\n"
                                                           L"  \"viewerActionCount\": {},\n"
                                                           L"  \"editorActionCount\": {},\n"
                                                           L"  \"userMenuActionCount\": {}\n"
                                                           L"}}\n",
                                                           totalUs.count(),
                                                           snapshot.associationIconCacheSizeBefore,
                                                           snapshot.associationIconCacheSizeAfterClear,
                                                           snapshot.viewerActionCount,
                                                           snapshot.editorActionCount,
                                                           snapshot.userMenuActionCount);
    const std::filesystem::path artifactPath = SelfTest::GetPerfArtifactPath(L"reread_associations_metrics.json");
    const bool artifactWriteOk               = ! artifactPath.empty() && SelfTest::WriteTextFile(artifactPath, perfArtifactText);
    state.Require(artifactWriteOk && SelfTest::PathExists(artifactPath), L"Failed to write Reread Associations perf artifact.");

    return state.failure.empty();
}

} // namespace (tests)

void RunSettingsCommandsSelfTestCases(HWND mainWindow, const SelfTest::SelfTestOptions& options, SelfTest::SelfTestSuiteResult& suite) noexcept
{
    SelfTest::RunCase(options, suite, L"cmd_app_session_end_persists_runtime_state_without_teardown", [=](CaseState& state) noexcept {
        return TestAppSessionEndPersistsRuntimeStateWithoutTeardown(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"settings_hot_reload_merge_runtime_session", [](CaseState& state) noexcept {
        return TestSettingsHotReloadMergePreservesRuntimeSession(state);
    });
    SelfTest::RunCase(options, suite, L"settings_hot_reload_merge_disk_preferences", [](CaseState& state) noexcept {
        return TestSettingsHotReloadMergeKeepsDiskPreferences(state);
    });
    SelfTest::RunCase(
        options, suite, L"settings_store_no_recovery_and_file_stamp", [](CaseState& state) noexcept { return TestSettingsStoreNoRecoveryAndFileStamp(state); });
    SelfTest::RunCase(options, suite, L"settings_store_grid_layout_parsing_parity", [](CaseState& state) noexcept {
        return TestSettingsStoreGridLayoutParsingParity(state);
    });
    SelfTest::RunCase(options, suite, L"settings_store_search_roundtrip", [](CaseState& state) noexcept { return TestSettingsStoreSearchRoundTrip(state); });
    SelfTest::RunCase(
        options, suite, L"settings_store_batch_rename_roundtrip", [](CaseState& state) noexcept { return TestSettingsStoreBatchRenameRoundTrip(state); });
    SelfTest::RunCase(options, suite, L"settings_store_file_actions_v16_roundtrip", [](CaseState& state) noexcept {
        return TestSettingsStoreFileActionsV16RoundTrip(state);
    });
    SelfTest::RunCase(options, suite, L"settings_store_file_actions_v16_disables_relative_executables", [](CaseState& state) noexcept {
        return TestSettingsStoreFileActionsV16DisablesRelativeExecutables(state);
    });
    SelfTest::RunCase(options, suite, L"settings_store_file_actions_v16_rejects_legacy_shape", [](CaseState& state) noexcept {
        return TestSettingsStoreFileActionsV16RejectsLegacyShape(state);
    });
    SelfTest::RunCase(options, suite, L"settings_store_unsupported_schema_backup_recovery", [](CaseState& state) noexcept {
        return TestSettingsStoreLoadSettingsReportsUnsupportedSchemaBackup(state);
    });
    SelfTest::RunCase(options, suite, L"settings_store_invalid_file_actions_preserves_unrelated_sections", [](CaseState& state) noexcept {
        return TestSettingsStoreInvalidFileActionsPreservesUnrelatedSections(state);
    });
    SelfTest::RunCase(options, suite, L"settings_store_invalid_shortcuts_preserves_unrelated_sections", [](CaseState& state) noexcept {
        return TestSettingsStoreInvalidShortcutsPreservesUnrelatedSections(state);
    });
    SelfTest::RunCase(options, suite, L"settings_store_unsupported_future_schema_never_overwrites_source", [](CaseState& state) noexcept {
        return TestSettingsStoreUnsupportedFutureSchemaNeverOverwritesSource(state);
    });
    SelfTest::RunCase(options, suite, L"settings_store_unknown_top_level_members_survive_save", [](CaseState& state) noexcept {
        return TestSettingsStoreUnknownTopLevelMembersSurviveSave(state);
    });
    SelfTest::RunCase(options, suite, L"resource_hresult_details_format_is_valid", [](CaseState& state) noexcept {
        return TestHResultDetailsResourceUsesValidFormatString(state);
    });
    SelfTest::RunCase(options, suite, L"resource_invalid_format_string_returns_raw_fallback", [](CaseState& state) noexcept {
        return TestInvalidResourceFormatStringReturnsRawFallback(state);
    });
    SelfTest::RunCase(options, suite, L"resource_format_placeholders_are_positional", [](CaseState& state) noexcept {
        return TestResourceFormatPlaceholdersArePositional(state);
    });
    SelfTest::RunCase(
        options, suite, L"popup_dialog_titles_are_localized", [](CaseState& state) noexcept { return TestPopupAndDialogTitlesAreLocalized(state); });
    SelfTest::RunCase(options, suite, L"embedded_viewer_context_menus_expose_menu_actions", [](CaseState& state) noexcept {
        return TestEmbeddedViewerContextMenusExposeMenuActions(state);
    });
    SelfTest::RunCase(options, suite, L"embedded_vlc_audio_preview_stays_inside_preview", [](CaseState& state) noexcept {
        return TestEmbeddedVlcAudioPreviewKeepsPlaybackInsidePreview(state);
    });
    SelfTest::RunCase(options, suite, L"settings_store_file_actions_v16_rejects_malformed_definitions", [](CaseState& state) noexcept {
        return TestSettingsStoreFileActionsV16RejectsMalformedDefinitions(state);
    });
    SelfTest::RunCase(options, suite, L"settings_store_file_actions_v16_empty_viewers_roundtrip", [](CaseState& state) noexcept {
        return TestSettingsStoreFileActionsV16EmptyViewersRoundTrip(state);
    });
    SelfTest::RunCase(options, suite, L"file_action_resolution_v16_explains_priority", [](CaseState& state) noexcept {
        return TestFileActionResolutionV16ExplainsPriority(state);
    });
    SelfTest::RunCase(options, suite, L"file_action_resolution_v16_action_ids_are_case_insensitive", [](CaseState& state) noexcept {
        return TestFileActionResolutionV16ActionIdsAreCaseInsensitive(state);
    });
    SelfTest::RunCase(options, suite, L"file_action_resolution_v16_command_keys_are_distinct", [](CaseState& state) noexcept {
        return TestFileActionResolutionV16CommandKeysAreDistinct(state);
    });
    SelfTest::RunCase(options, suite, L"file_action_defaults_v16_route_viewer_extensions", [](CaseState& state) noexcept {
        return TestFileActionDefaultsV16RouteViewerExtensions(state);
    });
    SelfTest::RunCase(options, suite, L"file_action_executable_path_template_macro_detection", [](CaseState& state) noexcept {
        return TestFileActionExecutablePathTemplateMacroDetection(state);
    });
    SelfTest::RunCase(
        options, suite, L"file_action_external_launch_plan_macros", [](CaseState& state) noexcept { return TestFileActionExternalLaunchPlanMacros(state); });
    SelfTest::RunCase(options, suite, L"file_action_external_launch_starts_process", [](CaseState& state) noexcept {
        return TestFileActionExternalLaunchStartsProcess(state);
    });
#if defined(ENABLE_TESTS)
    SelfTest::RunCase(options, suite, L"file_action_selected_paths_creation_contract", [](CaseState& state) noexcept {
        return TestFileActionSelectedPathsCreationContract(state);
    });
    SelfTest::RunCase(options, suite, L"file_action_selected_paths_record_contract", [](CaseState& state) noexcept {
        return TestFileActionSelectedPathsRecordContract(state);
    });
    SelfTest::RunCase(options, suite, L"file_action_selected_paths_streaming_perf", [](CaseState& state) noexcept {
        return TestFileActionSelectedPathsStreamingPerf(state);
    });
    SelfTest::RunCase(options, suite, L"file_action_selected_paths_child_parse", [](CaseState& state) noexcept {
        return TestFileActionSelectedPathsChildParsesRecords(state);
    });
    SelfTest::RunCase(options, suite, L"file_action_selected_paths_identity_cleanup", [](CaseState& state) noexcept {
        return TestFileActionSelectedPathsIdentityCleanup(state);
    });
    SelfTest::RunCase(options, suite, L"file_action_selected_paths_recovery_bounds", [](CaseState& state) noexcept {
        return TestFileActionSelectedPathsRecoveryBounds(state);
    });
#endif
    SelfTest::RunCase(options, suite, L"file_action_selected_paths_file_lifecycle", [](CaseState& state) noexcept {
        return TestFileActionSelectedPathsFileLifecycle(state);
    });
    SelfTest::RunCase(
        options, suite, L"settings_shortcuts_default_roundtrip", [](CaseState& state) noexcept { return TestSettingsStoreShortcutDefaultsRoundTrip(state); });
    SelfTest::RunCase(options, suite, L"settings_shortcuts_view_state_roundtrip", [](CaseState& state) noexcept {
        return TestSettingsStoreShortcutsViewStateRoundTrip(state);
    });
    SelfTest::RunCase(
        options, suite, L"settings_file_operations_roundtrip", [](CaseState& state) noexcept { return TestSettingsStoreFileOperationsRoundTrip(state); });
    SelfTest::RunCase(options, suite, L"settings_uia_blocked_operation_deadline_is_bounded", [](CaseState& state) noexcept {
        return TestUiaActionDeadlineCancelsBlockedOperation(state);
    });
    SelfTest::RunCase(
        options, suite, L"settings_ui_customization_roundtrip", [](CaseState& state) noexcept { return TestSettingsStoreUiCustomizationRoundTrip(state); });
    SelfTest::RunCase(
        options, suite, L"settings_ui_compact_mode_defaults_true", [](CaseState& state) noexcept { return TestSettingsStoreUiDefaultsUseCompactMode(state); });
    SelfTest::RunCase(options, suite, L"settings_mouse_focus_follows_pointer_roundtrip", [](CaseState& state) noexcept {
        return TestSettingsStoreMouseFocusFollowsPointerRoundTrip(state);
    });
    SelfTest::RunCase(options, suite, L"settings_shortcuts_invalid_section_rejected", [](CaseState& state) noexcept {
        return TestSettingsStoreRejectsMalformedShortcutSection(state);
    });
    SelfTest::RunCase(options, suite, L"settings_shortcuts_unassigned_sentinel_roundtrip", [](CaseState& state) noexcept {
        return TestSettingsStoreShortcutUnassignedSentinelRoundTrip(state);
    });
    SelfTest::RunCase(
        options, suite, L"terminal_shortcut_passthrough_roundtrip", [](CaseState& state) noexcept { return TestTerminalShortcutPassThroughRoundTrip(state); });
    SelfTest::RunCase(options, suite, L"settings_hot_reload_self_save_suppression", [=](CaseState& state) noexcept {
        return TestSettingsHotReloadSelfSaveSuppression(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"settings_save_queue_serializes_coalesces_and_flushes", [=](CaseState& state) noexcept {
        return TestSettingsSaveQueueSerializesCoalescesAndFlushes(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"settings_hot_reload_invalid_external_file", [=](CaseState& state) noexcept {
        return TestSettingsHotReloadInvalidExternalFile(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"settings_hot_reload_transient_arm_failure_is_async", [=](CaseState& state) noexcept {
        return TestSettingsHotReloadTransientArmFailureIsAsync(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"settings_hot_reload_stale_notification_cannot_cross_session", [=](CaseState& state) noexcept {
        return TestSettingsHotReloadRejectsStaleSessionNotification(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"settings_hot_reload_creates_missing_directory", [=](CaseState& state) noexcept {
        return TestSettingsHotReloadCreatesMissingDirectory(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"settings_file_system_curl_plugin_names_localized", [](CaseState& state) noexcept {
        return TestFileSystemCurlPluginNamesAreLocalized(state);
    });
    SelfTest::RunCase(options, suite, L"icon_bitmap_alpha_normalization", [](CaseState& state) noexcept { return TestIconBitmapAlphaNormalization(state); });
    SelfTest::RunCase(
        options, suite, L"folder_view_icon_bitmap_interpolation", [](CaseState& state) noexcept { return TestFolderViewIconBitmapInterpolation(state); });
    SelfTest::RunCase(
        options, suite, L"icon_cache_selects_non_upscaled_source", [](CaseState& state) noexcept { return TestIconCacheSelectsNonUpscaledSource(state); });
    SelfTest::RunCase(options, suite, L"red_salamander_help_lists_diagnostics_options", [](CaseState& state) noexcept {
        return TestRedSalamanderHelpListsDiagnosticsOptions(state);
    });
    SelfTest::RunCase(options, suite, L"registry_integrity", [](CaseState& state) noexcept { return TestRegistryIntegrity(state); });
    SelfTest::RunCase(
        options, suite, L"command_surface_coverage_contract", [=](CaseState& state) noexcept { return TestCommandSurfaceCoverageContract(mainWindow, state); });
    SelfTest::RunCase(
        options, suite, L"main_menu_information_architecture", [](CaseState& state) noexcept { return TestMainMenuInformationArchitecture(state); });
    SelfTest::RunCase(options, suite, L"shortcut_defaults_mapping", [](CaseState& state) noexcept { return TestShortcutDefaultsMapping(state); });
    SelfTest::RunCase(options, suite, L"terminal_shortcut_defaults_and_physical_positions", [](CaseState& state) noexcept {
        return TestTerminalShortcutDefaultsAndPhysicalPositions(state);
    });
    SelfTest::RunCase(options, suite, L"shortcut_defaults_restore_missing_f3_view", [](CaseState& state) noexcept {
        return TestShortcutDefaultsRestoreMissingF3View(state);
    });
    SelfTest::RunCase(options, suite, L"shortcut_defaults_restore_missing_defaults_and_preserve_unassigned", [](CaseState& state) noexcept {
        return TestShortcutDefaultsRestoreMissingDefaultsAndPreserveUnassigned(state);
    });
    SelfTest::RunCase(
        options, suite, L"implemented_menu_labels_not_todo", [](CaseState& state) noexcept { return TestImplementedCommandMenuLabelsAreNotMarkedTodo(state); });
    SelfTest::RunCase(options, suite, L"pane_view_options_live_in_left_right_menus", [](CaseState& state) noexcept {
        return TestPaneViewOptionsLiveInLeftRightMenus(state);
    });
    SelfTest::RunCase(
        options, suite, L"theme_menu_navigation_commands_are_last", [](CaseState& state) noexcept { return TestThemeMenuNavigationCommandsAreLast(state); });
    SelfTest::RunCase(
        options, suite, L"help_menu_links_external_documentation", [](CaseState& state) noexcept { return TestHelpMenuLinksExternalDocumentation(state); });
    SelfTest::RunCase(options, suite, L"cmd_app_rereadAssociations_reloads_actions_and_refreshes_panes", [=](CaseState& state) noexcept {
        return TestRereadAssociationsReloadsActionsAndRefreshesPanes(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"theme_cycle_commands", [=](CaseState& state) noexcept { return TestThemeCycleCommands(mainWindow, state); });
    SelfTest::RunCase(options, suite, L"theme_v2_runtime_resolution_and_dynamic_perf", [](CaseState& state) noexcept {
        return TestThemeV2RuntimeResolutionAndDynamicPerf(state);
    });
    SelfTest::RunCase(options, suite, L"generic_status_bar_command_routes_active_pane", [=](CaseState& state) noexcept {
        return TestGenericStatusBarCommandRoutesActivePane(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"settings_store_pane_view_options_roundtrip", [](CaseState& state) noexcept {
        return TestSettingsStorePaneViewOptionsRoundTrip(state);
    });
    SelfTest::RunCase(
        options, suite, L"folderView_thumbnail_settings_roundtrip", [](CaseState& state) noexcept { return TestFolderViewThumbnailSettingsRoundTrip(state); });
    SelfTest::RunCase(
        options, suite, L"settings_store_make_file_list_roundtrip", [](CaseState& state) noexcept { return TestSettingsStoreMakeFileListRoundTrip(state); });
    SelfTest::RunCase(options, suite, L"settings_store_make_file_list_suppresses_default_fields", [](CaseState& state) noexcept {
        return TestSettingsStoreMakeFileListSuppressesDefaultFields(state);
    });
    SelfTest::RunCase(options, suite, L"cmd_pane_makeFileList_generates_formats_and_saves_options", [=](CaseState& state) noexcept {
        return TestMakeFileListGeneratesFormatsAndSavesOptions(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"cmd_pane_listOpenedFiles_shows_sources_prunes_closed_editors_and_focuses_items", [=](CaseState& state) noexcept {
        return TestListOpenedFilesShowsSourcesPrunesClosedEditorsAndFocusesItems(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"cmd_pane_shares_shows_synthetic_rows_opens_paths_and_reports_access_denied", [=](CaseState& state) noexcept {
        return TestSharedDirectoriesShowsSyntheticRowsOpensPathsAndReportsAccessDenied(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"cmd_pane_archive_pack_unpack_zip_roundtrip_and_validation", [=](CaseState& state) noexcept {
        return TestArchiveCommandsPackUnpackZipRoundTripAndValidation(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"pane_view_options_toggle_file_extensions_navigation_filter_bar", [=](CaseState& state) noexcept {
        return TestPaneViewOptionsToggleFileExtensionsNavigationAndFilterBar(mainWindow, state);
    });
    SelfTest::RunCase(
        options, suite, L"pane_filter_bar_inline_workflow", [=](CaseState& state) noexcept { return TestPaneFilterBarInlineWorkflow(mainWindow, state); });
    SelfTest::RunCase(options, suite, L"pane_view_options_toggle_thumbnails", [=](CaseState& state) noexcept {
        return TestPaneViewOptionsToggleThumbnailsSchedulesBoundedAsyncWork(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"pane_view_options_toggle_preview_pane_tabs_and_selection", [=](CaseState& state) noexcept {
        return TestPaneViewOptionsTogglePreviewPaneUsesOppositePaneTabsAndSelection(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"pane_view_options_preview_uses_configured_embedded_viewer_and_preserves_focus", [=](CaseState& state) noexcept {
        return TestPaneViewOptionsPreviewUsesConfiguredEmbeddedViewerAndPreservesFocus(mainWindow, state);
    });
    SelfTest::RunCase(options,
                      suite,
                      L"pane_view_options_preview_rejects_zero_new_embedded_children",
                      [=](CaseState& state) noexcept
    {
        return TestPaneViewOptionsPreviewRejectsInvalidEmbeddedChildCardinality(
            mainWindow, state, FolderWindow::PreviewEmbeddedChildFaultForTest::ReportNoNewChild, 1u, 0u, L"zero-new-child");
    });
    SelfTest::RunCase(options,
                      suite,
                      L"pane_view_options_preview_rejects_multiple_new_embedded_children",
                      [=](CaseState& state) noexcept
    {
        return TestPaneViewOptionsPreviewRejectsInvalidEmbeddedChildCardinality(
            mainWindow, state, FolderWindow::PreviewEmbeddedChildFaultForTest::CreateAdditionalNewChild, 2u, 2u, L"multiple-new-child");
    });
    SelfTest::RunCase(options,
                      suite,
                      L"pane_view_options_preview_rejects_same_plugin_additional_embedded_child",
                      [=](CaseState& state) noexcept
    {
        return TestPaneViewOptionsPreviewRejectsInvalidEmbeddedChildSetOnReuse(
            mainWindow, state, FolderWindow::PreviewEmbeddedChildFaultForTest::CreateAdditionalNewChildOnReopen, L"additional-root");
    });
    SelfTest::RunCase(options,
                      suite,
                      L"pane_view_options_preview_rejects_same_plugin_replacement_embedded_child",
                      [=](CaseState& state) noexcept
    {
        return TestPaneViewOptionsPreviewRejectsInvalidEmbeddedChildSetOnReuse(
            mainWindow, state, FolderWindow::PreviewEmbeddedChildFaultForTest::ReplaceEmbeddedChildOnReopen, L"replacement-root");
    });
    SelfTest::RunCase(options, suite, L"pane_view_options_preview_uses_builtin_embedded_viewer_with_empty_associations", [=](CaseState& state) noexcept {
        return TestPaneViewOptionsPreviewUsesBuiltInEmbeddedViewerWhenAssociationsAreEmpty(mainWindow, state);
    });
    SelfTest::RunCase(
        options, suite, L"pane_view_options_preview_falls_back_to_item_properties_when_no_embedded_preview_matches", [=](CaseState& state) noexcept {
        return TestPaneViewOptionsPreviewFallsBackToItemPropertiesWhenNoEmbeddedPreviewMatches(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"pane_view_options_preview_properties_card_scrolls_and_uses_rainbow_theme", [=](CaseState& state) noexcept {
        return TestPaneViewOptionsPreviewPropertiesCardScrollsAndUsesRainbowTheme(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"pane_view_options_preview_pane_extends_without_function_bar", [=](CaseState& state) noexcept {
        return TestPaneViewOptionsPreviewPaneExtendsWhenFunctionBarHidden(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"alternate_view_uses_configured_viewer_action", [=](CaseState& state) noexcept {
        return TestAlternateViewUsesConfiguredViewerAction(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"alternate_view_launches_external_viewer_action", [=](CaseState& state) noexcept {
        return TestAlternateViewLaunchesExternalViewerAction(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"view_command_uses_configured_primary_viewer_action", [=](CaseState& state) noexcept {
        return TestViewCommandUsesConfiguredPrimaryViewerAction(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"view_with_disabled_action_reports_alert", [=](CaseState& state) noexcept {
        return TestViewWithDisabledActionReportsAlert(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"view_with_launch_failure_reports_alert", [=](CaseState& state) noexcept {
        return TestViewWithLaunchFailureReportsAlert(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"alternate_view_without_configured_action_reports_alert", [=](CaseState& state) noexcept {
        return TestAlternateViewWithoutConfiguredActionReportsAlert(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"edit_with_disabled_action_reports_alert", [=](CaseState& state) noexcept {
        return TestEditWithDisabledActionReportsAlert(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"edit_with_launch_failure_reports_alert", [=](CaseState& state) noexcept {
        return TestEditWithLaunchFailureReportsAlert(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"alternate_edit_without_configured_action_reports_alert", [=](CaseState& state) noexcept {
        return TestAlternateEditWithoutConfiguredActionReportsAlert(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"view_with_parameterized_command_uses_configured_viewer_action", [=](CaseState& state) noexcept {
        return TestViewWithParameterizedCommandUsesConfiguredViewerAction(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"view_with_parameterized_command_launches_external_viewer_action", [=](CaseState& state) noexcept {
        return TestViewWithParameterizedCommandLaunchesExternalViewerAction(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"view_with_menu_populates_applicable_viewer_actions", [=](CaseState& state) noexcept {
        return TestViewWithMenuPopulatesApplicableViewerActions(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"edit_with_parameterized_command_launches_external_editor_action", [=](CaseState& state) noexcept {
        return TestEditWithParameterizedCommandLaunchesExternalEditorAction(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"edit_command_uses_focused_primary_editor_action", [=](CaseState& state) noexcept {
        return TestEditCommandUsesFocusedPrimaryEditorAction(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"alternate_edit_launches_configured_editor_action", [=](CaseState& state) noexcept {
        return TestAlternateEditCommandLaunchesConfiguredEditorAction(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"edit_with_menu_populates_applicable_editor_actions", [=](CaseState& state) noexcept {
        return TestEditWithMenuPopulatesApplicableEditorActions(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"user_menu_populates_and_dispatches_configured_actions", [=](CaseState& state) noexcept {
        return TestUserMenuPopulatesAndDispatchesConfiguredActions(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"file_action_provider_record_rejected_in_command_route", [=](CaseState& state) noexcept {
        return TestFileActionProviderRecordRejectedInCommandRoute(mainWindow, state);
    });
    SelfTest::RunCase(options, suite, L"user_menu_parameterized_command_reports_unavailable", [=](CaseState& state) noexcept {
        return TestUserMenuParameterizedCommandReportsUnavailable(mainWindow, state);
    });
}

namespace
{
