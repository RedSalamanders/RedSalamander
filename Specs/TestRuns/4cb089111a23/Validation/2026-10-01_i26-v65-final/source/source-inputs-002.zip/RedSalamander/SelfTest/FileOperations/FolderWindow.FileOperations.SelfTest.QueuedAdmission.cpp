// Included from FolderWindow.FileOperations.SelfTest.cpp under ENABLE_TESTS.
// Admission/durable-owner contracts and private local execution witnesses; no foreground input.
[[nodiscard]] bool ValidateQueuedAdmissionContracts(SelfTestState& fixture, SelfTest::CaseState& state) noexcept
{
    using State                         = FolderWindow::FileOperationState;
    const SelfTest::TestSandbox sandbox = SelfTest::AcquireTestSandbox(SelfTest::SelfTestSuite::FileOperations, L"queued-admission-contracts");
    if (! state.Require(sandbox.IsValid() && fixture.fileOps && fixture.fsDummy, L"Queued admission contracts require the governed sandbox and Dummy fixture."))
        return false;
    const std::filesystem::path root           = sandbox.root;
    const std::filesystem::path breadcrumbRoot = root / L"breadcrumb-state";
    FileOperationMoveBreadcrumb::SetRootForSelfTest(breadcrumbRoot);
    const auto restoreRoot = wil::scope_exit([]() noexcept { FileOperationMoveBreadcrumb::ClearRootForSelfTest(); });

    constexpr auto sourceFolder      = L"/queued-admission-contracts-source";
    constexpr auto sourcePath        = L"/queued-admission-contracts-source/single.txt";
    constexpr auto destinationFolder = L"/queued-admission-contracts-destination";
    const auto cleanupDummy          = wil::scope_exit([&]() noexcept
    {
        static_cast<void>(fixture.fsDummy->DeleteItem(sourceFolder, FILESYSTEM_FLAG_RECURSIVE, nullptr, nullptr, nullptr));
        static_cast<void>(fixture.fsDummy->DeleteItem(destinationFolder, FILESYSTEM_FLAG_RECURSIVE, nullptr, nullptr, nullptr));
    });
    // These private fixture roots can survive an interrupted earlier process; seed from a known state.
    static_cast<void>(fixture.fsDummy->DeleteItem(sourceFolder, FILESYSTEM_FLAG_RECURSIVE, nullptr, nullptr, nullptr));
    static_cast<void>(fixture.fsDummy->DeleteItem(destinationFolder, FILESYSTEM_FLAG_RECURSIVE, nullptr, nullptr, nullptr));
    if (! state.Require(EnsureDummyFolderExists(fixture.fsDummy.get(), sourceFolder) && EnsureDummyFolderExists(fixture.fsDummy.get(), destinationFolder) &&
                            DummyWriteTextFile(fixture.fsDummy.get(), sourcePath, "unchanged-source"),
                        L"Captured admission fixture must create its provider-owned paths."))
        return false;

    State::OperationConstruction construction{};
    construction.operation                            = FILESYSTEM_MOVE;
    construction.sourcePane                           = FolderWindow::Pane::Right;
    construction.destinationPane                      = FolderWindow::Pane::Left;
    construction.fileSystem                           = fixture.fsDummy;
    construction.destinationFileSystem                = fixture.fsDummy;
    construction.sourcePaths                          = {std::filesystem::path(sourcePath)};
    construction.destinationFolder                    = destinationFolder;
    construction.sourcePluginId                       = kPluginIdDummy;
    construction.sourcePluginShortId                  = L"dummy";
    construction.sourceInstanceContext                = L"captured-context";
    construction.destinationPluginId                  = kPluginIdDummy;
    construction.destinationPluginShortId             = L"dummy";
    construction.destinationInstanceContext           = L"captured-context";
    construction.options.verifyAfterCopy              = true;
    construction.options.executionMode                = FileOperations::ExecutionMode::Queue;
    construction.options.bandwidthLimitBytesPerSecond = std::nullopt; // Captured unlimited, never reread defaults.
    construction.moveClipboardSequence                = 731u;         // Provenance only: constructing an envelope cannot consume it.
    std::vector<State::Task*> beforeTasks;
    fixture.fileOps->CollectTasks(beforeTasks);
    State::OperationAdmission admission{};
    const HRESULT buildHr = State::BuildOperationAdmission(construction, admission);
    const auto* transfer  = admission.plans.size() == 1u ? std::get_if<FileOperations::TransferPlan>(&admission.plans.front()) : nullptr;
    if (! state.Require(buildHr == S_OK && transfer && transfer->strategy == FileOperations::OperationStrategy::Native &&
                            transfer->sourceEndpoint.instanceId == L"host/context/captured-context" &&
                            transfer->destinationEndpoint.instanceId == L"host/context/captured-context" &&
                            transfer->destination.providerFolderPath == destinationFolder && transfer->selectedItems.size() == 1u &&
                            transfer->selectedItems.front().providerPath == sourcePath && transfer->options.verifyAfterCopy &&
                            transfer->options.executionMode == FileOperations::ExecutionMode::Queue &&
                            ! transfer->options.bandwidthLimitBytesPerSecond.has_value() && transfer->moveClipboardSequence.has_value() &&
                            transfer->moveClipboardSequence->windowsSequenceNumber == 731u && ! admission.preWorkerReleaseBarrier &&
                            admission.sourcePane == FolderWindow::Pane::Right && admission.destinationPane == FolderWindow::Pane::Left,
                        L"Private admission must preserve captured provider, options and clipboard provenance without publication."))
        return false;
    State::OperationAdmission noBarrier = admission;
    uint64_t refusedTaskId              = 999u;
    state.Require(fixture.fileOps->StartOperation(std::move(noBarrier), &refusedTaskId) == E_INVALIDARG && refusedTaskId == 0u,
                  L"A constructed clipboard-Move envelope cannot publish without its initial worker-release barrier.");
    State::TransferDestinationNameFailure nameFailure;
    std::atomic<bool> nameCancelled{false};
    state.Require(State::ValidateTransferDestinationNames(admission.plans, fixture.fsDummy.get(), FILESYSTEM_MOVE, {}, nameCancelled, nameFailure) == S_OK &&
                      nameFailure.rejectedLeaf.empty(),
                  L"Private destination-name validation must accept the provider's valid name without task diagnostics.");
    auto badNamePlans                                                             = admission.plans;
    std::get<FileOperations::TransferPlan>(badNamePlans.front()).explicitMappings = {{0u, L"/queued-admission-contracts-destination/bad:name.txt"}};
    state.Require(State::ValidateTransferDestinationNames(badNamePlans, fixture.fsDummy.get(), FILESYSTEM_MOVE, {}, nameCancelled, nameFailure) ==
                          HRESULT_FROM_WIN32(ERROR_INVALID_NAME) &&
                      nameFailure.rejectedLeaf == L"bad:name.txt" && nameFailure.sourcePath == sourcePath && nameFailure.destinationFolder == destinationFolder,
                  L"A rejected candidate must return its exact destination leaf, source and parent without publishing diagnostics.");
    state.Require(State::ValidateTransferDestinationNames(admission.plans, fixture.fsDummy.get(), FILESYSTEM_MOVE, {}, nameCancelled, nameFailure) == S_OK &&
                      nameFailure.rejectedLeaf.empty() && nameFailure.sourcePath.empty() && nameFailure.destinationFolder.empty(),
                  L"A subsequent valid candidate must clear all previous name-refusal facts.");
    nameCancelled.store(true, std::memory_order_release);
    nameFailure.rejectedLeaf = L"stale-refusal";
    state.Require(State::ValidateTransferDestinationNames(admission.plans, fixture.fsDummy.get(), FILESYSTEM_MOVE, {}, nameCancelled, nameFailure) ==
                          HRESULT_FROM_WIN32(ERROR_CANCELLED) &&
                      nameFailure.rejectedLeaf.empty(),
                  L"Cancellation must not return an earlier candidate's destination-name refusal.");
    nameCancelled.store(false, std::memory_order_release);
    std::stop_source nameStop;
    nameStop.request_stop();
    state.Require(
        State::ValidateTransferDestinationNames(admission.plans, fixture.fsDummy.get(), FILESYSTEM_MOVE, nameStop.get_token(), nameCancelled, nameFailure) ==
            HRESULT_FROM_WIN32(ERROR_CANCELLED),
        L"Worker stop must prevent private destination-name validation from continuing.");
    std::vector<FileOperations::MutationInterlockScope> scopes;
    if (! state.Require(State::BuildTransferInterlockScopes(admission.plans, fixture.fsDummy.get(), fixture.fsDummy.get(), FILESYSTEM_MOVE, scopes) == S_OK &&
                            scopes.size() == 2u &&
                            std::ranges::count_if(
                                scopes, [](const auto& scope) noexcept { return scope.access == FileOperations::MutationInterlockAccess::WriteSource; }) == 1 &&
                            std::ranges::count_if(scopes,
                                                  [](const auto& scope) noexcept
    { return scope.access == FileOperations::MutationInterlockAccess::PublishDestination; }) == 1,
                        L"Private preparation must bind both the Native Move source and selected destination scopes."))
        return false;
    // Exercise the actual scheduler and live-output consent predicates with immutable private
    // registrations. Public task identity stays fixed while the proposed admission changes.
    auto candidate             = std::make_unique<State::Task>(*fixture.fileOps);
    auto peer                  = std::make_unique<State::Task>(*fixture.fileOps);
    const auto artifactReceipt = [](std::wstring_view name)
    {
        FileOperationArtifacts::TouchGuardReceipt receipt;
        FileOperationArtifacts::TouchGuardItem item;
        item.path = std::filesystem::path(name);
        receipt.items.push_back(std::move(item));
        return receipt;
    };
    const auto receiptNames = [](const auto& receipt, std::wstring_view name) noexcept
    { return static_cast<bool>(receipt) && receipt->items.size() == 1u && receipt->items.front().path.native() == name; };
    candidate->StoreInitialArtifactTouchReceipt(artifactReceipt(L"live-original"));
    State::Task viewFixture(*fixture.fileOps);
    auto viewConstruction = construction;
    viewConstruction.destinationFileSystem.reset();
    viewConstruction.resolvedItems = {FolderWindow::ResolvedFileOperationItem{
        .sourcePath      = sourcePath,
        .destinationPath = std::filesystem::path(destinationFolder) / L"single.txt",
    }};
    State::OperationAdmission mappedViewAdmission;
    if (! state.Require(State::BuildOperationAdmission(viewConstruction, mappedViewAdmission) == S_OK,
                        L"The coherent-view fixture requires a canonical explicit-mapping plan."))
        return false;
    auto retainedPlans = std::make_shared<const FileOperations::FileOperationPlanGroup>(mappedViewAdmission.plans);
    State::AdmissionDestinationInputs originalDestination;
    originalDestination.folder          = destinationFolder;
    originalDestination.pluginId        = kPluginIdDummy;
    originalDestination.pluginShortId   = L"dummy";
    originalDestination.instanceContext = construction.destinationInstanceContext;
    originalDestination.resolvedItems   = mappedViewAdmission.resolvedItems;
    viewFixture.InitializeAdmissionInputs(retainedPlans, std::move(originalDestination), artifactReceipt(L"view-original"));
    const auto originalView                = viewFixture.LoadSelectedAdmission();
    viewConstruction.destinationFileSystem = fixture.fsDummy;
    viewConstruction.resolvedItems.clear();
    State::OperationAdmission plainViewAdmission;
    if (! state.Require(State::BuildOperationAdmission(viewConstruction, plainViewAdmission) == S_OK,
                        L"The coherent-view fixture requires a canonical plain-destination plan."))
        return false;
    const auto plainPlans = std::make_shared<const FileOperations::FileOperationPlanGroup>(plainViewAdmission.plans);
    State::AdmissionDestinationInputs explicitSameProvider;
    explicitSameProvider.fileSystem      = fixture.fsDummy;
    explicitSameProvider.folder          = destinationFolder;
    explicitSameProvider.pluginId        = kPluginIdDummy;
    explicitSameProvider.pluginShortId   = L"dummy";
    explicitSameProvider.instanceContext = construction.destinationInstanceContext;
    viewFixture.InitializeAdmissionInputs(plainPlans, std::move(explicitSameProvider), artifactReceipt(L"view-second"));
    const auto secondView = viewFixture.LoadSelectedAdmission();
    state.Require(
        originalView->plans == retainedPlans && secondView->plans == plainPlans && ! originalView->destination->fileSystem &&
            secondView->destination->fileSystem.get() == fixture.fsDummy.get() && originalView->destination->folder == destinationFolder &&
            secondView->destination->folder == destinationFolder && originalView->destination->resolvedItems.size() == 1u &&
            secondView->destination->resolvedItems.empty() &&
            std::get<FileOperations::TransferPlan>(originalView->plans->front()).explicitMappings.size() == 1u &&
            std::get<FileOperations::TransferPlan>(secondView->plans->front()).explicitMappings.empty() &&
            receiptNames(originalView->artifactTouchReceipt, L"view-original") && receiptNames(secondView->artifactTouchReceipt, L"view-second") &&
            ! originalView->interlock && ! secondView->interlock && ! originalView->preparation && ! secondView->preparation,
        L"Private initial views retain coherent typed mappings and receipt while preserving null versus explicit same-provider semantics without authority.");
    auto resealedPlans = std::make_shared<const FileOperations::FileOperationPlanGroup>(plainViewAdmission.plans);
    viewFixture.StorePlans(resealedPlans);
    const auto resealedView = viewFixture.LoadSelectedAdmission();
    state.Require(resealedView->plans == resealedPlans && secondView->plans == plainPlans && resealedView->destination == secondView->destination &&
                      resealedView->artifactTouchReceipt == secondView->artifactTouchReceipt,
                  L"Initial plan resealing replaces only the small selected view and preserves destination ownership without copying mappings.");
    candidate->_batchRenameArtifactPromptNextRequestId    = 2u;
    candidate->_batchRenameArtifactPromptPendingRequestId = 2u;
    candidate->CompleteBatchRenameArtifactPrompt(1u, S_OK, artifactReceipt(L"stale"));
    candidate->CompleteBatchRenameArtifactPrompt(0u, S_OK, artifactReceipt(L"uncorrelated"));
    state.Require(candidate->IsBatchRenameArtifactPromptPending(2u) && ! candidate->_batchRenameArtifactPromptResultReceipt.has_value() &&
                      candidate->_batchRenameArtifactPromptStatus == E_PENDING &&
                      receiptNames(candidate->LoadSelectedAdmission()->artifactTouchReceipt, L"live-original"),
                  L"Stale or uncorrelated artifact replies cannot complete a newer prompt or install a live receipt.");
    candidate->CompleteBatchRenameArtifactPrompt(2u, E_ACCESSDENIED, artifactReceipt(L"refused"));
    candidate->CompleteBatchRenameArtifactPrompt(2u, S_OK, artifactReceipt(L"duplicate"));
    state.Require(candidate->_batchRenameArtifactPromptCompleted && candidate->_batchRenameArtifactPromptStatus == E_ACCESSDENIED &&
                      ! candidate->_batchRenameArtifactPromptResultReceipt.has_value() &&
                      receiptNames(candidate->LoadSelectedAdmission()->artifactTouchReceipt, L"live-original"),
                  L"Failed artifact preparation retains the installed receipt and rejects a duplicate successful reply.");
    candidate->_batchRenameArtifactPromptNextRequestId    = 3u;
    candidate->_batchRenameArtifactPromptPendingRequestId = 3u;
    candidate->_batchRenameArtifactPromptCompleted        = false;
    candidate->_batchRenameArtifactPromptStatus           = E_PENDING;
    candidate->CompleteBatchRenameArtifactPrompt(2u, S_OK, artifactReceipt(L"late-previous-request"));
    state.Require(candidate->_batchRenameArtifactPromptStatus == E_PENDING && ! candidate->_batchRenameArtifactPromptCompleted &&
                      ! candidate->_batchRenameArtifactPromptResultReceipt.has_value(),
                  L"A late reply for a completed request must leave the next pending artifact request untouched.");
    candidate->CompleteBatchRenameArtifactPrompt(3u, S_OK, artifactReceipt(L"candidate"));
    state.Require(candidate->_batchRenameArtifactPromptCompleted && candidate->_batchRenameArtifactPromptStatus == S_OK &&
                      receiptNames(candidate->_batchRenameArtifactPromptResultReceipt, L"candidate") &&
                      receiptNames(candidate->LoadSelectedAdmission()->artifactTouchReceipt, L"live-original"),
                  L"A correlated success stays private until the admission owner commits it.");
    std::optional<FileOperationArtifacts::TouchGuardReceipt> preparedArtifact = artifactReceipt(L"previous-output");
    state.Require(candidate->PrepareArtifactTouchGuard(admission.plans, fixture.fsDummy.get(), fixture.fsDummy.get(), preparedArtifact) == S_OK &&
                      ! preparedArtifact.has_value() && receiptNames(candidate->LoadSelectedAdmission()->artifactTouchReceipt, L"live-original"),
                  L"Ordinary paths need no prompt and clear only the private output receipt.");
    auto malformedArtifactPlans = admission.plans;
    std::get<FileOperations::TransferPlan>(malformedArtifactPlans.front()).sourceEndpoint.pathIdentity.reset();
    preparedArtifact = artifactReceipt(L"previous-output");
    state.Require(
        candidate->PrepareArtifactTouchGuard(malformedArtifactPlans, fixture.fsDummy.get(), fixture.fsDummy.get(), preparedArtifact) == E_INVALIDARG &&
            receiptNames(preparedArtifact, L"previous-output") && receiptNames(candidate->LoadSelectedAdmission()->artifactTouchReceipt, L"live-original"),
        L"Failed artifact capture preserves both the caller's output and the installed live receipt.");
    candidate->_cancelled.store(true, std::memory_order_release);
    state.Require(candidate->PrepareArtifactTouchGuard(admission.plans, fixture.fsDummy.get(), fixture.fsDummy.get(), preparedArtifact) ==
                          HRESULT_FROM_WIN32(ERROR_CANCELLED) &&
                      receiptNames(preparedArtifact, L"previous-output"),
                  L"Cancellation leaves the private artifact output unchanged.");
    candidate->_cancelled.store(false, std::memory_order_release);
    candidate->_batchRenameArtifactPromptCompleted = false;
    candidate->FailBatchRenameArtifactPromptWithoutPayload(S_OK);
    state.Require(candidate->_batchRenameArtifactPromptStatus == E_UNEXPECTED && ! candidate->_batchRenameArtifactPromptResultReceipt.has_value() &&
                      receiptNames(candidate->LoadSelectedAdmission()->artifactTouchReceipt, L"live-original"),
                  L"The payload-less fallback is failure-only and cannot grant artifact consent.");
    candidate->_taskId = 42u;
    candidate->_admissionKey.store(42u, std::memory_order_release);
    // Dummy supplies conservative scope identity. Real local objects prove that
    // coexisting admissions independently retain their bound destination parents.
    const auto localSourceRoot  = root / L"owned-source";
    const auto localDestination = root / L"owned-destination";
    const auto localReplacement = root / L"owned-replacement";
    const auto localSource      = localSourceRoot / L"single.txt";
    if (! state.Require(fixture.fsLocal && RecreateEmptyDirectory(localSourceRoot) && RecreateEmptyDirectory(localDestination) &&
                            RecreateEmptyDirectory(localReplacement) && SelfTest::WriteTextFile(localSource, "unchanged-local-source"),
                        L"Owned-admission fixtures require two real local destinations and an unchanged selected source."))
        return false;
    auto ownedConstruction                     = construction;
    ownedConstruction.fileSystem               = fixture.fsLocal;
    ownedConstruction.destinationFileSystem    = fixture.fsLocal;
    ownedConstruction.sourcePaths              = {localSource};
    ownedConstruction.destinationFolder        = localDestination;
    ownedConstruction.sourcePluginId           = kPluginIdLocal;
    ownedConstruction.destinationPluginId      = kPluginIdLocal;
    ownedConstruction.sourcePluginShortId      = L"file";
    ownedConstruction.destinationPluginShortId = L"file";
    ownedConstruction.sourceInstanceContext.clear();
    ownedConstruction.destinationInstanceContext.clear();
    State::OperationAdmission ownedAdmission;
    State::MutationInterlockScopes ownedScopes;
    if (! state.Require(
            State::BuildOperationAdmission(ownedConstruction, ownedAdmission) == S_OK &&
                State::BuildTransferInterlockScopes(ownedAdmission.plans, fixture.fsLocal.get(), fixture.fsLocal.get(), FILESYSTEM_MOVE, ownedScopes) == S_OK,
            L"Local ownership fixture must use canonical admission construction and bound scope preparation."))
        return false;
    auto movableScopes       = ownedScopes;
    const auto* movedStorage = movableScopes.data();
    candidate->InstallPreparedMutationInterlockScopes(std::move(movableScopes), false);
    const auto originalCandidateOwner = candidate->LoadMutationInterlockAdmission();
    state.Require(originalCandidateOwner && originalCandidateOwner->scopes->data() == movedStorage,
                  L"Freezing preparation must move the authority vector without copying its storage.");
    State::MutationInterlockAdmission candidateAdmission = *originalCandidateOwner;
    peer->_taskId                                        = 41u;
    peer->_admissionKey.store(41u, std::memory_order_release);
    peer->InstallPreparedMutationInterlockScopes(ownedScopes, false);
    const auto originalPeerOwner = peer->LoadMutationInterlockAdmission();
    std::array<State::ActiveMutationInterlock, 1> originalPeer{{{.taskId = 41u, .task = peer.get(), .admission = originalPeerOwner}}};
    auto replacementInput                     = *originalPeerOwner;
    replacementInput.key                      = 43u;
    auto replacementConstruction              = ownedConstruction;
    replacementConstruction.destinationFolder = localReplacement;
    State::OperationAdmission replacementAdmission;
    State::MutationInterlockScopes changedScopes;
    if (! state.Require(State::BuildOperationAdmission(std::move(replacementConstruction), replacementAdmission) == S_OK &&
                            State::BuildTransferInterlockScopes(
                                replacementAdmission.plans, fixture.fsLocal.get(), fixture.fsLocal.get(), FILESYSTEM_MOVE, changedScopes) == S_OK,
                        L"Replacement scopes must bind the canonical alternate destination, not edit a retained scope pathname."))
        return false;
    replacementInput.scopes  = std::make_shared<const State::MutationInterlockScopes>(std::move(changedScopes));
    const auto isPublication = [](const FileOperations::MutationInterlockScope& scope) noexcept
    { return scope.access == FileOperations::MutationInterlockAccess::PublishDestination; };
    const auto originalPublication    = std::ranges::find_if(*originalPeerOwner->scopes, isPublication);
    const auto replacementPublication = std::ranges::find_if(*replacementInput.scopes, isPublication);
    if (! state.Require(
            originalPublication != originalPeerOwner->scopes->end() && replacementPublication != replacementInput.scopes->end() && originalPublication->root &&
                replacementPublication->root && originalPublication->root->retained.authority.boundObject &&
                replacementPublication->root->retained.authority.boundObject && originalPublication->root->retained.providerPath == localDestination.native() &&
                replacementPublication->root->retained.providerPath == localReplacement.native() && originalPublication->root != replacementPublication->root,
            L"Coexisting registrations must retain separately bound original and replacement destination parents."))
        return false;
    std::array<State::ActiveMutationInterlock, 1> replacementPeer{
        {{.taskId = 41u, .task = peer.get(), .admission = std::make_shared<const State::MutationInterlockAdmission>(std::move(replacementInput))}}};
    uint64_t comparisons = 0u;
    state.Require(! State::MutationInterlocksPermit(42u, candidateAdmission, originalPeer, comparisons) && comparisons > 0u,
                  L"Overlapping immutable registrations must block without explicit consent.");
    candidateAdmission.relations.concurrentKeys[0] = 41u;
    candidateAdmission.relations.concurrentCount   = 1u;
    state.Require(State::MutationInterlocksPermit(42u, candidateAdmission, originalPeer, comparisons) &&
                      ! State::MutationInterlocksPermit(42u, candidateAdmission, replacementPeer, comparisons) &&
                      State::HasConcurrentPublisherConsent(candidateAdmission, originalPeer.front()) &&
                      ! State::HasConcurrentPublisherConsent(candidateAdmission, replacementPeer.front()),
                  L"An old Run grant cannot authorize a replacement registration with the same public task identity.");
    candidateAdmission.relations.concurrentKeys[0] = 43u;
    state.Require(State::MutationInterlocksPermit(42u, candidateAdmission, replacementPeer, comparisons) &&
                      State::HasConcurrentPublisherConsent(candidateAdmission, replacementPeer.front()),
                  L"Fresh consent names the replacement admission explicitly.");
    candidateAdmission.relations.concurrentCount = 0u;
    auto reciprocalInput                         = *originalPeerOwner;
    reciprocalInput.relations.concurrentKeys[0]  = 42u;
    reciprocalInput.relations.concurrentCount    = 1u;
    auto reciprocalPeer                          = originalPeer;
    reciprocalPeer.front().admission             = std::make_shared<const State::MutationInterlockAdmission>(reciprocalInput);
    state.Require(State::HasConcurrentPublisherConsent(candidateAdmission, reciprocalPeer.front()) &&
                      ! State::HasConcurrentPublisherConsent(candidateAdmission, originalPeer.front()) &&
                      reciprocalPeer.front().admission->scopes == originalPeerOwner->scopes,
                  L"A decided snapshot retains scopes while an older captured snapshot keeps its original decision.");
    candidateAdmission.key = 44u;
    state.Require(! State::HasConcurrentPublisherConsent(candidateAdmission, reciprocalPeer.front()),
                  L"A publisher's reciprocal grant names the exact recipient admission.");
    reciprocalInput.relations.concurrentKeys[0] = 44u;
    reciprocalPeer.front().admission            = std::make_shared<const State::MutationInterlockAdmission>(reciprocalInput);
    state.Require(State::HasConcurrentPublisherConsent(candidateAdmission, reciprocalPeer.front()) &&
                      ! State::HasConcurrentPublisherConsent(candidateAdmission, replacementPeer.front()),
                  L"Reciprocal consent is owned by the captured registration, never borrowed from its Task.");
    candidateAdmission.relations.advisoryDecided    = true;
    candidateAdmission.relations.predecessorKeys[0] = 41u;
    candidateAdmission.relations.predecessorCount   = 1u;
    std::vector<State::ActiveMutationInterlock> published{originalPeer.front(), replacementPeer.front()};
    state.Require(State::HasPublishedOverlapPredecessor(candidateAdmission, published, {}) &&
                      State::HasPublishedOverlapPredecessor(candidateAdmission, {}, published),
                  L"Queue-after recognizes the exact original admission in either registry.");
    State::EraseMutationInterlockAdmission(published, 41u);
    state.Require(published.size() == 1u && published.front().admission->key == 43u &&
                      ! State::HasPublishedOverlapPredecessor(candidateAdmission, published, {}) &&
                      originalPeerOwner->scopes->data() != replacementPeer.front().admission->scopes->data() &&
                      originalPeerOwner->scopes->back().providerPath == ownedScopes.back().providerPath,
                  L"Exact-key withdrawal releases the original predecessor while preserving replacement and retained original authority storage.");
    candidateAdmission.relations.predecessorKeys[0] = 43u;
    state.Require(State::HasPublishedOverlapPredecessor(candidateAdmission, published, {}),
                  L"A renewed Queue-after choice names the replacement registration.");
    published = {originalPeer.front(), replacementPeer.front()};
    State::EraseMutationInterlockAdmission(published, 43u);
    state.Require(published.size() == 1u && published.front().admission == originalPeerOwner,
                  L"Refusing a private replacement must withdraw only its key and retain the original snapshot exactly.");
    std::shared_ptr<const FileOperations::PreparationSnapshot> facts;
    if (! state.Require(State::BuildPreparationFacts(501u, FILESYSTEM_MOVE, admission.plans, scopes, 42u, facts) == S_OK && facts && facts->taskId == 501u &&
                            facts->operation == FILESYSTEM_MOVE && facts->selectedRootCount == 1u && facts->scopes.size() == 2u &&
                            facts->strategies.size() == 1u && facts->strategies.front().strategy == FileOperations::OperationStrategy::Native &&
                            facts->selectedRootReadinessUs >= 42u,
                        L"Private preparation facts must describe the supplied admission and scopes without a Task observer."))
        return false;
    auto invalidPlans = admission.plans;
    invalidPlans.emplace_back(FileOperations::DeletePlan{});
    const auto* originalScopeStorage = scopes.data();
    const auto originalScopeRoot     = scopes.front().root;
    const auto originalFacts         = facts;
    state.Require(State::BuildTransferInterlockScopes(invalidPlans, fixture.fsDummy.get(), fixture.fsDummy.get(), FILESYSTEM_MOVE, scopes) == E_INVALIDARG &&
                      scopes.data() == originalScopeStorage && scopes.size() == 2u && scopes.front().root == originalScopeRoot &&
                      State::BuildPreparationFacts(501u, FILESYSTEM_MOVE, {}, scopes, 42u, facts) == E_UNEXPECTED && facts == originalFacts,
                  L"Failed candidate preparation must leave previously accepted scope storage and facts intact.");
    // Drive the production request/queue transaction without executing file mutations.
    auto transactionTask     = std::make_unique<State::Task>(*fixture.fileOps);
    transactionTask->_taskId = fixture.fileOps->AllocateLateQueueOrderKey();
    transactionTask->_admissionKey.store(transactionTask->_taskId, std::memory_order_release);
    transactionTask->_queueOrderKey.store(transactionTask->_taskId, std::memory_order_release);
    transactionTask->_operation   = FILESYSTEM_MOVE;
    transactionTask->_fileSystem  = fixture.fsLocal;
    transactionTask->_sourcePaths = {localSource};
    State::AdmissionDestinationInputs transactionDestination;
    transactionDestination.fileSystem    = fixture.fsLocal;
    transactionDestination.folder        = localDestination;
    transactionDestination.pane          = FolderWindow::Pane::Left;
    transactionDestination.pluginId      = kPluginIdLocal;
    transactionDestination.pluginShortId = L"file";
    transactionTask->InitializeAdmissionInputs(std::make_shared<const FileOperations::FileOperationPlanGroup>(ownedAdmission.plans), transactionDestination);
    transactionTask->InstallPreparedMutationInterlockScopes(ownedScopes, false);
    fixture.fileOps->PublishPreparedMutationInterlock(*transactionTask);
    State::MutationInterlockRelations readyRelations;
    readyRelations.advisoryDecided = true;
    fixture.fileOps->PublishMutationInterlockDecision(*transactionTask, readyRelations);
    transactionTask->_selectedRootReadinessStatus.store(S_OK, std::memory_order_release);
    transactionTask->_selectedRootReadinessComplete.store(true, std::memory_order_release);
    transactionTask->SetWaitForOthers(false);
    const auto originalTransactionView    = transactionTask->LoadSelectedAdmission();
    const uint64_t originalTransactionKey = originalTransactionView->interlock->key;
    std::shared_ptr<const State::SelectedAdmissionView> activeTransactionView;
    const auto cleanTransaction = wil::scope_exit([&]() noexcept
    {
        if (activeTransactionView)
            fixture.fileOps->LeaveOperation(*transactionTask, activeTransactionView);
        const auto pending = transactionTask->_queuedDestinationRequest;
        if (pending)
        {
            if (transactionTask->_queuedDestinationPhase == State::QueuedDestinationPhase::CommitReserved)
                fixture.fileOps->FinishQueuedDestinationCommit(*transactionTask, *pending, E_ABORT);
            else
                fixture.fileOps->AbortQueuedDestinationRequest(*transactionTask, *pending);
        }
        fixture.fileOps->WithdrawPreparedMutationInterlock(transactionTask->LoadSelectedAdmission()->interlock->key);
    });
    state.Require(fixture.fileOps->RequestQueuedDestinationChange(*transactionTask, originalTransactionKey, transactionDestination) == S_FALSE,
                  L"An identical captured destination is a no-op, not a replacement generation.");
    transactionDestination.folder = localReplacement;
    if (! state.Require(fixture.fileOps->RequestQueuedDestinationChange(*transactionTask, originalTransactionKey, transactionDestination) == S_OK &&
                            fixture.fileOps->RequestQueuedDestinationChange(*transactionTask, originalTransactionKey, transactionDestination) ==
                                HRESULT_FROM_WIN32(ERROR_BUSY) &&
                            fixture.fileOps->RequestQueuedDestinationChange(*transactionTask, originalTransactionKey + 1000u, transactionDestination) ==
                                HRESULT_FROM_WIN32(ERROR_REVISION_MISMATCH),
                        L"The actual request gate must claim one candidate and refuse duplicate/stale menu requests."))
        return false;
    auto transactionEntry = fixture.fileOps->EnterOperation(*transactionTask, {});
    if (! state.Require(transactionEntry.outcome == State::OperationEntryOutcome::Reprepare && transactionEntry.request && ! transactionEntry.accepted &&
                            transactionEntry.request->original == originalTransactionView &&
                            transactionTask->LoadSelectedAdmission() == originalTransactionView,
                        L"The scheduler must yield its existing worker to private preparation without selecting the candidate."))
        return false;
    const auto prepareKernelCandidate = [&](const std::shared_ptr<const State::QueuedDestinationRequest>& request,
                                            bool originalTarget) -> std::shared_ptr<const State::SelectedAdmissionView>
    {
        auto view         = std::make_shared<State::SelectedAdmissionView>();
        view->destination = std::make_shared<const State::AdmissionDestinationInputs>(request->destination);
        view->plans       = std::make_shared<const FileOperations::FileOperationPlanGroup>(originalTarget ? ownedAdmission.plans : replacementAdmission.plans);
        auto registration = std::make_shared<State::MutationInterlockAdmission>();
        registration->key = request->candidateKey;
        registration->scopes = originalTarget ? originalPeerOwner->scopes : replacementPeer.front().admission->scopes;
        view->interlock      = registration;
        if (FAILED(State::BuildPreparationFacts(transactionTask->_taskId, FILESYSTEM_MOVE, *view->plans, *registration->scopes, 0u, view->preparation)))
            return {};
        return view;
    };
    const auto decideKernelCandidate =
        [](const std::shared_ptr<const State::SelectedAdmissionView>& tentative) -> std::shared_ptr<const State::SelectedAdmissionView>
    {
        auto view                               = std::make_shared<State::SelectedAdmissionView>(*tentative);
        auto registration                       = std::make_shared<State::MutationInterlockAdmission>(*tentative->interlock);
        registration->relations.advisoryDecided = true;
        view->interlock                         = std::move(registration);
        return view;
    };
    auto transactionCandidate = prepareKernelCandidate(transactionEntry.request, false);
    if (! state.Require(transactionCandidate &&
                            fixture.fileOps->PublishQueuedDestinationCandidate(*transactionTask, *transactionEntry.request, transactionCandidate) == S_OK,
                        L"Tentative canonical scopes must be published separately from the selected admission."))
        return false;
    transactionTask->SetDesiredSpeedLimit(456789u);
    const uint64_t retainedOrder = transactionTask->GetQueueOrderKey();
    if (! state.Require(
            fixture.fileOps->ReserveQueuedDestinationCommit(*transactionTask, *transactionEntry.request, decideKernelCandidate(transactionCandidate)) == S_OK,
            L"A completely prepared candidate must reserve before durable replacement."))
        return false;
    fixture.fileOps->FinishQueuedDestinationCommit(*transactionTask, *transactionEntry.request, HRESULT_FROM_WIN32(ERROR_WRITE_FAULT));
    state.Require(transactionTask->LoadSelectedAdmission() == originalTransactionView && transactionTask->GetQueueOrderKey() == retainedOrder &&
                      transactionTask->_desiredSpeedLimitBytesPerSecond.load(std::memory_order_acquire) == 456789u && ! transactionTask->IsWaitingForOthers() &&
                      ! transactionTask->_queuedDestinationRequest && transactionTask->_queuedDestinationPhase == State::QueuedDestinationPhase::None,
                  L"Failed durable settlement must preserve original selection, live controls and order while releasing only the candidate.");
    if (! state.Require(fixture.fileOps->RequestQueuedDestinationChange(*transactionTask, originalTransactionKey, transactionDestination) == S_OK,
                        L"A refusal must release the bounded request slot for another attempt."))
        return false;
    transactionEntry = fixture.fileOps->EnterOperation(*transactionTask, {});
    if (! state.Require(transactionEntry.outcome == State::OperationEntryOutcome::Reprepare && transactionEntry.request,
                        L"The same worker must accept another preparation request after refusal."))
        return false;
    transactionCandidate = prepareKernelCandidate(transactionEntry.request, false);
    if (! state.Require(transactionCandidate &&
                            fixture.fileOps->PublishQueuedDestinationCandidate(*transactionTask, *transactionEntry.request, transactionCandidate) == S_OK &&
                            fixture.fileOps->ReserveQueuedDestinationCommit(
                                *transactionTask, *transactionEntry.request, decideKernelCandidate(transactionCandidate)) == S_OK,
                        L"The successful candidate must pass actual publication and reservation."))
        return false;
    fixture.fileOps->FinishQueuedDestinationCommit(*transactionTask, *transactionEntry.request, S_OK);
    const auto committedTransactionView = transactionTask->LoadSelectedAdmission();
    state.Require(committedTransactionView != originalTransactionView && committedTransactionView->interlock->key == transactionEntry.request->candidateKey &&
                      committedTransactionView->destination->folder == localReplacement && originalTransactionView->destination->folder == localDestination,
                  L"Successful settlement atomically selects the new immutable destination and preserves retained old readers.");
    transactionEntry      = fixture.fileOps->EnterOperation(*transactionTask, {});
    activeTransactionView = transactionEntry.accepted;
    if (! state.Require(transactionEntry.outcome == State::OperationEntryOutcome::Entered && activeTransactionView == committedTransactionView &&
                            fixture.fileOps->RequestQueuedDestinationChange(
                                *transactionTask, committedTransactionView->interlock->key, transactionDestination) == HRESULT_FROM_WIN32(ERROR_BUSY),
                        L"Queue activation must pin the accepted owner and reject re-admission even before HasEnteredOperation is published."))
        return false;
    fixture.fileOps->LeaveOperation(*transactionTask, activeTransactionView);
    activeTransactionView.reset();

    // Publish the same immutable owner again to exercise cancellation at the reservation boundary.
    // This private fixture never invokes ExecuteOperation or publishes a terminal task.
    fixture.fileOps->PublishPreparedMutationInterlock(*transactionTask);
    transactionDestination.folder = localDestination;
    if (! state.Require(fixture.fileOps->RequestQueuedDestinationChange(*transactionTask, committedTransactionView->interlock->key, transactionDestination) ==
                            S_OK,
                        L"Cancellation-boundary fixture must claim its queued replacement."))
        return false;
    transactionEntry = fixture.fileOps->EnterOperation(*transactionTask, {});
    if (! state.Require(transactionEntry.outcome == State::OperationEntryOutcome::Reprepare && transactionEntry.request,
                        L"Cancellation-boundary fixture must reach private preparation."))
        return false;
    transactionCandidate = prepareKernelCandidate(transactionEntry.request, true);
    if (! state.Require(transactionCandidate &&
                            fixture.fileOps->PublishQueuedDestinationCandidate(*transactionTask, *transactionEntry.request, transactionCandidate) == S_OK &&
                            fixture.fileOps->ReserveQueuedDestinationCommit(
                                *transactionTask, *transactionEntry.request, decideKernelCandidate(transactionCandidate)) == S_OK,
                        L"Cancellation-boundary fixture must reserve a complete candidate."))
        return false;
    transactionTask->RequestCancel();
    fixture.fileOps->FinishQueuedDestinationCommit(*transactionTask, *transactionEntry.request, S_OK);
    const auto cancelledCommitted = transactionTask->LoadSelectedAdmission();
    state.Require(cancelledCommitted->interlock->key == transactionEntry.request->candidateKey && cancelledCommitted->destination->folder == localDestination &&
                      transactionTask->_cancelled.load(std::memory_order_acquire) && ! transactionTask->_queuedDestinationRequest &&
                      fixture.fileOps->EnterOperation(*transactionTask, {}).outcome == State::OperationEntryOutcome::Cancelled,
                  L"Cancellation after successful durable replacement must select the replacement before terminal cancellation can retire it.");

    wil::com_ptr<IFileSystemIO> realRetargetIo;
    if (! state.Require(SUCCEEDED(fixture.fsLocal->QueryInterface(IID_PPV_ARGS(realRetargetIo.addressof()))) && realRetargetIo,
                        L"Real retarget witnesses require local provider byte reads."))
        return false;
    const auto makeRealQueuedMove = [&](const std::filesystem::path& source, const std::filesystem::path& destination) -> std::unique_ptr<State::Task>
    {
        auto input              = ownedConstruction;
        input.sourcePaths       = {source};
        input.destinationFolder = destination;
        input.moveClipboardSequence.reset();
        State::OperationAdmission realAdmission;
        if (State::BuildOperationAdmission(input, realAdmission) != S_OK)
            return {};
        auto task     = std::make_unique<State::Task>(*fixture.fileOps);
        task->_taskId = fixture.fileOps->AllocateLateQueueOrderKey();
        task->_admissionKey.store(task->_taskId, std::memory_order_release);
        task->_queueOrderKey.store(task->_taskId, std::memory_order_release);
        task->_operation                = FILESYSTEM_MOVE;
        task->_sourcePane               = input.sourcePane;
        task->_fileSystem               = fixture.fsLocal;
        task->_sourcePaths              = input.sourcePaths;
        task->_sourcePluginId           = input.sourcePluginId;
        task->_sourcePluginShortId      = input.sourcePluginShortId;
        task->_sourceInstanceContext    = input.sourceInstanceContext;
        task->_flags                    = input.flags;
        task->_executionMode            = State::ExecutionMode::PerItem;
        task->_sourcePathAttributesHint = {GetFileAttributesW(source.c_str())};
        State::AdmissionDestinationInputs destinationInput;
        destinationInput.fileSystem      = fixture.fsLocal;
        destinationInput.folder          = destination;
        destinationInput.pane            = input.destinationPane;
        destinationInput.pluginId        = input.destinationPluginId;
        destinationInput.pluginShortId   = input.destinationPluginShortId;
        destinationInput.instanceContext = input.destinationInstanceContext;
        task->InitializeAdmissionInputs(std::make_shared<const FileOperations::FileOperationPlanGroup>(std::move(realAdmission.plans)),
                                        std::move(destinationInput));
        task->InitializeSourceItemResultBuilders();
        const HRESULT prepareHr = task->PrepareForExecution();
        if (FAILED(prepareHr))
        {
            fixture.fileOps->WithdrawPreparedMutationInterlock(task->_taskId);
            return {};
        }
        task->_selectedRootReadinessStatus.store(S_OK, std::memory_order_release);
        task->_selectedRootReadinessComplete.store(true, std::memory_order_release);
        task->SetWaitForOthers(false);
        if (FAILED(task->CreateMoveBreadcrumbAfterAcceptance()))
        {
            fixture.fileOps->WithdrawPreparedMutationInterlock(task->_taskId);
            return {};
        }
        return task;
    };
    const auto cleanRealQueuedMove = [&](State::Task& task) noexcept
    {
        const auto pending = task._queuedDestinationRequest;
        if (pending)
        {
            if (task._queuedDestinationPhase == State::QueuedDestinationPhase::CommitReserved)
                fixture.fileOps->FinishQueuedDestinationCommit(task, *pending, E_ABORT);
            else
                fixture.fileOps->AbortQueuedDestinationRequest(task, *pending);
        }
        fixture.fileOps->WithdrawPreparedMutationInterlock(task.LoadSelectedAdmission()->interlock->key);
        if (task._moveBreadcrumb.has_value())
            static_cast<void>(task._moveBreadcrumb->Finalize());
    };

    {
        // Pause the real worker-owned Process call only after its durable replacement succeeds.
        const auto durableWitnessRoot = root / L"real-retarget-durable";
        const auto durableOldFolder   = durableWitnessRoot / L"old";
        const auto durableNewFolder   = durableWitnessRoot / L"new";
        const auto durableSource      = durableWitnessRoot / L"source.txt";
        if (! state.Require(RecreateEmptyDirectory(durableWitnessRoot) && RecreateEmptyDirectory(durableOldFolder) &&
                                RecreateEmptyDirectory(durableNewFolder) && SelfTest::WriteTextFile(durableSource, "durable-source-unchanged"),
                            L"Real durable retarget witness must create isolated governed files."))
            return false;
        auto durableTask = makeRealQueuedMove(durableSource, durableOldFolder);
        if (! state.Require(durableTask && durableTask->_moveBreadcrumb.has_value(), L"Real queued Move must prepare and persist its initial breadcrumb."))
            return false;
        const auto durableCleanup        = wil::scope_exit([&]() noexcept { cleanRealQueuedMove(*durableTask); });
        const auto durableOriginal       = durableTask->LoadSelectedAdmission();
        const auto durableRecordOriginal = durableTask->_moveBreadcrumb->GetRecord();
        const auto durablePath           = durableTask->_moveBreadcrumb->GetPath();
        std::string durableOldBytes;
        if (! state.Require(
                SUCCEEDED(FileOperationDurableStore::ReadBoundedRegularFile(durablePath, FileOperationMoveBreadcrumb::kMaximumRecordBytes, durableOldBytes)),
                L"Real Move witness must read its initial durable bytes."))
            return false;
        auto durableDestination   = *durableOriginal->destination;
        durableDestination.folder = durableNewFolder;
        if (! state.Require(fixture.fileOps->RequestQueuedDestinationChange(*durableTask, durableOriginal->interlock->key, durableDestination) == S_OK,
                            L"Real Move witness must claim its destination request through the production gate."))
            return false;
        const auto durableEntry = fixture.fileOps->EnterOperation(*durableTask, {});
        if (! state.Require(durableEntry.outcome == State::OperationEntryOutcome::Reprepare && durableEntry.request,
                            L"Real Move witness must use the scheduler's reprepare outcome."))
            return false;
        SetFileOpsQueuedRetargetDurableCommitPauseForSelfTest(true);
        std::atomic<HRESULT> durableProcessHr{E_PENDING};
        std::jthread durableWorker([&](std::stop_token) noexcept
        { durableProcessHr.store(durableTask->ProcessQueuedDestinationRequest(durableEntry.request), std::memory_order_release); });
        const auto durableRelease       = wil::scope_exit([]() noexcept
        {
            ReleaseFileOpsQueuedRetargetDurableCommitPauseForSelfTest();
            SetFileOpsQueuedRetargetDurableCommitPauseForSelfTest(false);
        });
        const ULONGLONG durableDeadline = GetTickCount64() + 5'000ull;
        while (! HasFileOpsQueuedRetargetDurableCommitPauseEnteredForSelfTest() && durableProcessHr.load(std::memory_order_acquire) == E_PENDING &&
               GetTickCount64() < durableDeadline)
            Sleep(1);
        const bool durablePaused = HasFileOpsQueuedRetargetDurableCommitPauseEnteredForSelfTest();
        FileOperationMoveBreadcrumb::Record durableDuringPause;
        std::string durableNewBytes;
        const bool durableAlreadyReplaced =
            durablePaused && SUCCEEDED(FileOperationMoveBreadcrumb::Breadcrumb::Load(durablePath, durableDuringPause)) &&
            SUCCEEDED(FileOperationDurableStore::ReadBoundedRegularFile(durablePath, FileOperationMoveBreadcrumb::kMaximumRecordBytes, durableNewBytes)) &&
            durableNewBytes != durableOldBytes && durableDuringPause.destination.representativePath == durableNewFolder.native() &&
            durableDuringPause.taskId == durableRecordOriginal.taskId && durableDuringPause.createdFileTime == durableRecordOriginal.createdFileTime &&
            durableDuringPause.phase == FileOperationMoveBreadcrumb::DurablePhase::Admitted && durableTask->LoadSelectedAdmission() == durableOriginal;
        durableTask->RequestCancel();
        ReleaseFileOpsQueuedRetargetDurableCommitPauseForSelfTest();
        SetFileOpsQueuedRetargetDurableCommitPauseForSelfTest(false);
        durableWorker.join();
        const auto durableCommitted = durableTask->LoadSelectedAdmission();
        std::string durableSourceBytes;
        std::error_code durableExistsError;
        const bool durableNoMutation = ReadFileTextFsIo(realRetargetIo, durableSource, durableSourceBytes) &&
                                       durableSourceBytes == "durable-source-unchanged" &&
                                       ! std::filesystem::exists(durableOldFolder / durableSource.filename(), durableExistsError) && ! durableExistsError &&
                                       ! std::filesystem::exists(durableNewFolder / durableSource.filename(), durableExistsError) && ! durableExistsError;
        if (! state.Require(durableAlreadyReplaced && durableProcessHr.load(std::memory_order_acquire) == S_OK &&
                                durableCommitted->interlock->key == durableEntry.request->candidateKey &&
                                durableCommitted->destination->folder == durableNewFolder && durableTask->_moveBreadcrumb->GetPath() == durablePath &&
                                durableTask->_cancelled.load(std::memory_order_acquire) && ! durableTask->_queuedDestinationRequest && durableNoMutation &&
                                fixture.fileOps->EnterOperation(*durableTask, {}).outcome == State::OperationEntryOutcome::Cancelled,
                            L"A real successful durable Move replacement must select its new generation despite Cancel before Finish, without executing either "
                            L"destination."))
            return false;
    }

    for (const bool replaceBeforePreparation : {true, false})
    {
        const auto sourceWitnessRoot    = root / (replaceBeforePreparation ? L"real-retarget-source-before" : L"real-retarget-source-after");
        const auto sourceOldFolder      = sourceWitnessRoot / L"old";
        const auto sourceNewFolder      = sourceWitnessRoot / L"new";
        const auto originalSourcePath   = sourceWitnessRoot / L"selected.txt";
        const auto retainedOriginalPath = sourceWitnessRoot / L"renamed-original.txt";
        if (! state.Require(RecreateEmptyDirectory(sourceWitnessRoot) && RecreateEmptyDirectory(sourceOldFolder) && RecreateEmptyDirectory(sourceNewFolder) &&
                                SelfTest::WriteTextFile(originalSourcePath, "original-selected-object"),
                            L"Source-identity witness must create its private original source."))
            return false;
        auto sourceTask = makeRealQueuedMove(originalSourcePath, sourceOldFolder);
        if (! state.Require(sourceTask != nullptr, L"Source-identity witness must admit its real queued Move."))
            return false;
        const auto sourceCleanup  = wil::scope_exit([&]() noexcept { cleanRealQueuedMove(*sourceTask); });
        const auto sourceOriginal = sourceTask->LoadSelectedAdmission();
        const auto originalScope  = std::ranges::find_if(*sourceOriginal->interlock->scopes, [&](const auto& scope) noexcept {
            return scope.providerPath == originalSourcePath.native() && scope.root && scope.root->retained.providerPath == originalSourcePath.native();
        });
        if (! state.Require(originalScope != sourceOriginal->interlock->scopes->end() && originalScope->root->retained.authority.boundObject,
                            L"Source-identity witness must retain a real selected-source authority."))
            return false;
        const auto originalAuthority      = originalScope->root;
        const auto originalBreadcrumbPath = sourceTask->_moveBreadcrumb->GetPath();
        std::string sourceOriginalBreadcrumb;
        if (! state.Require(SUCCEEDED(FileOperationDurableStore::ReadBoundedRegularFile(
                                originalBreadcrumbPath, FileOperationMoveBreadcrumb::kMaximumRecordBytes, sourceOriginalBreadcrumb)),
                            L"Source-identity witness must retain its original durable bytes."))
            return false;
        const auto replaceSource = [&]() noexcept
        {
            return MoveFileExW(originalSourcePath.c_str(), retainedOriginalPath.c_str(), 0u) != FALSE &&
                   SelfTest::WriteTextFile(originalSourcePath, "replacement-must-survive");
        };
        if (replaceBeforePreparation && ! state.Require(replaceSource(), L"The before-preparation witness must replace the queued source pathname."))
            return false;
        auto sourceDestination   = *sourceOriginal->destination;
        sourceDestination.folder = sourceNewFolder;
        if (! state.Require(fixture.fileOps->RequestQueuedDestinationChange(*sourceTask, sourceOriginal->interlock->key, sourceDestination) == S_OK,
                            L"Source-identity witness must request its destination through the real gate."))
            return false;
        const auto sourceEntry = fixture.fileOps->EnterOperation(*sourceTask, {});
        if (! state.Require(sourceEntry.outcome == State::OperationEntryOutcome::Reprepare && sourceEntry.request,
                            L"Source-identity witness must reach production preparation."))
            return false;
        std::atomic<HRESULT> sourceProcessHr{E_PENDING};
        std::atomic<HRESULT> sourceExecutionHr{E_PENDING};
        std::atomic<bool> sourcePrepared{false};
        std::atomic<bool> sourceMutationReleased{false};
        std::atomic<bool> sourceWorkerDone{false};
        bool sourceAuthorityRetained = false;
        std::jthread sourceWorker([&](std::stop_token) noexcept
        {
            const HRESULT preparedHr = sourceTask->ProcessQueuedDestinationRequest(sourceEntry.request);
            sourceProcessHr.store(preparedHr, std::memory_order_release);
            if (SUCCEEDED(preparedHr) && ! replaceBeforePreparation)
            {
                // Fixture-only gate on the same worker; no production scheduling seam is changed.
                sourcePrepared.store(true, std::memory_order_release);
                sourceMutationReleased.wait(false, std::memory_order_acquire);
                const auto entered = fixture.fileOps->EnterOperation(*sourceTask, {});
                if (entered.outcome == State::OperationEntryOutcome::Entered && entered.accepted)
                {
                    const auto selectedSource = std::ranges::find_if(*entered.accepted->interlock->scopes, [&](const auto& scope) noexcept {
                        return scope.providerPath == originalSourcePath.native() && scope.root == originalAuthority;
                    });
                    sourceAuthorityRetained   = selectedSource != entered.accepted->interlock->scopes->end();
                    sourceExecutionHr.store(sourceTask->ExecuteOperation(entered.accepted), std::memory_order_release);
                    fixture.fileOps->LeaveOperation(*sourceTask, entered.accepted);
                }
            }
            sourceWorkerDone.store(true, std::memory_order_release);
        });
        const auto sourceRelease              = wil::scope_exit([&]() noexcept
        {
            sourceMutationReleased.store(true, std::memory_order_release);
            sourceMutationReleased.notify_all();
        });
        const ULONGLONG sourcePrepareDeadline = GetTickCount64() + 5'000ull;
        while (! sourcePrepared.load(std::memory_order_acquire) && ! sourceWorkerDone.load(std::memory_order_acquire) &&
               GetTickCount64() < sourcePrepareDeadline)
            Sleep(1);
        const bool preparedBeforeReplacement = replaceBeforePreparation || sourcePrepared.load(std::memory_order_acquire);
        const bool replacementCreated        = replaceBeforePreparation || (preparedBeforeReplacement && replaceSource());
        sourceMutationReleased.store(true, std::memory_order_release);
        sourceMutationReleased.notify_all();
        const ULONGLONG sourceExecutionDeadline = GetTickCount64() + 5'000ull;
        while (! sourceWorkerDone.load(std::memory_order_acquire) && GetTickCount64() < sourceExecutionDeadline)
            Sleep(1);
        const bool sourceCompletedWithoutForcedCancel = sourceWorkerDone.load(std::memory_order_acquire);
        if (! sourceCompletedWithoutForcedCancel)
            sourceTask->RequestCancel();
        sourceWorker.join();
        std::string retainedOriginalBytes;
        std::string replacementSourceBytes;
        std::string sourceFinalBreadcrumb;
        std::error_code sourceExistsError;
        const bool unchangedObjects = replacementCreated && ReadFileTextFsIo(realRetargetIo, retainedOriginalPath, retainedOriginalBytes) &&
                                      retainedOriginalBytes == "original-selected-object" &&
                                      ReadFileTextFsIo(realRetargetIo, originalSourcePath, replacementSourceBytes) &&
                                      replacementSourceBytes == "replacement-must-survive" &&
                                      ! std::filesystem::exists(sourceOldFolder / originalSourcePath.filename(), sourceExistsError) && ! sourceExistsError &&
                                      ! std::filesystem::exists(sourceNewFolder / originalSourcePath.filename(), sourceExistsError) && ! sourceExistsError;
        if (replaceBeforePreparation)
        {
            state.Require(
                sourceCompletedWithoutForcedCancel && sourceProcessHr.load(std::memory_order_acquire) == HRESULT_FROM_WIN32(ERROR_REVISION_MISMATCH) &&
                    sourceTask->LoadSelectedAdmission() == sourceOriginal && ! sourceTask->_cancelled.load(std::memory_order_acquire) &&
                    ! sourceTask->_queuedDestinationRequest &&
                    SUCCEEDED(FileOperationDurableStore::ReadBoundedRegularFile(
                        originalBreadcrumbPath, FileOperationMoveBreadcrumb::kMaximumRecordBytes, sourceFinalBreadcrumb)) &&
                    sourceFinalBreadcrumb == sourceOriginalBreadcrumb && unchangedObjects,
                L"Source replacement before preparation must refuse the real retarget and preserve the original selected owner and exact durable bytes.");
        }
        else
        {
            const auto selected = sourceTask->LoadSelectedAdmission();
            state.Require(sourceCompletedWithoutForcedCancel && preparedBeforeReplacement && sourceProcessHr.load(std::memory_order_acquire) == S_OK &&
                              sourceAuthorityRetained && selected->interlock->key == sourceEntry.request->candidateKey &&
                              selected->destination->folder == sourceNewFolder &&
                              sourceExecutionHr.load(std::memory_order_acquire) == HRESULT_FROM_WIN32(ERROR_REVISION_MISMATCH) && unchangedObjects,
                          L"Source replacement after successful retarget must be rejected by real execution using the retained original authority, without "
                          L"publishing or deleting either object.");
        }
    }

    const auto makeMappedCopy = [&](State::OperationConstruction captured) -> std::unique_ptr<State::Task>
    {
        State::OperationAdmission admitted;
        if (State::BuildOperationAdmission(captured, admitted) != S_OK)
            return {};
        auto task     = std::make_unique<State::Task>(*fixture.fileOps);
        task->_taskId = fixture.fileOps->AllocateLateQueueOrderKey();
        task->_admissionKey.store(task->_taskId, std::memory_order_release);
        task->_queueOrderKey.store(task->_taskId, std::memory_order_release);
        task->_operation             = captured.operation;
        task->_sourcePane            = captured.sourcePane;
        task->_fileSystem            = captured.fileSystem;
        task->_sourcePaths           = captured.sourcePaths;
        task->_sourcePluginId        = captured.sourcePluginId;
        task->_sourcePluginShortId   = captured.sourcePluginShortId;
        task->_sourceInstanceContext = captured.sourceInstanceContext;
        task->_flags                 = captured.flags;
        task->_executionMode         = State::ExecutionMode::PerItem;
        State::AdmissionDestinationInputs destination;
        destination.fileSystem      = captured.destinationFileSystem;
        destination.folder          = captured.destinationFolder;
        destination.pane            = captured.destinationPane;
        destination.pluginId        = captured.destinationPluginId;
        destination.pluginShortId   = captured.destinationPluginShortId;
        destination.instanceContext = captured.destinationInstanceContext;
        destination.resolvedItems   = std::move(admitted.resolvedItems);
        task->InitializeAdmissionInputs(std::make_shared<const FileOperations::FileOperationPlanGroup>(std::move(admitted.plans)), std::move(destination));
        task->InitializeSourceItemResultBuilders();
        const HRESULT prepared = task->PrepareForExecution();
        if (FAILED(prepared))
        {
            fixture.fileOps->WithdrawPreparedMutationInterlock(task->_taskId);
            return {};
        }
        task->_selectedRootReadinessStatus.store(S_OK, std::memory_order_release);
        task->_selectedRootReadinessComplete.store(true, std::memory_order_release);
        task->SetWaitForOthers(false);
        return task;
    };
    {
        const auto mappingRoot         = root / L"real-retarget-mappings";
        const auto mappingSourceRoot   = mappingRoot / L"source";
        const auto mappingNestedSource = mappingSourceRoot / L"nested-source";
        const auto mappingOldRoot      = mappingRoot / L"old";
        const auto mappingNewRoot      = mappingRoot / L"new";
        const auto sourceZ             = mappingSourceRoot / L"z-selected.txt";
        const auto sourceA             = mappingSourceRoot / L"a-selected.txt";
        if (! state.Require(RecreateEmptyDirectory(mappingRoot) && RecreateEmptyDirectory(mappingSourceRoot) && RecreateEmptyDirectory(mappingNestedSource) &&
                                RecreateEmptyDirectory(mappingOldRoot) && RecreateEmptyDirectory(mappingNewRoot) &&
                                SelfTest::WriteTextFile(sourceZ, "mapping-z-source") && SelfTest::WriteTextFile(sourceA, "mapping-a-source"),
                            L"Explicit mapping witness must create isolated real local roots and sources."))
            return false;
        auto mappedConstruction      = ownedConstruction;
        mappedConstruction.operation = FILESYSTEM_COPY;
        mappedConstruction.moveClipboardSequence.reset();
        mappedConstruction.options.verifyAfterCopy = false;
        mappedConstruction.sourcePaths             = {sourceZ, mappingSourceRoot, sourceA, mappingNestedSource};
        mappedConstruction.destinationFolder       = mappingOldRoot;
        // Preserve intentional result order, renamed leaves, flags, and both root/nested shells.
        mappedConstruction.resolvedItems = {
            {sourceZ,
             mappingOldRoot / L"nest" / L"deeper" / L"renamed-z.txt",
             FILESYSTEM_FLAG_ALLOW_OVERWRITE,
             FolderWindow::ResolvedFileOperationItemKind::Normal},
            {mappingSourceRoot, mappingOldRoot, FILESYSTEM_FLAG_NONE, FolderWindow::ResolvedFileOperationItemKind::DirectoryShell},
            {sourceA, mappingOldRoot / L"renamed-a.txt", FILESYSTEM_FLAG_CONTINUE_ON_ERROR, FolderWindow::ResolvedFileOperationItemKind::Normal},
            {mappingNestedSource, mappingOldRoot / L"nest" / L"deeper", FILESYSTEM_FLAG_NONE, FolderWindow::ResolvedFileOperationItemKind::DirectoryShell},
        };
        auto mappingTask = makeMappedCopy(mappedConstruction);
        if (! state.Require(mappingTask != nullptr, L"Nested/root DirectoryShell mappings must pass canonical initial construction and preparation."))
            return false;
        const auto mappingCleanup  = wil::scope_exit([&]() noexcept { cleanRealQueuedMove(*mappingTask); });
        const auto mappedOriginal  = mappingTask->LoadSelectedAdmission();
        const uint64_t mappedOrder = mappingTask->GetQueueOrderKey();
        mappingTask->SetDesiredSpeedLimit(765432u);
        auto newMappingDestination   = *mappedOriginal->destination;
        newMappingDestination.folder = mappingNewRoot;
        newMappingDestination.resolvedItems.clear(); // Request inputs carry no caller-written mappings.
        if (! state.Require(fixture.fileOps->RequestQueuedDestinationChange(*mappingTask, mappedOriginal->interlock->key, newMappingDestination) == S_OK,
                            L"Explicit mapping retarget must use the real request gate."))
            return false;
        const auto mappingEntry = fixture.fileOps->EnterOperation(*mappingTask, {});
        if (! state.Require(mappingEntry.outcome == State::OperationEntryOutcome::Reprepare && mappingEntry.request,
                            L"Explicit mapping retarget must use the scheduler's preparation outcome."))
            return false;
        std::atomic<HRESULT> mappingProcessHr{E_PENDING};
        std::jthread mappingWorker([&](std::stop_token) noexcept
        { mappingProcessHr.store(mappingTask->ProcessQueuedDestinationRequest(mappingEntry.request), std::memory_order_release); });
        const ULONGLONG mappingDeadline = GetTickCount64() + 5'000ull;
        while (mappingProcessHr.load(std::memory_order_acquire) == E_PENDING && GetTickCount64() < mappingDeadline)
            Sleep(1);
        if (mappingProcessHr.load(std::memory_order_acquire) == E_PENDING)
            mappingTask->RequestCancel();
        mappingWorker.join();
        const auto mappedSelected = mappingTask->LoadSelectedAdmission();
        if (! state.Require(mappedSelected && mappedSelected->plans && ! mappedSelected->plans->empty() && mappedOriginal->plans &&
                                ! mappedOriginal->plans->empty(),
                            L"Mapping preparation must retain an inspectable selected plan on both success and refusal."))
            return false;
        const std::array<std::filesystem::path, 4u> expectedMappedDestinations{
            mappingNewRoot / L"nest" / L"deeper" / L"renamed-z.txt", mappingNewRoot, mappingNewRoot / L"renamed-a.txt", mappingNewRoot / L"nest" / L"deeper"};
        bool mappingIntentPreserved    = mappingProcessHr.load(std::memory_order_acquire) == S_OK && mappedSelected->plans &&
                                         mappedSelected->interlock->key == mappingEntry.request->candidateKey &&
                                         mappedSelected->destination->folder == mappingNewRoot &&
                                         mappedSelected->destination->resolvedItems.size() == expectedMappedDestinations.size() &&
                                         mappingTask->_sourcePaths == mappedConstruction.sourcePaths && mappingTask->GetQueueOrderKey() == mappedOrder &&
                                         mappingTask->_desiredSpeedLimitBytesPerSecond.load(std::memory_order_acquire) == 765432u;
        size_t flattenedIndex          = 0u;
        const auto* originalMappedPlan = std::get_if<FileOperations::TransferPlan>(&mappedOriginal->plans->front());
        for (const auto& plan : *mappedSelected->plans)
        {
            const auto* mappedTransfer = std::get_if<FileOperations::TransferPlan>(&plan);
            if (! mappedTransfer || ! mappedTransfer->sourceEndpoint.pathIdentity || ! mappedTransfer->destinationEndpoint.pathIdentity)
            {
                mappingIntentPreserved = false;
                break;
            }
            mappingIntentPreserved = mappingIntentPreserved && originalMappedPlan &&
                                     FileOperations::QualifiedEndpointsHaveSamePathContract(mappedTransfer->sourceEndpoint, originalMappedPlan->sourceEndpoint);
            for (size_t childIndex = 0u; childIndex < mappedTransfer->selectedItems.size(); ++childIndex, ++flattenedIndex)
            {
                if (flattenedIndex >= expectedMappedDestinations.size() || flattenedIndex >= mappedSelected->destination->resolvedItems.size())
                {
                    mappingIntentPreserved = false;
                    break;
                }
                std::wstring actualDestination;
                const auto& mapped          = mappedSelected->destination->resolvedItems[flattenedIndex];
                const auto& originalMapping = mappedConstruction.resolvedItems[flattenedIndex];
                mappingIntentPreserved =
                    mappingIntentPreserved && mappedTransfer->selectedItems[childIndex].providerPath == originalMapping.sourcePath.native() &&
                    FileOperations::TryResolveTransferDestinationProviderPath(*mappedTransfer, childIndex, actualDestination) &&
                    EquivalentPath(
                        mappedTransfer->destinationEndpoint.pathIdentity.value(), actualDestination, expectedMappedDestinations[flattenedIndex].native()) &&
                    mapped.sourcePath == originalMapping.sourcePath && mapped.destinationPath == expectedMappedDestinations[flattenedIndex] &&
                    mapped.kind == originalMapping.kind && mapped.flags == originalMapping.flags;
            }
        }
        std::string mappingSourceZBytes;
        std::string mappingSourceABytes;
        std::error_code mappingEmptyError;
        state.Require(mappingIntentPreserved && flattenedIndex == expectedMappedDestinations.size() && mappedOriginal->destination->folder == mappingOldRoot &&
                          mappedOriginal->destination->resolvedItems[1].destinationPath == mappingOldRoot &&
                          ReadFileTextFsIo(realRetargetIo, sourceZ, mappingSourceZBytes) && mappingSourceZBytes == "mapping-z-source" &&
                          ReadFileTextFsIo(realRetargetIo, sourceA, mappingSourceABytes) && mappingSourceABytes == "mapping-a-source" &&
                          std::filesystem::is_empty(mappingOldRoot, mappingEmptyError) && ! mappingEmptyError &&
                          std::filesystem::is_empty(mappingNewRoot, mappingEmptyError) && ! mappingEmptyError,
                      L"Real Process must preserve selected-source order, root/nested DirectoryShell kinds, flags and relative renamed mappings without "
                      L"executing files.");
    }
    {
        // Local and Dummy expose the same separator profile. Use a real invalid relative
        // separator witness instead of inventing an executable endpoint descriptor.
        const std::wstring invalidMappingRoot  = std::format(L"/queued-invalid-mapping-{}", fixture.fileOps->AllocateLateQueueOrderKey());
        const std::wstring invalidSourceFolder = invalidMappingRoot + L"/source";
        const std::wstring invalidOldFolder    = invalidMappingRoot + L"/old";
        const std::wstring invalidNewFolder    = invalidMappingRoot + L"/new";
        const std::wstring invalidSourcePath   = invalidSourceFolder + L"/source.txt";
        wil::com_ptr<IFileSystemIO> mappingDummyIo;
        const auto invalidMappingCleanup = wil::scope_exit([&]() noexcept
        { static_cast<void>(fixture.fsDummy->DeleteItem(invalidMappingRoot.c_str(), FILESYSTEM_FLAG_RECURSIVE, nullptr, nullptr, nullptr)); });
        if (! state.Require(
                SUCCEEDED(fixture.fsDummy->QueryInterface(IID_PPV_ARGS(mappingDummyIo.addressof()))) && mappingDummyIo &&
                    EnsureDummyFolderExists(fixture.fsDummy.get(), invalidMappingRoot) && EnsureDummyFolderExists(fixture.fsDummy.get(), invalidSourceFolder) &&
                    EnsureDummyFolderExists(fixture.fsDummy.get(), invalidOldFolder) && EnsureDummyFolderExists(fixture.fsDummy.get(), invalidNewFolder) &&
                    DummyWriteTextFile(fixture.fsDummy.get(), invalidSourcePath, "invalid-mapping-source"),
                L"Invalid-separator witness must use private paths in the actual Dummy provider."))
            return false;
        auto invalidConstruction      = construction;
        invalidConstruction.operation = FILESYSTEM_COPY;
        invalidConstruction.moveClipboardSequence.reset();
        invalidConstruction.options.verifyAfterCopy = false;
        invalidConstruction.sourcePaths             = {std::filesystem::path(invalidSourcePath)};
        invalidConstruction.destinationFolder       = invalidOldFolder;
        invalidConstruction.resolvedItems = {{std::filesystem::path(invalidSourcePath), std::filesystem::path(invalidOldFolder + L"/nested//renamed.txt")}};
        auto invalidTask                  = makeMappedCopy(invalidConstruction);
        if (! state.Require(invalidTask != nullptr, L"The real provider must admit the initial explicit mapping before its retarget refusal is exercised."))
            return false;
        const auto invalidTaskCleanup = wil::scope_exit([&]() noexcept { cleanRealQueuedMove(*invalidTask); });
        const auto invalidOriginal    = invalidTask->LoadSelectedAdmission();
        auto invalidDestination       = *invalidOriginal->destination;
        invalidDestination.folder     = invalidNewFolder;
        invalidDestination.resolvedItems.clear();
        if (! state.Require(fixture.fileOps->RequestQueuedDestinationChange(*invalidTask, invalidOriginal->interlock->key, invalidDestination) == S_OK,
                            L"The invalid-separator witness must use the real queued request gate."))
            return false;
        const auto invalidEntry = fixture.fileOps->EnterOperation(*invalidTask, {});
        if (! state.Require(invalidEntry.outcome == State::OperationEntryOutcome::Reprepare && invalidEntry.request,
                            L"Invalid mapping must reach private canonical preparation."))
            return false;
        std::atomic<HRESULT> invalidProcessHr{E_PENDING};
        std::jthread invalidWorker([&](std::stop_token) noexcept
        { invalidProcessHr.store(invalidTask->ProcessQueuedDestinationRequest(invalidEntry.request), std::memory_order_release); });
        const ULONGLONG invalidDeadline = GetTickCount64() + 5'000ull;
        while (invalidProcessHr.load(std::memory_order_acquire) == E_PENDING && GetTickCount64() < invalidDeadline)
            Sleep(1);
        if (invalidProcessHr.load(std::memory_order_acquire) == E_PENDING)
            invalidTask->RequestCancel();
        invalidWorker.join();
        std::string invalidSourceBytes;
        state.Require(invalidProcessHr.load(std::memory_order_acquire) == HRESULT_FROM_WIN32(ERROR_NOT_SUPPORTED) &&
                          invalidTask->LoadSelectedAdmission() == invalidOriginal && ! invalidTask->_queuedDestinationRequest &&
                          ! invalidTask->_cancelled.load(std::memory_order_acquire) &&
                          ReadFileTextFsIo(mappingDummyIo, invalidSourcePath, invalidSourceBytes) && invalidSourceBytes == "invalid-mapping-source",
                      L"An explicit relative mapping with an empty separator component must refuse retarget without repairing its text or replacing the "
                      L"original admission.");
    }
    // Target the selected admission, after initial item safety checks and immediately
    // before each actual transfer attempt. Unrelated tasks cannot enter this pause.
    for (const unsigned int lateCase : {0u, 1u, 2u, 3u})
    {
        const bool lateMove              = lateCase == 0u;
        const bool lateShell             = lateCase == 2u;
        const auto lateRoot              = root / std::format(L"real-retarget-late-source-{}", lateCase);
        const auto lateOld               = lateRoot / L"old";
        const auto lateNew               = lateRoot / L"new";
        const auto lateSource            = lateRoot / (lateShell ? L"selected-directory" : L"selected.txt");
        const auto lateRetained          = lateRoot / L"retained-original";
        const auto lateSourceBytesPath   = lateShell ? lateSource / L"payload.txt" : lateSource;
        const auto lateRetainedBytesPath = lateShell ? lateRetained / L"payload.txt" : lateRetained;
        if (! state.Require(RecreateEmptyDirectory(lateRoot) && RecreateEmptyDirectory(lateOld) && RecreateEmptyDirectory(lateNew) &&
                                (! lateShell || RecreateEmptyDirectory(lateSource)) && SelfTest::WriteTextFile(lateSourceBytesPath, "late-original-object"),
                            L"Late source witness must create private file or DirectoryShell roots."))
            return false;
        std::unique_ptr<State::Task> lateTask;
        if (lateMove)
        {
            lateTask = makeRealQueuedMove(lateSource, lateOld);
        }
        else
        {
            auto lateConstruction      = ownedConstruction;
            lateConstruction.operation = FILESYSTEM_COPY;
            lateConstruction.moveClipboardSequence.reset();
            lateConstruction.options.verifyAfterCopy = false;
            lateConstruction.sourcePaths             = {lateSource};
            lateConstruction.destinationFolder       = lateOld;
            lateConstruction.resolvedItems.clear();
            if (lateCase == 3u)
                lateConstruction.destinationFileSystem.reset(); // Exercise provider CopyItem without the bridge.
            if (lateShell)
                lateConstruction.resolvedItems = {
                    {lateSource, lateOld / lateSource.filename(), FILESYSTEM_FLAG_NONE, FolderWindow::ResolvedFileOperationItemKind::DirectoryShell}};
            lateTask = makeMappedCopy(lateConstruction);
        }
        if (! state.Require(lateTask != nullptr, L"Late source witness must prepare a canonical Copy, native Move, or DirectoryShell."))
            return false;
        const auto lateCleanup  = wil::scope_exit([&]() noexcept { cleanRealQueuedMove(*lateTask); });
        const auto lateOriginal = lateTask->LoadSelectedAdmission();
        auto lateDestination    = *lateOriginal->destination;
        lateDestination.folder  = lateNew;
        lateDestination.resolvedItems.clear();
        if (! state.Require(fixture.fileOps->RequestQueuedDestinationChange(*lateTask, lateOriginal->interlock->key, lateDestination) == S_OK,
                            L"Late source witness must use the real queued request gate."))
            return false;
        const auto lateEntry = fixture.fileOps->EnterOperation(*lateTask, {});
        if (! state.Require(lateEntry.outcome == State::OperationEntryOutcome::Reprepare && lateEntry.request,
                            L"Late source witness must reach canonical private re-admission."))
            return false;
        SetFileOpsRetargetTransferAttemptPauseForSelfTest(lateEntry.request->candidateKey);
        const auto latePauseCleanup = wil::scope_exit([]() noexcept
        {
            ReleaseFileOpsRetargetTransferAttemptPauseForSelfTest();
            SetFileOpsRetargetTransferAttemptPauseForSelfTest(0u);
        });
        std::atomic<HRESULT> lateProcessHr{E_PENDING};
        std::atomic<HRESULT> lateExecutionHr{E_PENDING};
        std::atomic<bool> lateDone{false};
        std::jthread lateWorker([&](std::stop_token) noexcept
        {
            const HRESULT prepared = lateTask->ProcessQueuedDestinationRequest(lateEntry.request);
            lateProcessHr.store(prepared, std::memory_order_release);
            if (SUCCEEDED(prepared))
            {
                const auto lateAccepted = fixture.fileOps->EnterOperation(*lateTask, {});
                if (lateAccepted.outcome == State::OperationEntryOutcome::Entered && lateAccepted.accepted)
                {
                    lateExecutionHr.store(lateTask->ExecuteOperation(lateAccepted.accepted), std::memory_order_release);
                    fixture.fileOps->LeaveOperation(*lateTask, lateAccepted.accepted);
                }
            }
            lateDone.store(true, std::memory_order_release);
        });
        const ULONGLONG latePauseDeadline = GetTickCount64() + 5'000ull;
        while (! HasFileOpsRetargetTransferAttemptPauseEnteredForSelfTest() && ! lateDone.load(std::memory_order_acquire) &&
               GetTickCount64() < latePauseDeadline)
            Sleep(1);
        const bool latePaused   = HasFileOpsRetargetTransferAttemptPauseEnteredForSelfTest();
        const bool lateReplaced = latePaused && MoveFileExW(lateSource.c_str(), lateRetained.c_str(), 0u) != FALSE &&
                                  (! lateShell || RecreateEmptyDirectory(lateSource)) &&
                                  SelfTest::WriteTextFile(lateSourceBytesPath, "late-replacement-survives");
        ReleaseFileOpsRetargetTransferAttemptPauseForSelfTest();
        SetFileOpsRetargetTransferAttemptPauseForSelfTest(0u);
        const ULONGLONG lateFinishDeadline = GetTickCount64() + 5'000ull;
        while (! lateDone.load(std::memory_order_acquire) && GetTickCount64() < lateFinishDeadline)
            Sleep(1);
        const bool lateCompleted = lateDone.load(std::memory_order_acquire);
        if (! lateCompleted)
            lateTask->RequestCancel();
        lateWorker.join();
        std::string lateOriginalBytes;
        std::string lateReplacementBytes;
        std::error_code lateOutputError;
        state.Require(latePaused && lateReplaced && lateCompleted && lateProcessHr.load(std::memory_order_acquire) == S_OK &&
                          lateExecutionHr.load(std::memory_order_acquire) == HRESULT_FROM_WIN32(ERROR_REVISION_MISMATCH) &&
                          ReadFileTextFsIo(realRetargetIo, lateRetainedBytesPath, lateOriginalBytes) && lateOriginalBytes == "late-original-object" &&
                          ReadFileTextFsIo(realRetargetIo, lateSourceBytesPath, lateReplacementBytes) && lateReplacementBytes == "late-replacement-survives" &&
                          ! std::filesystem::exists(lateOld / lateSource.filename(), lateOutputError) && ! lateOutputError &&
                          ! std::filesystem::exists(lateNew / lateSource.filename(), lateOutputError) && ! lateOutputError,
                      L"A source replaced after the ordinary guard must fail at the selected admission's late attempt check for bridge/native Copy, Move and "
                      L"DirectoryShell, "
                      L"with original and replacement bytes intact and no destination item.");
    }

    admission.confirmationMessage = L"unchanged-output-sentinel";
    construction.resolvedItems    = {{std::filesystem::path(sourcePath), std::filesystem::path(L"/outside/single.txt")}};
    const HRESULT refusedHr       = State::BuildOperationAdmission(construction, admission);
    transfer                      = admission.plans.size() == 1u ? std::get_if<FileOperations::TransferPlan>(&admission.plans.front()) : nullptr;
    std::vector<State::Task*> afterTasks;
    fixture.fileOps->CollectTasks(afterTasks);
    wil::com_ptr<IFileSystemIO> dummyIo;
    std::string sourceBytes;
    std::string destinationBytes;
    state.Require(refusedHr == E_INVALIDARG && transfer && transfer->destination.providerFolderPath == destinationFolder &&
                      transfer->explicitMappings.empty() && admission.confirmationMessage == L"unchanged-output-sentinel" && beforeTasks == afterTasks &&
                      SUCCEEDED(fixture.fsDummy->QueryInterface(IID_PPV_ARGS(dummyIo.addressof()))) && dummyIo &&
                      ReadFileTextFsIo(dummyIo, sourcePath, sourceBytes) && sourceBytes == "unchanged-source" &&
                      ! ReadFileTextFsIo(dummyIo, L"/queued-admission-contracts-destination/single.txt", destinationBytes),
                  L"Rejected explicit mappings must preserve the prior envelope, task set and provider content.");

    FileOperationMoveBreadcrumb::Record record{};
    record.taskId                         = 0x5100u;
    record.admittedStrategies.nativeItems = 1u;
    record.sourceRootCount                = 1u;
    record.sourceRootSamples              = {FileOperationMoveBreadcrumb::QualifiedLocation{.pluginId           = L"builtin/file-system",
                                                                                            .pluginShortId      = L"file",
                                                                                            .instanceId         = L"host/default",
                                                                                            .profileId          = L"local",
                                                                                            .rootId             = L"source-root",
                                                                                            .representativePath = root / L"source.txt"}};
    record.destination                    = FileOperationMoveBreadcrumb::QualifiedLocation{.pluginId           = L"builtin/file-system",
                                                                                           .pluginShortId      = L"file",
                                                                                           .instanceId         = L"host/default",
                                                                                           .profileId          = L"local",
                                                                                           .rootId             = L"destination-root",
                                                                                           .representativePath = root / L"destination"};

    // A queued worker may replace only its own Admitted record. Exercise the same
    // serializer, direct-child store, and existing atomic-write failure seams.
    FileOperationMoveBreadcrumb::Record retargetInput = record;
    retargetInput.taskId                              = 0x5004u;
    FileOperationMoveBreadcrumb::Breadcrumb retarget;
    if (! state.Require(SUCCEEDED(FileOperationMoveBreadcrumb::Breadcrumb::Create(retargetInput, retarget)),
                        L"Queued Move re-admission test must first create a durable Admitted record."))
    {
        return false;
    }
    const std::filesystem::path retargetPath                   = retarget.GetPath();
    const FileOperationMoveBreadcrumb::Record originalAdmitted = retarget.GetRecord();
    std::string originalBytes;
    if (! state.Require(
            SUCCEEDED(FileOperationDurableStore::ReadBoundedRegularFile(retargetPath, FileOperationMoveBreadcrumb::kMaximumRecordBytes, originalBytes)),
            L"Queued Move re-admission test must capture the original durable bytes."))
    {
        return false;
    }

    FileOperationMoveBreadcrumb::Record replacement = originalAdmitted;
    replacement.destination.rootId                  = L"retargeted-root";
    replacement.destination.representativePath      = root / L"retargeted-destination";
    replacement.admittedStrategies.nativeItems      = 4u;
    replacement.admittedStrategies.managedItems     = 2u;
    replacement.admittedStrategies.copyOnlyItems    = 0u;
    FileOperationMoveBreadcrumb::Breadcrumb emptyRetarget;
    state.Require(emptyRetarget.ReplaceAdmittedRecord(replacement) == E_INVALIDARG && emptyRetarget.GetPath().empty(),
                  L"An uninitialized breadcrumb cannot publish a queued replacement.");
    const auto unchanged = [&]() noexcept
    {
        std::string bytes;
        const auto& live = retarget.GetRecord();
        return retarget.GetPath() == retargetPath && live.schemaVersion == originalAdmitted.schemaVersion && live.taskId == originalAdmitted.taskId &&
               live.createdFileTime == originalAdmitted.createdFileTime && live.phase == FileOperationMoveBreadcrumb::DurablePhase::Admitted &&
               live.destination.rootId == originalAdmitted.destination.rootId &&
               live.destination.representativePath == originalAdmitted.destination.representativePath &&
               live.admittedStrategies.nativeItems == originalAdmitted.admittedStrategies.nativeItems &&
               live.admittedStrategies.managedItems == originalAdmitted.admittedStrategies.managedItems &&
               live.admittedStrategies.copyOnlyItems == originalAdmitted.admittedStrategies.copyOnlyItems &&
               SUCCEEDED(FileOperationDurableStore::ReadBoundedRegularFile(retargetPath, FileOperationMoveBreadcrumb::kMaximumRecordBytes, bytes)) &&
               bytes == originalBytes;
    };

    FileOperationMoveBreadcrumb::Record invalid = replacement;
    invalid.phase                               = FileOperationMoveBreadcrumb::DurablePhase::Executing;
    state.Require(retarget.ReplaceAdmittedRecord(invalid) == E_INVALIDARG && unchanged(),
                  L"Queued replacement must reject an Executing candidate without changing memory or disk.");
    invalid       = replacement;
    invalid.phase = FileOperationMoveBreadcrumb::DurablePhase::Terminal;
    state.Require(retarget.ReplaceAdmittedRecord(invalid) == E_INVALIDARG && unchanged(),
                  L"Queued replacement must reject a Terminal candidate without changing memory or disk.");
    invalid = replacement;
    ++invalid.schemaVersion;
    state.Require(retarget.ReplaceAdmittedRecord(invalid) == E_INVALIDARG && unchanged(),
                  L"Queued replacement must preserve the breadcrumb schema and leave the original durable bytes intact.");
    invalid = replacement;
    ++invalid.taskId;
    state.Require(retarget.ReplaceAdmittedRecord(invalid) == E_INVALIDARG && unchanged(),
                  L"Queued replacement must preserve the task ID and leave the original durable bytes intact.");
    invalid = replacement;
    ++invalid.createdFileTime;
    state.Require(retarget.ReplaceAdmittedRecord(invalid) == E_INVALIDARG && unchanged(),
                  L"Queued replacement must preserve the creation time and leave the original durable bytes intact.");
    invalid                    = replacement;
    invalid.admittedStrategies = {};
    state.Require(retarget.ReplaceAdmittedRecord(invalid) == E_INVALIDARG && unchanged(),
                  L"Queued replacement must run the existing serializer's nonempty-strategy validation.");
    invalid                        = replacement;
    invalid.destination.instanceId = L"local";
    state.Require(retarget.ReplaceAdmittedRecord(invalid) == E_INVALIDARG && unchanged(),
                  L"Queued replacement must reject a noncanonical destination instance through the existing serializer.");

    // The owner must still be the configured direct child. Restore the process-wide
    // test override immediately before inspecting the original store again.
    FileOperationMoveBreadcrumb::SetRootForSelfTest(root / L"unrelated-state");
    const HRESULT wrongOwnerHr = retarget.ReplaceAdmittedRecord(replacement);
    FileOperationMoveBreadcrumb::SetRootForSelfTest(breadcrumbRoot);
    state.Require(wrongOwnerHr == E_INVALIDARG && unchanged(), L"Queued replacement must refuse a record outside the configured durable-store root.");

    const HRESULT writeFailure = HRESULT_FROM_WIN32(ERROR_ACCESS_DENIED);
    Common::Files::Testing::FailNextLocalFileTransactionWrite(writeFailure);
    state.Require(retarget.ReplaceAdmittedRecord(replacement) == writeFailure && unchanged(),
                  L"Failed queued breadcrumb write must preserve its original memory and complete disk record.");
    const HRESULT publishFailure = HRESULT_FROM_WIN32(ERROR_WRITE_FAULT);
    Common::Files::Testing::FailNextLocalFileTransactionPublish(publishFailure);
    state.Require(retarget.ReplaceAdmittedRecord(replacement) == publishFailure && unchanged(),
                  L"Failed queued breadcrumb publication must preserve its original memory and complete disk record.");

    FileOperationMoveBreadcrumb::Record reloadedRetarget{};
    std::string replacedBytes;
    state.Require(
        retarget.ReplaceAdmittedRecord(replacement) == S_OK && retarget.GetPath() == retargetPath &&
            SUCCEEDED(FileOperationMoveBreadcrumb::Breadcrumb::Load(retargetPath, reloadedRetarget)) &&
            SUCCEEDED(FileOperationDurableStore::ReadBoundedRegularFile(retargetPath, FileOperationMoveBreadcrumb::kMaximumRecordBytes, replacedBytes)) &&
            replacedBytes != originalBytes && reloadedRetarget.phase == FileOperationMoveBreadcrumb::DurablePhase::Admitted &&
            reloadedRetarget.schemaVersion == originalAdmitted.schemaVersion && reloadedRetarget.taskId == originalAdmitted.taskId &&
            reloadedRetarget.createdFileTime == originalAdmitted.createdFileTime && reloadedRetarget.destination.pluginId == replacement.destination.pluginId &&
            reloadedRetarget.destination.pluginShortId == replacement.destination.pluginShortId &&
            reloadedRetarget.destination.instanceId == replacement.destination.instanceId &&
            reloadedRetarget.destination.profileId == replacement.destination.profileId &&
            reloadedRetarget.destination.rootId == replacement.destination.rootId &&
            reloadedRetarget.destination.representativePath == replacement.destination.representativePath &&
            reloadedRetarget.admittedStrategies.nativeItems == replacement.admittedStrategies.nativeItems &&
            reloadedRetarget.admittedStrategies.managedItems == replacement.admittedStrategies.managedItems &&
            reloadedRetarget.admittedStrategies.copyOnlyItems == replacement.admittedStrategies.copyOnlyItems &&
            retarget.GetRecord().destination.rootId == replacement.destination.rootId &&
            retarget.GetRecord().admittedStrategies.nativeItems == replacement.admittedStrategies.nativeItems,
        L"Successful queued replacement must publish the new qualified destination and strategy counts at the same path.");

    state.Require(SUCCEEDED(retarget.Advance(FileOperationMoveBreadcrumb::DurablePhase::Executing)),
                  L"Queued replacement test must advance its record before checking the current-phase guard.");
    std::string executingBytes;
    state.Require(
        SUCCEEDED(FileOperationDurableStore::ReadBoundedRegularFile(retargetPath, FileOperationMoveBreadcrumb::kMaximumRecordBytes, executingBytes)) &&
            retarget.ReplaceAdmittedRecord(replacement) == E_INVALIDARG && retarget.GetRecord().phase == FileOperationMoveBreadcrumb::DurablePhase::Executing &&
            retarget.GetPath() == retargetPath &&
            SUCCEEDED(FileOperationDurableStore::ReadBoundedRegularFile(retargetPath, FileOperationMoveBreadcrumb::kMaximumRecordBytes, replacedBytes)) &&
            replacedBytes == executingBytes,
        L"An Executing breadcrumb must reject queued replacement without changing memory or disk.");
    std::error_code retargetPathError;
    state.Require(SUCCEEDED(retarget.Finalize()) && ! std::filesystem::exists(retargetPath, retargetPathError) && ! retargetPathError,
                  L"Queued replacement test must finish and acknowledge its own breadcrumb.");
    state.Require(retarget.ReplaceAdmittedRecord(replacement) == E_INVALIDARG &&
                      retarget.GetRecord().phase == FileOperationMoveBreadcrumb::DurablePhase::Terminal && retarget.GetPath() == retargetPath &&
                      ! std::filesystem::exists(retargetPath, retargetPathError) && ! retargetPathError,
                  L"A Terminal breadcrumb must reject queued replacement without recreating a durable record.");

    return state.failure.empty();
}
