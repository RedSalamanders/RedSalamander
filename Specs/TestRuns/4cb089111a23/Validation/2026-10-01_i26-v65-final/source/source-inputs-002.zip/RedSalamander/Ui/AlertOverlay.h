#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#pragma warning(push)
// Windows headers: C4710 (not inlined), C4711 (auto inline), C4514 (unreferenced inline)
#pragma warning(disable : 4710 4711 4514)
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

#include <d2d1.h>
#include <d2d1helper.h>
#include <dwrite.h>
#pragma warning(pop)

#pragma warning(push)
// WIL: C4625 (copy ctor deleted), C4626 (copy assign deleted), C5026 (move ctor deleted), C5027 (move assign deleted)
#pragma warning(disable : 4625 4626 5026 5027 28182)
#include <wil/com.h>
#include <wil/resource.h>
#pragma warning(pop)

#include "FluentIcons.h"
#include <DxUi/DxUi.h>
#include <DxUi/Typography.h>

namespace RedSalamander::Ui
{
enum class AlertSeverity : uint8_t
{
    Error,
    Warning,
    Info,
    Busy,
};

enum class AlertPresentation : uint8_t
{
    Severity,
    Copy,
    Move,
    Delete,
};

struct AlertButton
{
    uint32_t id = 0;
    std::wstring label;
    bool primary = false;
};

struct AlertOptionChoice
{
    uint64_t value = 0;
    std::wstring label;
};

// A compact prompt-owned choice. It deliberately supports only cycling a
// finite set of values; file-operation confirmation does not need a generic
// form or arbitrary text-entry surface. Zero or one choice is read-only; its
// label and current value remain available to explain why it cannot change.
struct AlertOption
{
    uint32_t id = 0;
    std::wstring label;
    std::vector<AlertOptionChoice> choices;
    size_t selectedIndex = 0;
};

struct AlertModel
{
    AlertSeverity severity         = AlertSeverity::Error;
    AlertPresentation presentation = AlertPresentation::Severity;
    std::wstring title;
    std::wstring message;
    bool closable = true;
    std::vector<AlertOption> options;
    std::vector<AlertButton> buttons;
};

struct AlertTheme
{
    // Base surface colors.
    D2D1::ColorF background = D2D1::ColorF(D2D1::ColorF::White);
    D2D1::ColorF text       = D2D1::ColorF(D2D1::ColorF::Black);
    D2D1::ColorF accent     = D2D1::ColorF(0.0f, 0.478f, 1.0f, 1.0f);

    // Selection colors (used for hover / button emphasis).
    D2D1::ColorF selectionBackground = D2D1::ColorF(0.0f, 0.478f, 1.0f, 1.0f);
    D2D1::ColorF selectionText       = D2D1::ColorF(D2D1::ColorF::White);

    // Alert palettes (per severity).
    D2D1::ColorF errorBackground = D2D1::ColorF(1.0f, 0.95f, 0.95f);
    D2D1::ColorF errorText       = D2D1::ColorF(0.8f, 0.0f, 0.0f);

    D2D1::ColorF warningBackground = D2D1::ColorF(1.0f, 0.98f, 0.90f);
    D2D1::ColorF warningText       = D2D1::ColorF(0.65f, 0.38f, 0.0f);

    D2D1::ColorF infoBackground = D2D1::ColorF(0.90f, 0.95f, 1.0f);
    D2D1::ColorF infoText       = D2D1::ColorF(0.0f, 0.47f, 0.84f);

    bool darkBase     = false;
    bool highContrast = false;
};

struct AlertHitTest
{
    enum class Part : uint8_t
    {
        None,
        Close,
        Option,
        Button,
    };

    Part part         = Part::None;
    uint32_t buttonId = 0;
};

inline D2D1::ColorF ColorFFromArgb(uint32_t argb) noexcept
{
    const uint8_t a = static_cast<uint8_t>((argb >> 24) & 0xFFu);
    const uint8_t r = static_cast<uint8_t>((argb >> 16) & 0xFFu);
    const uint8_t g = static_cast<uint8_t>((argb >> 8) & 0xFFu);
    const uint8_t b = static_cast<uint8_t>(argb & 0xFFu);

    const float af = static_cast<float>(a) / 255.0f;
    const float rf = static_cast<float>(r) / 255.0f;
    const float gf = static_cast<float>(g) / 255.0f;
    const float bf = static_cast<float>(b) / 255.0f;
    return D2D1::ColorF(rf, gf, bf, af);
}

class AlertOverlay final
{
private:
    enum class IconGlyphSet : uint8_t
    {
        None,
        Fluent,
        Unicode,
    };

public:
    // A host must route wheel/keyboard/pointer scrolling before opting in.
    // FolderView's pane overlay still uses its existing clipped presentation.
    void SetScrollingEnabled(bool enabled) noexcept
    {
        if (_scrollingEnabled == enabled)
            return;
        _scrollingEnabled = enabled;
        _scrollOffsetDip  = 0.0f;
        InvalidateLayout();
    }

    void SetModel(AlertModel model)
    {
        _model           = std::move(model);
        _scrollOffsetDip = 0.0f;
#if defined(ENABLE_TESTS)
        _debugLastDrawnIconPresentation = AlertPresentation::Severity;
        _debugLastDrawnIconGlyph        = L'\0';
#endif
        InvalidateTextLayouts();
        InvalidateButtonLayouts();
        InvalidateLayout();
        ResetFocus();
    }

    const AlertModel& GetModel() const noexcept
    {
        return _model;
    }

    void SetTheme(const AlertTheme& theme) noexcept
    {
        _theme = theme;
    }

    const AlertTheme& GetTheme() const noexcept
    {
        return _theme;
    }

    void ResetDeviceResources() noexcept
    {
        _scrimBrush.reset();
        _backgroundBrush.reset();
        _textBrush.reset();
        _targetIdentity = nullptr;
    }

    void ResetTextResources() noexcept
    {
        _titleFormat.reset();
        _bodyFormat.reset();
        _buttonFormat.reset();
        _iconFormat.reset();
        _closeIconFormat.reset();
        _iconGlyphSet   = IconGlyphSet::None;
        _dwriteIdentity = nullptr;
        _optionRects.clear();
        InvalidateTextLayouts();
        InvalidateButtonLayouts();
        InvalidateLayout();
    }

    void SetStartTick(uint64_t tickMs) noexcept
    {
        _startTickMs = tickMs;
    }

    void ClearHotState() noexcept
    {
        _hot = {};
    }

    void ClearFocusedButton() noexcept
    {
        _focusedControl = {};
    }

    [[nodiscard]] std::optional<uint32_t> GetFocusedButtonId() const noexcept
    {
        return _focusedControl.part == AlertHitTest::Part::Button ? std::optional<uint32_t>(_focusedControl.buttonId) : std::nullopt;
    }

    [[nodiscard]] std::optional<uint32_t> GetFocusedOptionId() const noexcept
    {
        return _focusedControl.part == AlertHitTest::Part::Option ? std::optional<uint32_t>(_focusedControl.buttonId) : std::nullopt;
    }

    [[nodiscard]] std::optional<uint64_t> GetOptionValue(uint32_t optionId) const noexcept
    {
        for (const auto& option : _model.options)
        {
            if (option.id == optionId && ! option.choices.empty() && option.selectedIndex < option.choices.size())
            {
                return option.choices[option.selectedIndex].value;
            }
        }
        return std::nullopt;
    }

    [[nodiscard]] bool IsOptionEnabled(uint32_t optionId) const noexcept
    {
        for (const auto& option : _model.options)
            if (option.id == optionId)
                return option.choices.size() > 1u;
        return false;
    }

    [[nodiscard]] bool ActivateOption(uint32_t optionId, bool reverse = false) noexcept
    {
        if (! IsOptionEnabled(optionId))
            return false;
        for (auto& option : _model.options)
        {
            if (option.id != optionId || option.choices.empty())
            {
                continue;
            }

            option.selectedIndex = reverse ? (option.selectedIndex == 0u ? option.choices.size() - 1u : option.selectedIndex - 1u)
                                           : ((option.selectedIndex + 1u) % option.choices.size());
            InvalidateLayout();
            return true;
        }
        return false;
    }

    [[nodiscard]] bool FocusNextButton(bool reverse) noexcept
    {
        if (_model.buttons.empty())
        {
            const bool changed = _focusedControl.part == AlertHitTest::Part::Button;
            _focusedControl    = {};
            return changed;
        }

        size_t nextIndex = 0;
        if (_focusedControl.part == AlertHitTest::Part::Button)
        {
            std::optional<size_t> currentIndex;
            for (size_t i = 0; i < _model.buttons.size(); ++i)
            {
                if (_model.buttons[i].id == _focusedControl.buttonId)
                {
                    currentIndex = i;
                    break;
                }
            }

            if (currentIndex.has_value())
            {
                if (reverse)
                {
                    nextIndex = currentIndex.value() == 0 ? (_model.buttons.size() - 1u) : (currentIndex.value() - 1u);
                }
                else
                {
                    nextIndex = (currentIndex.value() + 1u) % _model.buttons.size();
                }
            }
            else
            {
                nextIndex = reverse ? (_model.buttons.size() - 1u) : 0u;
            }
        }
        else
        {
            nextIndex = reverse ? (_model.buttons.size() - 1u) : 0u;
        }

        const uint32_t nextId = _model.buttons[nextIndex].id;
        if (_focusedControl.part == AlertHitTest::Part::Button && _focusedControl.buttonId == nextId)
        {
            return false;
        }

        _focusedControl.part     = AlertHitTest::Part::Button;
        _focusedControl.buttonId = nextId;
        RevealFocusedControl();
        return true;
    }

    [[nodiscard]] bool FocusNextInteractive(bool reverse) noexcept
    {
        std::vector<AlertHitTest> controls;
        controls.reserve(_model.options.size() + _model.buttons.size());
        for (const auto& option : _model.options)
        {
            if (IsOptionEnabled(option.id))
                controls.push_back(AlertHitTest{.part = AlertHitTest::Part::Option, .buttonId = option.id});
        }
        for (const auto& button : _model.buttons)
        {
            controls.push_back(AlertHitTest{.part = AlertHitTest::Part::Button, .buttonId = button.id});
        }
        if (controls.empty())
        {
            const bool changed = _focusedControl.part != AlertHitTest::Part::None;
            _focusedControl    = {};
            return changed;
        }

        size_t nextIndex = reverse ? controls.size() - 1u : 0u;
        for (size_t index = 0; index < controls.size(); ++index)
        {
            if (controls[index].part == _focusedControl.part && controls[index].buttonId == _focusedControl.buttonId)
            {
                nextIndex = reverse ? (index == 0u ? controls.size() - 1u : index - 1u) : ((index + 1u) % controls.size());
                break;
            }
        }
        if (controls[nextIndex].part == _focusedControl.part && controls[nextIndex].buttonId == _focusedControl.buttonId)
        {
            return false;
        }
        _focusedControl = controls[nextIndex];
        RevealFocusedControl();
        return true;
    }

    [[nodiscard]] bool ScrollBy(float deltaDip) noexcept
    {
        const float next = std::clamp(_scrollOffsetDip + deltaDip, 0.0f, _scrollMaximumDip);
        if (next == _scrollOffsetDip)
            return false;
        const float shift = _scrollOffsetDip - next;
        _scrollOffsetDip  = next;
        _layoutTextRect.top += shift;
        _layoutTextRect.bottom += shift;
        for (auto& option : _optionRects)
        {
            option.rect.top += shift;
            option.rect.bottom += shift;
        }
        if (_scrollFooter)
            for (auto& button : _buttonRects)
            {
                button.rect.top += shift;
                button.rect.bottom += shift;
            }
        ClearHotState();
        return true;
    }

    [[nodiscard]] D2D1_RECT_F GetScrollTrack() const noexcept
    {
        return _scrollMaximumDip > 0.0f ? D2D1::RectF(_bodyViewport.right, _bodyViewport.top, _bodyViewport.right + 12.0f, _bodyViewport.bottom)
                                        : D2D1_RECT_F{};
    }

    [[nodiscard]] bool ScrollAt(D2D1_POINT_2F point) noexcept
    {
        const auto track = GetScrollTrack();
        if (! PointInRect(point, track) || track.bottom <= track.top)
            return false;
        const float fraction = std::clamp((point.y - track.top) / (track.bottom - track.top), 0.0f, 1.0f);
        return ScrollBy(fraction * _scrollMaximumDip - _scrollOffsetDip);
    }

    void RevealFocusedControl() noexcept
    {
        D2D1_RECT_F focused{};
        if (_focusedControl.part == AlertHitTest::Part::Option)
            for (const auto& option : _optionRects)
                if (option.id == _focusedControl.buttonId)
                    focused = option.rect;
        if (_scrollFooter && _focusedControl.part == AlertHitTest::Part::Button)
            for (const auto& button : _buttonRects)
                if (button.id == _focusedControl.buttonId)
                    focused = button.rect;
        if (focused.bottom <= focused.top)
            return;
        const float viewportHeight = _bodyViewport.bottom - _bodyViewport.top;
        const float delta          = focused.top < _bodyViewport.top + 4.0f || focused.bottom - focused.top + 8.0f > viewportHeight
                                         ? focused.top - _bodyViewport.top - 4.0f
                                         : std::max(0.0f, focused.bottom - _bodyViewport.bottom + 4.0f);
        static_cast<void>(ScrollBy(delta));
    }

    [[nodiscard]] D2D1_RECT_F GetVisibleControlRect(AlertHitTest hit) const noexcept
    {
        if (! _hasLayout)
            return {};
        if (hit.part == AlertHitTest::Part::Close)
            return _closeRect;
        if (hit.part == AlertHitTest::Part::Button)
            for (const auto& button : _buttonRects)
                if (button.id == hit.buttonId)
                {
                    auto rect = button.rect;
                    if (_scrollFooter)
                    {
                        rect.top    = std::max(rect.top, _bodyViewport.top);
                        rect.bottom = std::min(rect.bottom, _bodyViewport.bottom);
                    }
                    return rect.bottom > rect.top ? rect : D2D1_RECT_F{};
                }
        if (hit.part == AlertHitTest::Part::Option)
            for (const auto& option : _optionRects)
                if (option.id == hit.buttonId)
                {
                    auto rect   = option.rect;
                    rect.top    = std::max(rect.top, _bodyViewport.top);
                    rect.bottom = std::min(rect.bottom, _bodyViewport.bottom);
                    return rect.bottom > rect.top ? rect : D2D1_RECT_F{};
                }
        return {};
    }

    [[nodiscard]] bool FocusControl(AlertHitTest hit) noexcept
    {
        bool valid = hit.part == AlertHitTest::Part::Close && _model.closable;
        valid      = valid || (hit.part == AlertHitTest::Part::Option && IsOptionEnabled(hit.buttonId));
        for (const auto& button : _model.buttons)
            valid = valid || (hit.part == AlertHitTest::Part::Button && button.id == hit.buttonId);
        if (! valid)
            return false;
        _focusedControl = hit;
        RevealFocusedControl();
        return true;
    }

    [[nodiscard]] D2D1_RECT_F GetVisibleTextRect() const noexcept
    {
        auto rect   = _layoutTextRect;
        rect.top    = std::max(rect.top, _bodyViewport.top);
        rect.bottom = std::min(rect.bottom, _bodyViewport.bottom);
        return _hasLayout && rect.bottom > rect.top ? rect : D2D1_RECT_F{};
    }

    [[nodiscard]] AlertHitTest GetFocusedControl() const noexcept
    {
        return _focusedControl;
    }
    [[nodiscard]] D2D1_RECT_F GetBodyViewport() const noexcept
    {
        return _bodyViewport;
    }
    [[nodiscard]] float GetScrollOffset() const noexcept
    {
        return _scrollOffsetDip;
    }
    [[nodiscard]] float GetScrollMaximum() const noexcept
    {
        return _scrollMaximumDip;
    }

    [[nodiscard]] bool HasLayout() const noexcept
    {
        return _hasLayout;
    }

    [[nodiscard]] D2D1_RECT_F GetPanelRect() const noexcept
    {
        return _panelRect;
    }

#if defined(ENABLE_TESTS)
    [[nodiscard]] uint64_t DebugGetLayoutPassCount() const noexcept
    {
        return _debugLayoutPassCount;
    }
    [[nodiscard]] bool DebugAllControlLabelsFit() const noexcept
    {
        if (_optionRects.size() != _model.options.size() || _buttonRects.size() != _model.buttons.size())
            return false;
        for (const auto& option : _optionRects)
        {
            DWRITE_TEXT_METRICS metrics{};
            if (! option.layout || FAILED(option.layout->GetMetrics(&metrics)) || metrics.width > option.rect.right - option.rect.left - 23.0f ||
                metrics.height > option.heightDip - 15.0f)
                return false;
        }
        for (const auto& button : _buttonRects)
        {
            DWRITE_TEXT_METRICS metrics{};
            if (button.layout)
            {
                if (FAILED(button.layout->GetMetrics(&metrics)) || metrics.width > button.rect.right - button.rect.left - 27.0f ||
                    metrics.height > button.rect.bottom - button.rect.top - 15.0f)
                    return false;
            }
            else if (button.labelWidthDip > button.rect.right - button.rect.left - 27.0f)
                return false;
        }
        return true;
    }

    [[nodiscard]] float DebugGetLastDrawOpacityForTest() const noexcept
    {
        return _debugLastDrawOpacity;
    }

    [[nodiscard]] float DebugGetLastDrawScrimOpacityForTest() const noexcept
    {
        return _debugLastDrawScrimOpacity;
    }

    [[nodiscard]] D2D1_RECT_F DebugGetCloseRectForTest() const noexcept
    {
        return _closeRect;
    }

    [[nodiscard]] bool DebugUsesSharedCloseChromeForTest() const noexcept
    {
        return _debugUsesSharedCloseChrome;
    }

    [[nodiscard]] bool DebugUsesSharedButtonChromeForTest() const noexcept
    {
        return _debugUsesSharedButtonChrome;
    }

    [[nodiscard]] AlertPresentation DebugGetLastDrawnIconPresentationForTest() const noexcept
    {
        return _debugLastDrawnIconPresentation;
    }

    [[nodiscard]] wchar_t DebugGetLastDrawnIconGlyphForTest() const noexcept
    {
        return _debugLastDrawnIconGlyph;
    }

    [[nodiscard]] wchar_t DebugGetLastDrawnCloseGlyphForTest() const noexcept
    {
        return _debugLastDrawnCloseGlyph;
    }
#endif

    [[nodiscard]] bool EnsureLayout(IDWriteFactory* dwriteFactory, float clientWidthDip, float clientHeightDip) noexcept
    {
        if (! dwriteFactory || clientWidthDip <= 0.0f || clientHeightDip <= 0.0f)
        {
            return false;
        }

        EnsureTextResources(dwriteFactory);
        if (! _titleFormat || ! _bodyFormat || ! _buttonFormat)
        {
            InvalidateLayout();
            return false;
        }

        const bool revealFocusAfterLayout = ! _hasLayout;
        if (_hasLayout && _layoutClientWidthDip == clientWidthDip && _layoutClientHeightDip == clientHeightDip)
            return true;
#if defined(ENABLE_TESTS)
        ++_debugLayoutPassCount;
#endif
        _layoutClientWidthDip  = clientWidthDip;
        _layoutClientHeightDip = clientHeightDip;

        constexpr float kOuterMarginDip  = 24.0f;
        constexpr float kInnerPaddingDip = 20.0f;
        constexpr float kMaxWidthDip     = 780.0f;

        constexpr float kIconSizeDip     = 80.0f;
        constexpr float kIconTextGapDip  = 18.0f;
        constexpr float kTitleBodyGapDip = 6.0f;
        constexpr float kCloseSizeDip    = 22.0f;
        constexpr float kCloseInsetDip   = 8.0f;

        constexpr float kButtonsRowGapDip = 14.0f;

        constexpr float kOptionGapDip      = 8.0f;
        constexpr float kOptionsTextGapDip = 14.0f;

        const float minDimDip      = std::min(clientWidthDip, clientHeightDip);
        const float outerMarginDip = std::min(kOuterMarginDip, minDimDip * 0.06f);

        const float availableWidth  = std::max(0.0f, clientWidthDip - outerMarginDip * 2.0f);
        const float availableHeight = std::max(0.0f, clientHeightDip - outerMarginDip * 2.0f);

        const float panelWidth     = std::max(0.0f, std::min(kMaxWidthDip, availableWidth));
        const float maxPanelHeight = std::max(0.0f, availableHeight);
        if (panelWidth <= 0.0f || maxPanelHeight <= 0.0f)
        {
            InvalidateLayout();
            return false;
        }

        float innerPaddingDip     = kInnerPaddingDip;
        const float maxPaddingDip = std::max(0.0f, std::min(panelWidth, maxPanelHeight) * 0.05f);
        if (maxPaddingDip > 0.0f)
        {
            innerPaddingDip = std::min(innerPaddingDip, maxPaddingDip);
        }
        else
        {
            innerPaddingDip = 0.0f;
        }

        // Use exactly the same right edge as contentRect below, including when
        // a short host reduces padding below the close-control inset.
        const float trailingInsetDip = _model.closable ? std::max(innerPaddingDip, kCloseSizeDip + kCloseInsetDip * 2.0f) : innerPaddingDip;
        const float maxTextWidthDip  = std::max(1.0f, panelWidth - innerPaddingDip - trailingInsetDip);

        const bool allowIcon = panelWidth >= 600.0f && maxPanelHeight >= (innerPaddingDip * 2.0f + kIconSizeDip);
        bool showIcon        = allowIcon;

        float textWidthDip = maxTextWidthDip;
        if (showIcon)
        {
            textWidthDip = std::max(1.0f, maxTextWidthDip - (kIconSizeDip + kIconTextGapDip));
        }

        constexpr float kMinTextWidthForIconDip = 120.0f;
        if (showIcon && textWidthDip < kMinTextWidthForIconDip)
        {
            showIcon     = false;
            textWidthDip = maxTextWidthDip;
        }

        EnsureTextLayouts(dwriteFactory, std::max(1.0f, textWidthDip - 12.0f));
        EnsureButtonLayouts(dwriteFactory);
        EnsureOptionLayouts(dwriteFactory, textWidthDip - 12.0f);

        float textHeightDip = 0.0f;
        if (_titleLayoutHeightDip > 0.0f)
        {
            textHeightDip += _titleLayoutHeightDip;
        }
        if (_bodyLayoutHeightDip > 0.0f)
        {
            if (textHeightDip > 0.0f)
            {
                textHeightDip += kTitleBodyGapDip;
            }
            textHeightDip += _bodyLayoutHeightDip;
        }

        float buttonRowHeightDip = MeasureFooter(dwriteFactory, panelWidth - innerPaddingDip * 2.0f);
        // Below the pinned-footer minimum, place actions at the end of the same
        // scrollable content so a short embedded host cannot silently lose them.
        _scrollFooter = _scrollingEnabled && buttonRowHeightDip + innerPaddingDip * 2.0f + 80.0f > maxPanelHeight;
        if (_scrollFooter)
            buttonRowHeightDip = MeasureFooter(dwriteFactory, textWidthDip - 12.0f);
        float optionBlockHeightDip = 0.0f;
        for (const auto& option : _optionRects)
            optionBlockHeightDip += option.heightDip + kOptionGapDip;
        if (! _optionRects.empty())
            optionBlockHeightDip -= kOptionGapDip;
        const float textAndOptionsHeightDip = textHeightDip + (optionBlockHeightDip > 0.0f ? kOptionsTextGapDip + optionBlockHeightDip : 0.0f);
        const float scrollContentHeightDip  = textAndOptionsHeightDip + (_scrollFooter ? buttonRowHeightDip + kButtonsRowGapDip : 0.0f);
        const float contentHeightDip        = std::max(showIcon ? kIconSizeDip : 0.0f, scrollContentHeightDip + 4.0f);

        float desiredPanelHeight = innerPaddingDip * 2.0f + contentHeightDip;
        if (buttonRowHeightDip > 0.0f && ! _scrollFooter)
        {
            desiredPanelHeight += kButtonsRowGapDip + buttonRowHeightDip;
        }

        const float clampedPanelHeight = std::min(desiredPanelHeight, maxPanelHeight);
        const float panelLeft          = (clientWidthDip - panelWidth) * 0.5f;
        const float panelTop           = (clientHeightDip - clampedPanelHeight) * 0.5f;

        _panelRect                = D2D1::RectF(panelLeft, panelTop, panelLeft + panelWidth, panelTop + clampedPanelHeight);
        _hasLayout                = true;
        _layoutPanelWidthDip      = panelWidth;
        _layoutPanelHeightDip     = clampedPanelHeight;
        _layoutButtonRowHeightDip = buttonRowHeightDip;
        _layoutShowIcon           = showIcon;

        D2D1_RECT_F contentRect = D2D1::RectF(
            _panelRect.left + innerPaddingDip, _panelRect.top + innerPaddingDip, _panelRect.right - innerPaddingDip, _panelRect.bottom - innerPaddingDip);

        if (_model.closable)
        {
            const float closeRight = _panelRect.right - kCloseInsetDip;
            const float closeTop   = _panelRect.top + kCloseInsetDip;
            _closeRect             = D2D1::RectF(closeRight - kCloseSizeDip, closeTop, closeRight, closeTop + kCloseSizeDip);
            contentRect.right      = std::min(contentRect.right, _closeRect.left - kCloseInsetDip);
        }
        else
        {
            _closeRect = {};
        }

        if (buttonRowHeightDip > 0.0f)
        {
            const D2D1_RECT_F buttonsRect =
                D2D1::RectF(contentRect.left, contentRect.bottom - buttonRowHeightDip, _panelRect.right - innerPaddingDip, contentRect.bottom);
            for (auto& button : _buttonRects)
            {
                button.rect.left += buttonsRect.left;
                button.rect.right += buttonsRect.left;
                button.rect.top += buttonsRect.top;
                button.rect.bottom += buttonsRect.top;
            }
        }
        else
        {
            _buttonRects.clear();
        }

        D2D1_RECT_F bodyTextRect = contentRect;
        if (buttonRowHeightDip > 0.0f && ! _scrollFooter)
        {
            bodyTextRect.bottom = std::max(bodyTextRect.top, bodyTextRect.bottom - buttonRowHeightDip - kButtonsRowGapDip);
        }

        D2D1_RECT_F iconRect{};
        D2D1_RECT_F textRect = bodyTextRect;
        if (showIcon)
        {
            const float iconTop = bodyTextRect.top + (contentHeightDip - kIconSizeDip) * 0.5f;
            iconRect            = D2D1::RectF(bodyTextRect.left, iconTop, bodyTextRect.left + kIconSizeDip, iconTop + kIconSizeDip);
            textRect            = D2D1::RectF(iconRect.right + kIconTextGapDip, bodyTextRect.top, bodyTextRect.right, bodyTextRect.bottom);
        }

        // Keep the full measured content. The viewport clips drawing/hit testing,
        // never the model or keyboard traversal. Reserve a scrollbar gutter.
        textRect.bottom = std::max(textRect.top, textRect.bottom);
        _bodyViewport   = textRect;
        _bodyViewport.right -= 12.0f;
        textRect.right    = _bodyViewport.right;
        _scrollMaximumDip = _scrollingEnabled ? std::max(0.0f, scrollContentHeightDip + 4.0f - (textRect.bottom - textRect.top)) : 0.0f;
        _scrollOffsetDip  = std::clamp(_scrollOffsetDip, 0.0f, _scrollMaximumDip);
        float rowTop      = textRect.top + textHeightDip + kOptionsTextGapDip - _scrollOffsetDip;
        for (auto& row : _optionRects)
        {
            row.rect = D2D1::RectF(textRect.left, rowTop, textRect.right, rowTop + row.heightDip);
            rowTop += row.heightDip + kOptionGapDip;
        }
        if (_scrollFooter && ! _buttonRects.empty())
        {
            const float shift  = textRect.top + textAndOptionsHeightDip + kButtonsRowGapDip - _scrollOffsetDip - _buttonRects.front().rect.top;
            const float shiftX = textRect.left - _buttonRects.front().rect.left;
            for (auto& button : _buttonRects)
            {
                button.rect.left += shiftX;
                button.rect.right += shiftX;
                button.rect.top += shift;
                button.rect.bottom += shift;
            }
        }
        textRect.top -= _scrollOffsetDip;
        textRect.bottom = textRect.top + textHeightDip;

        _layoutBodyTextRect = bodyTextRect;
        _layoutIconRect     = iconRect;
        _layoutTextRect     = textRect;
        if (revealFocusAfterLayout)
            RevealFocusedControl();
        return true;
    }

    [[nodiscard]] bool IsPointInPanel(D2D1_POINT_2F ptDip) const noexcept
    {
        if (! _hasLayout)
        {
            return false;
        }

        return ptDip.x >= _panelRect.left && ptDip.x <= _panelRect.right && ptDip.y >= _panelRect.top && ptDip.y <= _panelRect.bottom;
    }

    AlertHitTest HitTest(D2D1_POINT_2F ptDip) const noexcept
    {
        if (! _hasLayout)
        {
            return {};
        }

        if (_model.closable && PointInRect(ptDip, _closeRect))
        {
            AlertHitTest hit{};
            hit.part = AlertHitTest::Part::Close;
            return hit;
        }

        for (const auto& button : _buttonRects)
        {
            if ((! _scrollFooter || PointInRect(ptDip, _bodyViewport)) && PointInRect(ptDip, button.rect))
            {
                AlertHitTest hit{};
                hit.part     = AlertHitTest::Part::Button;
                hit.buttonId = button.id;
                return hit;
            }
        }

        for (const auto& option : _optionRects)
        {
            if (PointInRect(ptDip, _bodyViewport) && PointInRect(ptDip, option.rect))
            {
                AlertHitTest hit{};
                hit.part     = AlertHitTest::Part::Option;
                hit.buttonId = option.id;
                return hit;
            }
        }

        return {};
    }

    bool UpdateHotState(D2D1_POINT_2F ptDip) noexcept
    {
        AlertHitTest hit = HitTest(ptDip);
        if (hit.part == AlertHitTest::Part::Option && ! IsOptionEnabled(hit.buttonId))
            hit = {};
        if (hit.part == _hot.part && hit.buttonId == _hot.buttonId)
        {
            return false;
        }

        _hot = hit;
        return true;
    }

    void Draw(ID2D1RenderTarget* target, IDWriteFactory* dwriteFactory, float clientWidthDip, float clientHeightDip, uint64_t nowTickMs) noexcept
    {
#if defined(ENABLE_TESTS)
        _debugUsesSharedCloseChrome  = false;
        _debugUsesSharedButtonChrome = false;
        _debugLastDrawnCloseGlyph    = L'\0';
#endif
        if (! target || ! dwriteFactory)
        {
            return;
        }

        if (clientWidthDip <= 0.0f || clientHeightDip <= 0.0f)
        {
            return;
        }

        EnsureDeviceResources(target);
        EnsureTextResources(dwriteFactory);
        if (! _scrimBrush || ! _backgroundBrush || ! _textBrush || ! _titleFormat || ! _bodyFormat || ! _buttonFormat)
        {
            return;
        }

        constexpr float kCornerRadiusDip    = 12.0f;
        constexpr float kIconTextGapDip     = 18.0f;
        constexpr float kTitleBodyGapDip    = 6.0f;
        constexpr float kCardOpacity        = 0.96f;
        constexpr float kBorderOpacity      = 0.90f;
        constexpr float kButtonCornerDip    = 6.0f;
        constexpr uint64_t kShowAnimationMs = 220;

        if (! EnsureLayout(dwriteFactory, clientWidthDip, clientHeightDip))
        {
            return;
        }

        const float panelWidth         = _layoutPanelWidthDip;
        const float clampedPanelHeight = _layoutPanelHeightDip;
        const float buttonRowHeightDip = _layoutButtonRowHeightDip;
        const bool showIcon            = _layoutShowIcon;
        const float titleHeightDip     = _titleLayoutHeightDip;

        const uint64_t elapsedMs      = (nowTickMs >= _startTickMs) ? (nowTickMs - _startTickMs) : 0u;
        const float showT             = static_cast<float>(std::min<uint64_t>(elapsedMs, kShowAnimationMs)) / static_cast<float>(kShowAnimationMs);
        const float ease              = EaseOutCubic(showT);
        const float overlayOpacity    = ease;
        const float overlayScale      = std::lerp(0.975f, 1.0f, ease);
        const float overlayTranslateY = std::lerp(10.0f, 0.0f, ease);
#if defined(ENABLE_TESTS)
        _debugLastDrawOpacity = overlayOpacity;
#endif

        const float scrimOpacity = _theme.darkBase ? 0.65f : 0.50f;
#if defined(ENABLE_TESTS)
        _debugLastDrawScrimOpacity = scrimOpacity * overlayOpacity;
#endif
        _scrimBrush->SetOpacity(scrimOpacity * overlayOpacity);
        target->FillRectangle(D2D1::RectF(0.0f, 0.0f, clientWidthDip, clientHeightDip), _scrimBrush.get());

        D2D1_MATRIX_3X2_F baseTransform{};
        target->GetTransform(&baseTransform);
        const D2D1_POINT_2F panelCenter = D2D1::Point2F((_panelRect.left + _panelRect.right) * 0.5f, (_panelRect.top + _panelRect.bottom) * 0.5f);
        target->SetTransform(D2D1::Matrix3x2F::Scale(overlayScale, overlayScale, panelCenter) * D2D1::Matrix3x2F::Translation(0.0f, overlayTranslateY));

        D2D1::ColorF panelColor  = _theme.background;
        D2D1::ColorF accentColor = _theme.accent;
        D2D1::ColorF textColor   = _theme.text;
        ResolvePalette(_model.severity, _model.presentation, panelColor, accentColor, textColor);

        _backgroundBrush->SetColor(panelColor);
        _backgroundBrush->SetOpacity(kCardOpacity * overlayOpacity);

        const float cornerRadiusDip          = std::min(kCornerRadiusDip, std::max(0.0f, std::min(panelWidth, clampedPanelHeight) * 0.25f));
        const D2D1_ROUNDED_RECT roundedPanel = D2D1::RoundedRect(_panelRect, cornerRadiusDip, cornerRadiusDip);
        target->FillRoundedRectangle(roundedPanel, _backgroundBrush.get());

        _textBrush->SetColor(accentColor);
        _textBrush->SetOpacity(kBorderOpacity * overlayOpacity);
        target->DrawRoundedRectangle(roundedPanel, _textBrush.get(), 1.0f);

        if (_model.closable)
        {
            DrawCloseButton(target, _closeRect, accentColor, overlayOpacity);
        }

        const D2D1_RECT_F bodyTextRect = _layoutBodyTextRect;
        const D2D1_RECT_F iconRect     = _layoutIconRect;
        const D2D1_RECT_F textRect     = _layoutTextRect;
        if (showIcon)
        {
            const float dividerX = iconRect.right + kIconTextGapDip * 0.5f;
            _textBrush->SetColor(accentColor);
            _textBrush->SetOpacity(0.15f * overlayOpacity);
            target->DrawLine(D2D1::Point2F(dividerX, bodyTextRect.top), D2D1::Point2F(dividerX, bodyTextRect.bottom), _textBrush.get(), 1.0f);

            _textBrush->SetColor(accentColor);
            _textBrush->SetOpacity(overlayOpacity);
            DrawPromptIcon(target, _textBrush.get(), _model.severity, _model.presentation, iconRect, overlayOpacity, elapsedMs);
        }

        _textBrush->SetColor(textColor);
        _textBrush->SetOpacity(overlayOpacity);

        float textY = textRect.top;
        target->PushAxisAlignedClip(_bodyViewport, D2D1_ANTIALIAS_MODE_PER_PRIMITIVE);

        if (_titleLayout)
        {
            target->DrawTextLayout(D2D1::Point2F(textRect.left, textY), _titleLayout.get(), _textBrush.get());
            textY += titleHeightDip;
        }
        if (_bodyLayout)
        {
            if (textY > textRect.top)
            {
                textY += kTitleBodyGapDip;
            }
            if (_model.presentation != AlertPresentation::Severity)
                _textBrush->SetColor(_theme.text);
            target->DrawTextLayout(D2D1::Point2F(textRect.left, textY), _bodyLayout.get(), _textBrush.get());
        }

        DrawOptions(target, overlayOpacity, kButtonCornerDip);
        if (_scrollFooter)
            DrawButtons(target, overlayOpacity, kButtonCornerDip);
        target->PopAxisAlignedClip();
        if (_scrollMaximumDip > 0.0f)
        {
            const auto track        = GetScrollTrack();
            const float viewHeight  = track.bottom - track.top;
            const float thumbHeight = std::min(viewHeight, std::max(16.0f, viewHeight * viewHeight / (viewHeight + _scrollMaximumDip)));
            const float thumbTop    = track.top + (viewHeight - thumbHeight) * _scrollOffsetDip / _scrollMaximumDip;
            _textBrush->SetColor(_theme.text);
            _textBrush->SetOpacity(0.65f * overlayOpacity);
            target->FillRoundedRectangle(D2D1::RoundedRect(D2D1::RectF(track.left + 3.0f, thumbTop, track.right - 3.0f, thumbTop + thumbHeight), 2.0f, 2.0f),
                                         _textBrush.get());
        }

        if (buttonRowHeightDip > 0.0f && ! _scrollFooter)
        {
            DrawButtons(target, overlayOpacity, kButtonCornerDip);
        }
        target->SetTransform(baseTransform);
    }

private:
    struct ButtonRect
    {
        uint32_t id = 0;
        D2D1_RECT_F rect{};
        bool primary = false;
        std::wstring_view label;
        float labelWidthDip = 0.0f;
        wil::com_ptr<IDWriteTextLayout> layout;
    };

    struct OptionRect
    {
        uint32_t id = 0;
        D2D1_RECT_F rect{};
        std::wstring label;
        wil::com_ptr<IDWriteTextLayout> layout;
        float heightDip = 32.0f;
    };

    static bool PointInRect(D2D1_POINT_2F pt, const D2D1_RECT_F& rc) noexcept
    {
        return pt.x >= rc.left && pt.x <= rc.right && pt.y >= rc.top && pt.y <= rc.bottom;
    }

    static float EaseOutCubic(float t) noexcept
    {
        t               = std::clamp(t, 0.0f, 1.0f);
        const float inv = 1.0f - t;
        return 1.0f - inv * inv * inv;
    }

    void EnsureDeviceResources(ID2D1RenderTarget* target) noexcept
    {
        if (! target)
        {
            return;
        }

        if (_targetIdentity == target && _scrimBrush && _backgroundBrush && _textBrush)
        {
            return;
        }

        ResetDeviceResources();
        _targetIdentity = target;

        static_cast<void>(target->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.0f, 0.0f, 1.0f), _scrimBrush.put()));
        static_cast<void>(target->CreateSolidColorBrush(_theme.background, _backgroundBrush.put()));
        static_cast<void>(target->CreateSolidColorBrush(_theme.text, _textBrush.put()));
    }

    void EnsureTextResources(IDWriteFactory* dwriteFactory) noexcept
    {
        if (! dwriteFactory)
        {
            return;
        }

        if (_dwriteIdentity == dwriteFactory && _titleFormat && _bodyFormat && _buttonFormat)
        {
            return;
        }

        ResetTextResources();
        _dwriteIdentity = dwriteFactory;

        constexpr float kTitleSizeDip     = 18.0f;
        constexpr float kBodySizeDip      = 14.0f;
        constexpr float kButtonSizeDip    = 13.0f;
        constexpr float kIconSizeDip      = 56.0f;
        constexpr float kCloseIconSizeDip = 16.0f;

        static_cast<void>(DxUi::Typography::CreateTextFormat(
            dwriteFactory, DxUi::Typography::MakeUiTextSpec(kTitleSizeDip, DWRITE_FONT_WEIGHT_SEMI_BOLD), _titleFormat.put(), L""));
        static_cast<void>(DxUi::Typography::CreateTextFormat(dwriteFactory, DxUi::Typography::MakeUiTextSpec(kBodySizeDip), _bodyFormat.put(), L""));
        static_cast<void>(DxUi::Typography::CreateTextFormat(
            dwriteFactory, DxUi::Typography::MakeUiTextSpec(kButtonSizeDip, DWRITE_FONT_WEIGHT_SEMI_BOLD), _buttonFormat.put(), L""));

        if (FAILED(DxUi::Typography::CreateTextFormat(dwriteFactory, DxUi::Typography::MakeUiIconSpec(kIconSizeDip), _iconFormat.put(), L"")))
        {
            _iconFormat.reset();
            static_cast<void>(DxUi::Typography::CreateTextFormat(dwriteFactory,
                                                                 DxUi::Typography::TypographySpec{.familyName = DxUi::Typography::kSegoeMdl2AssetsFamily,
                                                                                                  .weight     = DWRITE_FONT_WEIGHT_NORMAL,
                                                                                                  .sizeDip    = kIconSizeDip},
                                                                 _iconFormat.put(),
                                                                 L""));
        }

        if (_iconFormat)
        {
            _iconGlyphSet = IconGlyphSet::Fluent;

            if (FAILED(DxUi::Typography::CreateTextFormat(dwriteFactory, DxUi::Typography::MakeUiIconSpec(kCloseIconSizeDip), _closeIconFormat.put(), L"")))
            {
                _closeIconFormat.reset();
                static_cast<void>(DxUi::Typography::CreateTextFormat(dwriteFactory,
                                                                     DxUi::Typography::TypographySpec{.familyName = DxUi::Typography::kSegoeMdl2AssetsFamily,
                                                                                                      .weight     = DWRITE_FONT_WEIGHT_NORMAL,
                                                                                                      .sizeDip    = kCloseIconSizeDip},
                                                                     _closeIconFormat.put(),
                                                                     L""));
            }
        }
        else
        {
            static_cast<void>(dwriteFactory->CreateTextFormat(L"Segoe UI Symbol",
                                                              nullptr,
                                                              DWRITE_FONT_WEIGHT_NORMAL,
                                                              DWRITE_FONT_STYLE_NORMAL,
                                                              DWRITE_FONT_STRETCH_NORMAL,
                                                              kIconSizeDip,
                                                              L"",
                                                              _iconFormat.put()));
            if (_iconFormat)
            {
                _iconGlyphSet = IconGlyphSet::Unicode;
                static_cast<void>(dwriteFactory->CreateTextFormat(L"Segoe UI Symbol",
                                                                  nullptr,
                                                                  DWRITE_FONT_WEIGHT_NORMAL,
                                                                  DWRITE_FONT_STYLE_NORMAL,
                                                                  DWRITE_FONT_STRETCH_NORMAL,
                                                                  kCloseIconSizeDip,
                                                                  L"",
                                                                  _closeIconFormat.put()));
            }
        }

        if (_titleFormat)
        {
            static_cast<void>(_titleFormat->SetWordWrapping(DWRITE_WORD_WRAPPING_WRAP));
        }
        if (_bodyFormat)
        {
            static_cast<void>(_bodyFormat->SetWordWrapping(DWRITE_WORD_WRAPPING_WRAP));
        }
        if (_buttonFormat)
        {
            static_cast<void>(_buttonFormat->SetWordWrapping(DWRITE_WORD_WRAPPING_NO_WRAP));
            static_cast<void>(_buttonFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER));
            static_cast<void>(_buttonFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER));
        }
        if (_iconFormat)
        {
            static_cast<void>(_iconFormat->SetWordWrapping(DWRITE_WORD_WRAPPING_NO_WRAP));
            static_cast<void>(_iconFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER));
            static_cast<void>(_iconFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER));
        }
        if (_closeIconFormat)
        {
            static_cast<void>(_closeIconFormat->SetWordWrapping(DWRITE_WORD_WRAPPING_NO_WRAP));
            static_cast<void>(_closeIconFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER));
            static_cast<void>(_closeIconFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER));
        }
    }

    void ResetFocus() noexcept
    {
        _focusedControl = {};
        for (const auto& button : _model.buttons)
        {
            if (button.primary)
            {
                _focusedControl.part     = AlertHitTest::Part::Button;
                _focusedControl.buttonId = button.id;
                return;
            }
        }

        if (! _model.buttons.empty())
        {
            _focusedControl.part     = AlertHitTest::Part::Button;
            _focusedControl.buttonId = _model.buttons.front().id;
        }
        else
        {
            for (const auto& option : _model.options)
            {
                if (! IsOptionEnabled(option.id))
                    continue;
                _focusedControl.part     = AlertHitTest::Part::Option;
                _focusedControl.buttonId = option.id;
                return;
            }
        }
    }

    void InvalidateTextLayouts() noexcept
    {
        _cachedTitle.clear();
        _cachedMessage.clear();
        _cachedTextWidthDip = 0.0f;
        _titleLayout.reset();
        _bodyLayout.reset();
        _titleLayoutHeightDip = 0.0f;
        _bodyLayoutHeightDip  = 0.0f;
    }

    void EnsureTextLayouts(IDWriteFactory* dwriteFactory, float textWidthDip) noexcept
    {
        if (! dwriteFactory || ! _titleFormat || ! _bodyFormat)
        {
            return;
        }

        if (_cachedTitle == _model.title && _cachedMessage == _model.message && std::abs(_cachedTextWidthDip - textWidthDip) <= 0.5f)
        {
            return;
        }

        _cachedTitle        = _model.title;
        _cachedMessage      = _model.message;
        _cachedTextWidthDip = textWidthDip;

        _titleLayout.reset();
        _bodyLayout.reset();
        _titleLayoutHeightDip = 0.0f;
        _bodyLayoutHeightDip  = 0.0f;

        if (! _model.title.empty())
        {
            const HRESULT hr = dwriteFactory->CreateTextLayout(
                _model.title.c_str(), static_cast<UINT32>(_model.title.size()), _titleFormat.get(), textWidthDip, 1000.0f, _titleLayout.put());
            if (SUCCEEDED(hr) && _titleLayout)
            {
                DWRITE_TEXT_METRICS metrics{};
                if (SUCCEEDED(_titleLayout->GetMetrics(&metrics)))
                {
                    _titleLayoutHeightDip = metrics.height;
                }
            }
        }

        if (! _model.message.empty())
        {
            const HRESULT hr = dwriteFactory->CreateTextLayout(
                _model.message.c_str(), static_cast<UINT32>(_model.message.size()), _bodyFormat.get(), textWidthDip, 1000.0f, _bodyLayout.put());
            if (SUCCEEDED(hr) && _bodyLayout)
            {
                DWRITE_TEXT_METRICS metrics{};
                if (SUCCEEDED(_bodyLayout->GetMetrics(&metrics)))
                {
                    _bodyLayoutHeightDip = metrics.height;
                }
            }
        }
    }

    void InvalidateButtonLayouts() noexcept
    {
        _cachedButtonLabels.clear();
        _buttonBaseRects.clear();
        _buttonRects.clear();
    }

    void InvalidateLayout() noexcept
    {
        _panelRect                = {};
        _closeRect                = {};
        _layoutBodyTextRect       = {};
        _layoutIconRect           = {};
        _layoutTextRect           = {};
        _layoutPanelWidthDip      = 0.0f;
        _layoutPanelHeightDip     = 0.0f;
        _layoutButtonRowHeightDip = 0.0f;
        _layoutShowIcon           = false;
        _buttonRects.clear();
        _bodyViewport = {};
        _hasLayout    = false;
    }

    void EnsureOptionLayouts(IDWriteFactory* factory, float widthDip) noexcept
    {
        widthDip = std::max(1.0f, widthDip);
        _optionRects.resize(_model.options.size());
        for (size_t index = 0; index < _model.options.size(); ++index)
        {
            const auto& option = _model.options[index];
            auto& row          = _optionRects[index];
            std::wstring label = option.label;
            if (! option.choices.empty() && option.selectedIndex < option.choices.size())
                label.append(L": ").append(option.choices[option.selectedIndex].label);
            row.id = option.id;
            if (row.layout && row.label == label && _optionWidthDip == widthDip)
                continue;
            row.label = std::move(label);
            row.layout.reset();
            row.heightDip = 32.0f;
            if (SUCCEEDED(factory->CreateTextLayout(row.label.c_str(),
                                                    static_cast<UINT32>(row.label.size()),
                                                    _bodyFormat.get(),
                                                    std::max(1.0f, widthDip - 24.0f),
                                                    100000.0f,
                                                    row.layout.put())))
            {
                row.layout->SetFontSize(_buttonFormat->GetFontSize(), DWRITE_TEXT_RANGE{0u, static_cast<UINT32>(row.label.size())});
                row.layout->SetWordWrapping(DWRITE_WORD_WRAPPING_WRAP);
                DWRITE_TEXT_METRICS metrics{};
                if (SUCCEEDED(row.layout->GetMetrics(&metrics)))
                    row.heightDip = std::max(32.0f, std::ceil(metrics.height) + 16.0f);
            }
        }
        _optionWidthDip = widthDip;
    }

    void EnsureButtonLayouts(IDWriteFactory* dwriteFactory) noexcept
    {
        if (! dwriteFactory || ! _buttonFormat)
        {
            return;
        }

        std::vector<std::wstring_view> labels;
        labels.reserve(_model.buttons.size());
        for (const auto& button : _model.buttons)
        {
            labels.emplace_back(button.label);
        }

        if (labels.size() == _cachedButtonLabels.size())
        {
            bool same = true;
            for (size_t i = 0; i < labels.size(); ++i)
            {
                if (labels[i] != _cachedButtonLabels[i])
                {
                    same = false;
                    break;
                }
            }
            if (same)
            {
                return;
            }
        }

        _cachedButtonLabels.clear();
        _cachedButtonLabels.reserve(labels.size());
        for (const auto& label : labels)
        {
            _cachedButtonLabels.emplace_back(label);
        }

        _buttonBaseRects.clear();
        _buttonBaseRects.reserve(_model.buttons.size());

        for (const auto& button : _model.buttons)
        {
            ButtonRect btn{};
            btn.id            = button.id;
            btn.primary       = button.primary;
            btn.label         = button.label;
            btn.labelWidthDip = 0.0f;

            if (! button.label.empty())
            {
                wil::com_ptr<IDWriteTextLayout> layout;
                const HRESULT hr = dwriteFactory->CreateTextLayout(
                    button.label.c_str(), static_cast<UINT32>(button.label.size()), _buttonFormat.get(), 1000.0f, 1000.0f, layout.put());
                if (SUCCEEDED(hr) && layout)
                {
                    DWRITE_TEXT_METRICS metrics{};
                    if (SUCCEEDED(layout->GetMetrics(&metrics)))
                    {
                        btn.labelWidthDip = metrics.widthIncludingTrailingWhitespace;
                    }
                }
            }

            _buttonBaseRects.emplace_back(std::move(btn));
        }
    }

    void ResolvePalette(AlertSeverity severity,
                        AlertPresentation presentation,
                        D2D1::ColorF& panelBackground,
                        D2D1::ColorF& accentColor,
                        D2D1::ColorF& textColor) const noexcept
    {
        if (presentation == AlertPresentation::Copy)
        {
            panelBackground = _theme.infoBackground;
            accentColor     = _theme.infoText;
            textColor       = _theme.infoText;
            return;
        }

        if (presentation == AlertPresentation::Move)
        {
            panelBackground = _theme.warningBackground;
            accentColor     = _theme.warningText;
            textColor       = _theme.warningText;
            return;
        }

        if (presentation == AlertPresentation::Delete)
        {
            panelBackground = _theme.errorBackground;
            accentColor     = _theme.errorText;
            textColor       = _theme.errorText;
            return;
        }

        if (severity == AlertSeverity::Error)
        {
            panelBackground = _theme.errorBackground;
            accentColor     = _theme.errorText;
            textColor       = _theme.errorText;
            return;
        }

        if (severity == AlertSeverity::Warning)
        {
            panelBackground = _theme.warningBackground;
            accentColor     = _theme.warningText;
            textColor       = _theme.warningText;
            return;
        }

        if (severity == AlertSeverity::Info)
        {
            panelBackground = _theme.infoBackground;
            accentColor     = _theme.infoText;
            textColor       = _theme.infoText;
            return;
        }

        if (severity == AlertSeverity::Busy)
        {
            panelBackground = _theme.background;
            accentColor     = _theme.accent;
            textColor       = _theme.text;
            return;
        }
    }

    void DrawCloseButton(ID2D1RenderTarget* target, const D2D1_RECT_F& rect, const D2D1::ColorF& accentColor, float opacity) noexcept
    {
        if (! target || ! _backgroundBrush || ! _textBrush)
        {
            return;
        }

        const bool hot     = (_hot.part == AlertHitTest::Part::Close);
        const bool focused = (_focusedControl.part == AlertHitTest::Part::Close);
        const float w      = std::max(0.0f, rect.right - rect.left);
        const float h      = std::max(0.0f, rect.bottom - rect.top);
        const float size   = std::min(w, h);
        const float radius = size * 0.35f;

        const wchar_t closeGlyph = _iconGlyphSet == IconGlyphSet::Fluent ? FluentIcons::kClear : FluentIcons::kFallbackClear;
        const wchar_t closeText[2]{closeGlyph, L'\0'};

        _backgroundBrush->SetOpacity(opacity);
        DxUi::ButtonChromeDrawSpec chrome{};
        chrome.bounds          = rect;
        chrome.text            = _closeIconFormat ? std::wstring_view(closeText, 1u) : std::wstring_view{};
        chrome.variant         = DxUi::ButtonVariant::IconOnly;
        chrome.hovered         = hot;
        chrome.focused         = focused;
        chrome.keyboardFocused = focused;
        chrome.customStyle     = DxUi::ButtonChromeCustomStyle{
            .fill            = D2D1::ColorF(accentColor.r, accentColor.g, accentColor.b, 0.14f),
            .text            = accentColor,
            .showFill        = hot,
            .showBorder      = false,
            .showFocus       = focused,
            .cornerRadiusDip = radius,
        };
        DxUi::DrawButtonChrome(target, _backgroundBrush.get(), nullptr, _closeIconFormat.get(), MakeChromeThemePalette(), chrome);
#if defined(ENABLE_TESTS)
        _debugUsesSharedCloseChrome = true;
        _debugLastDrawnCloseGlyph   = _closeIconFormat ? closeGlyph : L'\0';
#endif

        if (_closeIconFormat)
        {
            return;
        }

        const float stroke = std::clamp(size * 0.10f, 1.5f, 2.5f);
        const float pad    = size * 0.28f;
        _textBrush->SetColor(accentColor);
        _textBrush->SetOpacity(opacity);
        target->DrawLine(D2D1::Point2F(rect.left + pad, rect.top + pad), D2D1::Point2F(rect.right - pad, rect.bottom - pad), _textBrush.get(), stroke);
        target->DrawLine(D2D1::Point2F(rect.right - pad, rect.top + pad), D2D1::Point2F(rect.left + pad, rect.bottom - pad), _textBrush.get(), stroke);
    }

    float MeasureFooter(IDWriteFactory* factory, float widthDip) noexcept
    {
        _buttonRects = _buttonBaseRects;
        if (_buttonRects.empty())
            return 0.0f;
        widthDip            = std::max(1.0f, widthDip);
        constexpr float gap = 10.0f;
        float intrinsic     = -gap;
        for (const auto& button : _buttonRects)
            intrinsic += std::max(84.0f, button.labelWidthDip + 28.0f) + gap;
        const bool stacked = intrinsic > widthDip;
        float left         = stacked ? 0.0f : widthDip - intrinsic;
        float top          = 0.0f;
        for (auto& button : _buttonRects)
        {
            const float width = stacked ? widthDip : std::max(84.0f, button.labelWidthDip + 28.0f);
            float height      = 32.0f;
            if (stacked && SUCCEEDED(factory->CreateTextLayout(button.label.data(),
                                                               static_cast<UINT32>(button.label.size()),
                                                               _buttonFormat.get(),
                                                               std::max(1.0f, width - 28.0f),
                                                               100000.0f,
                                                               button.layout.put())))
            {
                button.layout->SetWordWrapping(DWRITE_WORD_WRAPPING_WRAP);
                button.layout->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR);
                DWRITE_TEXT_METRICS metrics{};
                if (SUCCEEDED(button.layout->GetMetrics(&metrics)))
                    height = std::max(height, std::ceil(metrics.height) + 16.0f);
            }
            button.rect = D2D1::RectF(left, top, left + width, top + height);
            if (stacked)
                top += height + gap;
            else
                left += width + gap;
        }
        return stacked ? top - gap : 32.0f;
    }

    [[nodiscard]] DxUi::ThemePalette MakeChromeThemePalette() const noexcept
    {
        // AlertOverlay paints from its own AlertTheme, but the shared button
        // chrome helper consumes a DxUi::ThemePalette (a Standard focus ring is
        // painted from the palette's focus strokes). Derive the fields the
        // chrome path can read from the overlay theme so the ring stays visible
        // and theme-correct instead of relying on default-palette colors.
        DxUi::ThemePalette palette{};
        palette.dark         = _theme.darkBase;
        palette.highContrast = _theme.highContrast;
        palette.accent       = _theme.accent;
        DxUi::RefreshAccentVariants(palette, _theme.darkBase);
        palette.text             = _theme.text;
        palette.windowBackground = _theme.background;
        palette.focusStroke      = _theme.accent;
        palette.focusStrokeOuter = _theme.darkBase ? D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f) : D2D1::ColorF(0.0f, 0.0f, 0.0f, 1.0f);
        palette.focusStrokeInner = _theme.darkBase ? D2D1::ColorF(0.0f, 0.0f, 0.0f, 1.0f) : D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f);
        if (_theme.highContrast)
        {
            palette.focusStrokeOuter = _theme.text;
            palette.focusStrokeInner = _theme.background;
        }
        return palette;
    }

    [[nodiscard]] DxUi::ButtonChromeCustomStyle MakeOverlayButtonChromeStyle(const ButtonRect& btn, bool hot, bool focused, float cornerDip) const noexcept
    {
        if (btn.primary)
        {
            return DxUi::ButtonChromeCustomStyle{
                .fill            = hot ? D2D1::ColorF(_theme.accent.r, _theme.accent.g, _theme.accent.b, 0.95f) : _theme.accent,
                .border          = _theme.selectionText,
                .focus           = _theme.selectionText,
                .text            = _theme.selectionText,
                .showFill        = true,
                .showBorder      = true,
                .showFocus       = focused,
                .cornerRadiusDip = cornerDip,
                .borderStrokeDip = 1.0f,
                .focusOutsetDip  = 2.0f,
                .focusStrokeDip  = 2.0f,
            };
        }

        const D2D1::ColorF border = hot ? _theme.accent : _theme.text;
        const D2D1::ColorF fill   = hot ? D2D1::ColorF(border.r, border.g, border.b, 0.10f) : D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
        return DxUi::ButtonChromeCustomStyle{
            .fill            = fill,
            .border          = border,
            .focus           = _theme.accent,
            .text            = _theme.text,
            .showFill        = hot,
            .showBorder      = true,
            .showFocus       = focused,
            .cornerRadiusDip = cornerDip,
            .borderStrokeDip = 1.0f,
            .focusOutsetDip  = 2.0f,
            .focusStrokeDip  = 2.0f,
        };
    }

    void DrawButtons(ID2D1RenderTarget* target, float opacity, float cornerDip) noexcept
    {
        if (! target || ! _backgroundBrush || ! _textBrush)
        {
            return;
        }

        for (const auto& btn : _buttonRects)
        {
            const bool hot     = (_hot.part == AlertHitTest::Part::Button && _hot.buttonId == btn.id);
            const bool focused = (_focusedControl.part == AlertHitTest::Part::Button && _focusedControl.buttonId == btn.id);

            _backgroundBrush->SetOpacity(opacity);
            DxUi::ButtonChromeDrawSpec chrome{};
            chrome.bounds          = btn.rect;
            chrome.text            = btn.layout ? std::wstring_view{} : btn.label;
            chrome.primary         = btn.primary;
            chrome.hovered         = hot;
            chrome.focused         = focused;
            chrome.keyboardFocused = focused;
            chrome.customStyle     = MakeOverlayButtonChromeStyle(btn, hot, focused, cornerDip);
            DxUi::DrawButtonChrome(target, _backgroundBrush.get(), _buttonFormat.get(), nullptr, MakeChromeThemePalette(), chrome);
            if (btn.layout)
            {
                _textBrush->SetColor(btn.primary ? _theme.selectionText : _theme.text);
                _textBrush->SetOpacity(opacity);
                target->DrawTextLayout(D2D1::Point2F(btn.rect.left + 14.0f, btn.rect.top + 8.0f), btn.layout.get(), _textBrush.get());
            }
#if defined(ENABLE_TESTS)
            _debugUsesSharedButtonChrome = true;
#endif
        }
    }

    void DrawOptions(ID2D1RenderTarget* target, float opacity, float cornerDip) noexcept
    {
        if (! target || ! _backgroundBrush || ! _textBrush)
        {
            return;
        }

        for (const auto& option : _optionRects)
        {
            const bool enabled = IsOptionEnabled(option.id);
            const bool hot     = enabled && _hot.part == AlertHitTest::Part::Option && _hot.buttonId == option.id;
            const bool focused = enabled && _focusedControl.part == AlertHitTest::Part::Option && _focusedControl.buttonId == option.id;
            ButtonRect chromeSource{};
            chromeSource.id      = option.id;
            chromeSource.rect    = option.rect;
            chromeSource.label   = option.label;
            chromeSource.primary = false;

            _backgroundBrush->SetOpacity(opacity);
            DxUi::ButtonChromeDrawSpec chrome{};
            chrome.bounds          = option.rect;
            chrome.enabled         = enabled;
            chrome.text            = {};
            chrome.hovered         = hot;
            chrome.focused         = focused;
            chrome.keyboardFocused = focused;
            chrome.customStyle     = MakeOverlayButtonChromeStyle(chromeSource, hot, focused, cornerDip);
            // Custom chrome owns its disabled styling. Remove the button outline
            // but keep the explanation at full contrast, including High Contrast.
            if (! enabled)
                chrome.customStyle.value().showBorder = false;
            DxUi::DrawButtonChrome(target, _backgroundBrush.get(), _buttonFormat.get(), nullptr, MakeChromeThemePalette(), chrome);
            if (option.layout)
            {
                _textBrush->SetColor(_theme.text);
                _textBrush->SetOpacity(opacity);
                target->DrawTextLayout(D2D1::Point2F(option.rect.left + 12.0f, option.rect.top + 8.0f), option.layout.get(), _textBrush.get());
            }
#if defined(ENABLE_TESTS)
            _debugUsesSharedButtonChrome = true;
#endif
        }
    }

    void DrawPromptIcon(ID2D1RenderTarget* target,
                        ID2D1SolidColorBrush* brush,
                        AlertSeverity severity,
                        AlertPresentation presentation,
                        const D2D1_RECT_F& rect,
                        float opacity,
                        uint64_t elapsedMs) noexcept
    {
        if (! target || ! brush)
        {
            return;
        }

#if defined(ENABLE_TESTS)
        _debugLastDrawnIconPresentation = presentation;
        _debugLastDrawnIconGlyph        = L'\0';
#endif

        const float width  = std::max(0.0f, rect.right - rect.left);
        const float height = std::max(0.0f, rect.bottom - rect.top);
        const float size   = std::min(width, height);
        if (size <= 0.0f)
        {
            return;
        }

        const D2D1_POINT_2F center = D2D1::Point2F((rect.left + rect.right) * 0.5f, (rect.top + rect.bottom) * 0.5f);
        const float stroke         = std::clamp(size * 0.06f, 2.0f, 4.0f);
        brush->SetOpacity(opacity);

        if (presentation == AlertPresentation::Copy)
        {
            if (_iconFormat && _iconGlyphSet != IconGlyphSet::None)
            {
                const wchar_t glyph = _iconGlyphSet == IconGlyphSet::Fluent ? FluentIcons::kCopyTo : FluentIcons::kFallbackCopyTo;
#if defined(ENABLE_TESTS)
                _debugLastDrawnIconGlyph = glyph;
#endif
                const wchar_t text[2]{glyph, L'\0'};
                target->DrawTextW(text, 1u, _iconFormat.get(), rect, brush, D2D1_DRAW_TEXT_OPTIONS_NO_SNAP, DWRITE_MEASURING_MODE_NATURAL);
                return;
            }

            const float cardWidth   = size * 0.52f;
            const float cardHeight  = size * 0.62f;
            const float offset      = size * 0.13f;
            const float radius      = std::max(2.0f, size * 0.05f);
            const D2D1_RECT_F back  = D2D1::RectF(center.x - cardWidth * 0.5f - offset,
                                                  center.y - cardHeight * 0.5f - offset,
                                                  center.x + cardWidth * 0.5f - offset,
                                                  center.y + cardHeight * 0.5f - offset);
            const D2D1_RECT_F front = D2D1::RectF(center.x - cardWidth * 0.5f + offset,
                                                  center.y - cardHeight * 0.5f + offset,
                                                  center.x + cardWidth * 0.5f + offset,
                                                  center.y + cardHeight * 0.5f + offset);
            target->DrawRoundedRectangle(D2D1::RoundedRect(back, radius, radius), brush, stroke);
            target->DrawRoundedRectangle(D2D1::RoundedRect(front, radius, radius), brush, stroke);
            return;
        }

        if (presentation == AlertPresentation::Move)
        {
            if (_iconFormat && _iconGlyphSet != IconGlyphSet::None)
            {
                const wchar_t glyph = _iconGlyphSet == IconGlyphSet::Fluent ? FluentIcons::kMoveToFolder : FluentIcons::kFallbackMoveToFolder;
#if defined(ENABLE_TESTS)
                _debugLastDrawnIconGlyph = glyph;
#endif
                const wchar_t text[2]{glyph, 0};
                target->DrawTextW(text, 1u, _iconFormat.get(), rect, brush, D2D1_DRAW_TEXT_OPTIONS_NO_SNAP, DWRITE_MEASURING_MODE_NATURAL);
                return;
            }

            const float halfShaft = size * 0.30f;
            const float head      = size * 0.22f;
            const float tip       = size * 0.38f;
            target->DrawLine(D2D1::Point2F(center.x - halfShaft, center.y), D2D1::Point2F(center.x + tip, center.y), brush, stroke);
            target->DrawLine(D2D1::Point2F(center.x + tip, center.y), D2D1::Point2F(center.x + tip - head, center.y - head), brush, stroke);
            target->DrawLine(D2D1::Point2F(center.x + tip, center.y), D2D1::Point2F(center.x + tip - head, center.y + head), brush, stroke);
            return;
        }

        if (presentation == AlertPresentation::Delete)
        {
            if (_iconFormat && _iconGlyphSet != IconGlyphSet::None)
            {
                const wchar_t glyph = _iconGlyphSet == IconGlyphSet::Fluent ? FluentIcons::kDelete : FluentIcons::kFallbackDelete;
#if defined(ENABLE_TESTS)
                _debugLastDrawnIconGlyph = glyph;
#endif
                const wchar_t text[2]{glyph, L'\0'};
                target->DrawTextW(text, 1u, _iconFormat.get(), rect, brush, D2D1_DRAW_TEXT_OPTIONS_NO_SNAP, DWRITE_MEASURING_MODE_NATURAL);
                return;
            }

            DrawSeverityIcon(target, brush, AlertSeverity::Error, rect, opacity, elapsedMs);
            return;
        }

        DrawSeverityIcon(target, brush, severity, rect, opacity, elapsedMs);
    }

    void DrawSeverityIcon(
        ID2D1RenderTarget* target, ID2D1SolidColorBrush* brush, AlertSeverity severity, const D2D1_RECT_F& rect, float opacity, uint64_t elapsedMs) noexcept
    {
        if (! target || ! brush)
        {
            return;
        }

        if (severity != AlertSeverity::Busy && _iconFormat && _iconGlyphSet != IconGlyphSet::None)
        {
            constexpr wchar_t kFallbackInfo = L'\u2139'; // ℹ

            wchar_t glyph = L'?';
            if (_iconGlyphSet == IconGlyphSet::Fluent)
            {
                switch (severity)
                {
                    case AlertSeverity::Error: glyph = L'\uEA39'; break;
                    case AlertSeverity::Warning: glyph = L'\uE7BA'; break;
                    case AlertSeverity::Info: glyph = L'\uE946'; break;
                    case AlertSeverity::Busy: break;
                    default: break;
                }
            }
            else
            {
                switch (severity)
                {
                    case AlertSeverity::Error: glyph = L'\u2716'; break;   // ✖
                    case AlertSeverity::Warning: glyph = L'\u26A0'; break; // ⚠
                    case AlertSeverity::Info: glyph = kFallbackInfo; break;
                    case AlertSeverity::Busy: break;
                    default: break;
                }
            }

            const wchar_t text[2]{glyph, 0};
            brush->SetOpacity(opacity);
            target->DrawTextW(text, 1, _iconFormat.get(), rect, brush, D2D1_DRAW_TEXT_OPTIONS_NO_SNAP, DWRITE_MEASURING_MODE_NATURAL);
            return;
        }

        constexpr float kPi = 3.14159265358979323846f;

        const float width  = std::max(0.0f, rect.right - rect.left);
        const float height = std::max(0.0f, rect.bottom - rect.top);
        const float size   = std::min(width, height);
        if (size <= 0.0f)
        {
            return;
        }

        const D2D1_POINT_2F center = D2D1::Point2F((rect.left + rect.right) * 0.5f, (rect.top + rect.bottom) * 0.5f);
        const float radius         = size * 0.46f;
        const float stroke         = std::clamp(size * 0.06f, 2.0f, 4.0f);

        brush->SetOpacity(opacity);

        if (severity == AlertSeverity::Error)
        {
            target->DrawEllipse(D2D1::Ellipse(center, radius, radius), brush, stroke);

            const float x = radius * 0.45f;
            const float y = radius * 0.45f;
            target->DrawLine(D2D1::Point2F(center.x - x, center.y - y), D2D1::Point2F(center.x + x, center.y + y), brush, stroke);
            target->DrawLine(D2D1::Point2F(center.x - x, center.y + y), D2D1::Point2F(center.x + x, center.y - y), brush, stroke);
            return;
        }

        if (severity == AlertSeverity::Warning)
        {
            const float a          = -kPi / 2.0f;
            const float b          = 5.0f * kPi / 6.0f;
            const float c          = kPi / 6.0f;
            const D2D1_POINT_2F p0 = D2D1::Point2F(center.x + radius * std::cos(a), center.y + radius * std::sin(a));
            const D2D1_POINT_2F p1 = D2D1::Point2F(center.x + radius * std::cos(b), center.y + radius * std::sin(b));
            const D2D1_POINT_2F p2 = D2D1::Point2F(center.x + radius * std::cos(c), center.y + radius * std::sin(c));

            target->DrawLine(p0, p1, brush, stroke);
            target->DrawLine(p1, p2, brush, stroke);
            target->DrawLine(p2, p0, brush, stroke);

            const float exHeight = radius * 0.55f;
            const float exTop    = center.y - exHeight * 0.45f;
            const float exBottom = center.y + exHeight * 0.15f;
            target->DrawLine(D2D1::Point2F(center.x, exTop), D2D1::Point2F(center.x, exBottom), brush, stroke);
            target->FillEllipse(D2D1::Ellipse(D2D1::Point2F(center.x, center.y + exHeight * 0.40f), stroke * 0.35f, stroke * 0.35f), brush);
            return;
        }

        if (severity == AlertSeverity::Info)
        {
            target->DrawEllipse(D2D1::Ellipse(center, radius, radius), brush, stroke);

            const float dotY = center.y - radius * 0.28f;
            target->FillEllipse(D2D1::Ellipse(D2D1::Point2F(center.x, dotY), stroke * 0.35f, stroke * 0.35f), brush);

            const float lineTop    = center.y - radius * 0.05f;
            const float lineBottom = center.y + radius * 0.38f;
            target->DrawLine(D2D1::Point2F(center.x, lineTop), D2D1::Point2F(center.x, lineBottom), brush, stroke);
            return;
        }

        if (severity == AlertSeverity::Busy)
        {
            constexpr int dotCount = 12;
            const float ringRadius = radius * 0.72f;
            const float dotRadius  = std::max(stroke * 0.45f, 2.0f);
            const float cycle      = static_cast<float>(elapsedMs % 900u) / 900.0f;

            for (int i = 0; i < dotCount; ++i)
            {
                const float angle = (static_cast<float>(i) / static_cast<float>(dotCount)) * (2.0f * kPi);
                const float local =
                    std::fmod((cycle * static_cast<float>(dotCount)) - static_cast<float>(i) + static_cast<float>(dotCount), static_cast<float>(dotCount));
                const float intensity  = 1.0f - (local / static_cast<float>(dotCount));
                const float dotOpacity = std::lerp(0.18f, 1.0f, intensity * intensity);

                brush->SetOpacity(opacity * dotOpacity);
                const D2D1_POINT_2F dotCenter = D2D1::Point2F(center.x + ringRadius * std::cos(angle), center.y + ringRadius * std::sin(angle));
                target->FillEllipse(D2D1::Ellipse(dotCenter, dotRadius, dotRadius), brush);
            }

            brush->SetOpacity(opacity);
            return;
        }
    }

private:
    AlertModel _model{};
    AlertTheme _theme{};

    ID2D1RenderTarget* _targetIdentity = nullptr;
    IDWriteFactory* _dwriteIdentity    = nullptr;

    wil::com_ptr<ID2D1SolidColorBrush> _scrimBrush;
    wil::com_ptr<ID2D1SolidColorBrush> _backgroundBrush;
    wil::com_ptr<ID2D1SolidColorBrush> _textBrush;

    wil::com_ptr<IDWriteTextFormat> _titleFormat;
    wil::com_ptr<IDWriteTextFormat> _bodyFormat;
    wil::com_ptr<IDWriteTextFormat> _buttonFormat;
    wil::com_ptr<IDWriteTextFormat> _iconFormat;
    wil::com_ptr<IDWriteTextFormat> _closeIconFormat;
    IconGlyphSet _iconGlyphSet = IconGlyphSet::None;

    std::wstring _cachedTitle;
    std::wstring _cachedMessage;
    float _cachedTextWidthDip = 0.0f;
    wil::com_ptr<IDWriteTextLayout> _titleLayout;
    wil::com_ptr<IDWriteTextLayout> _bodyLayout;
    float _titleLayoutHeightDip = 0.0f;
    float _bodyLayoutHeightDip  = 0.0f;

    std::vector<std::wstring_view> _cachedButtonLabels;
    std::vector<ButtonRect> _buttonBaseRects;
    std::vector<ButtonRect> _buttonRects;
    std::vector<OptionRect> _optionRects;

    float _layoutClientWidthDip  = 0.0f;
    float _layoutClientHeightDip = 0.0f;
    float _optionWidthDip        = 0.0f;
    float _scrollOffsetDip       = 0.0f;
    bool _scrollingEnabled       = false;
    bool _scrollFooter           = false;
    float _scrollMaximumDip      = 0.0f;
    D2D1_RECT_F _bodyViewport{};
    D2D1_RECT_F _panelRect{};
    D2D1_RECT_F _closeRect{};
    D2D1_RECT_F _layoutBodyTextRect{};
    D2D1_RECT_F _layoutIconRect{};
    D2D1_RECT_F _layoutTextRect{};
    float _layoutPanelWidthDip      = 0.0f;
    float _layoutPanelHeightDip     = 0.0f;
    float _layoutButtonRowHeightDip = 0.0f;
    bool _layoutShowIcon            = false;
    bool _hasLayout                 = false;

    AlertHitTest _hot{};
    AlertHitTest _focusedControl{};
    uint64_t _startTickMs = 0;
#if defined(ENABLE_TESTS)
    uint64_t _debugLayoutPassCount                    = 0u;
    float _debugLastDrawOpacity                       = 0.0f;
    float _debugLastDrawScrimOpacity                  = 0.0f;
    bool _debugUsesSharedCloseChrome                  = false;
    bool _debugUsesSharedButtonChrome                 = false;
    AlertPresentation _debugLastDrawnIconPresentation = AlertPresentation::Severity;
    wchar_t _debugLastDrawnIconGlyph                  = L'\0';
    wchar_t _debugLastDrawnCloseGlyph                 = L'\0';
#endif
};
} // namespace RedSalamander::Ui
