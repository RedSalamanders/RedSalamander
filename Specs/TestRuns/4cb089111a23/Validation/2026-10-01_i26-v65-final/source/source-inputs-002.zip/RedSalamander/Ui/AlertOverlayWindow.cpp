#include "AlertOverlayWindow.h"
#include "AnimationDispatcher.h"
#include "Win32CallbackHelpers.h"
#include "WindowMessages.h"

#include <UIAutomation.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cwctype>
#include <format>
#include <new>
#include <oleauto.h>
#include <vector>
#include <windowsx.h>

#pragma comment(lib, "uiautomationcore.lib")

namespace RedSalamander::Ui
{
namespace
{
// The alert records its existing DIP-based draw before host composition. This
// root only replays prepared content; it adds no competing input/UIA controls.
class AlertPresentationRoot final : public DxUi::Control
{
public:
    AlertPresentationRoot(const wil::com_ptr<ID2D1DeviceContext>& context, const wil::com_ptr<ID2D1CommandList>& frame) noexcept
        : _context(context),
          _frame(frame)
    {
    }
    AlertPresentationRoot(const AlertPresentationRoot&)            = delete;
    AlertPresentationRoot(AlertPresentationRoot&&)                 = delete;
    AlertPresentationRoot& operator=(const AlertPresentationRoot&) = delete;
    AlertPresentationRoot& operator=(AlertPresentationRoot&&)      = delete;

    void Paint(DxUi::WindowHost& host) const override
    {
        if (auto* context = host.GetDeviceContext(); context && context == _context.get() && _frame)
            context->DrawImage(_frame.get());
        else if (_frame)
            host.Invalidate(); // Retry only a prepared frame invalidated by device loss, never a persistent preparation failure.
    }

private:
    const wil::com_ptr<ID2D1DeviceContext>& _context;
    const wil::com_ptr<ID2D1CommandList>& _frame;
};

constexpr wchar_t kAlertOverlayWindowClassName[] = L"RedSalamander.AlertOverlayWindow";
constexpr uint64_t kShowAnimationMs              = 220;
constexpr wchar_t kParentOriginalWndProcProp[]   = L"RedSalamander.AlertOverlay.ParentOriginalWndProc";
constexpr wchar_t kParentStateProp[]             = L"RedSalamander.AlertOverlay.ParentState";
constexpr wchar_t kAnchorOriginalWndProcProp[]   = L"RedSalamander.AlertOverlay.AnchorOriginalWndProc";
constexpr wchar_t kAnchorStateProp[]             = L"RedSalamander.AlertOverlay.AnchorState";

// Synchronous in-process SendMessage only: the sender retains both payload and
// provider until the UI thread finishes. Never post or timeout a stack payload.
struct AlertUiaCall
{
    void* context                     = nullptr;
    HRESULT (*invoke)(void*) noexcept = nullptr;
    HRESULT result                    = static_cast<HRESULT>(UIA_E_ELEMENTNOTAVAILABLE);
};

LRESULT DispatchAlertUiaCall(LPARAM parameter) noexcept
{
    auto* call = reinterpret_cast<AlertUiaCall*>(parameter);
    if (! call || ! call->invoke)
        return FALSE;
    call->result = call->invoke(call->context);
    return TRUE;
}

POINT PointFromLParam(LPARAM lp) noexcept
{
    POINT pt{};
    pt.x = static_cast<LONG>(static_cast<short>(LOWORD(lp)));
    pt.y = static_cast<LONG>(static_cast<short>(HIWORD(lp)));
    return pt;
}

[[maybe_unused]] [[nodiscard]] WNDPROC GetStoredWndProc(HWND hwnd, const wchar_t* propName) noexcept
{
    return Win32Callback::GetStoredWndProc(hwnd, propName);
}

[[nodiscard]] bool InstallWndProcHook(HWND hwnd, const wchar_t* originalWndProcProp, WNDPROC wndProc) noexcept
{
    return Win32Callback::InstallWndProcHook(hwnd, originalWndProcProp, wndProc);
}

void RestoreWndProcHook(HWND hwnd, const wchar_t* originalWndProcProp, const wchar_t* stateProp) noexcept
{
    if (! hwnd)
    {
        return;
    }

    Win32Callback::RestoreWndProcHook(hwnd, originalWndProcProp);

    RemovePropW(hwnd, originalWndProcProp);
    RemovePropW(hwnd, stateProp);
}

LRESULT CallStoredWndProc(HWND hwnd, const wchar_t* originalWndProcProp, UINT msg, WPARAM wp, LPARAM lp) noexcept
{
    return Win32Callback::CallStoredWndProc(hwnd, originalWndProcProp, msg, wp, lp);
}
} // namespace

class AlertOverlayUiaProvider final : public IRawElementProviderSimple,
                                      public IRawElementProviderFragment,
                                      public IRawElementProviderFragmentRoot,
                                      public IInvokeProvider
{
public:
    enum class ElementKind : uint8_t
    {
        Root,
        Text,
        CloseButton,
        Option,
        Button,
    };

    struct ElementId
    {
        ElementKind kind = ElementKind::Root;
        size_t index     = 0u;
    };

    AlertOverlayUiaProvider(HWND hwnd, ElementId id) noexcept : _hwnd(hwnd), _id(id)
    {
    }

    AlertOverlayUiaProvider(const AlertOverlayUiaProvider&)            = delete;
    AlertOverlayUiaProvider& operator=(const AlertOverlayUiaProvider&) = delete;
    AlertOverlayUiaProvider(AlertOverlayUiaProvider&&)                 = delete;
    AlertOverlayUiaProvider& operator=(AlertOverlayUiaProvider&&)      = delete;

    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** object) noexcept override
    {
        if (! object)
        {
            return E_POINTER;
        }

        *object = nullptr;
        if (riid == __uuidof(IUnknown) || riid == __uuidof(IRawElementProviderSimple))
        {
            *object = static_cast<IRawElementProviderSimple*>(this);
        }
        else if (riid == __uuidof(IRawElementProviderFragment))
        {
            *object = static_cast<IRawElementProviderFragment*>(this);
        }
        else if (_id.kind == ElementKind::Root && riid == __uuidof(IRawElementProviderFragmentRoot))
        {
            *object = static_cast<IRawElementProviderFragmentRoot*>(this);
        }
        else if (IsButtonLike() && riid == __uuidof(IInvokeProvider))
        {
            *object = static_cast<IInvokeProvider*>(this);
        }
        else
        {
            return E_NOINTERFACE;
        }

        AddRef();
        return S_OK;
    }

    ULONG STDMETHODCALLTYPE AddRef() noexcept override
    {
        return _refCount.fetch_add(1u, std::memory_order_relaxed) + 1u;
    }

    ULONG STDMETHODCALLTYPE Release() noexcept override
    {
        const ULONG remaining = _refCount.fetch_sub(1u, std::memory_order_acq_rel) - 1u;
        if (remaining == 0u)
        {
            delete this;
        }
        return remaining;
    }

    HRESULT STDMETHODCALLTYPE get_ProviderOptions(ProviderOptions* options) noexcept override
    {
        if (! options)
        {
            return E_POINTER;
        }

        *options = ProviderOptions_ServerSideProvider;
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetPatternProvider(PATTERNID patternId, IUnknown** provider) noexcept override
    {
        if (! provider)
        {
            return E_POINTER;
        }

        *provider = nullptr;
        if (patternId == UIA_InvokePatternId && IsButtonLike())
        {
            *provider = static_cast<IInvokeProvider*>(this);
            AddRef();
        }
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetPropertyValue(PROPERTYID propertyId, VARIANT* value) noexcept override
    {
        if (GetWindowThreadProcessId(_hwnd, nullptr) != GetCurrentThreadId())
            return OnOwnerThread([&]() noexcept { return GetPropertyValue(propertyId, value); });
        if (! value)
        {
            return E_POINTER;
        }

        VariantInit(value);
        AlertOverlayWindow* window = ResolveWindow();
        if (! window)
        {
            if (propertyId == UIA_IsOffscreenPropertyId)
            {
                return SetBool(value, true);
            }
            return S_OK;
        }

        switch (propertyId)
        {
            case UIA_ControlTypePropertyId: return SetI4(value, ControlType());
            case UIA_NamePropertyId: return SetBstr(value, Name(*window));
            case UIA_AutomationIdPropertyId: return SetBstr(value, AutomationId(*window));
            case UIA_ClassNamePropertyId: return SetBstr(value, kAlertOverlayWindowClassName);
            case UIA_FrameworkIdPropertyId: return SetBstr(value, L"RedSalamander");
            case UIA_IsControlElementPropertyId: return SetBool(value, true);
            case UIA_IsContentElementPropertyId: return SetBool(value, _id.kind != ElementKind::Root);
            case UIA_IsEnabledPropertyId: return SetBool(value, IsEnabled(*window));
            case UIA_IsKeyboardFocusablePropertyId: return SetBool(value, IsEnabled(*window) && (IsButtonLike() || _id.kind == ElementKind::Root));
            case UIA_HasKeyboardFocusPropertyId:
            {
                const auto focused = window->_overlay.GetFocusedControl();
                const auto hit     = ControlHit(*window);
                return SetBool(value,
                               ::GetFocus() == _hwnd && (_id.kind == ElementKind::Root || (hit.part != AlertHitTest::Part::None && hit.part == focused.part &&
                                                                                           hit.buttonId == focused.buttonId)));
            }
            case UIA_IsOffscreenPropertyId:
            {
                const auto rect = VisibleRect(*window);
                return SetBool(value, IsWindowVisible(_hwnd) == FALSE || rect.right <= rect.left || rect.bottom <= rect.top);
            }
            case UIA_NativeWindowHandlePropertyId:
                if (_id.kind == ElementKind::Root)
                {
                    return SetI4(value, static_cast<int>(reinterpret_cast<ULONG_PTR>(_hwnd) & 0x7FFFFFFFu));
                }
                return S_OK;
            default: return S_OK;
        }
    }

    HRESULT STDMETHODCALLTYPE get_HostRawElementProvider(IRawElementProviderSimple** provider) noexcept override
    {
        if (! provider)
        {
            return E_POINTER;
        }

        *provider = nullptr;
        if (_id.kind != ElementKind::Root)
        {
            return S_OK;
        }

        return UiaHostProviderFromHwnd(_hwnd, provider);
    }

    HRESULT STDMETHODCALLTYPE Navigate(NavigateDirection direction, IRawElementProviderFragment** provider) noexcept override
    {
        if (GetWindowThreadProcessId(_hwnd, nullptr) != GetCurrentThreadId())
            return OnOwnerThread([&]() noexcept { return Navigate(direction, provider); });
        if (! provider)
        {
            return E_POINTER;
        }

        *provider                  = nullptr;
        AlertOverlayWindow* window = ResolveWindow();
        if (! window)
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }

        const std::vector<ElementId> children = Children(*window);
        switch (direction)
        {
            case NavigateDirection_FirstChild:
                if (_id.kind == ElementKind::Root && ! children.empty())
                {
                    return CreateFragment(_hwnd, children.front(), provider);
                }
                return S_OK;
            case NavigateDirection_LastChild:
                if (_id.kind == ElementKind::Root && ! children.empty())
                {
                    return CreateFragment(_hwnd, children.back(), provider);
                }
                return S_OK;
            case NavigateDirection_Parent:
                if (_id.kind != ElementKind::Root)
                {
                    return CreateFragment(_hwnd, ElementId{}, provider);
                }
                return S_OK;
            case NavigateDirection_NextSibling:
            case NavigateDirection_PreviousSibling:
                if (_id.kind == ElementKind::Root)
                {
                    return S_OK;
                }
                return NavigateSibling(children, direction, provider);
            default: return S_OK;
        }
    }

    HRESULT STDMETHODCALLTYPE GetRuntimeId(SAFEARRAY** runtimeId) noexcept override
    {
        if (! runtimeId)
        {
            return E_POINTER;
        }

        *runtimeId       = nullptr;
        SAFEARRAY* array = SafeArrayCreateVector(VT_I4, 0, 5u);
        if (! array)
        {
            return E_OUTOFMEMORY;
        }

        const ULONG_PTR hwndValue = reinterpret_cast<ULONG_PTR>(_hwnd);
        const LONG values[5]      = {UiaAppendRuntimeId,
                                     static_cast<LONG>(hwndValue & 0x7FFFFFFFu),
                                     static_cast<LONG>((hwndValue >> 32u) & 0x7FFFFFFFu),
                                     static_cast<LONG>(static_cast<int>(_id.kind)),
                                     static_cast<LONG>(_id.index & 0x7FFFFFFFu)};

        for (LONG i = 0; i < 5; ++i)
        {
            LONG item        = values[i];
            const HRESULT hr = SafeArrayPutElement(array, &i, &item);
            if (FAILED(hr))
            {
                SafeArrayDestroy(array);
                return hr;
            }
        }

        *runtimeId = array;
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE get_BoundingRectangle(UiaRect* rect) noexcept override
    {
        if (GetWindowThreadProcessId(_hwnd, nullptr) != GetCurrentThreadId())
            return OnOwnerThread([&]() noexcept { return get_BoundingRectangle(rect); });
        if (! rect)
        {
            return E_POINTER;
        }

        *rect              = {};
        const auto* window = ResolveWindow();
        if (! window)
            return UIA_E_ELEMENTNOTAVAILABLE;
        const auto visible = VisibleRect(*window);
        if (visible.right <= visible.left || visible.bottom <= visible.top)
            return S_OK;
        POINT origin{};
        if (! ClientToScreen(_hwnd, &origin))
            return UIA_E_ELEMENTNOTAVAILABLE;
        rect->left   = static_cast<double>(origin.x + window->PxFromDipFloor(visible.left));
        rect->top    = static_cast<double>(origin.y + window->PxFromDipFloor(visible.top));
        rect->width  = static_cast<double>(window->PxFromDipCeil(visible.right) - window->PxFromDipFloor(visible.left));
        rect->height = static_cast<double>(window->PxFromDipCeil(visible.bottom) - window->PxFromDipFloor(visible.top));
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetEmbeddedFragmentRoots(SAFEARRAY** roots) noexcept override
    {
        if (! roots)
        {
            return E_POINTER;
        }

        *roots = nullptr;
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE SetFocus() noexcept override
    {
        if (GetWindowThreadProcessId(_hwnd, nullptr) != GetCurrentThreadId())
            return OnOwnerThread([&]() noexcept { return SetFocus(); });
        if (! _hwnd || IsWindow(_hwnd) == FALSE)
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }

        auto* window = ResolveWindow();
        if (! window)
            return UIA_E_ELEMENTNOTAVAILABLE;
        if (_id.kind == ElementKind::Root)
        {
            ::SetFocus(_hwnd);
            return S_OK;
        }
        const auto hit = ControlHit(*window);
        if (hit.part == AlertHitTest::Part::None)
            return UIA_E_NOTSUPPORTED;
        if (! IsEnabled(*window))
            return UIA_E_ELEMENTNOTENABLED;
        return window->OnFocusControl(hit.part, hit.buttonId) ? S_OK : UIA_E_ELEMENTNOTAVAILABLE;
    }

    HRESULT STDMETHODCALLTYPE get_FragmentRoot(IRawElementProviderFragmentRoot** root) noexcept override
    {
        if (! root)
        {
            return E_POINTER;
        }

        *root = nullptr;
        return CreateRoot(_hwnd, root);
    }

    HRESULT STDMETHODCALLTYPE ElementProviderFromPoint(double x, double y, IRawElementProviderFragment** provider) noexcept override
    {
        if (GetWindowThreadProcessId(_hwnd, nullptr) != GetCurrentThreadId())
            return OnOwnerThread([&]() noexcept { return ElementProviderFromPoint(x, y, provider); });
        if (! provider)
        {
            return E_POINTER;
        }

        *provider          = nullptr;
        const auto* window = ResolveWindow();
        if (! window)
            return UIA_E_ELEMENTNOTAVAILABLE;
        POINT origin{};
        if (! ClientToScreen(_hwnd, &origin))
            return UIA_E_ELEMENTNOTAVAILABLE;
        const float dpiScale = static_cast<float>(window->_dpi) / 96.0f;
        const auto hit    = window->_overlay.HitTest(D2D1::Point2F(static_cast<float>(x - origin.x) / dpiScale, static_cast<float>(y - origin.y) / dpiScale));
        const auto& model = window->_overlay.GetModel();
        if (hit.part == AlertHitTest::Part::Close)
            return CreateFragment(_hwnd, {ElementKind::CloseButton, 0u}, provider);
        for (size_t i = 0; i < model.options.size(); ++i)
            if (hit.part == AlertHitTest::Part::Option && model.options[i].id == hit.buttonId)
                return CreateFragment(_hwnd, {ElementKind::Option, i}, provider);
        for (size_t i = 0; i < model.buttons.size(); ++i)
            if (hit.part == AlertHitTest::Part::Button && model.buttons[i].id == hit.buttonId)
                return CreateFragment(_hwnd, {ElementKind::Button, i}, provider);
        return CreateFragment(_hwnd, ElementId{}, provider);
    }

    HRESULT STDMETHODCALLTYPE GetFocus(IRawElementProviderFragment** provider) noexcept override
    {
        if (GetWindowThreadProcessId(_hwnd, nullptr) != GetCurrentThreadId())
            return OnOwnerThread([&]() noexcept { return GetFocus(provider); });
        if (! provider)
        {
            return E_POINTER;
        }

        *provider                  = nullptr;
        AlertOverlayWindow* window = ResolveWindow();
        if (! window)
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }

        if (window->_overlay.GetFocusedControl().part == AlertHitTest::Part::Close)
            return CreateFragment(_hwnd, {ElementKind::CloseButton, 0u}, provider);

        if (const std::optional<uint32_t> focusedButtonId = window->_overlay.GetFocusedButtonId(); focusedButtonId.has_value())
        {
            const auto& buttons = window->_overlay.GetModel().buttons;
            for (size_t index = 0; index < buttons.size(); ++index)
            {
                if (buttons[index].id == focusedButtonId.value())
                {
                    return CreateFragment(_hwnd, ElementId{ElementKind::Button, index}, provider);
                }
            }
        }

        if (const std::optional<uint32_t> focusedOptionId = window->_overlay.GetFocusedOptionId(); focusedOptionId.has_value())
        {
            const auto& options = window->_overlay.GetModel().options;
            for (size_t index = 0; index < options.size(); ++index)
            {
                if (options[index].id == focusedOptionId.value())
                {
                    return CreateFragment(_hwnd, ElementId{ElementKind::Option, index}, provider);
                }
            }
        }

        return CreateFragment(_hwnd, ElementId{}, provider);
    }

    HRESULT STDMETHODCALLTYPE Invoke() noexcept override
    {
        if (GetWindowThreadProcessId(_hwnd, nullptr) != GetCurrentThreadId())
            return OnOwnerThread([&]() noexcept { return Invoke(); });
        AlertOverlayWindow* window = ResolveWindow();
        if (! window || ! IsButtonLike())
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }

        if (_id.kind == ElementKind::CloseButton)
        {
            return PostInvokeMessage(_hwnd, WndMsg::kAlertOverlayInvokeDismiss, 0);
        }

        if (_id.kind == ElementKind::Option)
        {
            const auto& options = window->_overlay.GetModel().options;
            if (_id.index >= options.size())
            {
                return UIA_E_ELEMENTNOTAVAILABLE;
            }
            if (! IsEnabled(*window))
                return UIA_E_ELEMENTNOTENABLED;
            return PostInvokeMessage(_hwnd, WndMsg::kAlertOverlayInvokeOption, static_cast<WPARAM>(options[_id.index].id));
        }

        const auto& buttons = window->_overlay.GetModel().buttons;
        if (_id.index >= buttons.size())
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }

        return PostInvokeMessage(_hwnd, WndMsg::kAlertOverlayInvokeButton, static_cast<WPARAM>(buttons[_id.index].id));
    }

private:
    static HRESULT PostInvokeMessage(HWND hwnd, UINT message, WPARAM wParam) noexcept
    {
        if (PostMessageW(hwnd, message, wParam, 0) != FALSE)
        {
            return S_OK;
        }

        const DWORD lastError = GetLastError();
        return HRESULT_FROM_WIN32(lastError == ERROR_SUCCESS ? ERROR_INVALID_HANDLE : lastError);
    }

    static HRESULT SetBool(VARIANT* value, bool data) noexcept
    {
        value->vt      = VT_BOOL;
        value->boolVal = data ? VARIANT_TRUE : VARIANT_FALSE;
        return S_OK;
    }

    static HRESULT SetI4(VARIANT* value, int data) noexcept
    {
        value->vt   = VT_I4;
        value->lVal = data;
        return S_OK;
    }

    static HRESULT SetBstr(VARIANT* value, std::wstring_view text) noexcept
    {
        BSTR bstr = SysAllocStringLen(text.data(), static_cast<UINT>(text.size()));
        if (! bstr && ! text.empty())
        {
            return E_OUTOFMEMORY;
        }

        value->vt      = VT_BSTR;
        value->bstrVal = bstr;
        return S_OK;
    }

    [[nodiscard]] bool IsButtonLike() const noexcept
    {
        return _id.kind == ElementKind::Button || _id.kind == ElementKind::Option || _id.kind == ElementKind::CloseButton;
    }

    [[nodiscard]] bool IsEnabled(const AlertOverlayWindow& window) const noexcept
    {
        if (_id.kind != ElementKind::Option)
            return true;
        const auto& options = window._overlay.GetModel().options;
        return _id.index < options.size() && window._overlay.IsOptionEnabled(options[_id.index].id);
    }

    [[nodiscard]] AlertOverlayWindow* ResolveWindow() const noexcept
    {
        if (! _hwnd || IsWindow(_hwnd) == FALSE)
        {
            return nullptr;
        }

        auto* window = reinterpret_cast<AlertOverlayWindow*>(GetWindowLongPtrW(_hwnd, GWLP_USERDATA));
        if (! window || window->_hwnd.get() != _hwnd || ! window->_visible)
        {
            return nullptr;
        }

        return window;
    }

    template <typename Callback> HRESULT OnOwnerThread(Callback callback) noexcept
    {
        if (! _hwnd || ! IsWindow(_hwnd))
            return UIA_E_ELEMENTNOTAVAILABLE;
        AlertUiaCall call{&callback, [](void* context) noexcept { return (*static_cast<Callback*>(context))(); }};
        return SendMessageW(_hwnd, WndMsg::kAlertOverlayUiaCall, 0, reinterpret_cast<LPARAM>(&call)) ? call.result
                                                                                                     : static_cast<HRESULT>(UIA_E_ELEMENTNOTAVAILABLE);
    }

    [[nodiscard]] AlertHitTest ControlHit(const AlertOverlayWindow& window) const noexcept
    {
        const auto& model = window._overlay.GetModel();
        if (_id.kind == ElementKind::CloseButton)
            return {AlertHitTest::Part::Close, 0u};
        if (_id.kind == ElementKind::Button && _id.index < model.buttons.size())
            return {AlertHitTest::Part::Button, model.buttons[_id.index].id};
        if (_id.kind == ElementKind::Option && _id.index < model.options.size())
            return {AlertHitTest::Part::Option, model.options[_id.index].id};
        return {};
    }

    [[nodiscard]] D2D1_RECT_F VisibleRect(const AlertOverlayWindow& window) const noexcept
    {
        if (_id.kind == ElementKind::Root)
            return window._overlay.GetPanelRect();
        if (_id.kind == ElementKind::Text)
            return window._overlay.GetVisibleTextRect();
        return window._overlay.GetVisibleControlRect(ControlHit(window));
    }

    [[nodiscard]] CONTROLTYPEID ControlType() const noexcept
    {
        switch (_id.kind)
        {
            case ElementKind::Root: return UIA_PaneControlTypeId;
            case ElementKind::Text: return UIA_TextControlTypeId;
            case ElementKind::CloseButton:
            case ElementKind::Option:
            case ElementKind::Button: return UIA_ButtonControlTypeId;
            default: return UIA_CustomControlTypeId;
        }
    }

    [[nodiscard]] std::wstring Name(const AlertOverlayWindow& window) const
    {
        const AlertModel& model = window._overlay.GetModel();
        switch (_id.kind)
        {
            case ElementKind::Root: return ! model.title.empty() ? model.title : L"Alert";
            case ElementKind::Text:
            {
                if (model.title.empty())
                {
                    return model.message;
                }
                if (model.message.empty())
                {
                    return model.title;
                }
                return std::format(L"{}\n{}", model.title, model.message);
            }
            case ElementKind::CloseButton: return L"Close";
            case ElementKind::Option:
                if (_id.index < model.options.size())
                {
                    const auto& option = model.options[_id.index];
                    if (! option.choices.empty() && option.selectedIndex < option.choices.size())
                    {
                        return std::format(L"{}: {}", option.label, option.choices[option.selectedIndex].label);
                    }
                    return option.label;
                }
                return {};
            case ElementKind::Button:
                if (_id.index < model.buttons.size())
                {
                    return model.buttons[_id.index].label;
                }
                return {};
            default: return {};
        }
    }

    [[nodiscard]] std::wstring AutomationId(const AlertOverlayWindow& window) const
    {
        switch (_id.kind)
        {
            case ElementKind::Root: return L"AlertOverlay";
            case ElementKind::Text: return L"AlertOverlay.Text";
            case ElementKind::CloseButton: return L"AlertOverlay.Close";
            case ElementKind::Option:
            {
                const auto& options = window._overlay.GetModel().options;
                const uint32_t id   = _id.index < options.size() ? options[_id.index].id : 0u;
                return std::format(L"AlertOverlay.Option.{}", id);
            }
            case ElementKind::Button:
            {
                const auto& buttons = window._overlay.GetModel().buttons;
                const uint32_t id   = _id.index < buttons.size() ? buttons[_id.index].id : 0u;
                return std::format(L"AlertOverlay.Button.{}", id);
            }
            default: return {};
        }
    }

    [[nodiscard]] static std::vector<ElementId> Children(const AlertOverlayWindow& window)
    {
        std::vector<ElementId> children;
        const AlertModel& model = window._overlay.GetModel();
        children.reserve(model.options.size() + model.buttons.size() + 2u);
        if (! model.title.empty() || ! model.message.empty())
        {
            children.push_back(ElementId{ElementKind::Text, 0u});
        }
        if (model.closable)
        {
            children.push_back(ElementId{ElementKind::CloseButton, 0u});
        }
        for (size_t index = 0u; index < model.options.size(); ++index)
        {
            children.push_back(ElementId{ElementKind::Option, index});
        }
        for (size_t index = 0u; index < model.buttons.size(); ++index)
        {
            children.push_back(ElementId{ElementKind::Button, index});
        }
        return children;
    }

    [[nodiscard]] static bool SameElement(ElementId lhs, ElementId rhs) noexcept
    {
        return lhs.kind == rhs.kind && lhs.index == rhs.index;
    }

    static HRESULT CreateFragment(HWND hwnd, ElementId id, IRawElementProviderFragment** provider) noexcept
    {
        auto* created = new (std::nothrow) AlertOverlayUiaProvider(hwnd, id);
        if (! created)
        {
            return E_OUTOFMEMORY;
        }

        *provider = static_cast<IRawElementProviderFragment*>(created);
        return S_OK;
    }

    static HRESULT CreateRoot(HWND hwnd, IRawElementProviderFragmentRoot** root) noexcept
    {
        auto* created = new (std::nothrow) AlertOverlayUiaProvider(hwnd, ElementId{});
        if (! created)
        {
            return E_OUTOFMEMORY;
        }

        *root = static_cast<IRawElementProviderFragmentRoot*>(created);
        return S_OK;
    }

    HRESULT NavigateSibling(const std::vector<ElementId>& children, NavigateDirection direction, IRawElementProviderFragment** provider) noexcept
    {
        for (size_t index = 0u; index < children.size(); ++index)
        {
            if (! SameElement(children[index], _id))
            {
                continue;
            }

            if (direction == NavigateDirection_NextSibling && index + 1u < children.size())
            {
                return CreateFragment(_hwnd, children[index + 1u], provider);
            }
            if (direction == NavigateDirection_PreviousSibling && index > 0u)
            {
                return CreateFragment(_hwnd, children[index - 1u], provider);
            }
            return S_OK;
        }

        return S_OK;
    }

private:
    std::atomic<ULONG> _refCount{1u};
    HWND _hwnd = nullptr;
    ElementId _id{};
};

[[nodiscard]] LRESULT ReturnAlertOverlayUiaProvider(HWND hwnd, WPARAM wp, LPARAM lp) noexcept
{
    auto* provider = new (std::nothrow) AlertOverlayUiaProvider(hwnd, AlertOverlayUiaProvider::ElementId{});
    if (! provider)
    {
        return 0;
    }

    const LRESULT result = UiaReturnRawElementProvider(hwnd, wp, lp, static_cast<IRawElementProviderSimple*>(provider));
    static_cast<void>(provider->Release());
    return result;
}

AlertOverlayWindow::~AlertOverlayWindow()
{
    Destroy();
}

void AlertOverlayWindow::SetCallbacks(AlertOverlayWindowCallbacks callbacks) noexcept
{
    _callbacks = callbacks;
}

void AlertOverlayWindow::ClearCallbacks() noexcept
{
    _callbacks = {};
}

void AlertOverlayWindow::SetKeyBindings(std::optional<uint32_t> primaryButtonId, std::optional<uint32_t> escapeButtonId) noexcept
{
    _primaryButtonId = primaryButtonId;
    _escapeButtonId  = escapeButtonId;
}

HRESULT AlertOverlayWindow::ShowForParentClient(HWND parent, const AlertTheme& theme, AlertModel model, bool blocksInput) noexcept
{
    if (! parent || ! IsWindow(parent))
    {
        return HRESULT_FROM_WIN32(ERROR_INVALID_WINDOW_HANDLE);
    }

    AttachToParentClient(parent);
    return TransitionVisibility(true, &theme, &model, blocksInput);
}

HRESULT AlertOverlayWindow::ShowForAnchor(HWND anchor, const AlertTheme& theme, AlertModel model, bool blocksInput) noexcept
{
    if (! anchor || ! IsWindow(anchor))
    {
        return HRESULT_FROM_WIN32(ERROR_INVALID_WINDOW_HANDLE);
    }

    AttachToAnchor(anchor);
    if (! _hostParent || ! IsWindow(_hostParent))
    {
        return HRESULT_FROM_WIN32(ERROR_INVALID_WINDOW_HANDLE);
    }

    return TransitionVisibility(true, &theme, &model, blocksInput);
}

void AlertOverlayWindow::Hide() noexcept
{
    static_cast<void>(TransitionVisibility(false, nullptr, nullptr, false));
}

LRESULT CALLBACK AlertOverlayWindow::WndProcThunk(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) noexcept
{
    if (msg == WM_NCCREATE)
    {
        const auto* cs = reinterpret_cast<const CREATESTRUCTW*>(lp);
        auto* self     = static_cast<AlertOverlayWindow*>(cs->lpCreateParams);
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
        return DefWindowProcW(hwnd, msg, wp, lp);
    }

    auto* self = reinterpret_cast<AlertOverlayWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (self)
    {
        return self->WndProc(hwnd, msg, wp, lp);
    }

    return DefWindowProcW(hwnd, msg, wp, lp);
}

LRESULT AlertOverlayWindow::WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) noexcept
{
    switch (msg)
    {
        case WM_ERASEBKGND: return 1;
        case WndMsg::kAlertOverlayUiaCall: return DispatchAlertUiaCall(lp);
        case WM_GETOBJECT:
            if (lp == static_cast<LPARAM>(UiaRootObjectId))
            {
                return ReturnAlertOverlayUiaProvider(hwnd, wp, lp);
            }
            break;
        case WndMsg::kAlertOverlayInvokeButton: InvokeButton(static_cast<uint32_t>(wp)); return 0;
        case WndMsg::kAlertOverlayInvokeOption: InvokeOption(static_cast<uint32_t>(wp)); return 0;
        case WndMsg::kAlertOverlayInvokeDismiss: InvokeDismiss(); return 0;
        case WM_PAINT: OnPaint(); return 0;
        case WM_DPICHANGED:
        case WM_DPICHANGED_AFTERPARENT:
        {
            bool handled = false;
            static_cast<void>(_presentationHost.HandleMessage(hwnd, msg, wp, lp, handled));
            _dpi = GetDpiForWindow(hwnd);
            _overlay.ResetTextResources();
            _panelRegionPx.reset();
            UpdatePlacement();
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        case WM_SHOWWINDOW:
        {
            bool handled = false;
            static_cast<void>(_presentationHost.HandleMessage(hwnd, msg, wp, lp, handled));
            break;
        }
        case WM_SIZE: OnSize(LOWORD(lp), HIWORD(lp)); return 0;
        case WM_MOUSEWHEEL: OnMouseWheel(GET_WHEEL_DELTA_WPARAM(wp), PointFromLParam(lp)); return 0;
        case WM_MOUSEMOVE: OnMouseMove(PointFromLParam(lp)); return 0;
        case WM_MOUSELEAVE: OnMouseLeave(); return 0;
        case WM_LBUTTONDOWN: OnLButtonDown(PointFromLParam(lp)); return 0;
        case WM_LBUTTONUP: OnLButtonUp(PointFromLParam(lp)); return 0;
        case WM_CAPTURECHANGED: OnCaptureChanged(reinterpret_cast<HWND>(lp)); return 0;
        case WM_MOUSEACTIVATE: return MA_ACTIVATE;
        case WM_KEYDOWN: OnKeyDown(wp); return 0;
        case WM_SYSCHAR:
            if (OnSysChar(wp))
            {
                return 0;
            }
            break;
        case WM_SETCURSOR: return OnSetCursor(reinterpret_cast<HWND>(wp), LOWORD(lp), HIWORD(lp));
        case WM_NCDESTROY:
        {
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, 0);
            StopAnimationTimer();
            DiscardD2DResources();
            _presentationHost.Detach();
            _hwnd.release();
            return DefWindowProcW(hwnd, msg, wp, lp);
        }
        default: break;
    }

    return DefWindowProcW(hwnd, msg, wp, lp);
}

void AlertOverlayWindow::OnPaint() noexcept
{
    if (! _hwnd)
        return;
    EnsureD2DResources();
    const bool needsInitialFrame = ! _preparedFrame;
    HRESULT hr                   = E_FAIL;
    const float widthDip         = DipFromPx(_clientSizePx.cx);
    const float heightDip        = DipFromPx(_clientSizePx.cy);
    if (_target && _dwriteFactory && widthDip > 0.0f && heightDip > 0.0f)
    {
        wil::com_ptr<ID2D1CommandList> frame;
        hr = _target->CreateCommandList(frame.put());
        if (SUCCEEDED(hr))
        {
            // Borrow the host context only for preparation, restoring all modified state.
            wil::com_ptr<ID2D1Image> previousTarget;
            _target->GetTarget(previousTarget.put());
            D2D1_MATRIX_3X2_F previousTransform{};
            _target->GetTransform(&previousTransform);
            const auto previousTextAntialiasMode = _target->GetTextAntialiasMode();
            {
                const auto restore = wil::scope_exit([&]() noexcept
                {
                    _target->SetTarget(previousTarget.get());
                    _target->SetTransform(previousTransform);
                    _target->SetTextAntialiasMode(previousTextAntialiasMode);
                });
                _target->SetTarget(frame.get());
                _target->SetTransform(D2D1::Matrix3x2F::Identity());
                _target->SetTextAntialiasMode(D2D1_TEXT_ANTIALIAS_MODE_CLEARTYPE);
                _target->BeginDraw();
                const auto endDraw = wil::scope_exit([&]() noexcept { hr = _target->EndDraw(); });
                _target->Clear(D2D1::ColorF(0.0f, 0.0f, 0.0f, 1.0f));
                if (_backdropBitmap)
                    _target->DrawBitmap(_backdropBitmap.get(), D2D1::RectF(0.0f, 0.0f, widthDip, heightDip), 1.0f, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR);
                _overlay.Draw(_target.get(), _dwriteFactory.get(), widthDip, heightDip, GetTickCount64());
            }
            if (SUCCEEDED(hr))
                hr = frame->Close();
            if (SUCCEEDED(hr))
                _preparedFrame = std::move(frame);
        }
    }
#if defined(ENABLE_TESTS)
    _debugLastEndDrawResult     = hr; // Recording result; the pixel witness separately verifies presented content.
    const float lastDrawOpacity = _overlay.DebugGetLastDrawOpacityForTest();
    _debugMinimumDrawOpacity    = (_debugPaintCount == 0u) ? lastDrawOpacity : std::min(_debugMinimumDrawOpacity, lastDrawOpacity);
    ++_debugPaintCount;
#endif
    if (FAILED(hr))
        DiscardD2DResources();
    ApplyRegionFromOverlay();
    // Nonmodal alerts clip their HWND to the panel. That makes WM_PAINT's first
    // dirty region partial, before the composition swap chain has a full frame.
    // Publish the prepared content once after creation/resize/device reset;
    // normal animation and subsequent paints keep their bounded dirty region.
    if (needsInitialFrame && _preparedFrame)
        static_cast<void>(_presentationHost.RenderInitialFrameForShow());
    bool handled = false;
    static_cast<void>(_presentationHost.HandleMessage(_hwnd.get(), WM_PAINT, 0, 0, handled));
    if (! handled)
    {
        PAINTSTRUCT ps{};
        const wil::unique_hdc_paint hdc = wil::BeginPaint(_hwnd.get(), &ps);
    }
}

void AlertOverlayWindow::OnSize(UINT width, UINT height) noexcept
{
    _clientSizePx.cx = static_cast<LONG>(width);
    _clientSizePx.cy = static_cast<LONG>(height);
    bool handled     = false;
    static_cast<void>(_presentationHost.HandleMessage(_hwnd.get(), WM_SIZE, SIZE_RESTORED, MAKELPARAM(width, height), handled));
    _preparedFrame.reset();
    _panelRegionPx.reset();
    if (_visible && EnsureOverlayLayoutForInput())
        _overlay.RevealFocusedControl();
}

LRESULT AlertOverlayWindow::OnFocusControl(AlertHitTest::Part part, uint32_t id) noexcept
{
    if (! _visible || ! EnsureOverlayLayoutForInput() || ! _overlay.FocusControl({part, id}))
        return FALSE;
    SetFocus(_hwnd.get());
    InvalidateRect(_hwnd.get(), nullptr, FALSE);
    return TRUE;
}

void AlertOverlayWindow::OnMouseWheel(int delta, POINT screenPoint) noexcept
{
    if (! _visible || ! _hwnd || ! EnsureOverlayLayoutForInput() || ! ScreenToClient(_hwnd.get(), &screenPoint))
        return;
    const auto viewport = _overlay.GetBodyViewport();
    const float x       = DipFromPx(screenPoint.x);
    const float y       = DipFromPx(screenPoint.y);
    if (x < viewport.left || x > viewport.right + 12.0f || y < viewport.top || y > viewport.bottom)
        return;
    // Floating DIP movement preserves high-resolution partial wheel deltas.
    if (_overlay.ScrollBy(-static_cast<float>(delta) * 48.0f / WHEEL_DELTA))
    {
        _pressedHit = {};
        InvalidateRect(_hwnd.get(), nullptr, FALSE);
    }
}

void AlertOverlayWindow::OnMouseMove(POINT pt) noexcept
{
    if (_scrollDragging && _hwnd)
    {
        const auto track = _overlay.GetScrollTrack();
        if (_overlay.ScrollAt(D2D1::Point2F((track.left + track.right) * 0.5f, std::clamp(DipFromPx(pt.y), track.top, track.bottom))))
            InvalidateRect(_hwnd.get(), nullptr, FALSE);
        return;
    }
    if (! _visible || ! _hwnd)
    {
        return;
    }

    if (! _trackingMouseLeave)
    {
        TRACKMOUSEEVENT tme{};
        tme.cbSize    = sizeof(tme);
        tme.dwFlags   = TME_LEAVE;
        tme.hwndTrack = _hwnd.get();
        if (TrackMouseEvent(&tme) != 0)
        {
            _trackingMouseLeave = true;
        }
    }

    if (! EnsureOverlayLayoutForInput())
    {
        return;
    }

    const float xDip = DipFromPx(pt.x);
    const float yDip = DipFromPx(pt.y);
    if (_overlay.UpdateHotState(D2D1::Point2F(xDip, yDip)))
    {
        InvalidateRect(_hwnd.get(), nullptr, FALSE);
    }
}

void AlertOverlayWindow::OnMouseLeave() noexcept
{
    if (! _visible || ! _hwnd)
    {
        return;
    }

    _trackingMouseLeave = false;
    _overlay.ClearHotState();
    InvalidateRect(_hwnd.get(), nullptr, FALSE);
}

void AlertOverlayWindow::OnLButtonDown(POINT pt) noexcept
{
    if (! _visible || ! _hwnd)
    {
        return;
    }

#if defined(ENABLE_TESTS)
    ++_debugMouseDownCount;
    _debugLastMouseDownPointPx = pt;
    _debugLastMouseDownHitPart = -1;
#endif

    if (! EnsureOverlayLayoutForInput())
    {
        return;
    }

    const float xDip = DipFromPx(pt.x);
    const float yDip = DipFromPx(pt.y);
    const auto track = _overlay.GetScrollTrack();
    if (track.bottom > track.top && xDip >= track.left && xDip <= track.right && yDip >= track.top && yDip <= track.bottom)
    {
        _scrollDragging = true;
        SetCapture(_hwnd.get());
        static_cast<void>(_overlay.ScrollAt(D2D1::Point2F(xDip, yDip)));
        _pressedHit = {};
        InvalidateRect(_hwnd.get(), nullptr, FALSE);
        return;
    }
    const AlertHitTest hit = _overlay.HitTest(D2D1::Point2F(xDip, yDip));
#if defined(ENABLE_TESTS)
    _debugLastMouseDownHitPart = static_cast<int>(hit.part);
#endif
    if (hit.part == AlertHitTest::Part::None || (hit.part == AlertHitTest::Part::Option && ! _overlay.IsOptionEnabled(hit.buttonId)))
    {
        return;
    }

    _pressedHit = hit;
    SetCapture(_hwnd.get());
    if (_overlay.UpdateHotState(D2D1::Point2F(xDip, yDip)))
    {
        InvalidateRect(_hwnd.get(), nullptr, FALSE);
    }
}

void AlertOverlayWindow::OnLButtonUp(POINT pt) noexcept
{
    if (_scrollDragging)
    {
        _scrollDragging = false;
        if (GetCapture() == _hwnd.get())
            ReleaseCapture();
        return;
    }
    if (! _visible || ! _hwnd)
    {
        _pressedHit = {};
        return;
    }

#if defined(ENABLE_TESTS)
    ++_debugMouseUpCount;
    _debugLastMouseUpPointPx = pt;
    _debugLastMouseUpHitPart = -1;
#endif

    if (! EnsureOverlayLayoutForInput())
    {
        _pressedHit = {};
        return;
    }

    const AlertHitTest pressed = _pressedHit;
    _pressedHit                = {};
    if (GetCapture() == _hwnd.get())
    {
        ReleaseCapture();
    }

    const float xDip       = DipFromPx(pt.x);
    const float yDip       = DipFromPx(pt.y);
    const AlertHitTest hit = _overlay.HitTest(D2D1::Point2F(xDip, yDip));
#if defined(ENABLE_TESTS)
    _debugLastMouseUpHitPart = static_cast<int>(hit.part);
#endif
    // If activation or another transient capture path consumed the mouse-down, a
    // release on the close glyph still behaves like a standard dialog close.
    if (pressed.part == AlertHitTest::Part::None && hit.part == AlertHitTest::Part::Close)
    {
        InvokeDismiss();
        return;
    }

    if (pressed.part == AlertHitTest::Part::Close && hit.part == AlertHitTest::Part::Close)
    {
        InvokeDismiss();
        return;
    }

    if (pressed.part == AlertHitTest::Part::Button && hit.part == AlertHitTest::Part::Button && pressed.buttonId == hit.buttonId)
    {
        InvokeButton(hit.buttonId);
        return;
    }

    if (pressed.part == AlertHitTest::Part::Option && hit.part == AlertHitTest::Part::Option && pressed.buttonId == hit.buttonId)
    {
        InvokeOption(hit.buttonId);
        return;
    }

    if (_overlay.UpdateHotState(D2D1::Point2F(xDip, yDip)))
    {
        InvalidateRect(_hwnd.get(), nullptr, FALSE);
    }
}

void AlertOverlayWindow::OnCaptureChanged(HWND newCapture) noexcept
{
    if (newCapture != _hwnd.get())
    {
        _pressedHit     = {};
        _scrollDragging = false;
    }
}

void AlertOverlayWindow::OnKeyDown(WPARAM key) noexcept
{
    if (! _visible || ! _hwnd)
    {
        return;
    }

    if (key == VK_ESCAPE)
    {
        InvokeDismiss();
        return;
    }

    if (key == VK_PRIOR || key == VK_NEXT || key == VK_HOME || key == VK_END)
    {
        if (! EnsureOverlayLayoutForInput())
            return;
        const auto viewport = _overlay.GetBodyViewport();
        const float page    = std::max(1.0f, viewport.bottom - viewport.top - 24.0f);
        const float delta   = key == VK_HOME ? -_overlay.GetScrollMaximum() : key == VK_END ? _overlay.GetScrollMaximum() : key == VK_PRIOR ? -page : page;
        if (_overlay.ScrollBy(delta))
        {
            _pressedHit = {};
            InvalidateRect(_hwnd.get(), nullptr, FALSE);
        }
        return;
    }

    if (key == VK_TAB)
    {
        const bool reverse = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
        static_cast<void>(EnsureOverlayLayoutForInput());
        if (_overlay.FocusNextInteractive(reverse))
        {
            InvalidateRect(_hwnd.get(), nullptr, FALSE);
        }
        return;
    }

    if (key == VK_LEFT || key == VK_UP || key == VK_RIGHT || key == VK_DOWN)
    {
        const bool reverse = (key == VK_LEFT || key == VK_UP);
        if (const std::optional<uint32_t> optionId = _overlay.GetFocusedOptionId(); optionId.has_value())
        {
            InvokeOption(optionId.value(), reverse);
            return;
        }
        if (_overlay.FocusNextButton(reverse))
        {
            InvalidateRect(_hwnd.get(), nullptr, FALSE);
        }
        return;
    }

    if (key == VK_RETURN || key == VK_SPACE)
    {
        if (_overlay.GetFocusedControl().part == AlertHitTest::Part::Close)
        {
            InvokeDismiss();
            return;
        }
        if (const std::optional<uint32_t> optionId = _overlay.GetFocusedOptionId(); optionId.has_value())
        {
            InvokeOption(optionId.value());
            return;
        }
        std::optional<uint32_t> buttonId = _overlay.GetFocusedButtonId();
        if (! buttonId.has_value())
        {
            buttonId = _primaryButtonId;
        }
        if (! buttonId.has_value())
        {
            const auto& buttons = _overlay.GetModel().buttons;
            for (const auto& button : buttons)
            {
                if (button.primary)
                {
                    buttonId = button.id;
                    break;
                }
            }
            if (! buttonId.has_value() && ! buttons.empty())
            {
                buttonId = buttons.front().id;
            }
        }

        if (buttonId.has_value())
        {
            InvokeButton(buttonId.value());
        }
        return;
    }
}

bool AlertOverlayWindow::OnSysChar(WPARAM key) noexcept
{
    if (! _visible || ! _hwnd)
    {
        return false;
    }

    const wchar_t mnemonic = static_cast<wchar_t>(key);
    if (mnemonic == L'\0')
    {
        return false;
    }

    const auto normalize = [](wchar_t ch) noexcept -> wchar_t { return static_cast<wchar_t>(std::towupper(static_cast<wint_t>(ch))); };

    for (const auto& button : _overlay.GetModel().buttons)
    {
        for (const wchar_t ch : button.label)
        {
            if (ch == L'&')
            {
                continue;
            }

            if (std::iswspace(static_cast<wint_t>(ch)))
            {
                continue;
            }

            if (normalize(ch) == normalize(mnemonic))
            {
                InvokeButton(button.id);
                return true;
            }
            break;
        }
    }

    return false;
}

LRESULT AlertOverlayWindow::OnSetCursor(HWND cursorWindow, UINT hitTest, UINT mouseMsg) noexcept
{
    static_cast<void>(cursorWindow);
    static_cast<void>(mouseMsg);

    if (! _hwnd)
    {
        return FALSE;
    }

    if (! _visible)
    {
        return DefWindowProcW(_hwnd.get(), WM_SETCURSOR, reinterpret_cast<WPARAM>(cursorWindow), MAKELPARAM(hitTest, mouseMsg));
    }

    if (hitTest == HTCLIENT)
    {
        static_cast<void>(EnsureOverlayLayoutForInput());
        const LPARAM messagePos = static_cast<LPARAM>(GetMessagePos());
        POINT pt{GET_X_LPARAM(messagePos), GET_Y_LPARAM(messagePos)};
        if (ScreenToClient(_hwnd.get(), &pt) != 0)
        {
            const float xDip       = DipFromPx(pt.x);
            const float yDip       = DipFromPx(pt.y);
            const AlertHitTest hit = _overlay.HitTest(D2D1::Point2F(xDip, yDip));
            if (hit.part == AlertHitTest::Part::Close || hit.part == AlertHitTest::Part::Button ||
                (hit.part == AlertHitTest::Part::Option && _overlay.IsOptionEnabled(hit.buttonId)))
            {
                SetCursor(LoadCursorW(nullptr, IDC_HAND));
                return TRUE;
            }
        }
    }

    SetCursor(LoadCursorW(nullptr, IDC_ARROW));
    return TRUE;
}

void AlertOverlayWindow::InvokeButton(uint32_t buttonId) noexcept
{
    if (_callbacks.onButton)
    {
        _callbacks.onButton(_callbacks.context, buttonId);
        return;
    }

    Hide();
}

void AlertOverlayWindow::InvokeOption(uint32_t optionId, bool reverse) noexcept
{
    if (_overlay.ActivateOption(optionId, reverse) && _hwnd)
    {
        // Pointer/UIA activation follows the activated option, never stale tab focus.
        static_cast<void>(_overlay.FocusControl({AlertHitTest::Part::Option, optionId}));
        if (EnsureOverlayLayoutForInput())
            _overlay.RevealFocusedControl();
        InvalidateRect(_hwnd.get(), nullptr, FALSE);
    }
}

void AlertOverlayWindow::InvokeDismiss() noexcept
{
#if defined(ENABLE_TESTS)
    ++_debugDismissCount;
#endif

    if (_escapeButtonId.has_value())
    {
        InvokeButton(_escapeButtonId.value());
        return;
    }

    if (! _overlay.GetModel().closable)
    {
        return;
    }

    if (_callbacks.onDismissed)
    {
        _callbacks.onDismissed(_callbacks.context);
    }

    Hide();
}

void AlertOverlayWindow::StartAnimationTimer() noexcept
{
    if (! _hwnd || ! _visible)
    {
        StopAnimationTimer();
        return;
    }

    const uint64_t now        = GetTickCount64();
    const bool needsAnimation = _alwaysAnimate || now < _animateUntilTickMs;
    if (! needsAnimation)
    {
        StopAnimationTimer();
        return;
    }

    if (_animationSubscriptionId == 0)
    {
        _animationSubscriptionId = AnimationDispatcher::GetInstance().Subscribe(&AlertOverlayWindow::AnimationTickThunk, this);
    }
}

void AlertOverlayWindow::StopAnimationTimer() noexcept
{
    if (_animationSubscriptionId == 0)
    {
        return;
    }

    AnimationDispatcher::GetInstance().Unsubscribe(_animationSubscriptionId);
    _animationSubscriptionId = 0;
}

bool AlertOverlayWindow::AnimationTickThunk(void* context, uint64_t nowTickMs) noexcept
{
    auto* self = static_cast<AlertOverlayWindow*>(context);
    if (! self)
    {
        return false;
    }

    return self->OnAnimationTimer(nowTickMs);
}

bool AlertOverlayWindow::OnAnimationTimer(uint64_t nowTickMs) noexcept
{
    if (! _visible || ! _hwnd)
    {
        StopAnimationTimer();
        return false;
    }

    if (! _alwaysAnimate && nowTickMs >= _animateUntilTickMs)
    {
        StopAnimationTimer();
        return false;
    }

    InvalidateRect(_hwnd.get(), nullptr, FALSE);
    return true;
}

HRESULT AlertOverlayWindow::TransitionVisibility(bool show, const AlertTheme* theme, AlertModel* model, bool blocksInput) noexcept
{
    if (! show)
    {
        StopAnimationTimer();

        _visible            = false;
        _blocksInput        = false;
        _trackingMouseLeave = false;
        _alwaysAnimate      = false;
        _animateUntilTickMs = 0;
        _startTickMs        = 0;
        _pressedHit         = {};

        if (_hwnd && GetCapture() == _hwnd.get())
        {
            ReleaseCapture();
        }

        _overlay.ClearHotState();
        _panelRegionPx.reset();
        _backdropBitmap.reset();
        ClearRegion();

        HWND restoreFocus = nullptr;
        HWND restoreRoot  = nullptr;
        if (_restoreFocus && IsWindow(_restoreFocus))
        {
            restoreFocus = _restoreFocus;
            restoreRoot  = GetAncestor(_restoreFocus, GA_ROOT);
        }
        else if (_hostParent && IsWindow(_hostParent))
        {
            restoreRoot = GetAncestor(_hostParent, GA_ROOT);
        }

        if (_hwnd)
        {
            ShowWindow(_hwnd.get(), SW_HIDE);
        }

        if (restoreRoot && IsWindow(restoreRoot))
        {
            SetForegroundWindow(restoreRoot);
        }

        if (restoreFocus)
        {
            SetFocus(restoreFocus);
        }
        _restoreFocus = nullptr;

        // HostServices may retain hidden overlays for reuse; release graphics/text resources
        // immediately so debug-layer shutdown cannot see them as live process-exit objects.
        DiscardD2DResources();
        _presentationHost.Detach();
        _dwriteFactory.reset();

        ClearCallbacks();
        _primaryButtonId.reset();
        _escapeButtonId.reset();
        return S_OK;
    }

    if (! theme || ! model)
    {
        return E_INVALIDARG;
    }

    if (! _hostParent || ! IsWindow(_hostParent))
    {
        return HRESULT_FROM_WIN32(ERROR_INVALID_WINDOW_HANDLE);
    }

    const HRESULT hrCreate = EnsureCreated(_hostParent);
    if (FAILED(hrCreate))
    {
        return hrCreate;
    }

    EnsureD2DResources();
    if (! _target || ! _dwriteFactory)
    {
        DiscardD2DResources();
        _presentationHost.Detach();
        return E_FAIL; // Never show a blocking surface without a usable presentation device.
    }

    const bool wasVisible     = _visible && _hwnd && IsWindowVisible(_hwnd.get()) != FALSE;
    const bool wasBlocksInput = _blocksInput;

    _blocksInput        = blocksInput;
    _visible            = true;
    _trackingMouseLeave = false;
    _pressedHit         = {};
    _panelRegionPx.reset();
#if defined(ENABLE_TESTS)
    _debugPaintCount           = 0;
    _debugLastEndDrawResult    = E_PENDING;
    _debugMinimumDrawOpacity   = 1.0f;
    _debugBackdropCaptureCount = 0;
    _debugBackdropSizePx       = {};
    _debugMouseDownCount       = 0;
    _debugMouseUpCount         = 0;
    _debugDismissCount         = 0;
    _debugLastMouseDownPointPx = {};
    _debugLastMouseUpPointPx   = {};
    _debugLastMouseDownHitPart = -1;
    _debugLastMouseUpHitPart   = -1;
#endif

    _overlay.SetTheme(*theme);
    _overlay.SetModel(std::move(*model));
    _overlay.ClearHotState();

    const uint64_t now = GetTickCount64();
    // Modal alerts must be readable on the first paint; otherwise they can appear blank
    // until another input message causes a later animation frame.
    const uint64_t visibleStartTick = _blocksInput ? ((now >= kShowAnimationMs) ? (now - kShowAnimationMs) : 0u) : now;
    _startTickMs                    = visibleStartTick;
    _animateUntilTickMs             = _blocksInput ? now : (now + kShowAnimationMs);
    _overlay.SetStartTick(visibleStartTick);

    const AlertSeverity severity = _overlay.GetModel().severity;
    _alwaysAnimate               = severity == AlertSeverity::Busy;

    _restoreFocus = nullptr;
    if (_blocksInput)
    {
        _restoreFocus = GetFocus();
    }

    ClearRegion();
    UpdatePlacement();
    if (EnsureOverlayLayoutForInput())
    {
        ApplyRegionFromOverlay();
    }
    const bool reuseVisibleBackdrop = wasVisible && wasBlocksInput && _blocksInput && _backdropBitmap;
    if (! reuseVisibleBackdrop)
    {
        CaptureBackdrop(wasVisible && _blocksInput);
    }

    if (_blocksInput)
    {
        SetWindowPos(_hwnd.get(), HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
        SetFocus(_hwnd.get());
    }
    else
    {
        SetWindowPos(_hwnd.get(), HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW | SWP_NOACTIVATE | SWP_NOOWNERZORDER);
    }

    StartAnimationTimer();
    InvalidateRect(_hwnd.get(), nullptr, FALSE);
    return S_OK;
}

HRESULT AlertOverlayWindow::EnsureCreated(HWND hostParent) noexcept
{
    if (_hwnd && IsWindow(_hwnd.get()))
    {
        return S_OK;
    }

    static ATOM atom = 0;
    if (atom == 0)
    {
        WNDCLASSEXW wc{};
        wc.cbSize        = sizeof(wc);
        wc.style         = CS_HREDRAW | CS_VREDRAW;
        wc.lpfnWndProc   = &AlertOverlayWindow::WndProcThunk;
        wc.hInstance     = GetModuleHandleW(nullptr);
        wc.hCursor       = LoadCursorW(nullptr, IDC_ARROW);
        wc.lpszClassName = kAlertOverlayWindowClassName;
        atom             = RegisterClassExW(&wc);
    }

    if (atom == 0)
    {
        const DWORD lastError = GetLastError();
        return lastError != 0 ? HRESULT_FROM_WIN32(lastError) : E_FAIL;
    }

    RECT rc{};
    GetClientRect(hostParent, &rc);
    const int width  = std::max(0L, rc.right - rc.left);
    const int height = std::max(0L, rc.bottom - rc.top);

    const DWORD style   = WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
    const DWORD exStyle = WS_EX_TOOLWINDOW;
    HWND hwnd = CreateWindowExW(exStyle, kAlertOverlayWindowClassName, L"", style, 0, 0, width, height, hostParent, nullptr, GetModuleHandleW(nullptr), this);
    if (! hwnd)
    {
        const DWORD lastError = GetLastError();
        return lastError != 0 ? HRESULT_FROM_WIN32(lastError) : E_FAIL;
    }

    _hwnd.reset(hwnd);

    RECT clientRect{};
    GetClientRect(hwnd, &clientRect);
    _clientSizePx.cx = std::max(0L, clientRect.right - clientRect.left);
    _clientSizePx.cy = std::max(0L, clientRect.bottom - clientRect.top);
    _dpi             = GetDpiForWindow(hwnd);
    return S_OK;
}

void AlertOverlayWindow::Destroy() noexcept
{
    Hide();
    ApplyAttachmentState(nullptr, nullptr, false, false);
    DiscardD2DResources();
    _presentationHost.Detach();
    _dwriteFactory.reset();

    _hwnd.reset();
}

void AlertOverlayWindow::AttachToParentClient(HWND parent) noexcept
{
    ApplyAttachmentState(parent, nullptr, true, false);
}

void AlertOverlayWindow::AttachToAnchor(HWND anchor) noexcept
{
    HWND hostParent = nullptr;
    if (anchor && IsWindow(anchor))
    {
        hostParent = GetParent(anchor);
        if (! hostParent || ! IsWindow(hostParent))
        {
            hostParent = anchor;
        }
    }

    ApplyAttachmentState(hostParent, anchor, hostParent && hostParent != anchor, true);
}

void AlertOverlayWindow::ApplyAttachmentState(HWND hostParent, HWND anchor, bool trackHostParent, bool trackAnchor) noexcept
{
    if (hostParent && ! IsWindow(hostParent))
    {
        hostParent = nullptr;
    }

    if (anchor && ! IsWindow(anchor))
    {
        anchor = nullptr;
    }

    if (_hostParent == hostParent && _anchor == anchor && _hostParentSubclassed == trackHostParent && _anchorSubclassed == trackAnchor)
    {
        return;
    }

    if (_hostParentSubclassed && _hostParent && IsWindow(_hostParent))
    {
        RestoreWndProcHook(_hostParent, kParentOriginalWndProcProp, kParentStateProp);
    }

    if (_anchorSubclassed && _anchor && IsWindow(_anchor))
    {
        RestoreWndProcHook(_anchor, kAnchorOriginalWndProcProp, kAnchorStateProp);
    }

    _hostParentSubclassed = false;
    _anchorSubclassed     = false;

    _hostParent = hostParent;
    _anchor     = anchor;
    if (trackHostParent && _hostParent && IsWindow(_hostParent))
    {
        if (SetPropW(_hostParent, kParentStateProp, this) != 0 &&
            InstallWndProcHook(_hostParent, kParentOriginalWndProcProp, &AlertOverlayWindow::ParentWndProc))
        {
            _hostParentSubclassed = true;
        }
        else
        {
            RemovePropW(_hostParent, kParentStateProp);
            RemovePropW(_hostParent, kParentOriginalWndProcProp);
        }
    }

    if (trackAnchor && _anchor && IsWindow(_anchor))
    {
        if (SetPropW(_anchor, kAnchorStateProp, this) != 0 && InstallWndProcHook(_anchor, kAnchorOriginalWndProcProp, &AlertOverlayWindow::AnchorWndProc))
        {
            _anchorSubclassed = true;
        }
        else
        {
            RemovePropW(_anchor, kAnchorStateProp);
            RemovePropW(_anchor, kAnchorOriginalWndProcProp);
        }
    }
}

void AlertOverlayWindow::UpdatePlacement() noexcept
{
    if (! _hwnd || ! _hostParent || ! IsWindow(_hostParent))
    {
        return;
    }

    RECT rc{};
    if (_anchor && _anchor != _hostParent && IsWindow(_anchor))
    {
        if (GetWindowRect(_anchor, &rc) == 0)
        {
            GetClientRect(_hostParent, &rc);
            POINT pts[2]{{rc.left, rc.top}, {rc.right, rc.bottom}};
            MapWindowPoints(_hostParent, nullptr, pts, 2);
            rc = RECT{pts[0].x, pts[0].y, pts[1].x, pts[1].y};
        }
    }
    else
    {
        GetClientRect(_hostParent, &rc);
        POINT pts[2]{{rc.left, rc.top}, {rc.right, rc.bottom}};
        MapWindowPoints(_hostParent, nullptr, pts, 2);
        rc = RECT{pts[0].x, pts[0].y, pts[1].x, pts[1].y};
    }

    const int width  = std::max(0L, rc.right - rc.left);
    const int height = std::max(0L, rc.bottom - rc.top);

    UINT flags = SWP_NOACTIVATE;
    if (! _visible)
    {
        flags |= SWP_NOZORDER | SWP_NOOWNERZORDER;
    }
    else if (! _blocksInput)
    {
        flags |= SWP_NOOWNERZORDER;
    }

    SetWindowPos(_hwnd.get(), HWND_TOP, rc.left, rc.top, width, height, flags);
    if (_visible && _blocksInput && IsWindowVisible(_hwnd.get()) != FALSE)
    {
        EnsureD2DResources();
        CaptureBackdrop(false);
        InvalidateRect(_hwnd.get(), nullptr, FALSE);
    }
}

bool AlertOverlayWindow::EnsureOverlayLayoutForInput() noexcept
{
    if (! _hwnd || ! _visible)
    {
        return false;
    }

    RECT clientRect{};
    if (GetClientRect(_hwnd.get(), &clientRect) != 0)
    {
        _clientSizePx.cx = std::max(0L, clientRect.right - clientRect.left);
        _clientSizePx.cy = std::max(0L, clientRect.bottom - clientRect.top);
    }

    if (_clientSizePx.cx <= 0 || _clientSizePx.cy <= 0)
    {
        return false;
    }

    EnsureD2DResources();
    if (! _dwriteFactory)
    {
        return false;
    }

    return _overlay.EnsureLayout(_dwriteFactory.get(), DipFromPx(_clientSizePx.cx), DipFromPx(_clientSizePx.cy));
}

LRESULT CALLBACK AlertOverlayWindow::ParentWndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) noexcept
{
    auto* self = reinterpret_cast<AlertOverlayWindow*>(GetPropW(hwnd, kParentStateProp));
    if (! self)
    {
        return CallStoredWndProc(hwnd, kParentOriginalWndProcProp, msg, wp, lp);
    }

    if (msg == WM_SIZE || msg == WM_WINDOWPOSCHANGED)
    {
        self->UpdatePlacement();
    }

    if (msg == WM_NCDESTROY)
    {
        if (self->_hostParent == hwnd)
        {
            self->_hostParent           = nullptr;
            self->_hostParentSubclassed = false;
        }

        if (self->_anchor == hwnd)
        {
            self->_anchor           = nullptr;
            self->_anchorSubclassed = false;
        }

        self->Destroy();
        const LRESULT result = CallStoredWndProc(hwnd, kParentOriginalWndProcProp, msg, wp, lp);
        RemovePropW(hwnd, kParentStateProp);
        RemovePropW(hwnd, kParentOriginalWndProcProp);
        return result;
    }

    return CallStoredWndProc(hwnd, kParentOriginalWndProcProp, msg, wp, lp);
}

LRESULT CALLBACK AlertOverlayWindow::AnchorWndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) noexcept
{
    auto* self = reinterpret_cast<AlertOverlayWindow*>(GetPropW(hwnd, kAnchorStateProp));
    if (! self)
    {
        return CallStoredWndProc(hwnd, kAnchorOriginalWndProcProp, msg, wp, lp);
    }

    if (msg == WM_SIZE || msg == WM_WINDOWPOSCHANGED)
    {
        self->UpdatePlacement();
    }

    if (msg == WM_NCDESTROY)
    {
        if (self->_anchor == hwnd)
        {
            self->_anchor           = nullptr;
            self->_anchorSubclassed = false;
        }

        self->Hide();

        HWND hostParent = self->_hostParent;
        if (hostParent == hwnd)
        {
            hostParent = nullptr;
        }

        self->ApplyAttachmentState(hostParent, nullptr, false, false);
        const LRESULT result = CallStoredWndProc(hwnd, kAnchorOriginalWndProcProp, msg, wp, lp);
        RemovePropW(hwnd, kAnchorStateProp);
        RemovePropW(hwnd, kAnchorOriginalWndProcProp);
        return result;
    }

    return CallStoredWndProc(hwnd, kAnchorOriginalWndProcProp, msg, wp, lp);
}

void AlertOverlayWindow::EnsureD2DResources() noexcept
{
    if (! _hwnd)
        return;
    if (! _presentationHost.GetHwnd())
    {
        DxUi::WindowHost::AttachOptions options{};
        options.presentationMode = DxUi::WindowHost::PresentationMode::CompositionSwapChain;
        if (! _presentationHost.Attach(_hwnd.get(), options))
            return;
        _presentationHost.SetRoot(std::make_unique<AlertPresentationRoot>(_target, _preparedFrame));
    }
    if (! _presentationHost.PrimeForShow())
    {
        DiscardD2DResources();
        return;
    }
    const UINT dpi = GetDpiForWindow(_hwnd.get());
    if (dpi != 0u && dpi != _dpi)
    {
        _dpi = dpi;
        _overlay.ResetTextResources();
        _panelRegionPx.reset();
    }
    auto* context = _presentationHost.GetDeviceContext();
    if (_target.get() != context)
    {
        DiscardD2DResources();
        _target = context;
    }
    _dwriteFactory = _presentationHost.GetWriteFactory();
}

void AlertOverlayWindow::DiscardD2DResources() noexcept
{
    _preparedFrame.reset();
    _backdropBitmap.reset();
    _target.reset();
    _overlay.ResetDeviceResources();
    _overlay.ResetTextResources();
}

void AlertOverlayWindow::CaptureBackdrop(bool preserveExistingOnFailure) noexcept
{
    wil::com_ptr<ID2D1Bitmap> capturedBackdrop;
    const auto publishCapture = wil::scope_exit([&] noexcept
    {
        if (capturedBackdrop)
        {
            _backdropBitmap = std::move(capturedBackdrop);
        }
        else if (! preserveExistingOnFailure)
        {
            _backdropBitmap.reset();
        }
    });

    if (! _blocksInput || ! _hwnd)
    {
        return;
    }

    EnsureD2DResources();
    if (! _target)
    {
        return;
    }

    RECT screenRect{};
    if (GetWindowRect(_hwnd.get(), &screenRect) == FALSE)
    {
        return;
    }

    const LONG widthPx  = screenRect.right - screenRect.left;
    const LONG heightPx = screenRect.bottom - screenRect.top;
    if (widthPx <= 0 || heightPx <= 0)
    {
        return;
    }

    BITMAPINFO bmi{};
    bmi.bmiHeader.biSize        = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth       = widthPx;
    bmi.bmiHeader.biHeight      = -heightPx;
    bmi.bmiHeader.biPlanes      = 1;
    bmi.bmiHeader.biBitCount    = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    void* bits = nullptr;
    wil::unique_hdc_window screenDc{GetDC(nullptr)};
    if (! screenDc)
    {
        return;
    }

    wil::unique_hdc memoryDc{CreateCompatibleDC(screenDc.get())};
    if (! memoryDc)
    {
        return;
    }

    wil::unique_hbitmap bitmap{CreateDIBSection(screenDc.get(), &bmi, DIB_RGB_COLORS, &bits, nullptr, 0)};
    if (! bitmap || ! bits)
    {
        return;
    }

    [[maybe_unused]] const auto oldBitmap = wil::SelectObject(memoryDc.get(), bitmap.get());
    bool capturedPixels                   = false;
    if (_anchor && IsWindow(_anchor) != FALSE)
    {
        RECT anchorRect{};
        if (GetWindowRect(_anchor, &anchorRect) != FALSE && anchorRect.left == screenRect.left && anchorRect.top == screenRect.top &&
            anchorRect.right == screenRect.right && anchorRect.bottom == screenRect.bottom)
        {
            capturedPixels = PrintWindow(_anchor, memoryDc.get(), PW_RENDERFULLCONTENT) != FALSE;
        }
    }

    if (! capturedPixels && _hostParent && IsWindow(_hostParent) != FALSE)
    {
        RECT hostClient{};
        if (GetClientRect(_hostParent, &hostClient) != FALSE)
        {
            std::array<POINT, 2> hostClientPoints{{
                POINT{hostClient.left, hostClient.top},
                POINT{hostClient.right, hostClient.bottom},
            }};
            if (MapWindowPoints(_hostParent, nullptr, hostClientPoints.data(), static_cast<UINT>(hostClientPoints.size())) != 0)
            {
                const RECT hostClientScreen{hostClientPoints[0].x, hostClientPoints[0].y, hostClientPoints[1].x, hostClientPoints[1].y};
                if (hostClientScreen.left == screenRect.left && hostClientScreen.top == screenRect.top && hostClientScreen.right == screenRect.right &&
                    hostClientScreen.bottom == screenRect.bottom)
                {
                    capturedPixels = PrintWindow(_hostParent, memoryDc.get(), PW_CLIENTONLY | PW_RENDERFULLCONTENT) != FALSE;
                }
            }
        }
    }

    if (! capturedPixels)
    {
        capturedPixels = BitBlt(memoryDc.get(), 0, 0, widthPx, heightPx, screenDc.get(), screenRect.left, screenRect.top, SRCCOPY | CAPTUREBLT) != FALSE;
    }

    if (! capturedPixels)
    {
        return;
    }

    const UINT32 width  = static_cast<UINT32>(widthPx);
    const UINT32 height = static_cast<UINT32>(heightPx);
    const D2D1_BITMAP_PROPERTIES props =
        D2D1::BitmapProperties(D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_IGNORE), static_cast<float>(_dpi), static_cast<float>(_dpi));
    const HRESULT hr = _target->CreateBitmap(D2D1::SizeU(width, height), bits, width * 4u, props, capturedBackdrop.addressof());
    if (SUCCEEDED(hr))
    {
#if defined(ENABLE_TESTS)
        ++_debugBackdropCaptureCount;
        _debugBackdropSizePx = SIZE{widthPx, heightPx};
#endif
    }
}

void AlertOverlayWindow::ApplyRegionFromOverlay() noexcept
{
    if (! _hwnd)
    {
        return;
    }

    if (_blocksInput)
    {
        if (_panelRegionPx.has_value())
        {
            _panelRegionPx.reset();
            ClearRegion();
        }
        return;
    }

    if (! _overlay.HasLayout())
    {
        return;
    }

    const D2D1_RECT_F panelDip = _overlay.GetPanelRect();
    RECT panelPx{};
    panelPx.left   = PxFromDipFloor(panelDip.left);
    panelPx.top    = PxFromDipFloor(panelDip.top);
    panelPx.right  = PxFromDipCeil(panelDip.right);
    panelPx.bottom = PxFromDipCeil(panelDip.bottom);

    if (_panelRegionPx.has_value())
    {
        const RECT prev = _panelRegionPx.value();
        if (prev.left == panelPx.left && prev.top == panelPx.top && prev.right == panelPx.right && prev.bottom == panelPx.bottom)
        {
            return;
        }
    }

    const int radiusPx   = std::max(1, PxFromDipRound(12.0f));
    const int diameterPx = std::max(1, radiusPx * 2);

    wil::unique_any<HRGN, decltype(&::DeleteObject), ::DeleteObject> region;
    region.reset(CreateRoundRectRgn(panelPx.left, panelPx.top, panelPx.right, panelPx.bottom, diameterPx, diameterPx));
    if (! region)
    {
        return;
    }

    if (SetWindowRgn(_hwnd.get(), region.get(), TRUE) != 0)
    {
        region.release();
        _panelRegionPx = panelPx;
    }
}

void AlertOverlayWindow::ClearRegion() noexcept
{
    if (_hwnd)
    {
        SetWindowRgn(_hwnd.get(), nullptr, TRUE);
    }
}

float AlertOverlayWindow::DipFromPx(int px) const noexcept
{
    const float dpi = static_cast<float>(_dpi > 0 ? _dpi : 96u);
    return (static_cast<float>(px) * 96.0f) / dpi;
}

int AlertOverlayWindow::PxFromDipFloor(float dip) const noexcept
{
    const float dpi = static_cast<float>(_dpi > 0 ? _dpi : 96u);
    const float px  = (dip * dpi) / 96.0f;
    return static_cast<int>(std::floor(px));
}

int AlertOverlayWindow::PxFromDipCeil(float dip) const noexcept
{
    const float dpi = static_cast<float>(_dpi > 0 ? _dpi : 96u);
    const float px  = (dip * dpi) / 96.0f;
    return static_cast<int>(std::ceil(px));
}

int AlertOverlayWindow::PxFromDipRound(float dip) const noexcept
{
    const float dpi = static_cast<float>(_dpi > 0 ? _dpi : 96u);
    const float px  = (dip * dpi) / 96.0f;
    return static_cast<int>(std::lround(px));
}

#if defined(ENABLE_TESTS)
bool DebugCaptureAlertOverlayWindowBitmap(HWND hwnd, DxUi::WindowHostBitmapCapture& out) noexcept
{
    out = {};
    if (! hwnd || GetWindowThreadProcessId(hwnd, nullptr) != GetCurrentThreadId())
        return false;
    auto* window = reinterpret_cast<AlertOverlayWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    return window && window->_hwnd.get() == hwnd && window->_presentationHost.DebugCaptureBitmap(out);
}

bool DebugGetAlertOverlayWindowSnapshot(HWND hwnd, AlertOverlayWindowDebugSnapshot& out) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    auto* window = reinterpret_cast<AlertOverlayWindow*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (! window || window->_hwnd.get() != hwnd)
    {
        return false;
    }

    out.visible                     = window->_visible;
    out.hasLayout                   = window->_overlay.HasLayout();
    out.hasBackdropBitmap           = window->_backdropBitmap != nullptr;
    out.paintCount                  = window->_debugPaintCount;
    out.lastEndDrawResult           = window->_debugLastEndDrawResult;
    out.renderTargetWindowState     = 0u; // Composition presentation does not expose the legacy HWND occlusion flag.
    out.usesCompositionPresentation = window->_presentationHost.GetHwnd() == hwnd;
    out.hasPreparedFrame            = static_cast<bool>(window->_preparedFrame);
    out.lastDrawOpacity             = window->_overlay.DebugGetLastDrawOpacityForTest();
    out.lastDrawScrimOpacity        = window->_overlay.DebugGetLastDrawScrimOpacityForTest();
    out.minimumDrawOpacity          = window->_debugMinimumDrawOpacity;
    out.backdropCaptureCount        = window->_debugBackdropCaptureCount;
    out.clientSizePx                = window->_clientSizePx;
    out.backdropSizePx              = window->_debugBackdropSizePx;
    const D2D1_RECT_F closeRectDip  = window->_overlay.DebugGetCloseRectForTest();
    out.closeRectPx.left            = window->PxFromDipFloor(closeRectDip.left);
    out.closeRectPx.top             = window->PxFromDipFloor(closeRectDip.top);
    out.closeRectPx.right           = window->PxFromDipCeil(closeRectDip.right);
    out.closeRectPx.bottom          = window->PxFromDipCeil(closeRectDip.bottom);
    out.usesSharedCloseChrome       = window->_overlay.DebugUsesSharedCloseChromeForTest();
    out.usesSharedButtonChrome      = window->_overlay.DebugUsesSharedButtonChromeForTest();
    out.mouseDownCount              = window->_debugMouseDownCount;
    out.mouseUpCount                = window->_debugMouseUpCount;
    out.dismissCount                = window->_debugDismissCount;
    out.lastMouseDownPointPx        = window->_debugLastMouseDownPointPx;
    out.lastMouseUpPointPx          = window->_debugLastMouseUpPointPx;
    out.lastMouseDownHitPart        = window->_debugLastMouseDownHitPart;
    out.lastMouseUpHitPart          = window->_debugLastMouseUpHitPart;
    const AlertModel& model         = window->_overlay.GetModel();
    out.presentation                = model.presentation;
    out.renderedIconPresentation    = window->_overlay.DebugGetLastDrawnIconPresentationForTest();
    out.renderedIconGlyph           = window->_overlay.DebugGetLastDrawnIconGlyphForTest();
    out.renderedCloseGlyph          = window->_overlay.DebugGetLastDrawnCloseGlyphForTest();
    out.title                       = model.title;
    out.optionValues.clear();
    out.optionValues.reserve(model.options.size());
    for (const AlertOption& option : model.options)
    {
        out.optionValues.push_back((! option.choices.empty() && option.selectedIndex < option.choices.size()) ? option.choices[option.selectedIndex].value
                                                                                                              : 0u);
    }
    out.bodyViewport     = window->_overlay.GetBodyViewport();
    out.scrollOffsetDip  = window->_overlay.GetScrollOffset();
    out.scrollMaximumDip = window->_overlay.GetScrollMaximum();
    out.visibleOptionRects.clear();
    out.optionIds.clear();
    for (const auto& option : model.options)
    {
        out.optionIds.push_back(option.id);
        out.visibleOptionRects.push_back(window->_overlay.GetVisibleControlRect({AlertHitTest::Part::Option, option.id}));
    }
    out.focusedControl = window->_overlay.GetFocusedControl();
    out.primaryButtonLabel.clear();
    for (const AlertButton& button : model.buttons)
    {
        if (button.primary)
        {
            out.primaryButtonLabel = button.label;
            break;
        }
    }
    return true;
}
#endif
} // namespace RedSalamander::Ui
