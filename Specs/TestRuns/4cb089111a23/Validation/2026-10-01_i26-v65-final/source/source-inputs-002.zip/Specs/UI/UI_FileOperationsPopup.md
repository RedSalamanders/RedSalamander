# File Operations Popup UI Contract

Last updated: 2026-10-01

This spec covers the hybrid Direct2D/DirectWrite and hosted DxUi File Operations progress popup surface in:

- `RedSalamander/FolderWindow.FileOperations.Popup.h`
- `RedSalamander/FolderWindow.FileOperations.Popup.cpp`

Engine execution, conflict semantics, streaming discovery, plugin contracts, and performance-validation
rules remain owned by `Specs/FileSystem/FileSystem_FileOperations.md`.

Implementation status, October 1: the I26 redesign adopts qualified DxUi revision
`19ca44d95a0cd493fc7fb1a57f4d4ad227bdefc1`, including the multiline caret viewport correction.
Both x64 builds pass without warnings/errors; broad Debug FileOps has 197 passes, no failures and
twenty documented conditional skips. The [V55 harness gallery](../Plans/WIP/FileOperationsUiReview_2026-09-16/implementation/2026-10-01-v55-final/README.md)
contains 562 static and ten protected captures with all 512 distinct image hashes reviewed.
Native 96/144-DPI and same-HWND keyboard/focus transitions pass. Release Full/Fresh and paired
consumer-resource acceptance remain in [I26](../Plans/WIP/UI_FileOperationsReview_2026-09-16.md).
Native 192 DPI, external screen-reader execution and separately owned consumer ARM64/ASan/release
handoff are not claimed. Original captures and failed intermediate runs remain historical evidence.

Eligible cards now expose a hosted throughput disclosure. Collapse removes the hosted graph,
retains the rate/qualified ETA summary and task actions, and preserves the outer window rectangle.
New/recreated cards inherit the remembered default; existing cards retain independent choices across
compact/footer-only suppression. Explicit changes use the existing queued settings save; painting
does not write settings. The consumer synchronizes the pinned disclosure's expanded state. Its
focused Commands journey exercises UIA Invoke, Space and pointer activation with graph/summary
and saved-preference checks. The adjacent consumer label is outside the chevron's hit rectangle.
DxUi exposes ExpandCollapse state for this retained control; the V35 application-pattern witness
passes actual Collapse/Expand, post-transition state, persistence/default omission and idempotence
checks in x64 Release. Final integrated gates remain tracked in I26.
The recurring missing client text/background was reproduced with S_OK legacy EndDraw results,
matching target sizes and post-draw occlusion. Client drawing now shares the DxUi presentation:
non-interactive chrome/text is prepared as a command list on the host device and replayed beneath
its controls. The harness retains its text/background witnesses and absent-color rejection.
The deterministic harness checks covered/uncovered captures, zero-size recovery and French
path/UIA behavior. Current qualification and remaining gates are listed above. See the historical
[single-surface captures and rejected baseline](../Plans/WIP/FileOperationsUiReview_2026-09-16/implementation/2026-09-19-single-surface/README.md).

Repeat scope uses a hosted Checkbox with UIA Toggle, Space and pointer/release-outside parity.
Space on this Checkbox changes scope;
the task pause shortcut must not intercept it. Its visible state comes from the acknowledged task
model, and synchronization must not trigger another user callback. Complete repeat-scope captions
wrap using their measured Body-font height; conflict actions use qualified DxUi measured action
arrangement with whole buttons wrapping to another row. Painting, hit-testing and UIA share the
measured bounds; current French/native-DPI captures are linked above.
[Before/after captures and paired redraw measurements](../Plans/WIP/FileOperationsUiReview_2026-09-16/implementation/2026-09-20-measured-conflict-actions/README.md)
retain the original clipping failure and the scoped qualification that first corrected it.

Ordinary path rows retain their complete localized label and exact Unicode value in the tooltip,
accessible name and HelpText on the same rectangle as the abbreviated painted path. Running
Copy/Move destination rows describe the destination folder; completed rows describe the recorded
destination file. `FileOperations.Task.<task>.Path.Source.<row>` identifies a bounded displayed
source slot, not a durable file identity; `.Path.Destination` identifies the destination row.
Current snapshot updates replace the value, and empty/retired rows remove it. Delete has no
destination region. These regions offer read-only inspection and do not alter file-operation authority.
The painted Source/Destination/Delete/Verify label column MUST fit its complete localized text
without overlapping the path. The consumer retains four bounded text/format measurements and
reuses them on unchanged paints; locale text and actual font/DPI recreation invalidate the affected
measurements. The column retains its ordinary minimum and grows for labels such as French
`Suppression :` and `Vérification`. The path, mini progress and destination selector use the remaining
width and retain their full tooltip/UIA value.
Path rows are focusable in visual Tab order and draw the shared contrasting focus outline. Focus
reveals the labelled value through the existing host tooltip. Left click, Enter, Space or UIA Invoke
opens a read-only full-path workspace inside the same popup HWND. Its multiline field MUST allow
selection, exact selected-text copy and scrolling through the complete Unicode value. Initial selection
covers the whole path with the viewport at its root; a separate Copy full path action always copies
the whole value. Tab cycles within the editor and its copy/close actions. Hidden task actions and
default-decision shortcuts MUST NOT run while detail is open. Escape closes only detail and returns
to the same live row, or a safe live control if that row disappeared. Showing detail MUST NOT activate
a background popup. Same-row value updates replace the detail; removal or popup hide retires its
editor and stale accessibility providers. Reflow preserves selection/focus for an unchanged value.
The row's
Ctrl+C copies only the exact underlying Unicode path. The first Escape dismisses visible detail
without invoking a task decision; subsequent Escape retains the normal popup decision/hide policy.
These path-specific keys take precedence over task shortcuts. Updating a row refreshes its value;
rebuilding retains a still-live row identity, or moves focus to a live action without invoking it.
The provider MUST acknowledge UIA keyboard focus, not merely store a host focus pointer.

The current 6,155-unit Unicode/UNC fixture covers selection and exact copy, read-only input,
scrolling, Escape, stale-provider rejection, row retirement and 40 open/close cycles. Space,
pointer and UIA open the same detail with editor focus; Copy full path, Close and bidirectional
Tab use actual controls. V55 captures show the adopted caret-clipping correction at native
96/144 DPI and retain the same-HWND text/selection/focus assertions. This bounded fixture is
not proof for arbitrary-length input or external screen readers. See I26 for integrated gate
status and the earlier
[path keyboard evidence](../Plans/WIP/FileOperationsUiReview_2026-09-16/implementation/2026-09-19-path-keyboard/README.md).

## Purpose

The popup is an operational surface for long-running copy, move, delete, and informational tasks. It
MUST make the current state legible at a glance, keep active controls stable while the task list
changes, and expose enough debug state for deterministic selftests without pixel inspection.

When the active language preference changes while the popup is open, its native window title MUST
reload from the selected language resource alongside the retained content. The change MUST keep
the same popup, task, conflict decision, and focus authority. The Issues pane follows the
corresponding retained-content requirements below.

## Reference Captures

Documentation screenshots MUST be captured from the real product popup through the named test-scenario
harness. Static captures do not activate; explicitly authorized interaction captures use the existing
warning and desktop lease, then restore focus/cursor. `FileOps_VisualGallery` supplies deterministic presentation fixtures;
its capture and provenance contract is in `Specs/Testing/Testing_SelfTests.md`. Mockups remain proposals.
The images below are historical Debug x64 captures; they do not prove the current checkout's appearance:

- Historical conflict and minimum-width footer: `Specs/UI/Images/FileOperationsPopup_Product_Conflict_2026-07-10.png`.
- Active running/waiting popup: `Specs/UI/Images/FileOperationsPopup_Product_Active_2026-07-09.png`.
- Completed partial-result popup: `Specs/UI/Images/FileOperationsPopup_Product_Partial_2026-07-09.png`.

![Historical conflict and minimum-width footer product capture](Images/FileOperationsPopup_Product_Conflict_2026-07-10.png)

![Active running/waiting File Operations popup product capture](Images/FileOperationsPopup_Product_Active_2026-07-09.png)

![Completed partial-result File Operations popup product capture](Images/FileOperationsPopup_Product_Partial_2026-07-09.png)

## Regions

Implementation observation, 2026-09-16: the I26 harness gallery at dirty `9c68026dd` exposes existing
deviations from the intended action/checkbox layout below: ordinary expanded task actions receive a
zero-height row, the hosted repeat-decision strip does not visibly convey the checked fixture state,
and some long conflict-action labels clip at minimum width. French captures on physical 96/144 DPI
displays additionally show custom-speed help/error overlap at 96 DPI and vertically clipped Issues
messages. On 2026-09-19 the ordinary action row was repaired to reserve its height independently of
conflict rows. Its settled native Debug bounds/hit-target regression and pause/resize/resume/cancel
sequence pass, with 300 French harness captures on two currently 144-DPI displays. See the
[first implementation slice](../Plans/WIP/FileOperationsUiReview_2026-09-16/implementation/2026-09-19-ordinary-actions/README.md).
The subsequent [conflict-action slice](../Plans/WIP/FileOperationsUiReview_2026-09-16/implementation/2026-09-19-conflict-actions/README.md)
removes the policy's three-primary cap and applies Replace/Remplacer. Its 300 French captures show
four direct choices, but long action labels still clipped at 480 DIP. The September 21 measured-action
candidate fixes that focused witness; it does not close the rest of the redesign.
The hosted checked-state, measured speed-dialog regions and shared complete-line Issues rendering
have since been implemented. Current gallery, mixed-DPI and full-suite qualification are recorded
at the start of this contract. These historical observations do not change the required behavior.
Evidence and proposed remediation are in
[the I26 review](../Plans/WIP/FileOperationsUiReview_2026-09-16/proposal.md).

The popup has three visible regions:

- Title bar: standard captioned tool window, independently minimizable/restorable.
- Operations list: scrollable stack of task cards.
- Global footer: always visible, including footer-only mode.

Footer-only mode hides the operations list, persists through `SettingsStore`, resizes the window to
the footer-only minimum height, and restores the previous captured rectangle when details are shown
again. The compact rectangle uses the normal `FileOperationsPopup` placement key; the last expanded
rectangle uses `FileOperationsPopupExpanded` and MUST NOT be overwritten while footer-only mode is
active.

When no valid persisted placement is restored, the popup is centered over its valid owner and clamped to the
owner monitor work area. Placement changes size neither the popup nor its z-order/activation state. This uses the
shared owner-centering geometry contract; monitor-work-area lookup failure leaves the existing position intact.

## Footer

The global footer MUST include:

- Aggregate progress bar across active file-operation work.
- Left transfer-action cluster: `Pause all` / `Resume all` first when applicable, then `Cancel all`
  while active work exists.
- Right settings/view cluster: one drop-down selector whose label is the current `Queue` or
  `Parallel` new-task mode, an `Options` overflow, then the details disclosure button.
- Status summary assembled from nonzero categories only (for example, `Running: 2`; omit
  zero-valued categories), optionally followed by aggregate ETA and throughput. Running,
  Waiting, and Needs-attention clauses MUST use separate count-neutral localized resources in
  the source file and all four satellite resource files; a combined singular/plural format or
  a retained dead combined-summary resource is forbidden.
- Right-aligned details chevron for footer-only collapse/expand.

Cancel all asks for confirmation. Declining leaves live work, pending decisions, completed
records and informational tasks unchanged. Accepting requests cancellation of the operation
tasks present when the engine snapshots its task list after confirmation. A task admitted
while the confirmation is open is included if present in that snapshot; a later admission
is not retroactively cancelled. Completed records and informational tasks are not dismissed.

Retained task controls share the task-list viewport clip; pointer and UIA hit testing must not
reach them through the footer. Keyboard traversal reveals the focused task control including its
outer focus chrome through the same native scroll state, without changing OS foreground. An
explicit interactive resize cancels pending automatic expansion. Collapsed completed-card content
and its child controls retire on the first frame, even while their height transition continues.
Consecutive focus requests before the next paint MUST translate retained bounds from their painted
scroll origin to the pending native offset before deciding whether to scroll. The final focused
control and its focus chrome must remain visible; an already valid pending offset is preserved.
First-frame collapse tests MUST inspect the actual raw provider tree, including offscreen children,
after witnessing each case-owned task before collapse. Missing roots, traversal failures and logical
visibility flags alone cannot establish that providers retired.

Reflow preserves the focused control's task/action identity without transferring native focus.
If that action disappears, focus moves to the same task's disclosure; if the task is no longer
present, focus moves to global Options. Neither fallback resolves an operation or selects another
task's decision. A removed focusable path uses global Options as its safe fallback.

Footer controls live outside the scrolled task-list viewport and MUST remain hit-testable there. The
`Options` overflow owns persistent preferences: auto-dismiss success/canceled and Compact/Expanded
density. Density MUST round-trip through canonical settings save even when it is the only non-default
file-operation setting. Auto-dismiss is a future-retention policy: changing it does not clear cards
already retained. `Clear completed` is an immediate bulk action for the current completed group and
MUST NOT be duplicated in the footer.

The footer has separate aggregate-progress, status-summary, and command rows. Its previous 88-DIP
height is a baseline, not a ceiling: measure the localized content and wrap whole command controls
into further rows when needed. Reserve the measured footer height before laying out task content.
The supported minimum client width is 480 DIP. At that width, every required control MUST retain a
positive, non-overlapping hit target. The square Options and details buttons remain icon-only; the
current mode selector may narrow but MUST retain its label and drop-down affordance.

The current bounded footer implementation measures the hosted Body text for Pause all, Resume all
and Cancel all, adding 12 DIP padding on each side. Pause/Resume reserves the larger label width so
an engine state change does not move the following controls. Widths retain the existing 112-DIP
minimum and no longer shrink to 72 DIP at narrow widths. A fixed three-label/format cache avoids
repeated text layout and applies DPI conversion at arrangement. French running-copy guards cover
480/640/760/480 DIP, visible label padding, non-overlapping actions and active Queue/Options targets.
The consumer footer adapter now delegates row placement to DxUi `ArrangeMeasuredActions`.
It preserves each measured transfer-action width and keeps Queue, Options and Details together as
one right-aligned group. When that group cannot fit beside the transfer actions, it moves to the
next command row; Queue MUST NOT disappear because the current row is full. Each added command
row increases footer height. Task comparison bounds, list clipping, footer painting, automatic
window sizing and footer-only minimum sizing use that same height. The fixed label cache remains
bounded and is consulted once per render. The localized summary uses one retained DirectWrite
layout keyed by current text, format identity and available width. Measurement and paint share that
layout; the summary wraps and all required lines increase the footer height before commands are
placed. An unchanged frame performs no summary layout allocation; DPI/font recreation invalidates
the retained layout. The same layout also measures the summary at minimum client width once per
cache miss; manual sizing uses that cached height, without creating text resources while dragging.
The 88-DIP height remains the one-line/one-command-row baseline. This implementation still requires
final Debug/Full, native mixed-DPI/keyboard/UIA qualification. `ProductUiTests` covers measured-width
boundaries, hidden actions, long-label row flow, wrapped-summary heights, indivisible settings,
contained nonoverlapping targets and invalid input.

The Queue/Parallel selector MUST read `GetQueueNewTasks()` on every hosted-control sync so its label
always reflects engine state. Activating it opens a radio flyout with Queue and Parallel; choosing an
item calls `ApplyQueueMode(...)`, and choosing the current item is idempotent. It MUST NOT use an
animated sliding thumb or keep a second UI-local mode state. It uses the shared DxUi current-value
selector chrome: one whole click target, flat borderless rest state, quiet chevron, shared hover
animation across the complete target, and no split-button divider or nested chevron button.

A flyout opened from a popup button MUST use the invoking button's width as its minimum root-surface
width. Longer localized labels, shortcut columns, and other flyout content may expand the surface
beyond that minimum; the monitor work area remains the final size constraint.

## Task Cards

Every file-operation card MUST resolve exactly one `TaskSnapshot::StatusKind` before drawing. The
same resolved status drives:

- header text,
- status glyph,
- status stripe,
- status chip,
- graph overlay,
- caption severity,
- footer counters,
- Windows taskbar state.

The left stripe is required for every non-`None` file-operation status. A header chip is used except
for Conflict: its expanded body carries one measured waiting/loading line, while the collapsed title
carries the status. Do not duplicate that sentence in the expanded header or a fixed-width chip. Tone mapping:

| Status | Tone |
|--------|------|
| Running, Discovering, Preparing, Verifying | Accent |
| Waiting, Stopping, Canceled | Neutral |
| Paused | Muted |
| Conflict, Partial | Warning |
| Failed | Error |
| Done | Ok |

The chip uses localized short labels and MUST NOT be the only status signal. Status must remain
readable without color through glyph and/or text.
Discovering and Preparing use their short localized labels in the chip; elapsed detail belongs
in the header and full status accessibility text. The chip's entire label must fit the actual
painted text lane. A finished card with a visible status chip uses an operation-only heading,
so `Done`/`Terminé` is not repeated immediately beside it. When the chip cannot be painted,
the heading retains a localized textual status fallback.

The card consumes the engine-owned `TaskLifecyclePhase`; it MUST NOT infer Preparing from missing
progress, zero totals, or a worker that has not emitted a transfer callback. `Preparing` and
`AwaitingAcceptance` render as Preparing. `Ready` is a transition boundary before Waiting/Running;
`Stopping` and `Terminal` remain explicit. Pause, conflict, verification, and discovery are
orthogonal facts and retain their existing status precedence without rewriting the lifecycle.

Publication does not synchronously create or show the popup. Every ordinary, clipboard, Inline
Rename, Batch Rename, and Change Case task arms the fixed 500-ms `kTaskCardRevealDelayMs` deadline.
Queue waiting and actionable conflict/failure/partial/canceled/indeterminate states reveal
immediately. Otherwise, a task that is still live at the deadline reveals its one stable card in
its current lifecycle state; a slow gate therefore appears as Preparing and later transitions in
place. Clean routine work that completes before the deadline keeps its completed-history receipt
without opening or focusing the popup. **Show File Operations** reveals a hidden live task
immediately. The delay is not a Preference, and deterministic tests use a fake clock rather than
sleeping.

### Confirmation surface

Routine accepted-default Copy/Move starts without a generic confirmation. This includes F5/F6,
destination-picker transfers, clipboard paste, and internal drag/drop when their ingress does not request a separate material
decision. The existing confirmation surface is shown only for an explicit `requireConfirmation`, a
known Copy-only Move, or an existing exact artifact/risk gate. Permanent Delete and command-owned
preview/editor/drop decisions retain their separate contracts.

When shown, Copy/Move confirmation captures the complete immutable task intent before task
publication. In addition to the operation summary and destination it exposes:

- for Copy, `Links`, with exactly `Preserve links` and `Skip links`; Follow is never displayed or
  accepted; a Move confirmation does not show the row;
- `Verify copied file contents`, initialized from `fileOperations.verifyAfterCopy` and changeable
  for this task without changing Preferences;
- the existing Queue/Parallel and bandwidth controls;
- for clipboard Move, the fixed warning that accepting the task consumes the captured cut list and
  that the list will not be restored if a source is retained.

`HostPromptRequest::fileOperationOptions` points to a caller-owned, synchronous
`HostFileOperationPromptOptions` in/out snapshot. The host renders its finite choices as four
option rows, with available choices invokable by keyboard, mouse, and UIA, and writes accepted values back only for the
affirmative action. Links exposes Preserve/Skip, Verify exposes Off/On, Start exposes Queue/Parallel,
and Bandwidth cycles Unlimited, the standard presets, plus the captured custom value when needed.
Flattening the choices into an unstructured message string or rereading Preferences/provider
configuration after acceptance is forbidden. Cancel leaves the caller snapshot unchanged, admits no
task, and consumes no clipboard sequence.

Verify also renders the caller-provided `verificationAvailability`: Supported exposes Off/On;
Unsupported and Not applicable force a disabled Off row with a localized reason; Check during
operation leaves Off/On enabled and explains that the exact route is resolved when work starts. The
prompt cannot infer support from provider name or method existence, and an accepted runtime-check
choice is not silently cleared when the per-item result later becomes Unavailable.

### Streaming discovery

There is no `Calculating` task state and no separate pre-calculation pass. After mandatory
Preparing/Ready, execution traversal may enter `Discovering` while the single traversal runs ahead
of execution. While discovery-ahead is active,
the card exposes `Skip discovery`; selecting it atomically switches the task to just-in-time
discovery, releases discovery-ahead reservations and scheduler throttles, removes the action, and
allows eligible transfer work to use the full task bandwidth/concurrency budget. The status becomes
`Discovering as needed` until traversal closes.

A task whose selection is a single known file never presents this state during its transfer. Its
exact byte total is published and its discovery scope closes before any payload moves, so the card
shows a fixed full-file denominator, a determinate meter and a real item count from the first frame.
With several selected roots an early leaf closure is still correct while another root keeps
discovering: the task aggregate stays open until every root resolves.

`Skip discovery` skips only the run-ahead user experience. It never skips recursive enumeration,
name validation, identity/containment checks, capability queries, conflicts, or revalidation before
an item is acted on. While traversal is open, the card presents discovery as a dedicated animated
three-dot activity signal and presents transfer independently: live source rows, transferred bytes,
throughput history, and the whole-task bar continue to update. Until traversal closes the whole-task
bar is indeterminate (a marquee once transfer is active) and the card shows two separate exact-counter
rows: discovered bytes and items so far, then transferred bytes and completed items (D2-A08). The
discovery row says when discovery is happening on demand after Skip. It never presents the growing
discovered counts as a final denominator. No
growing-denominator fraction or percent is rendered. A provisional ETA, `Remaining: {0} (still
discovering)`, appears only while a usable smoothed transfer rate exists over the workload discovered
so far; it may rise or fall, is hidden while paused, stalled, or without progress callbacks, and is
replaced by the ordinary ETA once totals close. Aggregate progress reports **Known work** over the
closed-total cohort (see Progress Rules); the taskbar remains indeterminate while any included total
is open. After Skip, the ordinary operation rate/throughput remains
visible beside the secondary `Discovering as needed` signal; full transfer speed is not presented as
proof that totals are known. Once traversal closes, totals become final, determinate progress and ETA
may begin, and the action can never reappear for that task.

The discovery and transfer counter rows are separate localized grammar-bearing resources. The
renderer MUST load the active satellite versions rather than the executable's embedded source-language
strings. Tests cover the complete French row labels and the on-demand variant; byte values retain
the application's active locale formatting.
For deletion, the processed-work row says `Deleted` / `Supprimés`; it never describes deletion as transfer.

The Copy/Move discovery action row measures `Skip discovery` using the hosted Button's live Body
typography, with at least 12 DIP of horizontal padding on each side. Its logical width is cached
for the current label and retained text-format identity; unchanged paints and width-only resizing
reuse it, and DPI conversion happens when arranging. The French `Ignorer la découverte` guard
covers 480/640/760/480-DIP widths with active Skip, limit and Cancel hit targets and no overlap.
This discovery-action component does not provide general whole-button wrapping for ordinary task
actions; that remains required by the adaptive layout contract. Measured footer row and summary
height are implemented separately in the global footer described above.

### Same-host overlap warning

When Preparing finds that the new task's scopes overlap another published-prepared or active task in this host
(R4-A02-1), the task card shows one deferred-consent prompt titled "Another task is working in the
same place" whose question names the concrete problem and the first overlapping task by number, for
example "This task may remove items that task #3 is still reading." Its actions are **Queue after
these tasks** (the default and Enter action), **Run at the same time**, and **Don't start** (Escape).
Run is present only when every disclosed relation fits the fixed bound and applies only to the named
concurrently-live task IDs; another undisclosed overlap still asks independently. Queue keeps the task
as `Waiting` behind the named tasks without a `Start now` control (the wait is the user's scheduling
choice, not the queue mode); Don't start ends the task as canceled before any mutation and leaves no
completed-history success entry. The warning appears at most once per task, and a task that prepared
later than a peer still learns about that peer once the peer has decided its own warning; when it
queues after a younger peer it takes its place behind every task admitted so far, which the queue
order on the cards shows; queue-mode
waits and the interlock wait itself remain silent. Read/read overlaps and clearly disjoint paths never warn, and
neither does the conservative wait of a provider without bound objects (its interlock cannot prove
which objects two paths name, so it serializes without naming a problem).

A Permanent Delete asks its confirmation on the card, not in a modal at ingress: once Preparing has
pinned every selected root the card shows "Permanent delete" with the question the modal used
("Permanently delete {what} from {where}. This cannot be undone."), and its actions are **Cancel**
(first, the default and Escape action) and **Permanently delete**. Cancel ends the task as canceled
before any mutation and leaves no completed-history success entry; Permanently delete lets the task
re-check the confirmed pathnames against the pinned objects and then run. Archive cleanup deletes
whose consent the archive prompt already captured do not ask again.

When a task without a covering Run relation is about to delete, rename, move, or replace an exact
item that another task is still publishing, the same card changes to a deferred-consent prompt titled
**Another task is still publishing here**. The question names the publisher task and explains that
changing the item can invalidate its result. Actions are **Queue until the other task finishes**
(default and Enter), **Skip**, the operation-specific **Delete it anyway**, **Rename it anyway**,
**Move anyway**, or **Replace it anyway** action, and **Cancel** (Escape). Queue waits only for that
publisher and then revalidates; Skip completes the item as skipped; the destructive action applies
only to the parked effect and has no Apply-to-all/cache semantics. If the bounded exact-output index
overflows, the destructive action is withheld and the conservative Queue/Skip/Cancel surface remains.
The prompt and its task relation disappear when the publisher terminates and are never reconstructed
from completed history or shared with another app instance.

### Inline-F2 completion exception

A one-step `RenamePlan(InlineRename)` uses workers and the normal safety/interlock engine. It follows
the common deferred presentation rules, with one narrower clean-completion exception:

- waiting on an interlock, conflict, failure, partial, canceled, or indeterminate state reveals the
  popup and card immediately;
- a clean-running task reveals its card only if it is still running at the common fixed 500-ms deadline;
- clean success before that deadline creates no card, no completed row, and does not activate the
  popup, while telemetry, pane refresh, and identity-based focus retention still occur;
- once a card has been revealed it never becomes retroactively silent and follows ordinary
  completion/auto-dismiss behavior.

Batch Rename, `RenamePlan(ChangeCase)`, and Copy/Move/Delete keep their ordinary completed-history
receipts after a clean hidden completion; only Inline F2 suppresses the completed row. Change Case
may show a threshold-delayed informational card during command-owned discovery, but once immutable
mappings are admitted the central File Operations task is the sole mutation/progress/result card
owner.

In normal themes, `Ok` status MUST resolve through the scoped `fileOperations.successText` theme
color and MUST be visually distinct from the active `Accent` tone. High-contrast themes may map
`Ok` to the system/menu text color when that is required for contrast.

In high-contrast themes, the card-level stripe, applicable chip and tone semantics remain present, and warning/error/
ok statuses retain a glyph plus text signal. The non-client caption status glyph is suppressed in
high contrast so system caption contrast is not compromised.

Queued file-operation cards MUST expose `Start now` before the task begins. The action releases only
that task's wait gate and MUST NOT flip the global footer Queue/Parallel setting. The footer MUST
expose a bulk `Pause all` command while any active started task is running and a bulk `Resume all`
command when started tasks are paused with no unpaused running tasks. Bulk pause/resume toggles only
the per-task manual pause state for started live tasks and MUST NOT clear queue gating or change the
global Queue/Parallel mode. Discovering/preparing tasks that have not entered execution are not bulk-command
eligible and MUST NOT change a `Resume all` decision back to `Pause all`.

Queued tasks have a stable engine-owned queue-order key. The popup sorts queued cards by that key and
exposes Move Up/Move Down only when an adjacent queued task exists in the requested direction. A move
swaps the adjacent keys and the engine queue order under the queue mutex. Worker-thread start does not
make a task ineligible: queue actions remain valid until the task enters operation. `Start now` releases
only the selected task and queue reordering does not change the global Queue/Parallel mode.
The compact destination-history button beside a path uses its menu chevron without a clipped text
caption. Its localized Destination name remains available through UI Automation and its tooltip,
and the whole visible control remains an active menu hit target.
Its local destination-history rows show the folder name as primary text and its parent location
underneath. Both fields wrap at the menu's measured available width. Repeated folder names remain
distinguishable by their parents. A drive or UNC share root keeps its complete root as the primary
text, without inventing a parent above that root. Names containing ampersands remain literal.
Every row exposes the exact original full history location as its accessible name. Provider-qualified
history without an admitted per-entry path profile keeps that full location as primary text;
opening the menu must not synchronously query providers or infer separator semantics. Display
decomposition changes neither history eligibility/instance filtering nor the original selected
destination value, command identity or checked state.
Changing a queued destination MUST update the qualified execution request as well as its visible
location. A display-field change is never evidence of successful retargeting. The owner must reserve
the queued task against dequeue/preparation races, re-admit the chosen endpoint through the canonical
operation admission path and revalidate capability, path identity, transfer strategy, mutation
interlocks and applicable Move recovery records. Provider calls must not run under queue locks.
Cancel, refusal, failed re-admission or a stale callback leave the original admitted destination
and task intact. Preserve queue mode/order, speed settings and the existing clipboard-consumption
decision; a destination change must not consume the clipboard again or reuse inapplicable consent.
Implemented M06 transaction: a queued destination change is claimed against the admitted generation,
privately re-admitted, reserved and selected only after successful durable settlement. Refusal,
cancellation before reservation and stale/started requests preserve the original admitted destination.
The isolated V9 Release history-menu/output journey exercised actual UIA selection and Copy/Move bytes;
the admission matrix also covers failed settlement and the cancellation boundary. Current-source
integrated interaction and resource qualification remain in I26; the original display-only failure
is historical evidence, not the current implementation.
Ordinary path rows abbreviate the filename itself when the leaf is wider than the available row;
they must not reserve an unmeasured whole filename and clip its extension. Abbreviation retains
only complete DirectWrite shaping clusters, fits the measured row, and preserves the extension
whenever it fits. The exact unabbreviated path remains the tooltip, accessible value and copy value.
Informational `Analyse` rows use the same measured, cluster-safe middle abbreviation for
their changing path. Reserve space for the localized label and folder/item counters before
abbreviating the path; if even that scaffold cannot fit, abbreviate the complete status rather
than clipping it. Preserve the full localized status in the tooltip and UIA Name/HelpText,
including retained scan counts on completed cards. A nonempty scan path retains its exact
absolute or relative copy value; the display-only `.` placeholder must not become a copy action.
Unchanged visible scan rows reuse measured text and their retained layout. The cache is bounded
by the current snapshot, invalidates on text/width/height/format changes, and releases layouts for
unpainted or removed rows and on theme/DPI teardown. Historical task identities must not accumulate.

Completed cards auto-collapse once when they first resolve to a finished state, unless auto-dismiss
removes them or the user already has a manual expanded/collapsed override for that task. The footer
Compact/Expanded density setting applies to every visible task card as a default display state, not
as a forced stored collapse; the per-card chevron can expand a compact-density row and restore the
card's normal actions without disabling later completed-card auto-collapse. Compact rows keep the
status signal and task name on one line. A final published byte/item denominator permits a mini
progress meter plus localized percent text. While discovery is open and transfer is active, the
compact row shows a marquee and no meter or percent text. A row with completed
work but no denominator MUST NOT render a misleading `0%` meter. When at least two completed file-operation cards remain visible, the
popup groups them under `Completed (N)`, expanded by default. `Clear completed` is the first control
in the group header and the disclosure chevron occupies the same trailing 18-DIP lane as task-card
chevrons. The chevron hides/shows completed rows without dismissing them. While collapsed, the header
shows separate nonzero badges for Completed, Partial, Indeterminate, Failed, and Canceled result counts. Task-card
height and completed-group visibility animate together with bounded smoothstep easing over 260 ms.
User-triggered disclosure motion temporarily advances at a 16-ms cadence, then returns to the
100-ms telemetry timer; reduced motion snaps both transitions to their target state.

The group header MUST measure the clear caption using the actual hosted Button Body font,
including padding. The clear action, heading and every nonzero badge retain their complete
measured sizes; overflow moves whole regions to additional rows and increases the card height.
The disclosure keeps its trailing position on the first row. No badge may disappear merely
because earlier regions used the first row. Numeric badge widths include the full count, icon
and insets. A heading longer than a full row wraps within that row. The group layout is app
policy: the pinned generic measured-action flow uses a uniform width for every row, whereas
only this header's first row reserves the disclosure lane.

Partial and Indeterminate group badges MUST use different icons as well as distinct localized
category names. Both may retain the warning tone; color alone cannot distinguish their meaning.
The actual drawn glyph and hosted accessible name must agree with the category. Availability of
the icon font is not assumed: the unknown-result fallback is an ordinary question mark.

Each nonzero collapsed-group badge has a retained DxUi status region whose tooltip explains the
category and count (successful, partial/warning, indeterminate, failed, or canceled); the same text is exposed as
its accessible name and HelpText. `Clear completed` and other text buttons MUST NOT show a tooltip
that only repeats their visible label. Glyph-only disclosure and overflow actions retain descriptive
tooltips because their action name is not visible.

All popup disclosure affordances use the shared Fluent disclosure-chevron path. A leading-edge
collapsed disclosure points right; a trailing-edge collapsed disclosure points left. File Operations
task, completed-group, and footer details chevrons occupy a trailing lane and therefore use left/down,
while trees keep right/down. The transition takes the shortest 90-degree path with the shared
`PointToPoint` easing, uses native untransformed directional glyphs at rest, and snaps under reduced motion. Task-card
and completed-group chevrons are card-integrated disclosure targets without standard button fill/border
chrome; keyboard focus remains visible. Hand-drawn stroke chevrons are forbidden.

## Hosted DxUi Control And Accessibility Contract

The popup retains one top-level HWND and its existing hand-drawn card/chrome layout, but every
interactive hit target MUST be mirrored by a real `DxUi::Button` hosted by a `DxUi::WindowHost`
attached to that same HWND. Determinate progress is exposed by hosted `DxUi::ProgressBar` controls
and bandwidth history by hosted `DxUi::ThroughputGraph` controls. Application drawing remains
responsible for non-interactive text, status decoration, and card geometry; hosted controls use the
same calculated rectangles and action descriptors. Each progress rectangle and each graph has one
pixel owner: the hosted control. There is no second, hand-painted progress or graph route and no
legacy mouse hit-testing route; when the host is unavailable the popup shows the failure surface
below instead. File Operations progress descriptors set the hosted control's explicit track height
to the complete calculated lane height; the generic 2/4-DIP ProgressBar default is too subtle for the
popup's aggregate and whole-task marquee lanes.

All normal client pixels MUST share the WindowHost presentation. The application prepares one
Direct2D command list before retained-tree painting and restores the borrowed host target, DPI,
transform and text antialias mode. A consumer root replays it in the existing physical-pixel
coordinate system beneath the hosted controls; replay performs no layout or tree mutation.
The previous prepared frame is released on replacement, theme reset or device-context change.
A frame from a different context MUST NOT be replayed. Caption GDI drawing and the native failure
surface remain separate non-client/fallback paths. No second HWND client render target is created.
After host device recreation, normal painting MUST replace the consumer's previous context and
prepared frame, restore readable text and controls, and preserve disclosure actions. Hidden timer
delivery may update taskbar progress, but MUST NOT submit hosted client frames. Showing the popup
again resumes normal painting without activation. Deterministic simulated loss and short hidden
intervals validate these transitions; they do not establish hardware-removal or memory-soak acceptance.

## Failure Surface

When the DxUi host cannot attach to the popup HWND, or the popup's Direct2D target or device
resources cannot be created, the popup switches to a failure surface that needs no Direct2D,
DirectWrite, or DxUi: native `STATIC` text and two native `BUTTON` children owned by the same HWND.
The text states that the window's graphics could not start, that operations continue, and how to
stop or hide them; it carries the live global status summary and one line per operation (its kind
and status) and refreshes on the popup timer. The buttons are **Cancel all** (the same confirmation
and cancel path as the hosted footer control) and **Close** (hide-only, as the caption Close). No
task graph, queue or speed menu, Replace or Retry action, conflict decision, or other action is
reachable while the failure surface is shown; a debug or hosted-path invoke of any other action is
refused. Waiting tasks keep waiting and running tasks keep running unless Cancel all is confirmed.

`Tab` and `Shift+Tab` move between the two buttons, `Enter` invokes the focused button, and `Escape`
hides the popup. UIA names and Invoke come from the native control classes. Colors are system colors,
so high contrast applies automatically; a DPI change re-lays out the children with the system message
font for the new DPI. Close and reopen re-attempts the host; when it attaches, the hosted popup
returns and no failure-surface child remains. If a native child cannot be created, the popup reports
through the host error surface and Cancel all stays reachable from the main window's File Operations
command. Deterministic runtime coverage MUST be able to force the next host attachment and the next
Direct2D target creation to fail separately, without the production attach-error diagnostic, and
prove the contract above through a real popup fixture.

The host MUST receive the original `WM_SIZE` size type so minimize/restore lifecycle handling stays
truthful. A zero-area or minimized client MUST suspend preparation, retain resources and avoid a
permanent failure surface or forced immediate paint. Before rebuilding the hosted control tree, the popup MUST reset WindowHost hover,
capture, and focus pointers; focus may then be restored by the stable action identity. This prevents
retained interaction pointers from outliving controls removed during a layout rebuild.

Hosted action automation IDs are stable and encode action kind, task ID, and action data as
`FileOperations.Action.<kind>.<task>.<data>`. Aggregate/task progress and throughput graphs use stable
role/task IDs. Progress controls expose a read-only UIA RangeValue contract with minimum `0`, maximum
`100`, and the current displayed percentage. Throughput graphs expose a semantic Custom control.
The UIA fragment count MUST equal the popup's hosted-control debug counts; hidden or scrolled-out
legacy hit targets MUST NOT leave duplicate semantic controls.

Keyboard behavior is:

- `Tab` / `Shift+Tab` traverse hosted interactive controls in visual order.
- Path-row Enter/Space and Ctrl+C follow the read-only detail contract above before task shortcuts.
- `Enter` otherwise invokes the focused action or the actionable decision snapshot's explicit default.
- Left/Right/Up/Down move between actions belonging to the same task when a neighbor exists.
- `Space` activates the focused task-details or throughput disclosure, scope Checkbox,
  decision or inspection control without changing task pause state. Otherwise it pauses
  or resumes the focused live task. Disclosure state changes preserve both pending decisions.
- `Delete` cancels the focused cancellable task.
- For an actionable conflict/deferred-consent decision, `Escape` invokes that immutable snapshot's
  Cancel action and never Cancel All. The bound decision is the focused task's decision; when focus
  is on global controls or no task, `Enter`/`Escape` bind to a decision only if exactly one is
  actionable. Focus on another present task without a published decision, including its loading
  disclosure fallback, must not bind Enter/Escape to that decision.
  Outside a bound decision, `Escape` hides the popup. Window Close always hides without resolving a
  decision.
- Window Close is the caption Close of the global File Operations popup, not a task action. It MUST
  remain hide-only and MUST NOT cancel the focused task or all tasks. The hidden surface remains
  reachable through **View > File Operations**, `cmd/app/showFileOperations`, and the default
  application shortcut `Ctrl+Shift+J`. Publishing a newly actionable decision automatically shows
  the same popup; metadata-loading attention alone does not. Explicit show and automatic show never
  submit, focus, or otherwise alter the published decision.

Hosted-control creation order is not the navigation contract. After layout, the popup
MUST derive one focus/UIA traversal list from final visible geometry: top-to-bottom,
then logical leading-to-trailing within a row (mirrored in RTL), with a stable action
identity tie-breaker. Hidden or removed controls are excluded. Forward and reverse
keyboard traversal and the UIA sibling chain MUST consume that same list, so rebuilding
cards, footer controls, or conflict actions cannot make semantic order disagree with the
painted surface.

Conflict appearance and terminal transitions to Done, Partial, Failed, or Conflict raise a bounded
WindowHost accessibility notification when the OS provider accepts it. Notifications supplement,
and do not replace, the stable Name/AutomationId/pattern state exposed by the control tree.
The per-task notification generation/history map MUST be pruned whenever a task is no
longer in the live popup snapshot. Teardown clears it completely. Reusing a numeric task
ID after removal starts a new generation; stale history must not suppress or retain the
new task's announcement.

Conflict semantic text is exposed as stable sibling regions in visual reading order: State,
Question, Facts, From/Deleting, To, Last note, then actions. Loading-to-actionable is a real state
transition and is announced once; repaint alone never repeats it. Hidden discovery, transfer, and
graph elements do not remain in the conflict card's UIA tree.

## Progress Rules

Per-file progress has one home: the current file line. Copy/Move cards MUST NOT render a second
under-graph current-item bar. The under-graph progress region is reserved for exactly one whole-task
bar. During streaming discovery it is indeterminate: a visible marquee once transfer is active, never
a fraction over the growing discovered-so-far denominator (D2-A08). The separate discovery indicator
and the exact counters line make the open scope explicit. Compact cards show no meter or percent text
until `discoveryClosed`; percent, ordinary ETA, and the hosted progress value begin only after closure.
The cure for an indeterminate meter is an honest producer, never a forced determinate presentation:
a task that knows its total closes its scope and this rule then yields a determinate meter on its
own. ETA still waits for the estimator's normal warm-up, so a closed total does not imply an
immediate remaining-time figure.

The whole-task bar has equal semantic halves when verification is requested: the left half is
transfer/publication and the right half is verification. Verification uses the
`fileOps.progressVerify` fill plus diagonal hatching and a divider, so it remains distinct without
color; the ordinary single bar survives unchanged when verification is Off. A file row currently
being verified uses the same verification fill on its mini bar. The aggregate graph keeps transfer
as the primary series and exposes verification readback as a separate warning-tone series;
provider-proof completion advances the verification bar but creates no fake read throughput sample.
The current and footer bandwidth values include both series, while pump-only Copy/Move throughput
excludes verification. Aggregate ETA is remaining transfer time plus remaining verification time and
is hidden whenever either required denominator/rate is unknown.

The hosted DxUi `ProgressBar` remains the exclusive determinate owner for this whole-task model. For
Verify On, the popup supplies transfer and proof values to its two equal semantic halves and supplies
the themed verification color; the control owns the divider, diagonal hatch, invalidation, and
accessible state. The popup does not drop the hosted descriptor merely because verification is
enabled.

The hosted control's value MUST describe the same whole-task progress as its visible model.
With equal verification halves, completed transfer and half-completed verification report 75%,
while the independent segments remain 100% and 50%. A closed known Delete denominator, including
one known item, is determinate at zero before the first completion; absent byte and item totals
remain indeterminate. Open discovery never becomes determinate merely because provisional totals
or processed counters are nonzero.

The footer aggregate bar uses live byte totals first and live item totals second. Finished cards may
remain visible when auto-dismiss is off, but all finished cards are excluded from live footer
counters, aggregate totals, need-attention totals, and Windows taskbar progress. Their completed
status remains on the individual card. The footer aggregate is **Known work** (`FO-DISCOVERY-01`): a
compatible closed-total cohort renders determinate progress and `Known work: N%` while other included
tasks still discover, and the status line adds `N discovering, total may grow`; without a closed
cohort the footer is indeterminate and shows no percentage, and an active task whose discovery
closed without any total keeps it indeterminate (nothing is known about it and it will not close
later). The Windows taskbar model stays
indeterminate while any included total is open, even when other active tasks have known totals.

One whole-task presentation decision supplies paint, hosted controls, debug snapshots, UIA,
footer, and taskbar. Unstarted Queue waiting, interlock waiting, conflict metadata loading, and
actionable conflict are excluded from the active aggregate cohort and expose no discovery activity,
transfer bar/marquee, or throughput graph. A running open-discovery card renders the marquee plus
exact counters and contributes only its open-discovery count to the footer; the footer's Known-work
denominator is the closed cohort alone and the taskbar stays indeterminate while that card is
included. Cohort membership and denominator rebasing are deterministic when tasks enter or leave
waiting/attention/running states.

Needs-attention remains visible through the taskbar's error state without publishing a progress
value or re-admitting the blocked task to the active aggregate cohort. Completed compact cards may
retain their final determinate meter as static history; they never contribute that value to the
live footer or taskbar aggregate.

All unsigned aggregate byte/item totals MUST use saturating addition. Extreme task snapshots may
clamp a displayed aggregate to `uint64_t::max`; they MUST NOT wrap backward and expose a smaller
progress value, ETA input, or taskbar total.

For a closed byte-total cohort containing verification, the footer and Windows
taskbar use each task's whole-task fraction, weighted by that task's transfer-byte
total. Transfer and verification remain equal halves regardless of their different
byte denominators. A fully transferred, half-verified task therefore contributes
75%, not 100%. Work weights are accumulated separately from the saturating actual
transfer-byte counters; neither proof bytes nor normalized work units are reported
as transferred bytes. The taskbar receives bounded normalized work units for this
cohort. Open-total, attention, pause and finished-task eligibility rules still apply.

Aggregate throughput includes only live Copy/Move rates. Aggregate ETA uses the matching determinate
task/rate set and MUST be hidden when any live Copy/Move task has unknown byte totals or lacks a
usable matching rate; throughput remains visible. Taskbar progress MUST continue to update from the
popup timer while the popup is hidden or minimized, without requiring a paint.

Ordinary deletion cards expose a localized, accessible item rate alongside item progress
and the source path. They reserve no byte-throughput graph, graph disclosure or
empty graph body. Their compact expanded layout keeps the progress bar and actions
separate from the text rows. Copy/Move retain the saved, initially expanded byte
graph preference; deleting does not modify that preference.

## Typed results, clipboard consumption, and Issues

Cards and completed-group badges derive from the typed per-item axes rather than one HRESULT:
destination publication, verification, source disposition, and item completion. `Copied; source
kept` and `Moved; source folder kept` are Partial/warning results, never successful Move. Expanded
terminal cards expose independent, labelled Publication, Source and Verification facts below the exact
result summary. Show only positive recorded counts: published/unknown publication; removed/retained/unknown
sources; verified/failed/unavailable/canceled verification. Mixed outcomes retain every applicable count;
one selected verification state MUST NOT hide the others. Do not derive complements from totals, infer
success from zero unknown, or turn missing/NotAttempted evidence into published output. Source retention
for an ordinary Copy remains a neutral fact. The native-retained subset's specific explanation remains
in the canonical result summary. Unknown/indeterminate axes never remove source rows optimistically.

The facts use up to three wrapped paragraphs with explicit axis labels and complete localized count
clauses. Their meaning does not depend on color. Replace the fixed three-badge row with measured Body
text: the same retained layout supplies drawing and height before paths, progress and actions are
placed. The entire text is exposed by one `FileOperations.Task.<id>.TerminalFacts` hosted region.
Cache keys include task identity, the nine counts, categorical verification fallback, language revision,
font identity and available width. Hidden, collapsed, removed and footer-only content releases the layout;
unchanged frames reuse it. Historical categorical verification evidence without numeric counts remains
labelled, without inventing a count. Empty/default snapshots produce no facts; interrupted-Move breadcrumbs
retain their dedicated notice rather than pretending to be per-item receipts.
The canonical result line is localized as `Copied`, `Moved`, `Copied; source kept`, `Moved; source
folder kept` (a rename merge whose emptied source directory could not be removed because a child was
skipped, conflicted, or appeared late), `Skipped`, or `Outcome unknown`; it is carried from the engine result reducer and is not reconstructed from the
aggregate HRESULT. Unknown publication/source uses its distinct indeterminate warning state and
completed-group badge, while a
planned Copy-only or exact retained-source downgrade uses the warning/partial state.

Owned-stage cleanup is a separate axis from primary completion. When a provider proves the requested
mutation committed but reports the cleanup object `Retained`, the card remains Completed/Published,
adds exactly one localized cleanup warning, and uses the canonical result line `Completed; cleanup
item retained.` No automatic retry is attempted. `Unknown` or `RetainedIncomplete` cleanup still
renders as Indeterminate/Possible artifact; a failed or canceled primary is never rewritten to
Completed merely because its cleanup disposition is known.

Verification is a distinct labelled result axis: Verified, Failed, Unavailable and Canceled retain
their separate recorded counts. Unavailable and Canceled never claim byte equality;
NotApplicable is shown only where the detail surface needs to explain Native/directory behavior;
NotRequested adds no verification fact. A published destination with Failed/Unavailable/Canceled verification
never renders as a clean success. For Move it also carries `Copied; source kept`, because the source
cleanup gate was not crossed.

For a clipboard Move, accepted admission publishes a non-running card and a gated worker before the
clipboard barrier. Successful consumption records `Move queued — cut list cleared.` immediately.
If selected-root readiness or sequence-matched clearing fails, the accepted task terminates before
discovery/mutation. The card says that the Move did not start and the source remains unchanged; it
must not claim that the cut list was consumed. The host's bounded accepted-sequence ledger still
rejects another admission of that exact sequence. The terminal item rows are dense Failed/Canceled
`NotAttempted + Retained` truth rather than Unknown. After successful clear, the card and Issues view
retain the consumption fact after cancel, failure, Copy-only
downgrade, or `Copied; source kept`; neither Dismiss nor Retry recreates the old clipboard sequence.

When typed results contain retained sources, the completed overflow menu offers `Open source` and
`Select retained` where locations are known. `Cut retained items again` is offered only when every
retained item has a captured no-follow identity and no source disposition is Unknown. Select and
Cut-again rebind the complete set on click and compare object identities; one missing/replaced item
aborts the action and shows a warning. The current `CF_HDROP` Cut-again action is shown only for the
Local file provider. Cut-again publishes a new cut payload as an explicit user action; it never
simulates restoration of the old clipboard sequence.

If any source disposition is Unknown, the card says that some source states are unknown and that a
successfully cleared cut list was not restored. `Open source`/destination remains available where a
qualified path is known, but Select retained and Cut-again are withheld until a later operation has
an exact complete retained set.

Every skipped, warned, failed, retained-source, verification-mismatch, and indeterminate item has an
Issues row with its canonical bucket, qualified source/destination, selected conflict action or
grant, and typed axes. `Skip All` is represented as Skip plus its explicit same-bucket task grant;
Recycle escalation never gains Apply-to-all.

### Interrupted Move restart card

On startup, each valid non-terminal Move breadcrumb projects as a completed warning card with
`Outcome unknown`. The card identifies the last durable `Admitted` or `Executing` phase, admitted
Native/Managed/Copy-only counts, and total qualified source-root count. Its message explicitly says
that RedSalamander was interrupted, the Move outcome
cannot be inferred, and source and destination objects may both exist.

The card's live `taskId` is a newly allocated in-session card/action key. If the historical
breadcrumb identifier is shown, it is carried as `interruptedOperationId` and labeled
**Interrupted operation ID**. UI text, accessibility, commands, telemetry, and dismissal must not
call both values “task ID” or imply that the historical identifier names an active or resumable
task. Every card action continues to address the live session key; Dismiss resolves that card to and
acknowledges only its exact breadcrumb file.

The card can open a representative qualified source location or the qualified destination location
in the source/destination pane roles captured at admission; those actions perform normal pane
navigation/enumeration and do not infer item disposition. The persisted File Operations instance ID
is comparison-only canonical identity: restart navigation must decode `host/default` to the empty
pane context and `host/context/<opaque-context>` to that opaque context, and must reject any other
form rather than navigating with canonical identity text. A pane hint is presentation only and does
not weaken normal navigation/provider validation. The user
may then use the ordinary Refresh command. The card never offers Resume, Retry, Roll back, Delete
source, Delete destination, or automatic cleanup. It is distinct from a Possible name-shape warning
because its breadcrumb contains no object identity or mutation receipt.

The card uses the ordinary indeterminate warning tone without inventing an Issues payload.
`warningCount`, `errorCount`, and issue rows remain zero unless a real diagnostic exists, so Failed
items, Show log, and Export issues are absent on the breadcrumb-only notice. Open destination targets
the recorded destination folder; Reveal item is absent because the breadcrumb deliberately stores no
single destination leaf mapping.

`Dismiss` acknowledges only the card's regular non-reparse JSON breadcrumb directly beneath the
application breadcrumb directory. The host reopens the exact child no-follow beneath a still-identical
regular directory root and retires that file by handle; path text alone is not deletion authority.
It does not touch either provider namespace. Malformed, unknown-
schema, reparse, or out-of-directory records produce no actionable card and are never deleted by this
surface. If terminal retirement previously failed, the same conservative notice may reappear until
the user dismisses it; this is preferable to claiming a known outcome.

### Possible-artifact touch warning

The shared classifier projects only Ordinary or Possible name-shape state. Possible objects remain
visible and badged in FolderView, Find, Search, and Compare. The popup is not a provider-wide scanner,
does not list a recovery inventory, and exposes no Resume, Roll back, cleanup, or automatic-recovery
action. A stale badge, filename, task card, or search-index hint has no ownership authority.

When a user action or another task attempts to Copy/export, externally Open/Edit, Move, Rename,
Delete/Recycle, overwrite, write, or otherwise use a Possible item, reveal the popup/conflict surface
immediately with a prominent name-shape warning. Copy states that bytes may be incomplete;
destructive actions also state that the data may be altered or removed. Cancel is the safe default.
Continue is a one-request grant for the exact displayed identities, has no Apply-to-all/persistence,
and is revalidated immediately before the touch. It never upgrades the item to app-owned or grants
recovery/cleanup authority.

The shared host prompt uses the artifact-touch presentation: `Continue` is the affirmative label,
`Cancel` is the initial/default and Escape action, and there is no Apply-to-all control. If any
candidate cannot supply a current exact identity, the surface explains that the request is blocked
and exposes only acknowledgment; it never turns an unavailable identity into a Continue receipt.
Accepted typed File Operations requests are re-queried on their worker after queue/interlock waiting
and before I/O. FolderView/Find default Shell Open/Open With, configured external viewer/editor
launches, and user-menu programs use the same warning and immediately revalidate the exact referenced
set before process launch; internal viewer/VFS inspection remains prompt-free. Browsing the
current-directory Shell context menu is inspection. After a verb is chosen, the warning appears
before invocation. Opening the Shell Security page also warns first because that page can change
ACLs. Non-recursive Change Attributes and Change Case use this same Cancel-default warning after
their options are accepted and before mutation/worker admission. Change Case must additionally
retain the accepted receipt on its worker and revalidate immediately before each rename batch; that
worker-side step is not implied by its admission prompt. Their recursive forms must pause their
existing discovery/apply worker before the first guarded mutation and marshal the exact-set warning
to the UI thread. The popup does not invent a global artifact inventory.

Displayed speed and ETA values are display estimates and MUST be safe for extreme callback-silence
decay. Before converting floating-point rates or ETA seconds to integer display values, the popup
MUST clamp non-finite/negative values to zero and saturate values above `uint64_t::max`. ETA MUST
not be computed from decayed byte rates below 1 B/s; those rates are treated as zero so the UI
returns to estimating instead of showing a phantom multi-century ETA.

## Completed Card Actions

An expanded finished file-operation card MUST show its exact nonempty recorded result summary
as a separate wrapped body paragraph, including canceled and indeterminate outcomes. A clipped
one-line heading is not a substitute. The operation heading stays concise; the terminal status
remains visible, and the full summary has its own accessible text region. The summary precedes
diagnostics and paths, with height reserved for the progress indicator and actions below it.
Outer scrolling exposes content taller than the work area. Current text layouts are cached by
task, text, available width and font identity, and released when their task is collapsed,
hidden by the completed group or footer-only mode, or removed;
unchanged paints reuse the layout. I26 records the native rendering and interaction qualification.

Completed cards keep `Dismiss` as the first action, followed by a direct `Issues` action whenever
that task has an actual retained projectable Issues row, then `More...` for available recovery
and diagnostic commands. The same application-owned qualification predicate drives the pane
and this action: raw typed observations must pass task/prompt identity checks, and invalid typed
observations do not become ordinary problems merely because their severity is Error. Scan both
retained diagnostic reservoirs; warning/error counters alone do not establish a row.
Invocation revalidates current rows, creates or reuses the pane, and selects/reveals the originating
task in its current sort order. It does not dismiss the completed card or close an already-visible
pane. The former `Failed items` menu item is replaced by the direct action.

All terminal action captions use the hosted Body font and measured wrapping. Arrange complete
actions into rows with the pinned shared measured-action helper, reserve their height before
placing the progress indicator, and retain only current expanded-card measurements. The More
button measures its actual ellipsis plus dropdown chrome and exposes the full localized name.
Current correctness and interaction qualification is recorded in I26, including its explicit limits.
The completed-card overflow action set includes `Open destination`, `Reveal item`, `Show log`,
and `Export issues`, as well as applicable retained-source recovery commands.
`Export issues` writes the task report and opens it with its associated application. A failed
save or open shows a localized, dismissible error on the File Operations popup, without
dismissing the task or claiming the report was saved. Escaping the menu performs no export.
Explicit alert clear and popup destruction release that window-scoped overlay and its host
entry before the popup HWND can be reused. The governed test route uses its owned output
directory and suppresses external application launch; it still invokes the real menu and writer.
`Open destination` and `Reveal item` are available for completed copy/move tasks with resolved
destination data; `Open destination` navigates the destination pane to the completed destination
folder, while `Reveal item` navigates to the parent folder and selects the completed item when a
single revealable destination item is known. The direct `Issues` action opens the real File
Operations Issues pane so the user can inspect the retained problem, decision and result facts.

The task captures destination plugin ID, plugin short ID, and instance context when the operation is
accepted and the supplied destination filesystem matches that pane. Explicit provider filesystem
objects that do not belong to the pane MUST NOT inherit its identity. Completed navigation resolves
the qualified identity even if the pane later changes provider. Missing, stale, or mismatched
identity MUST fail recoverably and restore the pane's prior provider/context/path instead of
executing against the current provider. Provider changes navigate directly to the qualified target;
the UI MUST NOT visit or enumerate an intermediate provider root.

When a conflict needs metadata, the task card appears immediately with one complete **Reading
decision details...** state indicator, as specified under Conflict Layout. Its title and detail do
not repeat that state. The loading state contains no decision buttons, Apply-to-all
control, default/Escape action, Skip All eligibility, button-publishability grant, or accepted
decision. After metadata resolves, the loading state
is replaced in place by one stable, complete action set. For built-in local-to-local **Exists**
conflicts, a file-on-directory collision therefore never publishes **Overwrite**, while a replaceable
file collision includes **Overwrite** in the first actionable layout. Cross-provider prompts retain
their provider-defined action set without depending on local Win32 metadata.

## Speed-Limit Selector

The Copy/Move speed selector MUST display the complete current localized value in active,
queued and discovery states. Its preferred width comes from the actual hosted Body font and
the Selector's leading and trailing chrome lanes, with visual padding; a fixed 140-DIP cap
must not clip the caption. Value, locale and font changes invalidate the measurement. Reuse
measurements on unchanged redraws and bound live entries by the current task snapshot, with
no cache keyed by historical task identity. The selector remains an auxiliary control and
does not expand merely to consume spare row width. Complete action wrapping at smaller
available widths remains part of the adaptive layout contract.

## Custom Speed-Limit Grammar

The prompt is initially created on its owner's monitor, using that monitor's DPI before centering;
default-location creation must not apply an unrelated monitor scale first. Label and help/error
height use the actual hosted Body/Small fonts with wrapping. Size changes and validation appearance
or clearing reflow the form, preserving gaps between label, input, help/error and actions. The
window may grow to fit but does not shrink on correction. Growth is clamped to the current monitor
work area; minimized/zero-size notifications do not trigger growth, and the synchronous resize has
a reentrancy guard. When the complete form cannot fit, its label, edit and help/error occupy a
measured scrolling body above fixed OK/Cancel actions. Focus reveals the edit; overflowing help
can receive keyboard/UIA focus and scroll with arrows, Page Up/Down and Home/End. Full text is
retained. The existing modal result, parser, default Enter/Escape and shutdown semantics remain unchanged.

The existing settings/theme notification to the owning File Operations popup refreshes an open
speed prompt's caption, labels, accessible edit name, buttons and active validation resource after
a locale change. It retains the same controls, edit text, selection and focus; no polling or prompt
recreation is needed. Layout remeasures the translated strings and keeps the focused edit visible.
Native caption refresh must bypass the hosted edit's `WM_SETTEXT` compatibility route. Tests
read native chrome independently of `WM_GETTEXT` on that focused edit and retain a distinct
invalid input through English/French reload, including its selection and validation message.

The original French Debug constrained-client witness remains historical. The production-backed
132-DIP body/fixed-action case exercises validation, scrolling, retained edit identity, help focus
and live English/French reload; its capacity cap does not claim a physical short-work-area test.
The V24 Debug gallery moved the same invalid French dialog between physical 144- and 96-DPI monitors
and back, checking unchanged edit/validation/selection/focus and monitor-work-area fit. The later V32
protected Commands case exercised actual Tab/Shift+Tab, invalid Escape without applying a speed, and
valid Enter applying a changed speed. Current combined Full and the separate physical short-work-area,
native 192-DPI and external AT limitations remain recorded in I26.

The custom speed-limit prompt uses the shared binary-throughput edit grammar. Empty input means
unlimited (`0`). A bare number means KiB/s. `B`, `K`/`KB`/`KiB`, `M`/`MB`/`MiB`,
`G`/`GB`/`GiB`, `T`/`TB`/`TiB`, and `P`/`PB`/`PiB` are accepted case-insensitively, with an
optional case-insensitive `/s` suffix. Both `.` and `,` are accepted as locale-independent decimal
separators; results round to the nearest byte and saturate at `uint64_t` maximum. Signed values,
multiple decimal separators, and unknown units are invalid.

The prompt's modal message drain is part of File Operations teardown. It checks the shared host
prompt-shutdown fence before waiting and immediately after every dispatched message. Shutdown clears
the pending edit result and unwinds the prompt; it never continues pumping arbitrary thread messages
after owner teardown begins. The containing File Operations prompt-dispatch scope keeps engine state
alive until that nested modal frame returns. The prompt never retains a task pointer across the pump:
it captures the task ID, re-finds the task after a successful answer, and silently discards the edit
when shutdown or task removal won the race.

The popup preserves its existing boundary policy and trims only the six ASCII whitespace characters
space, tab, carriage return, line feed, form feed, and vertical tab. Text emitted by the paired
throughput formatter (`GiB/s`, `MiB/s`, `KiB/s`, or `B/s`) MUST round-trip through the parser.

## Graph

The bandwidth graph samples smoothed display throughput at popup timer cadence. It MUST not visualize
callback silence as a trough when bytes later arrive in a burst.

The popup graph uses the shared `DxUi::ThroughputGraph` primitive. It shows:

- recent throughput history,
- per-stream colored bands when concurrent transfer streams are present,
- the current effective smoothed bandwidth as a labeled marker,
- the smoothed remaining time right-aligned beside the left-aligned bandwidth above the plot, or
  below it when the measured localized labels cannot share a row.

Throughput is expanded by default and has a keyboard-accessible `Débit` disclosure. Persist its
last explicit expanded/collapsed choice as `fileOperations.popupThroughputExpanded` (default `true`),
through the normal settings save pipeline alongside window placement. This is a remembered view
preference, never an operation option. Each new card and a recreated popup start with that preference;
an explicit disclosure changes that card and the saved default, without moving other live cards.
Retain each live card's choice across hide/show, phase changes and DPI changes; discard transient
task IDs on destruction. Last explicit choice wins when several cards differ. Footer-only mode and
compact card density temporarily suppress graphs without changing this preference.

External settings reload updates the remembered default for new cards through the normal
watcher/merge/apply route. It must not reset any live card's choice or enqueue a save merely
to display the reloaded preference. A full application process restart loads the last saved
choice before creating a card and preserves both `FileOperationsPopup` and
`FileOperationsPopupExpanded` placement records, including position, dimensions, state and DPI.
The [focused Debug reload/restart receipt](../TestRuns/4cb089111a23/Commands/2026-09-21-throughput-reload-restart/README.md)
covers the real watcher and three sequential owned application processes. Final integrated
Release, native mixed-DPI/AT and resource acceptance remain separate gates.

A collapsed graph removes its plot and graph-specific UIA child, not useful information: current
rate and qualified ETA remain on one measured summary row. Expanded graphs place those same values
in a measured label area above the plot without duplicate marker labels. Cache the two DirectWrite
layouts by text, font and available width, with explicit near paragraph alignment and wrapping.
Stack labels when their measured widths plus spacing exceed the row; reserve their complete height
before the positive plot bounds. Keep the numeric current-rate marker in the shared graph. The
consumer's prepared client layer paints these labels; the shared graph remains the sole plot painter.
Retain at most two live layouts per visible expanded graph and release retired/collapsed slots.
Each label has its complete tooltip/UIA name and help on its actual rectangle, with stable
`FileOperations.Task.<id>.Throughput.Rate` and `.Eta` automation IDs. The visible summary or expanded
graph's accessible help retains both values. Unknown values remain explicit; no ETA is invented.
A conflict or queued card still has no transfer graph regardless of preference.
Disclosure has UIA ExpandCollapse state and a visible chevron; collapsing returns focus to its header
if a child owned focus. It preserves the task's scroll anchor, pause/cancel controls and window
placement. Do not resize the saved outer window merely to toggle a graph.
The first expanded-popup layout after restoring saved placement must preserve that
rectangle, including when throughput was last collapsed. Subsequent unrelated content
changes may follow the normal growth policy. Footer-only restoration remains separate.
A failed asynchronous settings save preserves the live disclosure and leaves the prior
disk state intact; a later explicit change can save successfully. Disclosure saves must
preserve both ordinary and expanded placement keys, including their DPI and window state.


Measure expanded and collapsed card heights from visible content. The former 244-DIP Copy/Move
base and 280-DIP generic base are historical metrics, not fixed layout budgets.
Expanded Copy/Move cards awaiting admission use only their header, visible counters, source and
destination rows, and action row, separated by the ordinary content/action gap. They reserve no
hidden graph area. Optional known-byte totals, concurrency and additional active/recent source rows
contribute their actual row heights. This applies to unstarted queue/interlock waits; a transfer
already admitted and paused by the user or Queue mode retains its active layout. Queue mode's
`queuePaused` state is not admission waiting. Expanded cards reserve their measured body height on
the first paint whenever content height changes or a card expands. This includes admission phases,
running stream-row growth/contraction and informational tasks; body text, graphs and live controls
must not overlap while interpolating from an obsolete smaller card. Collapse animation remains
available because the expanded body is already hidden. Hidden plot controls
do not prepare, paint, animate or request ticks. Existing bounded transfer sampling may continue
while the visible task needs current rate; collapsing adds no timer or worker. Reopening retains
the existing bounded history, without synthesizing zero samples for the hidden interval.

The configured speed limit belongs in the shared current-value selector/flyout, not as the graph
marker. Its visible value is `Limit: Unlimited` or the localized compact configured rate; the whole
selector opens the choices and it has no separate primary action.

In Rainbow theme, graph history keeps per-sample colors stable as samples scroll. It MUST NOT blink or
cycle historic samples by time.

Each active file row's mini progress bar MUST use the exact assigned color of that transfer stream's
band in the graph. The association uses the stream cookie and progress-stream ID, with the source path
as an identity guard; a path-derived hue is only a fallback before the graph has assigned a live stream
hue. Row bars and graph bands use the shared `DxUi::ThroughputGraphColorFromHue` conversion so matching
hues cannot render with different saturation or brightness.

The shared graph supports accent history, stable per-sample rainbow hue weights, per-stream bands,
the configured-limit reference, current-value overlay, and latest-value easing. High contrast uses
system-safe colors and reduced motion disables latest-value easing without suppressing the data.
History is bounded to the most recent 180 samples. Per-stream colors use at most 16 stable reusable
slots (`0..15`), hue-weight deduplication is by slot, and aggregate-only samples MUST NOT allocate a
slot or expand the palette. The shared semantic gate disables per-stream bands in high contrast;
Rainbow may show one admitted stream; the normal theme requires at least two concurrent admitted
slots. The hosted graph consumes this same gate and slot assignment.
Continuing streams MUST occupy their previously assigned slots before leftover
slots are given to newly appearing streams, so unique live-stream colors hold
when in-flight callback order permutes (same cookies, different array order).

The area and every per-stream band are translucent (18% alpha in light themes, 22% in dark themes;
High Contrast uses its explicit system-safe treatment). Hue selection MUST preserve the caller's fill
alpha instead of replacing it with an opaque hue. Discovery activity is rendered outside the graph;
status motion may draw lightweight strokes/dots over an otherwise empty plot but MUST NOT fill the
graph surface or obscure live history.

Band construction is bounded by `O(samples * activeSlots)` with a maximum of 180 by 16 logical
quads. The accepted painter rasterizes into one fixed 180x64 premultiplied-BGRA buffer, uploads one
`ID2D1Bitmap`, clips it with one covered-area geometry/layer, and issues one bitmap draw. It MUST NOT
reintroduce one geometry or draw submission per logical quad. The instrumentation contract reports
sample count, active slot count, logical quad count, rendered geometry count, and painter duration.
Per-stream bands form a complete stacked area from the graph baseline to the interpolated throughput
envelope. Adjacent band geometries MUST share exact boundaries and the area MUST retain a covered base
fill, so descending segments expose neither baseline gaps nor black seams between streams. The stack
is clipped to the envelope, so its upper edge follows and remains below the history stroke instead of
exposing square sample-column tops.

## Motion

The popup resolves reduced-motion through the app theme's DxUi palette. When reduced motion is
enabled:

- Automatic popup resize snaps to the target rectangle instead of debouncing/easing. Footer-only
  collapse still snaps to the footer minimum, and expand still restores the captured rectangle.
- Task, completed-group, and footer disclosure chevrons snap directly between their contextual
  collapsed direction and down.
- Dedicated discovery activity and graph status animation are static; neither suppresses throughput data.
- The graph latest-point easing is disabled; throughput history, rainbow/per-stream bands, and the
  current effective-bandwidth marker remain visible as static state.
- Task-card height, completed-group visibility, and hosted progress-value transitions snap to their
  target values.
- Every indeterminate global/task/file/conflict bar renders a stable centered segment instead of a
  moving marquee.

## Conflict Layout

**Implemented R1 subset, 2026-09-20:** identical qualified leaves in ordinary collision families now
render as one bold, wrapped `.Conflict.Name` heading, followed by stacked parent folders/metadata.
Expanded conflict headers no longer duplicate the waiting/loading text; their fixed-width status
chip is removed. Different leaves and unqualified paths retain explicit context. Actual UIA count,
order and metadata pixels pass the focused French fixture (3/3); static native 144/96-DPI captures
show complete long headings/parents. [Evidence and remaining gates](../Plans/WIP/FileOperationsUiReview_2026-09-16/implementation/2026-09-20-common-name/README.md)
records the broader 34/36 run's PNG clipboard snapshot failure. That receipt qualified only its
September 20 slice. Later source and focused fixtures add measured narrow action fit, the live
blocked-metadata single subject/loading UIA hierarchy, exact path copy and inspection controls.
V34 passes the sixteen input/pane/role inspection-return routes and the two-pending-task journey;
I26 records current integrated configuration/resource qualification and external AT limits.

**Revised intended behavior, 2026-09-20:** the user's interaction review supersedes the earlier
requirement to repeat a common filename in the question and both comparison rows. This section
states the target; the [current audit](../Plans/WIP/FileOperationsUiReview_2026-09-16/interaction-review-2026-09-20/README.md)
records remaining implementation and test gaps.

For an ordinary name collision, display one complete warning indicator, for example `Conflit de nom`,
and one prominent, unquoted, full-width filename heading. The task header identifies the operation
and useful progress/count context; it MUST NOT repeat the waiting sentence. The explanation describes
the problem without interpolating the same name again: `Un fichier du même nom existe dans la
destination.` Source/Incoming then Destination/Existing remain vertically stacked at every width.
Each role shows its **parent folder only**, followed by that item's size/date/type metadata and
inspection/copy affordances. Do not repeat the common leaf in those folder rows. The filename is
decision evidence, not a fragment buried in a sentence or a full path.

Qualified transfer/delete prompts already publish display facts using the selected item's admitted
source/destination path profiles. Reuse those facts; nested collisions retain the selected root's
namespace. No provider I/O or separator guessing occurs during rendering. Display facts grant no
mutation authority. A single common heading is valid only when the qualified displayed leaf values
match exactly. Case, Unicode normalization or renamed-source differences MUST remain visible in the
relevant role; never conceal them through case-folded string deduplication. A one-item prompt uses
one item heading, without inventing a second comparison. Missing/unstable profiles, missing identity,
namespace roots and unqualified rename schedules retain labelled exact-path fallback rather than
an invented filename/folder split. Distinguish this fallback in fixtures from a qualified local item.

The common name has one semantic heading identity, proposed
`FileOperations.Task.<id>.Conflict.Name`; role folder regions retain `.From.Parent` / `.To.Parent`
(or `.Deleting.Parent`) identities. Retire duplicate per-role `.Name` providers when the common
heading applies. UIA reading order follows the visual order; hidden duplicate labels are not an
accessibility workaround. Full original paths remain available in explicitly labelled detail and
`Copier le chemin complet` actions. Copying a folder versus an item's full path has distinct wording.
Exact clipboard values, tooltips, exports and explicitly opened detail need not omit the leaf.

The [earlier provider qualification slice](../Plans/WIP/FileOperationsUiReview_2026-09-16/implementation/2026-09-20-conflict-paths/README.md)
passed 33/33 checks for separate name/parent rows. Those tests protect path interpretation; they do
not establish the new one-name hierarchy. Update semantic/count/pixel assertions together with the
presentation instead of retaining duplicate `.Name` controls to satisfy superseded expectations.

An active conflict replaces ordinary transfer detail, including its path providers, mini-progress
and concurrency text. This applies while metadata is loading and while awaiting a decision. The
decision body follows the task header; card height reserves the measured prompt plus the actual
published action/scope rows and spacing, without an ordinary transfer/graph body underneath it.
The popup retains the exact conflict context and all engine-published decision semantics. Native
checks MUST inspect actual displayed/accessible rows; a policy-only progress flag cannot prove
the absence of stale painted transfer detail. [French implementation captures](../Plans/WIP/FileOperationsUiReview_2026-09-16/implementation/2026-09-20-conflict-decision/README.md)
cover this earlier step; September 21 adds adaptive actions and short-body scrolling.

Each available comparison metadata value uses a full-width wrapped row beneath its name/location or exact-path fallback,
with normal readable text foreground. Measurement includes the row and gap in the card height;
metadata MUST NOT consume the heading/path width or be abbreviated to a narrow side column.
The path region exposes its label and exact path; the separate metadata region exposes its complete
value using `FileOperations.Task.<id>.Conflict.From.Metadata` or `.To.Metadata` (and
`.Deleting.Metadata` for the deleting context). Incoming remains above Existing. Missing metadata
does not create an empty value row or imply a zero-byte fact.

This bounded presentation passes the French 480/640/760-DIP native-144-DPI Debug fixture and the
nine-case popup regression set, 27/27. This is historical metadata evidence. September 21 adds
the single-name hierarchy, adaptive actions and short-height scrolling; general path detail and
full qualification remain required. [Before/after captures](../Plans/WIP/FileOperationsUiReview_2026-09-16/implementation/2026-09-20-conflict-metadata/README.md)
explicitly retain the remaining narrow-action clipping and duplicated progress content.

Conflict prompts are inline on the affected card. Source and destination paths MUST be stacked in
full-width rows rather than side-by-side columns so long names keep useful width. This applies at
every width: Incoming is always above Existing, including wide layouts. File names and parent
locations retain the full available width and wrap independently, without silently dropping the
root or extension. Complete values remain keyboard-accessible. For an ordinary eligible file-name
collision, the engine publishes four direct actions in this order: `Keep both`, `Replace`, `Skip`,
`Cancel task`; French: `Conserver les deux`, `Remplacer`, `Ignorer`, `Annuler la tâche`.
Omit an action the typed policy cannot authorize; never manufacture replacement eligibility.
The primary group has no three-button cap. `More...` is reserved for additional scoped actions such
as `Skip All`, not these four choices. Measure localized labels and wrap whole controls into rows when
needed, preserving published action order, default and Escape semantics. Critical action labels
MUST NOT be clipped or ellipsized. At a short work area, scroll content while keeping decisions
and safe exit reachable; do not grow beyond that monitor’s work area.

The popup is a presentation-only consumer of the immutable engine conflict policy. It copies and
renders the supplied complete action order, primary/`More...` placement, default action, Escape
action, Apply-to-all and Skip All eligibility, metadata-loading state, and button-publishability
flag. It MUST NOT switch on the conflict bucket to add, remove, reorder, place, or select a default
action. Primary clicks, `More...` selections, `Enter`, and `Escape` are accepted only when they match
the currently published snapshot placement/action. A stale or unpublishable action fails closed.

Every active prompt has one persistent, nonanimated localized state indicator. While facts are
being decorated, use one `Chargement des détails pour la décision…` indicator and expose no
unpublished decision buttons or stale transfer progress. Do not repeat it in the task title and body.
Once actionable, the conflict/risk indicator plus the available decisions communicates the pending
choice. An ordinary name conflict MUST NOT add a second or third `En attente de votre décision`
line. Preserve the actual conflict explanation, object evidence and consequences; deduplication
does not remove a distinct warning. Do not represent waiting through a marquee, pulsing or fake
percentage, and do not repeatedly announce unchanged waiting state to assistive technology.

Status indicators, task action labels, repeat-scope text and disabled reasons use measured localized
content, including all padding and icons. When the header cannot fit, place whole regions on another
line; a badge cannot silently crop its final word. Shortening a French resource is not a substitute
for layout that also fits deliberately longer test strings. Consequential actions never use ellipsis.

Question, facts, From/Deleting, To, and Last note use measured DirectWrite wrapping; their measured
height contributes to the card height. At the supported minimum width and all supported density,
locale, and DPI combinations, these decision-critical regions must remain unclipped and must not
overlap the actions or footer.

Checked File Operations controls, including conflict `Apply to all`, render the checkmark through the
existing DirectWrite icon format (`Segoe Fluent Icons` preferred, Unicode fallback) instead of custom
line geometry. The box fill, border, theme colors, hit target, and state semantics remain unchanged.
The Recycle-failed escalation prompt never renders `Apply to all`; its Permanent delete grant is
one-shot for the exact revalidated item. Cancel is the first keyboard/default action, followed by
Delete permanently and Skip, so Enter or initial focus cannot authorize deletion.

Every other actionable conflict also keeps the engine-published Cancel action directly visible.
Ordinary name conflicts retain Cancel as initial focus, default and Escape action even though it is
visually last. The published placement change belongs in the engine policy, not a popup-only switch.
Read-only and link collisions retain their specific replacement labels and authority checks; apply
the same direct-action order to their eligible counterparts. Other classes keep their own typed
order and defaults, including the safe Queue-after default for same-host overlap. Hosted default
and cancel identities follow that published policy; they are not inferred from button position.
Closing the popup hides it without changing the prompt; Escape invokes Cancel for that prompt.
If Close hid the popup before the prompt became actionable, publication of the completed immutable
action set restores the popup automatically. If Close hid an already-actionable prompt, the decision
remains parked and **View > File Operations** / `Ctrl+Shift+J` restores the exact same surface.

Deferred-consent prompts reuse this inline card surface but remain distinct from ordinary retryable
conflicts. The card shows the risk-specific message and, when known, a localized fact line for item
count and/or bytes; unknown facts are omitted rather than estimated. The published action order is:

| Risk | Primary actions | Final/default action |
|---|---|---|
| Insufficient space / space unknown / sparse inflation | Continue | Cancel |
| Placeholder hydration | Download and continue | Cancel |
| EFS plaintext | Continue as plaintext / Keep source | Cancel |
| Metadata loss on Move | Move anyway / Keep source | Cancel |
| Recycle failure | Cancel / Delete permanently / Skip | Cancel |

Eligible non-Recycle risks may expose `Apply to all` only for the exact task/risk/destination-root
scope. Recycle never exposes it. The prompt snapshot includes the deferred-consent marker, known
item/byte facts, and optional source/destination identity so tests and assistive presentation can
distinguish a consent gate from an ordinary conflict without reading path text. An action not present
in that immutable snapshot is rejected as Cancel. Closing the popup does not grant consent, persist a
choice, or make the prompt session-sticky.

For eligible non-Recycle Apply-to-all, one visible acceptance creates one receipt for the complete
task/risk/destination-root scope. Later matching gates reuse that scoped grant; the UI and receipt log
do not claim a separate object-specific acceptance. Recycle remains exact-item only.

When metadata is available from the source/destination `IFileSystemIO`, each stacked comparison
shows its role, full parent folder and size/modified-time metadata below the single common filename.
Only a meaningful differing leaf or unqualified exact-path fallback adds item-name text to a role.
Names and locations wrap independently across the full width; metadata wraps into further rows when
necessary and never consumes the folder's width. Copy preserves the exact underlying path.
Modified times MUST convert the provider's UTC FILETIME to
local time and use the user's short-date/time formats. Provider metadata reads call
`GetFileBasicInformation` first and call `GetAttributes` only as a fallback when basic information
fails. Missing metadata is omitted rather than guessed. A Copy/Move collision exposes `Keep Both`
when the operation can retry that exact colliding item with a unique sibling destination. The
action preserves the existing destination and retries the incoming item as `name (2).ext`,
`name (3).ext`, and so on (or `folder (2)` for directories), probing existence through the
destination provider. Nested Local recursive Copy collisions are renamed in their own parent; they
never cause a second copy of the selected top-level root. Keep Both is eligible for Apply to all
only when the exact typed conflict scope permits it, and is available to same-filesystem and
cross-filesystem transfers.

The prompt action set is driven by the typed conflict class. Regular file Exists offers Overwrite;
read-only Exists offers Replace read-only; type mismatch never offers Overwrite; an exact final
destination link offers Replace link and never follows or replaces its target. Apply to all is
rendered only for an eligible exact scope. Destination-link scope includes the known link kind
(file symlink, directory symlink, or junction); an unknown kind is one-shot. `Skip All` is a
separate More-menu action that records the scoped Skip grant. Ordinary Skip never checks or stores
Apply to all. Recycle escalation and semantic target-conflict retention never expose Apply to all.
Overwrite, Replace read-only, and Replace link are omitted when the provider cannot return and
consume an exact no-follow destination receipt; the UI never presents a destructive button that is
known to end in `ERROR_NOT_SUPPORTED`. Target conflict exposes no mutation action. Replacing a
selected-root link does not suppress a later child collision prompt.

Prompt identity and actions are published under the conflict-arbiter lock before decoration.
Metadata calls and diagnostic logging run outside that lock, and late results merge only when the
same owner/bucket/status/paths are still active. Decoration MUST NOT create an `IFileReader` or read
content. The built-in local provider may use `GetFileAttributesExW`; provider paths use metadata-only
`IFileSystemIO` calls and may leave size unknown.

The Failed Items/Issues pane has one close contract regardless of whether close originates from its
window chrome or the popup toggle: save view state and placement, hide (do not destroy) the pane, then
restore active-pane FolderView focus when focus belonged to the hidden pane.

## Debug Snapshot Contract

`PopupLayoutDebugSnapshot` is the non-pixel acceptance surface. New UI controls or durable visual
contracts MUST extend it when feasible. Current closeout fields cover:

- footer control count and overlap detection,
- selected-task button overlap detection,
- single Queue/Parallel selector visibility, current mode, and live hit target,
- Options overflow visibility and live hit target,
- hidden legacy segmented-mode, auto-dismiss, and density footer controls,
- footer bulk Pause all / Resume all visibility and target action,
- compact-density persisted state,
- footer-only details toggle placement,
- high-contrast state and color-blind-safe status signal coverage,
- reduced-motion state, active layout-motion state, and animation enablement for auto-resize,
  disclosure controls, and graph status overlays; normal-motion geometry acceptance waits for a
  synchronous settled snapshot before applying minimum-width overlap gates,
- aggregate footer progress totals,
- aggregate ETA/throughput,
- taskbar progress state/value, timer-update count, taskbar-button readiness, interface availability,
  initialization attempts, and retry-pending delay,
- status stripe/chip visibility, tone, and resolved theme color,
- queued Start now visibility,
- queued Move Up/Move Down edge visibility and queue-order keys,
- confirmation Links/Verify/clipboard-consumption control state and immutable accepted snapshot,
- discovery mode, traversal-closed state, Skip-discovery visibility/release generation, and truthful
  provisional/final denominator state,
- Inline-F2 origin, reveal reason/deadline, ever-revealed state, and silent-clean-success suppression,
- typed publication/verification/source-disposition/item-completion axes, retained-source badge, and
  clipboard-consumed detail state,
- completed Open destination / Reveal item / Failed Items menu-action visibility,
- task collapsed/compact-row state, completed auto-collapse state, and compact progress visibility,
- completed-group visibility, expanded state, total and per-result badge counts, group toggle/clear
  visibility, and per-task hidden-by-completed-group state,
- duplicate progress-bar absence,
- conflict stacked-path layout,
- conflict source/destination metadata visibility and size/date compare coverage,
- conflict waiting/loading-state visibility, prompt-before-actions order, wrapped prompt/context/
  last-note fit, and absence of conflict discovery/transfer indicators,
- asynchronous popup-setting save generation/thread ownership and bounded flush coverage,
- graph current-bandwidth marker and label, right-aligned ETA label, absence of duplicate inline
  speed/ETA rows, and the operation-specific expanded base height,
- failure-surface state, native child count, and text, plus actual active-row canonical-color
  matches and mismatches,
- same-HWND WindowHost use, hosted action/progress/graph counts, focused automation ID, and accepted
  accessibility-notification count,
- task-card, completed-group, hosted-progress, and shared-graph motion state under normal and reduced
  motion.

Taskbar retry selftests drive the same `UpdateTaskbarProgress` path synchronously after injecting the
failure, capture the pending snapshot before pumping unrelated window traffic, wait the published
retry delay, and drive the retry explicitly. They do not depend on observing a one-second transient
state through a bulk message-queue drain.

The focused runtime guards `cmd_pane_fileops_popup_failure_surface_on_host_attach_failure` and
`cmd_pane_fileops_popup_failure_surface_on_d2d_target_failure` force each failure separately and
prove the failure-surface contract (native text with the live summary, Cancel all and Close, Tab,
Enter, Escape, UIA names and Invoke, high contrast and DPI, refused actions, hide and reopen, and a
hosted popup after close and reopen). `TestThroughputGraphBandsStayBelowHistoryLine` preserves
the band/history pixel contract, and `TestThroughputGraphHueChurnPerformanceScenario` records the
deterministic bounded-work metrics.

Accepted same-machine Release evidence is archived at
`Specs/TestRuns/4cb089111a23/FileOps/2026-08-15_175346_graph_before/` and
`Specs/TestRuns/4cb089111a23/FileOps/2026-08-16_064500_graph_after/`. Across five captures, median
frame time improved from 18,493 us to 16,583 us (10.3%) and mean from 18,768.4 us to 16,593.2 us
(11.6%). The accepted after captures report painter median 81 us, 180 samples, 16 slots, 2,864
logical quads, and one rendered geometry on every measured row.

The translucent-fill restoration candidate is archived separately at
`Specs/TestRuns/7d3a1247382a/FileOps/2026-08-27_165050_graph_transparency_release/`. Its five
Release captures retain the bounded 180-sample, 16-slot, 2,864-quad, one-geometry workload and
report a 111 us median band-painter cost. This is candidate-only evidence because the accepted
before/after archive belongs to a different machine profile; it does not establish a cross-profile
performance comparison.

## Inspect a pending conflict in a file pane

This is approved intended interaction, not the existing completed-task Reveal action. Beside each
qualified role location, expose `Afficher la source dans le volet actif` or `Afficher la destination
dans le volet actif`. Both are inspection actions, with the same keyboard and UIA invocation path.
Their wording and placement MUST distinguish browsing from changing a queued task's destination.
Do not hide destination inspection in a completed-only overflow menu.

Inspection targets MUST derive from the selected admitted plan partition, preserving each role's
provider/instance/profile/root, path comparison rules and exact provider path. Successful display-only
filename splitting does not establish navigation qualification. Missing qualification for one role
must not invent that role or invalidate another independently qualified role. A retained immutable
prompt-generation token must survive metadata decoration and popup hiding; equal path strings never
make an old generation current. Prompt freshness must be checked on the owning UI thread against the
live task/prompt, independently of pane-navigation completion and foreground ownership.

Implemented prerequisite (2026-09-20): snapshots carry qualified transfer/delete inspection contexts
and a UI-thread freshness check; unknown/task-wide/unmapped-rename contexts remain unavailable.
FolderView now also provides a lifetime/visit-scoped, provider-rule-aware exact-selection primitive
with pending, failed, stale, unavailable, missing/filtered and ambiguous outcomes. Its focused native
selection/failed-enumeration/reentry checks pass; it does not verify live remote endpoint identity or
foreground ownership. The owning pane now exposes success/failure enumeration settlement after
queued work, with attempted folder, exact HRESULT and visit; stale results are suppressed and
self-unsubscription is safe. `ResolvePendingConflictInspectionTarget` now retains the requested role's
admitted task adapter and raw pane context, independently of the current pane provider. Qualification
MUST use typed item and parent route facts matching the admitted provider/profile/root/path rules,
canonical instance identity and consistent parent/leaf. Reuse the existing canonical instance and
path-identity comparison helpers. Canonical `host/default` / `host/context/...` values MUST NOT be
passed as raw pane contexts. Failures clear output; stale prompt is `E_ABORT`, changed endpoint is
`ERROR_REVISION_MISMATCH`, unavailable qualification is `ERROR_NOT_SUPPORTED`, and typed provider
query failures retain their HRESULT. Recheck prompt freshness after provider calls; no borrowed task
may survive those calls. Reentrant shutdown invalidates the existing weak UI-lifetime marker and MUST
prevent further owner access. The context is retained by value before clearing output, including
when caller passes that output context back for requalification. This resolver does not navigate, focus, enumerate, mutate or grant consent.
`BeginPendingConflictInspection` now implements non-activating parent navigation and exact selection
in the captured active pane. A single accepted request completes through enumeration settlement;
a concurrent invocation returns busy and explicit cancellation reports stale. Keep external listeners
intact. Before selecting, revalidate the original visit, live pane adapter/identity and pending prompt.
Retain live COM ownership and strings across provider calls and reject reentrant replacement. Remove
the completed request/listener before invoking its callback, which may start another request.
A missing/filtered item is distinct from failed folder enumeration. On enumeration failure, restore
the previous qualified location; report restoration only after successful rollback settlement.
Rollback failure remains explicit. No operation decision or OS focus changes in this component.
`focusUnchanged` compares input, foreground, focus and active-pane witnesses; it is advisory and
MUST be rechecked with current prompt/control ownership immediately before any final focus commit.
Source/destination inspection controls and complete localized result presentation are now implemented.
The buttons bind to the painted immutable prompt and share the hosted keyboard/UIA action path.
One request/result is retained, late callbacks reject destroyed popups, and replacement prompts cannot
inherit prior result text or announcements. Expanded decisions immediately use their measured content
height when metadata/inspection results change; no interpolated shorter card may overlap scope/actions.
French hosted label fit and wrapped-result height/separation are tested. Guarded foreground
inspection and popup hide/return are implemented: a one-shot ticket retains the post-selection visit,
live adapter/context and unchanged input/foreground witness. It is consumed on final commit or refusal,
revalidated across synchronous Windows focus calls and invalidated by newer navigation/cancellation.
The popup retains stable invoking hit/context/scroll, never a borrowed control pointer. The explicit
View command restores foreground/keyboard focus only while the owner's input witness remains current;
automatic presentation stays non-activating. Reopening a resolved/replaced prompt never restores old
consent or control state. Decision/inspection controls own Space/Enter; the task-pause shortcut must
not intercept them. Debug UIA and Space/Enter journeys verify exact item focus, same-popup return,
scope/default/cancel preservation and changed-focus ticket refusal/replay. Native mixed-DPI/AT,
provider refusal/switching and rollback-failure acceptance remain open. Local failed-folder rollback
is covered. This implemented subset does not complete the entire interaction matrix below.

At invocation, resolve the last active file pane through the existing pane-focus service; focus
currently belonging to the popup does not select an arbitrary pane. Capture the task, prompt/item
identity and generation, role, admitted provider/instance/profile/root, exact parent and item. Reuse
the canonical pane navigation transaction, navigating directly to the parent without an intermediate
provider root. After enumeration settles, select, scroll into view and focus the exact conflicting
item in that captured pane. Never open/execute the file or select a neighboring item as a fallback.
No overwrite, skip, cancel, retry, repeat-scope grant or transfer retargeting follows from inspection.

On successful inspection, hide the File Operations popup through its existing hide lifecycle and
focus the pane's file list. Preserve the pending decision, checkbox state, card scroll/disclosure,
and other tasks. The ordinary File Operations command (`View > File Operations`, `Ctrl+Shift+J`)
returns to the same unresolved card and invoking inspection control. It does not change the safe
default or implicitly send Enter. If the prompt has since resolved, show the current truthful state
without resurrecting the old decision. Source inspection follows the same contract.

Unavailable qualification or a disconnected provider yields a complete, accessible reason. A failed
navigation retains/rolls back the pane location using the owning navigation contract. If the folder
opens but the item was deleted, renamed or filtered out, explain that outcome and do not claim it
was selected. Do not silently remove user filters; offer their existing explicit adjustment path
where applicable. A newer pane navigation or prompt generation supersedes an older completion.
Revalidate before committing a late selection/focus result. If the user moved focus elsewhere while
navigation was pending, do not steal it back; expose a recoverable completion state instead.

Required native scenarios cover left/right last-active panes, a task created in the other pane,
local and nested provider-qualified paths, changed provider/profile, unknown qualification, missing
or filtered items, refused navigation, repeat invocation, prompt replacement/completion, multiple
pending tasks, popup close/reopen and return after inspection. Verify exact selected identity, focus,
unchanged decision/scope, and no provider mutation calls. Preserve unrelated pane state and restore
all harness-owned fixture changes. Static menus and a successful helper return are insufficient.

The local inspection journey exercises the full cross-product of source/destination, left/right
last-active pane, and UI Automation/Space/Enter/owned-pointer activation (sixteen combinations). Do not bind one
role or activation key to one pane. For each combination, the harness records exact selection and
pane focus before returning, then the same unresolved popup, invoking control, repeat scope,
disclosure/scroll state and safe default/cancel behavior. Capture both the selected pane and returned
popup through the owned-window screenshot helper, with named role/pane/activation provenance.
External foreground/input changes invalidate uninterrupted handoff acceptance; preserve that failed
trial and verify the product does not apply a late focus handoff. Do not take focus back from the
user merely to manufacture a successful test result.

The September 30 Release journey additionally verifies an existing destination hidden by an active
filter: successful folder enumeration must report the item unavailable without selecting a neighbor,
altering the filter or resolving the conflict. Explicitly removing the filter and settling the new
folder model permits exact selection. A separate pending-navigation teardown case verifies that state
shutdown releases the request's completion owner and makes a saved late callback inert, both before
and after successful enumeration of its old target. These checks pass in the retained V17 Commands
run and the V22 combined sequence. V22 additionally switches the captured pane to the built-in
`fk:/` provider before inspecting the originally admitted local source and destination, and restores
both panes' provider/context/path before releasing fixture-owned plugin state. A two-actual-task
journey keeps one conflict unresolved while an exact Skip resolves the other, then returns to the
original task/prompt/scope. These are provider-switch and task-identity witnesses; they do not
establish live remote-endpoint or external assistive-technology qualification.

## DPI, long text and interaction acceptance

Confirmation instructions and consequences use a readable body foreground independent of the semantic
accent color. Colored icons, borders or tints must not reduce paragraph or disabled-reason legibility.

File-operation dialogs MUST remeasure text and layout after DPI, localization and validation-state
changes. Input, explanatory/error text and actions occupy separate non-overlapping measured regions.
Window geometry respects the active monitor work area. Long French sentences and names are required
fixtures, including actual 96/144 DPI monitor transitions. A future 200% run must use a genuine native
DPI environment; scaled PNGs do not qualify.

Focus, hover, pressed, disabled and checked states must remain distinct. Reflow preserves focus and
uses the same rectangles for paint, input, tooltip and UIA. A long path remains available without
requiring hover. Issues grids use readable bounded rows and accessible complete values; clipped
multiline paragraphs do not satisfy that requirement. The following I26 requirements are implemented
in the slices identified above; current consumer acceptance is recorded at the start of this contract.

Acceptance covers complete user journeys, not just the existence of a screenshot or nonzero control
bounds. Inventory every popup action kind, menu command, adjacent dialog and keyboard/window route.
For each, retain the initial state, trigger, visible result, real state/provider effect, keyboard/UIA
equivalent, cancellation/failure behavior and restoration. Reconcile that inventory when actions are
added. The [interaction matrix](../Plans/WIP/FileOperationsUiReview_2026-09-16/interaction-review-2026-09-20/README.md)
is the current implementation checklist; tests own executable outcomes, not the prose matrix.

Reserve measured global footer and task action heights before arranging scrollable bodies. A card's
controls MUST NOT paint or receive input over the global footer, including when several tasks and a
short work area coexist. Completed-group clear and queued destination controls have the same full
label and hit-target requirements as conflict buttons. Distinguish local task controls from global
controls, and inspect existing/disabled/loading/removed targets after every reflow.

For an oversized conflict, the common filename and conflict state remain visible above the scrolling
folder comparison; the complete scope and decision controls remain visible below it. Wheel input over
the comparison moves that content, not its fixed decision controls. Paint, pointer hit testing and UIA
use the same nested viewport. Keyboard focus reveals the selected comparison control without resolving
the conflict, changing its scope or stealing unrelated foreground focus. Long French parent paths in a
short window must prove actual content movement and stationary subject/action bounds; inert clipping
or zero-height accessible controls cannot satisfy this contract.
Geometry snapshots compare visible comparison regions after intersection with the same viewport
against the fixed decision controls. They retain raw content extents separately; off-screen scroll
content is not visible overlap. Full-value, scroll/reveal and actual clipping checks remain required.
Inspection feedback stays outside that scrolling body, immediately above the scope and decisions.
Qualified differing filenames each use a prominent heading in their role; the question and enclosing
semantic contexts MUST NOT repeat them. Unknown provider paths retain their exact values in labelled
source/destination role rows, without guessing a leaf or parent. Their question uses the localized
conflict-bucket sentence and MUST NOT repeat either complete path. Replacing
a prompt on the same task rebuilds its panel; moving semantic regions between fixed and scrolling
content changes their retained parent too.

The [September 21 Debug implementation](../Plans/WIP/FileOperationsUiReview_2026-09-16/implementation/2026-09-21-bounded-conflict-comparison/README.md)
passes repeated single-card wheel/UIA/keyboard and inspection-return tests. The September 30 V34
Release focused packet passes the strengthened two-task reflow and inspection-return journey,
including narrow/wide geometry, safe fallback and task-specific default/cancel identity. Earlier
V33 failures/skips are retained separately and do not count as passes.
Full current-build gallery, mixed-DPI/AT and resource qualification remain separate gates. Performance
batches must retain their declared physical display device, geometry and DPI; opaque HMONITOR lifetime
is not device identity, and a pre-resize DPI cannot prove capture density. Historical V11 hosted-paint
timing outliers remain in their original evidence; current equal-feature paired measurements must
establish their disposition. Functional and pixel passes do not establish performance acceptance.


The same state is not repeated in badge, title and body merely because each accepts a status string.
Use one phase indicator and put different useful information in the remaining regions. A paused
graph may retain history, but an old sample must be labelled as the last measured rate rather than
an active transfer rate. Aggregate retained/unknown source results state their distinct item scopes.
An empty task list says that no operation is active; it must not look like failed rendering.

## Conflict, decision and result meaning

The active conflict card presents its current problem once, with the existing warning/error
header glyph. Do not add a second copy of that icon or waiting state. After acceptance, the
retained Issues detail presents original problem, accepted decision and observed result in
separate labelled regions. Text and distinct icons carry meaning in every theme; color reinforces
it and is never the only distinction. A missing or ambiguous fact uses a neutral question mark.
Decorative icons use a measured gutter inside the scrolling detail viewport; native label text,
UIA names and copied detail retain the complete localized values without duplicated glyph text.

| Fact | French example | Visual meaning |
|---|---|---|
| Problem / conflict | `Conflit : un fichier du même nom existe déjà.` | Warning triangle and warning tone; an actual failure uses error icon/tone |
| No accepted decision yet | The conflict/risk indicator and available choices; `Décision non prise` in Issues detail if needed | One pending-state presentation, no duplicate waiting banner and no success checkmark |
| Accepted decision | `Décision : Remplacer` | Action arrow and neutral/accent tone; include scope and user/policy origin |
| Execution after acceptance | `Résultat : en cours` | Neutral activity/state text, not a success color |
| Confirmed result | `Résultat : fichier remplacé` | Success check only when typed completion and operation-specific mutation evidence confirm it |
| Partial / failed / unknown result | `Source conservée` / `Échec du remplacement` / `Résultat inconnu` | Warning / error / neutral-question icon and explicit words |

A Copy, Move or Rename check requires `Completed` and `Published`; Move and Rename additionally
require confirmed source removal. Delete has no destination publication axis and instead requires `Completed`
and confirmed source removal. Known failed/unavailable/canceled verification prevents a success
check. Missing mutation evidence remains unknown even when the HRESULT is successful; known
retained source for Move/Delete is partial, not success.

Replacing the file is not yet a result when the user clicks Remplacer. While waiting, show the
consequence of each action (preserve both with a new name, replace the destination, skip this item,
or cancel this task); this explanation is available without hover. For noneligible replacements,
explain the typed reason. A decision accepted for a scope is labelled with that exact scope; a
later automatically applied decision is not labelled as another explicit user acceptance.
Use palette semantic colors; high contrast preserves system foreground/background pairs and icons.

## Issues presentation

The default column order is affected file, problem/conflict, operation, decision, result. Technical
columns (timestamp, task ID, HRESULT, storage and concurrency) are opt-in. At narrow widths, operation
moves to a labelled secondary line/detail rather than pushing the problem or decision offscreen.
Bound summary row height and preserve stable row identity, sorting and selection. A summary may
abbreviate a path or long problem only when selection exposes the complete value; critical decision
and result labels wrap and remain distinguishable. No multiline paragraph is painted into a
single-line row rectangle.

Selecting a row exposes complete wrapped problem, operation, accepted decision and scope, result,
Incoming/Source above Existing/Destination, and eligible recovery actions below the grid. The detail
body scrolls in a short window; recovery/copy controls stay reachable. `Détails techniques` starts
collapsed, exposes the existing diagnostic fields, and retains its state only for that pane session.
No selection shows a concise instruction; an empty list has a localized empty state. Refresh/sort
retains selection by stable identity; removal clears it without selecting a destructive action.
Retain existing copy, export, navigation and hide/restore lifecycle contracts.

Decisions and outcomes require typed producer data with task, item/prompt identity and generation;
do not parse translated messages or join records by path alone. Extend the existing bounded diagnostic
model for accepted action, exact scope, explicit/cached origin and correlated result as necessary.
Unknown legacy data reads `Décision non enregistrée` / `Résultat inconnu`, never an invented success.
Retention follows existing diagnostics limits; this is not a new persistent operation-history feature.
Pending decisions are answered on the authoritative task card; Issues must not duplicate consent.

### Accepted decision observations (I26 implementation)

The worker records an offered action when it consumes the active actionable prompt, with a task-local
prompt generation, optional selected-root index, exact prompt paths, action, conflict scope and origin.
Metadata-loading, pending, invalid ingress and cancellation without an accepted choice produce no
accepted record. A cached scope application records its own prompt generation and the originating
user-choice generation; it is not presented as fresh user consent.

These observations remain within the existing bounded diagnostic and completed-task retention limits,
including when optional Info logging is disabled. The diagnostic HRESULT retains the original conflict
status; it is not the result of the accepted action. These records do not increment warning/error counts or
replace the last problem message. JSONL adds an `acceptedDecision` schema-v1 object; task-issue export
adds the same object as an optional trailing field. Missing or evicted records remain unknown.
Neither a decision record nor its selected-root index authorizes mutation or establishes a descendant
result correlation.

Inline Rename carries the exact accepted task/prompt generation through its executor. An exact
Batch Rename scheduler callback also carries an unambiguous accepted reference when that callback
consumes a conflict choice. The callback captures its conditional `RenameIfUnchanged` receipt
and accepted reference before a coarse engine result is folded across rows; preview/Run alone does
not create an accepted conflict decision. Per-item Recycle escalation carries its exact
**Delete permanently** choice through the retained bound object's single
`DeleteIfUnchanged` result. The earlier Recycle failure remains the original problem, not the
result of the accepted deletion. Bulk Recycle has no equivalent per-item carrier.

Only after first-truth terminal storage succeeds does a carrier publish a separate
`conflictResult`. The record preserves publication, verification, source disposition, completion,
owned-stage disposition and HRESULT independently; JSONL and the trailing task-issue TSV field
retain schema-v1 numeric codes. A malformed, unknown or contradictory conditional rename receipt
projects `Unknown` publication and source disposition, `Indeterminate` completion and
`ERROR_IO_INCOMPLETE`. For exact Recycle escalation, destination publication is
`NotAttempted`, content verification is `NotRequested`, and a malformed, unknown or
contradictory bound-delete receipt projects `Unknown` source disposition,
`Indeterminate` completion and `ERROR_IO_INCOMPLETE`. The UI must not show a confirmed
removal merely because the real file disappeared or the provider returned a successful HRESULT;
neither case retries the destructive mutation.

Duplicate terminal stores, invalid source indexes, foreign task references and zero generations
cannot publish a new correlated observation. Ordinary Info logging may be disabled without losing
this bounded record or incrementing warning/error counts. The observation extends no provider ABI
and grants no mutation authority.

Issues joins these results only by the explicit owner-local task/prompt reference. Original problem,
accepted decision and result can arrive in any order. Identical duplicates do not rebuild the grid;
contradictory results stay unknown while retained. A result alone does not invent a missing decision
or original problem, including Error-severity results. Raw typed fact presence prevents invalid results
or decisions from falling through as legacy problems; promptless ordinary warnings remain supported.
Until an original diagnostic arrives, the Problem field is unknown rather than copied from result prose.
The result column/detail translate the typed completion, not HRESULT or the
chosen action; complete copied technical detail preserves every independent result axis. Completed
does not imply content verification. Copy, Move, bulk Recycle and other executors without an exact
carrier remain unknown; paths, selected-root indexes and overall task completion are never
association fallbacks.

The earlier Inline Rename association was qualified in focused x64 Debug tests. The additional
Batch Rename and exact Recycle carriers pass matched red-to-green x64 Release fixtures in
[the September 26 evidence](../TestRuns/4cb089111a23/Validation/2026-09-26_exact-bound-results/README.md),
including malformed receipt rejection. The [additional Recycle Skip round](../TestRuns/4cb089111a23/Validation/2026-09-27_recycle-skip-gallery/README.md)
also passes: the real file remains intact, the result is separately `Skipped`, and task/popup/export
retain `S_FALSE` completed-with-notes truth rather than a false failure or removal.
Both carriers also pass the [broad x64 Debug/Release FileOps runs](../TestRuns/4cb089111a23/Validation/2026-09-27_default-family-dispatch/README.md).
The default-family omission exposed by the preceding Release run is repaired and guarded at compile time;
its forbidden skip remains retained as a failure.
I26 records integrated Debug/Release, native mixed-DPI and resource acceptance, with explicit
assistive-technology qualification limits.

Original conflict diagnostics and accepted/cached records carry a `conflictPrompt` observation.
Within the producing FileOperationState lifetime, the containing task ID plus prompt generation
identifies the same problem/choice; the observation
also preserves conflict class and optional selected-root index. Pending problems have no accepted
decision. Original-problem/choice projections use this explicit key, never log order or paths.
This key does not establish a later mutation result. JSONL and TSV extend additively.

Combining records from different owners or application runs requires separate provenance; numeric
task/prompt values alone cannot associate those historical records.

The Issues projection groups observations only by owner-local task and nonzero prompt generation.
Same-path conflicts with different generations remain separate. Legacy records are deduplicated only
as complete diagnostic records, never associated with a choice by text or path. An accepted observation
may arrive before its original problem; the original warning/error supplies the problem when retained.
Mismatched identity is rejected; contradictory accepted observations remain unknown. No result follows
from this join. Pane-local stable row IDs survive append, sorting and decision arrival, and are never
recycled after eviction. Projection storage is bounded by the retained input; unchanged sorted rows
must not notify/rebuild the grid. The implemented primary columns and typed later-result
association are specified below and above respectively; I26 records their integrated
configuration, interaction and resource qualification.

The Issues adapter must process its own size/DPI layout even when the shared host consumes those
messages. Retained ScrollPanel children use host coordinates; only scroll offset is applied by the
panel. Fixed actions must lie inside the actual resized client bounds, proven by real harness pixels.
The Issues pane native caption identifies file-operation issues, including pending conflicts and
resolved decisions as well as failures; it MUST NOT imply that every row failed. Applying a new
language to an existing Issues pane MUST refresh its native caption, primary and
technical column titles, localized row labels, hidden-sort explanation, detail labels, action captions,
copy feedback, empty state and accessible detail name together. Original recorded diagnostic messages,
provider names and paths remain their original facts. Relocalization retains the grid/model, stable
selection, semantic sort, disclosure, valid scroll positions and column order/width preferences;
translated detail is remeasured and scroll offsets clamp only when the content extent requires it.
Repeated theme notifications with unchanged rows MUST NOT publish a new row projection.
On destruction, application view state is saved before the retained host tree is detached. The factory
owns adapter state throughout CreateWindowEx, including failed WM_CREATE; successful creation transfers
ownership to the window. Close and creation failure release both the adapter and shared host exactly once.

The implemented selected detail uses wrapped problem, operation, accepted choice/origin/scope and explicit
unknown result, then Source above Destination. Its independent scroll body supports arrows, Page Up/Down,
Home/End and complete Unicode copy; fixed measured Show/Hide Technical and Copy actions remain reachable.
Tab order is grid, detail body, technical toggle, copy, with reverse traversal and stable row selection.
Choice text uses the normal readable foreground on the detail background, with strong type and labels;
severity colors are not used to imply successful execution. Expensive test-only text measurements are
explicitly requested by layout fixtures, not part of ordinary production or churn snapshots.

Provider-qualified source/destination names and parent folders are retained as authority-free strings
on the bounded `ConflictPromptObservation`. The producer copies the already-resolved prompt display
facts under the arbiter lock; it does not retain the inspection capability or parse provider paths
again. The original warning and accepted/cached observations retain their own item's display facts.
Missing qualification leaves empty pairs and requires an exact-path fallback. JSONL and TSV extend
the existing prompt object additively; this display observation does not establish result identity.

Selected detail places the qualified common filename once in prominent type above the problem.
Differing qualified names occupy separate labelled source/destination lines. The comparison shows
parent folders only for complete name/parent pairs; partial or absent pairs preserve the exact path
fallback without guessing provider syntax. Copy preserves complete source/destination paths even
when visual comparison omits repeated leaf names. Retained child order matches visual reading order.
The filename wraps under measured Subtitle typography and remains part of the independent scroll body.

The I26 primary Issues projection uses file, problem, operation, accepted decision and result columns;
below 680 DIP of content width, operation remains available in selected detail. The technical
disclosure opts into the previous diagnostic columns as well as the technical detail. It starts
collapsed each pane session, including when reopening old technical-only saved layouts.
Primary and technical columns use independent stable IDs in the existing saved layout collection.
Hidden columns retain preferred widths/order; fitting primary widths to a smaller viewport does not
overwrite those preferences. Sort identity remains semantic across presentations; a hidden sorted
column is named above the grid. Selection and full copied model values survive presentation changes.
Migration validation MUST seed a technical-only layout before first creation, including nondefault
widths/order and a hidden sort. Showing the technical columns and recreating the pane must preserve
those values while appending the new summary defaults; an empty-settings round trip is insufficient.
The minimum client height reserves the sort explanation, header and at least one complete primary
summary row before splitting the remaining space with independently scrollable selected detail.
The proportional split must not clip the last summary line; both footer actions remain fixed and reachable.
This implementation passes functional Debug tests. Complete-line summary rendering is implemented
in the explicitly adopted DxUi revision, including its separately qualified Grid overflow correction.
Current consumer visual, interaction and resource acceptance remains required independently.
