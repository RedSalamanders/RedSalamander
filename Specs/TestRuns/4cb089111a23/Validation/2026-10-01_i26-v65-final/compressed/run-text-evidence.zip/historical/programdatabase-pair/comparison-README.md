# Integrated presentation A78/B19 comparison

Generated 2026-10-01T11:53:47.4447333+00:00. Case: `FileOps_IntegratedPresentationPerf`. This is descriptive only: per-process observations do not establish causality or performance acceptance.

Verdict: **descriptive-needs-product-source-review**. All eight ordered runs passed one exact FileOps case with clean disk audit, the exact approved V46 fixture SHA, matching resource-helper SHA, native DPI, settled popup/Issues/scan client pixels, logical target extent/bytes and both semantic workload FNV digests. Each frozen manifest and pin was checked against the run-bound receipt/qualification and source root. The product-source delta list has 69 non-pin rows; review these for feature equivalence before interpreting deltas. Source HEADs and projects are recorded, not silently normalized.

| Run | Variant | runner/app ID | Receipt | Candidate manifest SHA | DPI | FNV64 |
|---|---|---|---|---|---:|---:|
| A78-1 | A | 20261001T114343Z-96048-00fb56c8a6cb4b6dbb527f384e2f326a/2026-10-01_114408 | b9781f0dffb2 | ca58d25c0582 | 144 | 11213680259031909754 |
| B19-1 | B | 20261001T114702Z-52468-6204df90d1fc41f79d6f09ec07bfbe05/2026-10-01_114727 | 9b6be68716db | 3222ff1f2e90 | 144 | 11213680259031909754 |
| B19-2 | B | 20261001T114751Z-52468-60ffe609ea4e4678af113020ed3743d3/2026-10-01_114814 | 9b6be68716db | 3222ff1f2e90 | 144 | 11213680259031909754 |
| A78-2 | A | 20261001T114838Z-52468-6ca25498727046e8813666e01fc4bc6a/2026-10-01_114859 | b9781f0dffb2 | ca58d25c0582 | 144 | 11213680259031909754 |
| B19-3 | B | 20261001T114922Z-52468-0f3e05ce30c040c89f9afbaada3dfabc/2026-10-01_114945 | 9b6be68716db | 3222ff1f2e90 | 144 | 11213680259031909754 |
| A78-3 | A | 20261001T115007Z-52468-09c74085d7434edc8a5ae0e475af9c5c/2026-10-01_115027 | b9781f0dffb2 | ca58d25c0582 | 144 | 11213680259031909754 |
| A78-4 | A | 20261001T115059Z-52468-f81e1c857e014ebf99e3ab839806296a/2026-10-01_115121 | b9781f0dffb2 | ca58d25c0582 | 144 | 11213680259031909754 |
| B19-4 | B | 20261001T115144Z-52468-40b5e737c820455da981dc6af4f5043b/2026-10-01_115211 | 9b6be68716db | 3222ff1f2e90 | 144 | 11213680259031909754 |

| Run | Metric | N | Median us | P95 us | Min us | Max us |
|---|---|---:|---:|---:|---:|---:|
| A78-1 | GraphOpenRedraw8Us | 5 | 66605 | 67038 | 66463 | 67038 |
| A78-1 | GraphCollapsedRedraw8Us | 5 | 66687 | 66710 | 59161 | 66710 |
| A78-1 | ChurnUpdate8Us | 32 | 66678.5 | 73114 | 58514 | 74788 |
| A78-1 | IssuesDetailRedraw8Us | 5 | 66375 | 66871 | 61151 | 66871 |
| A78-1 | ScanStatusCleanRedraw8Us/compare | 5 | 66852 | 108176 | 66250 | 108176 |
| A78-1 | ScanStatusCleanRedraw8Us/change-case | 5 | 175077 | 400004 | 41224 | 400004 |
| A78-1 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66674 | 184387 | 40385 | 184387 |
| A78-1 | ScanStatusCleanRedraw8Us/file-list | 5 | 77029 | 134480 | 56980 | 134480 |
| A78-1 | ScanStatusChangingRedraw8Us/compare | 5 | 66831 | 192608 | 41459 | 192608 |
| A78-1 | ScanStatusChangingRedraw8Us/change-case | 5 | 150028 | 263087 | 38356 | 263087 |
| A78-1 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 68512 | 514682 | 66649 | 514682 |
| A78-1 | ScanStatusChangingRedraw8Us/file-list | 5 | 66590 | 67175 | 45838 | 67175 |
| B19-1 | GraphOpenRedraw8Us | 5 | 66682 | 66733 | 66383 | 66733 |
| B19-1 | GraphCollapsedRedraw8Us | 5 | 66673 | 67924 | 63628 | 67924 |
| B19-1 | ChurnUpdate8Us | 32 | 66656.5 | 68648 | 50582 | 82765 |
| B19-1 | IssuesDetailRedraw8Us | 5 | 66580 | 66864 | 64858 | 66864 |
| B19-1 | ScanStatusCleanRedraw8Us/compare | 5 | 66572 | 66680 | 66010 | 66680 |
| B19-1 | ScanStatusCleanRedraw8Us/change-case | 5 | 66657 | 66975 | 66287 | 66975 |
| B19-1 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66586 | 66785 | 66014 | 66785 |
| B19-1 | ScanStatusCleanRedraw8Us/file-list | 5 | 66493 | 67059 | 66282 | 67059 |
| B19-1 | ScanStatusChangingRedraw8Us/compare | 5 | 66633 | 66816 | 66493 | 66816 |
| B19-1 | ScanStatusChangingRedraw8Us/change-case | 5 | 66691 | 66846 | 66448 | 66846 |
| B19-1 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66619 | 66775 | 66596 | 66775 |
| B19-1 | ScanStatusChangingRedraw8Us/file-list | 5 | 66646 | 66749 | 66618 | 66749 |
| B19-2 | GraphOpenRedraw8Us | 5 | 66652 | 66715 | 66398 | 66715 |
| B19-2 | GraphCollapsedRedraw8Us | 5 | 66628 | 66810 | 59898 | 66810 |
| B19-2 | ChurnUpdate8Us | 32 | 66668 | 66778 | 59060 | 78529 |
| B19-2 | IssuesDetailRedraw8Us | 5 | 66618 | 66856 | 64843 | 66856 |
| B19-2 | ScanStatusCleanRedraw8Us/compare | 5 | 66635 | 67806 | 65949 | 67806 |
| B19-2 | ScanStatusCleanRedraw8Us/change-case | 5 | 66547 | 66793 | 66226 | 66793 |
| B19-2 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66489 | 66814 | 42485 | 66814 |
| B19-2 | ScanStatusCleanRedraw8Us/file-list | 5 | 66546 | 66850 | 65383 | 66850 |
| B19-2 | ScanStatusChangingRedraw8Us/compare | 5 | 66650 | 67313 | 65570 | 67313 |
| B19-2 | ScanStatusChangingRedraw8Us/change-case | 5 | 66661 | 66729 | 66608 | 66729 |
| B19-2 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66659 | 68897 | 64412 | 68897 |
| B19-2 | ScanStatusChangingRedraw8Us/file-list | 5 | 66662 | 67556 | 65729 | 67556 |
| A78-2 | GraphOpenRedraw8Us | 5 | 66540 | 66682 | 65687 | 66682 |
| A78-2 | GraphCollapsedRedraw8Us | 5 | 66715 | 66824 | 63002 | 66824 |
| A78-2 | ChurnUpdate8Us | 32 | 66669.5 | 66852 | 63094 | 66890 |
| A78-2 | IssuesDetailRedraw8Us | 5 | 66635 | 72817 | 59827 | 72817 |
| A78-2 | ScanStatusCleanRedraw8Us/compare | 5 | 66602 | 66706 | 65482 | 66706 |
| A78-2 | ScanStatusCleanRedraw8Us/change-case | 5 | 66670 | 66861 | 61275 | 66861 |
| A78-2 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66629 | 66746 | 64540 | 66746 |
| A78-2 | ScanStatusCleanRedraw8Us/file-list | 5 | 66550 | 81980 | 48440 | 81980 |
| A78-2 | ScanStatusChangingRedraw8Us/compare | 5 | 66658 | 66775 | 66501 | 66775 |
| A78-2 | ScanStatusChangingRedraw8Us/change-case | 5 | 66666 | 66987 | 66376 | 66987 |
| A78-2 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66742 | 67765 | 66514 | 67765 |
| A78-2 | ScanStatusChangingRedraw8Us/file-list | 5 | 66698 | 74300 | 66649 | 74300 |
| B19-3 | GraphOpenRedraw8Us | 5 | 66615 | 78164 | 55015 | 78164 |
| B19-3 | GraphCollapsedRedraw8Us | 5 | 66694 | 70938 | 63619 | 70938 |
| B19-3 | ChurnUpdate8Us | 32 | 66672.5 | 69888 | 59512 | 71072 |
| B19-3 | IssuesDetailRedraw8Us | 5 | 66767 | 68964 | 64006 | 68964 |
| B19-3 | ScanStatusCleanRedraw8Us/compare | 5 | 66606 | 66775 | 65503 | 66775 |
| B19-3 | ScanStatusCleanRedraw8Us/change-case | 5 | 66529 | 67034 | 66124 | 67034 |
| B19-3 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66447 | 66751 | 64842 | 66751 |
| B19-3 | ScanStatusCleanRedraw8Us/file-list | 5 | 66611 | 66670 | 66112 | 66670 |
| B19-3 | ScanStatusChangingRedraw8Us/compare | 5 | 66710 | 76146 | 66599 | 76146 |
| B19-3 | ScanStatusChangingRedraw8Us/change-case | 5 | 66776 | 73544 | 59681 | 73544 |
| B19-3 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66688 | 66853 | 66471 | 66853 |
| B19-3 | ScanStatusChangingRedraw8Us/file-list | 5 | 66702 | 71715 | 61690 | 71715 |
| A78-3 | GraphOpenRedraw8Us | 5 | 66601 | 80216 | 52781 | 80216 |
| A78-3 | GraphCollapsedRedraw8Us | 5 | 66627 | 79780 | 53534 | 79780 |
| A78-3 | ChurnUpdate8Us | 32 | 66675 | 66755 | 63897 | 67318 |
| A78-3 | IssuesDetailRedraw8Us | 5 | 66566 | 66863 | 66440 | 66863 |
| A78-3 | ScanStatusCleanRedraw8Us/compare | 5 | 66632 | 67003 | 63715 | 67003 |
| A78-3 | ScanStatusCleanRedraw8Us/change-case | 5 | 66710 | 66949 | 66176 | 66949 |
| A78-3 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66641 | 88924 | 66274 | 88924 |
| A78-3 | ScanStatusCleanRedraw8Us/file-list | 5 | 66605 | 66675 | 66434 | 66675 |
| A78-3 | ScanStatusChangingRedraw8Us/compare | 5 | 66663 | 66856 | 66546 | 66856 |
| A78-3 | ScanStatusChangingRedraw8Us/change-case | 5 | 66653 | 66712 | 66614 | 66712 |
| A78-3 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66625 | 68171 | 44740 | 68171 |
| A78-3 | ScanStatusChangingRedraw8Us/file-list | 5 | 66679 | 67204 | 66026 | 67204 |
| A78-4 | GraphOpenRedraw8Us | 5 | 66704 | 87489 | 65900 | 87489 |
| A78-4 | GraphCollapsedRedraw8Us | 5 | 66641 | 66686 | 58776 | 66686 |
| A78-4 | ChurnUpdate8Us | 32 | 66654 | 72599 | 59724 | 73543 |
| A78-4 | IssuesDetailRedraw8Us | 5 | 66591 | 66737 | 64632 | 66737 |
| A78-4 | ScanStatusCleanRedraw8Us/compare | 5 | 66597 | 66898 | 66394 | 66898 |
| A78-4 | ScanStatusCleanRedraw8Us/change-case | 5 | 66575 | 66968 | 66305 | 66968 |
| A78-4 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66696 | 66783 | 66366 | 66783 |
| A78-4 | ScanStatusCleanRedraw8Us/file-list | 5 | 66621 | 67040 | 66369 | 67040 |
| A78-4 | ScanStatusChangingRedraw8Us/compare | 5 | 66648 | 66728 | 66576 | 66728 |
| A78-4 | ScanStatusChangingRedraw8Us/change-case | 5 | 66684 | 66694 | 66625 | 66694 |
| A78-4 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66704 | 66749 | 66542 | 66749 |
| A78-4 | ScanStatusChangingRedraw8Us/file-list | 5 | 66646 | 66736 | 66589 | 66736 |
| B19-4 | GraphOpenRedraw8Us | 5 | 66657 | 76637 | 55368 | 76637 |
| B19-4 | GraphCollapsedRedraw8Us | 5 | 66701 | 75027 | 58219 | 75027 |
| B19-4 | ChurnUpdate8Us | 32 | 66668 | 73828 | 57354 | 75981 |
| B19-4 | IssuesDetailRedraw8Us | 5 | 66621 | 79155 | 54078 | 79155 |
| B19-4 | ScanStatusCleanRedraw8Us/compare | 5 | 66640 | 66783 | 66178 | 66783 |
| B19-4 | ScanStatusCleanRedraw8Us/change-case | 5 | 66660 | 66748 | 66390 | 66748 |
| B19-4 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66716 | 68145 | 66336 | 68145 |
| B19-4 | ScanStatusCleanRedraw8Us/file-list | 5 | 66466 | 80397 | 53152 | 80397 |
| B19-4 | ScanStatusChangingRedraw8Us/compare | 5 | 66669 | 66761 | 66530 | 66761 |
| B19-4 | ScanStatusChangingRedraw8Us/change-case | 5 | 66635 | 68000 | 65382 | 68000 |
| B19-4 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66636 | 68195 | 65177 | 68195 |
| B19-4 | ScanStatusChangingRedraw8Us/file-list | 5 | 66658 | 66916 | 66412 | 66916 |

See `cross-pair-latency.csv` for every one of the 16 A×B process pairs, including five clean and five changing 8-redraw samples for each of four scan kinds. `scan-cpu-per-process.csv` and `scan-cpu-cross-pair.csv` subtract the before sample of each scan kind for after/closed UI-thread and process CPU. `resource-cross-pair.csv` and `surface-cross-pair.csv` include every scan phase; `surface-phase-rows.csv` / `resource-phase-rows.csv` preserve raw values. Resource `fromCold` values subtract only within the same process; CPU raw values are cumulative. `source-delta.csv` distinguishes run-manifest coverage from SHA-verified archived source bytes. Missing counterparts remain unverified and require manual equal-feature review; their absence from an original checkout is not inferred. Five-sample p95 is a descriptive maximum, not a quality-gated tail claim. Synchronous redraw is not FPS. Memory is point-in-time private bytes/working set; handles/hosts and GDI/USER/attachments are counts. No value here is a driver GPU allocation or transient peak measurement; `SurfaceCounters` is E_NOTIMPL. This packet does not close the separate FileOps resource-lifetime, idle-wakeup, presentation or full-suite gates.
