# Integrated presentation A78/B19 comparison

Generated 2026-10-01T13:51:02.1310194+00:00. Case: `FileOps_IntegratedPresentationPerf`. This is descriptive only: per-process observations do not establish causality or performance acceptance.

Verdict: **descriptive-needs-product-source-review**. All eight ordered runs passed one exact FileOps case with clean disk audit, the exact approved V46 fixture SHA, matching resource-helper SHA, native DPI, settled popup/Issues/scan client pixels, logical target extent/bytes and both semantic workload FNV digests. Each frozen manifest and pin was checked against the run-bound receipt/qualification and source root. The product-source delta list has 69 non-pin rows; review these for feature equivalence before interpreting deltas. Source HEADs and projects are recorded, not silently normalized.

| Run | Variant | runner/app ID | Receipt | Candidate manifest SHA | DPI | FNV64 |
|---|---|---|---|---|---:|---:|
| A78-1 | A | 20261001T134339Z-99728-7996af16afbb40aa989fdf8fc3b00db7/2026-10-01_134403 | 9e7ae9c5b52d | ca58d25c0582 | 144 | 11213680259031909754 |
| B19-1 | B | 20261001T134424Z-99728-2992ef3411c94348a86259781bbfc870/2026-10-01_134447 | 7442adedcaf1 | 3222ff1f2e90 | 144 | 11213680259031909754 |
| B19-2 | B | 20261001T134509Z-99728-f926bdd514624d98b210ecae386842de/2026-10-01_134533 | 7442adedcaf1 | 3222ff1f2e90 | 144 | 11213680259031909754 |
| A78-2 | A | 20261001T134608Z-99728-7ec55133ee7540118d5de8f30a55b962/2026-10-01_134632 | 9e7ae9c5b52d | ca58d25c0582 | 144 | 11213680259031909754 |
| B19-3 | B | 20261001T134654Z-99728-f6ac26a530c94a3cab517a9bdf5b677a/2026-10-01_134724 | 7442adedcaf1 | 3222ff1f2e90 | 144 | 11213680259031909754 |
| A78-3 | A | 20261001T134747Z-99728-e2c763fc282a4a5ea5bfcc122b2f7d11/2026-10-01_134811 | 9e7ae9c5b52d | ca58d25c0582 | 144 | 11213680259031909754 |
| A78-4 | A | 20261001T134832Z-99728-6d9d3657964e40a2b2de091cf4619057/2026-10-01_134855 | 9e7ae9c5b52d | ca58d25c0582 | 144 | 11213680259031909754 |
| B19-4 | B | 20261001T134917Z-99728-3fbfe96e5c734a18b1c6aa3f96d33fed/2026-10-01_134942 | 7442adedcaf1 | 3222ff1f2e90 | 144 | 11213680259031909754 |

| Run | Metric | N | Median us | P95 us | Min us | Max us |
|---|---|---:|---:|---:|---:|---:|
| A78-1 | GraphOpenRedraw8Us | 5 | 66636 | 66713 | 66503 | 66713 |
| A78-1 | GraphCollapsedRedraw8Us | 5 | 66610 | 66742 | 58249 | 66742 |
| A78-1 | ChurnUpdate8Us | 32 | 66666.5 | 68047 | 51366 | 68918 |
| A78-1 | IssuesDetailRedraw8Us | 5 | 66668 | 66678 | 66464 | 66678 |
| A78-1 | ScanStatusCleanRedraw8Us/compare | 5 | 66653 | 67022 | 66291 | 67022 |
| A78-1 | ScanStatusCleanRedraw8Us/change-case | 5 | 66660 | 76935 | 56207 | 76935 |
| A78-1 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66629 | 66818 | 66533 | 66818 |
| A78-1 | ScanStatusCleanRedraw8Us/file-list | 5 | 66676 | 66786 | 66494 | 66786 |
| A78-1 | ScanStatusChangingRedraw8Us/compare | 5 | 66676 | 66756 | 66578 | 66756 |
| A78-1 | ScanStatusChangingRedraw8Us/change-case | 5 | 66688 | 66860 | 66641 | 66860 |
| A78-1 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66672 | 72145 | 61196 | 72145 |
| A78-1 | ScanStatusChangingRedraw8Us/file-list | 5 | 66647 | 69741 | 63645 | 69741 |
| B19-1 | GraphOpenRedraw8Us | 5 | 66642 | 67347 | 65697 | 67347 |
| B19-1 | GraphCollapsedRedraw8Us | 5 | 66678 | 66796 | 59875 | 66796 |
| B19-1 | ChurnUpdate8Us | 32 | 66662 | 71135 | 59150 | 74199 |
| B19-1 | IssuesDetailRedraw8Us | 5 | 66649 | 69667 | 63312 | 69667 |
| B19-1 | ScanStatusCleanRedraw8Us/compare | 5 | 66641 | 66693 | 66224 | 66693 |
| B19-1 | ScanStatusCleanRedraw8Us/change-case | 5 | 66660 | 73784 | 66210 | 73784 |
| B19-1 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66709 | 74707 | 58541 | 74707 |
| B19-1 | ScanStatusCleanRedraw8Us/file-list | 5 | 66645 | 66700 | 66420 | 66700 |
| B19-1 | ScanStatusChangingRedraw8Us/compare | 5 | 66662 | 66766 | 66609 | 66766 |
| B19-1 | ScanStatusChangingRedraw8Us/change-case | 5 | 66669 | 66730 | 59632 | 66730 |
| B19-1 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66644 | 66687 | 62174 | 66687 |
| B19-1 | ScanStatusChangingRedraw8Us/file-list | 5 | 66675 | 66709 | 66634 | 66709 |
| B19-2 | GraphOpenRedraw8Us | 5 | 66614 | 66873 | 66222 | 66873 |
| B19-2 | GraphCollapsedRedraw8Us | 5 | 66634 | 66762 | 59471 | 66762 |
| B19-2 | ChurnUpdate8Us | 32 | 66652.5 | 76393 | 53635 | 79711 |
| B19-2 | IssuesDetailRedraw8Us | 5 | 66619 | 66751 | 66444 | 66751 |
| B19-2 | ScanStatusCleanRedraw8Us/compare | 5 | 66674 | 66924 | 66202 | 66924 |
| B19-2 | ScanStatusCleanRedraw8Us/change-case | 5 | 66664 | 66783 | 65205 | 66783 |
| B19-2 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66644 | 66679 | 66466 | 66679 |
| B19-2 | ScanStatusCleanRedraw8Us/file-list | 5 | 66653 | 66688 | 66416 | 66688 |
| B19-2 | ScanStatusChangingRedraw8Us/compare | 5 | 66594 | 66925 | 66432 | 66925 |
| B19-2 | ScanStatusChangingRedraw8Us/change-case | 5 | 66673 | 66782 | 66557 | 66782 |
| B19-2 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66685 | 66752 | 66601 | 66752 |
| B19-2 | ScanStatusChangingRedraw8Us/file-list | 5 | 66658 | 68748 | 64590 | 68748 |
| A78-2 | GraphOpenRedraw8Us | 5 | 66666 | 68434 | 64892 | 68434 |
| A78-2 | GraphCollapsedRedraw8Us | 5 | 66648 | 66690 | 63523 | 66690 |
| A78-2 | ChurnUpdate8Us | 32 | 66668 | 67276 | 59675 | 69250 |
| A78-2 | IssuesDetailRedraw8Us | 5 | 66654 | 66770 | 66439 | 66770 |
| A78-2 | ScanStatusCleanRedraw8Us/compare | 5 | 66605 | 66758 | 66419 | 66758 |
| A78-2 | ScanStatusCleanRedraw8Us/change-case | 5 | 66642 | 66692 | 66527 | 66692 |
| A78-2 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66626 | 66687 | 66228 | 66687 |
| A78-2 | ScanStatusCleanRedraw8Us/file-list | 5 | 66639 | 66741 | 66523 | 66741 |
| A78-2 | ScanStatusChangingRedraw8Us/compare | 5 | 66679 | 66852 | 66494 | 66852 |
| A78-2 | ScanStatusChangingRedraw8Us/change-case | 5 | 66664 | 66704 | 66634 | 66704 |
| A78-2 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66671 | 66756 | 66589 | 66756 |
| A78-2 | ScanStatusChangingRedraw8Us/file-list | 5 | 66648 | 66756 | 66629 | 66756 |
| B19-3 | GraphOpenRedraw8Us | 5 | 66631 | 84325 | 48990 | 84325 |
| B19-3 | GraphCollapsedRedraw8Us | 5 | 66643 | 66729 | 59558 | 66729 |
| B19-3 | ChurnUpdate8Us | 32 | 66670.5 | 69767 | 52343 | 75371 |
| B19-3 | IssuesDetailRedraw8Us | 5 | 66670 | 66700 | 66378 | 66700 |
| B19-3 | ScanStatusCleanRedraw8Us/compare | 5 | 66683 | 72734 | 60538 | 72734 |
| B19-3 | ScanStatusCleanRedraw8Us/change-case | 5 | 66668 | 66751 | 66397 | 66751 |
| B19-3 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66699 | 67667 | 65406 | 67667 |
| B19-3 | ScanStatusCleanRedraw8Us/file-list | 5 | 66665 | 66693 | 65673 | 66693 |
| B19-3 | ScanStatusChangingRedraw8Us/compare | 5 | 66673 | 66917 | 66393 | 66917 |
| B19-3 | ScanStatusChangingRedraw8Us/change-case | 5 | 66646 | 66893 | 66441 | 66893 |
| B19-3 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66670 | 66678 | 66591 | 66678 |
| B19-3 | ScanStatusChangingRedraw8Us/file-list | 5 | 66702 | 66727 | 66581 | 66727 |
| A78-3 | GraphOpenRedraw8Us | 5 | 66621 | 66763 | 66196 | 66763 |
| A78-3 | GraphCollapsedRedraw8Us | 5 | 66615 | 66671 | 62991 | 66671 |
| A78-3 | ChurnUpdate8Us | 32 | 66678 | 78948 | 45272 | 88131 |
| A78-3 | IssuesDetailRedraw8Us | 5 | 66650 | 66680 | 65163 | 66680 |
| A78-3 | ScanStatusCleanRedraw8Us/compare | 5 | 66663 | 66717 | 66612 | 66717 |
| A78-3 | ScanStatusCleanRedraw8Us/change-case | 5 | 66654 | 66735 | 66459 | 66735 |
| A78-3 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66458 | 72434 | 61489 | 72434 |
| A78-3 | ScanStatusCleanRedraw8Us/file-list | 5 | 66647 | 66679 | 66578 | 66679 |
| A78-3 | ScanStatusChangingRedraw8Us/compare | 5 | 66667 | 69477 | 63853 | 69477 |
| A78-3 | ScanStatusChangingRedraw8Us/change-case | 5 | 66688 | 66703 | 66613 | 66703 |
| A78-3 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66667 | 66699 | 66286 | 66699 |
| A78-3 | ScanStatusChangingRedraw8Us/file-list | 5 | 66674 | 66710 | 66643 | 66710 |
| A78-4 | GraphOpenRedraw8Us | 5 | 66636 | 66739 | 66430 | 66739 |
| A78-4 | GraphCollapsedRedraw8Us | 5 | 66641 | 66723 | 59215 | 66723 |
| A78-4 | ChurnUpdate8Us | 32 | 66654 | 72908 | 58748 | 74637 |
| A78-4 | IssuesDetailRedraw8Us | 5 | 66662 | 76372 | 66260 | 76372 |
| A78-4 | ScanStatusCleanRedraw8Us/compare | 5 | 66660 | 83977 | 49308 | 83977 |
| A78-4 | ScanStatusCleanRedraw8Us/change-case | 5 | 66624 | 67465 | 65821 | 67465 |
| A78-4 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66701 | 66739 | 66556 | 66739 |
| A78-4 | ScanStatusCleanRedraw8Us/file-list | 5 | 66635 | 66721 | 53787 | 66721 |
| A78-4 | ScanStatusChangingRedraw8Us/compare | 5 | 66674 | 66708 | 66604 | 66708 |
| A78-4 | ScanStatusChangingRedraw8Us/change-case | 5 | 66673 | 66853 | 66528 | 66853 |
| A78-4 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66722 | 83427 | 49814 | 83427 |
| A78-4 | ScanStatusChangingRedraw8Us/file-list | 5 | 66624 | 66873 | 66544 | 66873 |
| B19-4 | GraphOpenRedraw8Us | 5 | 66648 | 66743 | 66409 | 66743 |
| B19-4 | GraphCollapsedRedraw8Us | 5 | 66659 | 66673 | 59546 | 66673 |
| B19-4 | ChurnUpdate8Us | 32 | 66656.5 | 76586 | 43645 | 89736 |
| B19-4 | IssuesDetailRedraw8Us | 5 | 66639 | 66690 | 66471 | 66690 |
| B19-4 | ScanStatusCleanRedraw8Us/compare | 5 | 66645 | 80689 | 52671 | 80689 |
| B19-4 | ScanStatusCleanRedraw8Us/change-case | 5 | 66677 | 67465 | 63696 | 67465 |
| B19-4 | ScanStatusCleanRedraw8Us/change-attributes | 5 | 66649 | 66881 | 65413 | 66881 |
| B19-4 | ScanStatusCleanRedraw8Us/file-list | 5 | 66643 | 66698 | 66267 | 66698 |
| B19-4 | ScanStatusChangingRedraw8Us/compare | 5 | 66688 | 66743 | 66608 | 66743 |
| B19-4 | ScanStatusChangingRedraw8Us/change-case | 5 | 66696 | 69791 | 63883 | 69791 |
| B19-4 | ScanStatusChangingRedraw8Us/change-attributes | 5 | 66687 | 66719 | 66545 | 66719 |
| B19-4 | ScanStatusChangingRedraw8Us/file-list | 5 | 66676 | 66747 | 66608 | 66747 |

See `cross-pair-latency.csv` for every one of the 16 A×B process pairs, including five clean and five changing 8-redraw samples for each of four scan kinds. `scan-cpu-per-process.csv` and `scan-cpu-cross-pair.csv` subtract the before sample of each scan kind for after/closed UI-thread and process CPU. `resource-cross-pair.csv` and `surface-cross-pair.csv` include every scan phase; `surface-phase-rows.csv` / `resource-phase-rows.csv` preserve raw values. Resource `fromCold` values subtract only within the same process; CPU raw values are cumulative. `source-delta.csv` distinguishes run-manifest coverage from SHA-verified archived source bytes. Missing counterparts remain unverified and require manual equal-feature review; their absence from an original checkout is not inferred. Five-sample p95 is a descriptive maximum, not a quality-gated tail claim. Synchronous redraw is not FPS. Memory is point-in-time private bytes/working set; handles/hosts and GDI/USER/attachments are counts. No value here is a driver GPU allocation or transient peak measurement; `SurfaceCounters` is E_NOTIMPL. This packet does not close the separate FileOps resource-lifetime, idle-wakeup, presentation or full-suite gates.
